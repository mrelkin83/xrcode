import React, { useState } from 'react';
import './LoginForm.css';

const LoginForm = () => {
  const [isFormOpen, setIsFormOpen] = useState(false);

  return (
    <div className="login-wrapper">
      <div className="login-mobile-frame">
        {/* Background gradient & decorative petal/leaf shapes */}
        <div className="login-bg-art">
          <div className="petal petal-1"></div>
          <div className="petal petal-2"></div>
          <div className="petal petal-3"></div>
          <div className="petal petal-4"></div>
          <div className="petal petal-5"></div>
          <div className="petal petal-6"></div>
        </div>

        {/* Bottom container containing the exact curve & text */}
        <div className={`login-content ${isFormOpen ? 'open' : ''}`}>
          <div className="wave-divider">
            <svg
              viewBox="0 0 1000 400"
              preserveAspectRatio="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Back subtle translucent curve layer */}
              <path
                fill="rgba(255, 255, 255, 0.32)"
                d="M 0, 75 C 60, 40 130, 15 220, 15 C 360, 15 480, 110 600, 190 C 740, 275 870, 315 1000, 325 L 1000, 400 L 0, 400 Z"
              />
              {/* Main solid white curve */}
              <path
                fill="#ffffff"
                d="M 0, 110 C 60, 70 120, 45 200, 45 C 330, 45 440, 140 560, 225 C 700, 320 840, 365 1000, 368 L 1000, 400 L 0, 400 Z"
              />
            </svg>
          </div>

          <div className="login-text-area">
            <div className="header-text-container">
              {isFormOpen ? (
                <h1 className="welcome-title fade-in">Sign In</h1>
              ) : (
                <h1 className="welcome-title fade-in">Welcome</h1>
              )}
              <p className="welcome-subtitle">Sign in to your Registered Account.</p>
            </div>

            <div className="divider-row">
              {!isFormOpen ? (
                <button
                  className="divider-arrow-btn fade-in"
                  onClick={() => setIsFormOpen(true)}
                  aria-label="Get Started"
                >
                  <svg width="42" height="16" viewBox="0 0 42 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 8H38M38 8L31 2M38 8L31 14" stroke="#ffaa95" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              ) : (
                <div className="divider-line fade-in"></div>
              )}
            </div>

            {isFormOpen && (
              <div className="form-container fade-in-up">
                <div className="input-group">
                  <label>Email Address</label>
                  <input type="email" placeholder="simonnjege@gmail.com" />
                </div>

                <div className="input-group">
                  <label>Password</label>
                  <div className="password-wrapper">
                    <input type="password" placeholder="•••••••••" />
                    <span className="eye-icon">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                      </svg>
                    </span>
                  </div>
                </div>

                <div className="forgot-password">
                  <a href="#">Forgot Password?</a>
                </div>

                <div className="action-buttons">
                  <button className="btn-signup">SIGN UP</button>
                  <button className="btn-signin">SIGN IN</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
