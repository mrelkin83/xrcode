import React from 'react';
import './LoginForm2.css';
import rightImage from '../assets/image.png';

const LoginForm2 = () => {
  return (
    <div className="login2-wrapper">
      <div className="login2-card">
        {/* Left Form Section */}
        <div className="login2-left">
          <div className="login2-form-container">
            <div className="login2-header">
              <div className="house-icon">🏡</div>
              <h1>Welcome home</h1>
              <p>Please enter your details.</p>
            </div>

            <form className="login2-form">
              <div className="input-box">
                <input type="email" placeholder="Email" />
                <span className="input-icon">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                </span>
              </div>

              <div className="input-box">
                <input type="password" placeholder="Password" />
                <span className="input-icon">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </span>
              </div>

              <div className="form-options">
                <label className="remember-me">
                  <input type="checkbox" />
                  <span className="checkmark"></span>
                  Remember for 30 days
                </label>
                <a href="#" className="forgot-pwd">Forgot password?</a>
              </div>

              <button type="submit" className="login2-btn">Login</button>
            </form>

            <div className="login2-divider">
              <span>or</span>
            </div>

            <div className="social-logins">
              <button className="social-btn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.19 2.31-.88 3.5-.8 1.93.07 3.3.93 4.15 2.38-3.25 1.86-2.73 6.07.45 7.31-.76 1.76-1.89 3.63-3.18 3.28zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.02 4.41-3.74 4.25z"/></svg>
              </button>
              <button className="social-btn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M21.35 11.1h-9.17v2.73h6.51c-.33 3.81-3.5 5.44-6.5 5.44-3.88 0-7.27-2.91-7.27-7.27s3.39-7.27 7.27-7.27c1.76 0 3.34.61 4.54 1.65l2.21-2.21C17.15 2.58 14.81 1.5 12.18 1.5 6.37 1.5 1.5 6.37 1.5 12.18s4.87 10.68 10.68 10.68c5.44 0 10.35-3.81 10.35-10.35 0-.74-.11-1.41-.3-2z"/></svg>
              </button>
              <button className="social-btn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.04c-5.5 0-10 4.49-10 10.02 0 5 3.66 9.15 8.44 9.9v-7h-2.54v-2.9h2.54V9.8c0-2.5 1.49-3.89 3.78-3.89 1.09 0 2.24.19 2.24.19v2.47h-1.26c-1.24 0-1.63.77-1.63 1.56v1.88h2.78l-.45 2.9h-2.33v7A10.05 10.05 0 0 0 22 12.06c0-5.53-4.5-10.02-10-10.02z"/></svg>
              </button>
            </div>
          </div>
        </div>

        {/* Right Image Section */}
        <div className="login2-right">
          <img src={rightImage} alt="Abstract Background" className="login2-bg-image" />
        </div>
      </div>
    </div>
  );
};

export default LoginForm2;
