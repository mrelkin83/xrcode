import React, { useState } from 'react';
import './App.css'
import LoginForm from './components/LoginForm'
import LoginForm2 from './components/LoginForm2'

function App() {
  const [activeForm, setActiveForm] = useState(1);

  return (
    <div className="app-container">
      <div className="form-switcher">
        <button 
          className={activeForm === 1 ? 'active' : ''} 
          onClick={() => setActiveForm(1)}
        >
          Form 1 (Mobile)
        </button>
        <button 
          className={activeForm === 2 ? 'active' : ''} 
          onClick={() => setActiveForm(2)}
        >
          Form 2 (Desktop)
        </button>
      </div>

      {activeForm === 1 ? <LoginForm /> : <LoginForm2 />}
    </div>
  )
}

export default App
