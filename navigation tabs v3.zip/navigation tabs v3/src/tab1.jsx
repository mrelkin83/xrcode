import React, { useState } from 'react';
import { motion, useAnimationControls } from 'framer-motion';
import './tab1.css';

const TABS = [
  {
    id: 'home',
    label: 'Home',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3.5 10.5L12 3.5l8.5 7v10a1 1 0 0 1-1 1h-15a1 1 0 0 1-1-1v-10z" />
      </svg>
    ),
  },
  {
    id: 'search',
    label: 'Search',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="7" />
        <path d="M21 21l-4.35-4.35" />
      </svg>
    ),
  },
  {
    id: 'likes',
    label: 'Likes',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
      </svg>
    ),
  },
  {
    id: 'notifications',
    label: 'Notifications',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
        <path d="M13.73 21a2 2 0 0 1-3.46 0" />
      </svg>
    ),
  },
  {
    id: 'profile',
    label: 'Profile',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="7" r="4.5" />
        <path d="M4.5 20.5c0-4.2 3.3-7 7.5-7s7.5 2.8 7.5 7" />
      </svg>
    ),
  },
];

const Tab1 = () => {
  // Default to index 3 ('Notifications') to match the user's reference image
  const [activeIndex, setActiveIndex] = useState(3);

  // Framer Motion Animation Controls for ball & dip
  const dotControls = useAnimationControls();
  const notchControls = useAnimationControls();

  const triggerJump = async (newIndex) => {
    if (newIndex === activeIndex) return;

    const distance = Math.abs(newIndex - activeIndex);
    const jumpHeight = Math.min(26 + distance * 3.5, 38);
    const flightDuration = Math.min(0.20 + distance * 0.03, 0.32);

    setActiveIndex(newIndex);

    // 1. Notch collapses cleanly as ball takes off
    notchControls.start({
      scaleY: 0,
      opacity: 0,
      transition: { duration: 0.12, ease: 'easeOut' },
    });

    // 2. Ball leaps into the air
    await dotControls.start({
      y: -jumpHeight,
      transition: {
        duration: flightDuration,
        ease: [0.22, 0.61, 0.36, 1],
      },
    });

    // 3. Notch re-opens with elastic dip under the falling ball
    notchControls.start({
      scaleY: [0, 1.25, 0.94, 1],
      opacity: 1,
      transition: { duration: 0.38, ease: 'easeOut' },
    });

    // 4. Ball lands with Framer Motion's bouncy spring physics!
    dotControls.start({
      y: 0,
      transition: {
        type: 'spring',
        stiffness: 420,
        damping: 12,
        mass: 0.8,
        bounce: 0.5,
      },
    });
  };

  const handleKeyDown = (e, index) => {
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      triggerJump((activeIndex + 1) % TABS.length);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      triggerJump((activeIndex - 1 + TABS.length) % TABS.length);
    } else if (e.key === 'Home') {
      e.preventDefault();
      triggerJump(0);
    } else if (e.key === 'End') {
      e.preventDefault();
      triggerJump(TABS.length - 1);
    }
  };

  return (
    <div className="nav-demo-wrapper">
      {/* Main Curved Navigation Bar */}
      <nav
        className="curved-navbar-container"
        role="tablist"
        aria-label="Bottom Navigation"
      >
        {/* Animated Sliding Indicator with Framer Motion Spring */}
        <motion.div
          className="nav-indicator"
          aria-hidden="true"
          initial={false}
          animate={{ x: `${activeIndex * 100}%` }}
          transition={{
            type: 'spring',
            stiffness: 270,
            damping: 26,
            mass: 0.85,
          }}
        >
          {/* Smooth curved cutout SVG dipping into the navbar */}
          <motion.svg
            className="notch-svg"
            viewBox="0 0 70 20"
            preserveAspectRatio="none"
            initial={{ x: '-50%', scaleY: 1, opacity: 1 }}
            animate={notchControls}
            style={{ originY: 0 }}
          >
            <path d="M 0 -2 L 70 -2 L 70 0 C 52 0 50 18 35 18 C 20 18 18 0 0 0 Z" />
          </motion.svg>

          {/* Floating White Dot that leaps and lands with a bouncy spring */}
          <motion.div
            className="indicator-dot"
            initial={{ x: '-50%', y: 0 }}
            animate={dotControls}
          />
        </motion.div>

        {/* Tab Buttons */}
        {TABS.map((tab, index) => {
          const isActive = activeIndex === index;
          return (
            <button
              key={tab.id}
              role="tab"
              id={`tab-${tab.id}`}
              aria-selected={isActive}
              aria-controls={`panel-${tab.id}`}
              tabIndex={isActive ? 0 : -1}
              className={`tab-button ${isActive ? 'active' : ''}`}
              onClick={() => triggerJump(index)}
              onKeyDown={(e) => handleKeyDown(e, index)}
            >
              <motion.span
                className="tab-icon-wrap"
                animate={{
                  scale: isActive ? 1.08 : 1,
                }}
                transition={{
                  type: 'spring',
                  stiffness: 380,
                  damping: 18,
                }}
              >
                {tab.icon}
              </motion.span>
              <span className="tab-title">{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default Tab1;