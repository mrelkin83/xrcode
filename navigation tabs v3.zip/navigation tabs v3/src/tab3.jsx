import React, { useState } from 'react';
import { motion } from 'framer-motion';
import './tab3.css';

// 5 tabs with Cart replacing Notifications
const TABS = [
  {
    id: 'home',
    label: 'Home',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3.5 10.5L12 3.5l8.5 7v10a1 1 0 0 1-1 1h-15a1 1 0 0 1-1-1v-10z" />
      </svg>
    ),
  },
  {
    id: 'search',
    label: 'Search',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="7" />
        <path d="M21 21l-4.35-4.35" />
      </svg>
    ),
  },
  {
    id: 'likes',
    label: 'Likes',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
      </svg>
    ),
  },
  {
    id: 'cart',
    label: 'Cart',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="9" cy="20" r="1.5" />
        <circle cx="18" cy="20" r="1.5" />
        <path d="M1 2h3.5l2.4 12.2a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6L22 6H6" />
      </svg>
    ),
  },
  {
    id: 'profile',
    label: 'Profile',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="7" r="4.5" />
        <path d="M4.5 20.5c0-4.2 3.3-7 7.5-7s7.5 2.8 7.5 7" />
      </svg>
    ),
  },
];

const Tab3 = () => {
  // Default to index 0 ('Home')
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="tab3-demo-wrapper">
      {/* Black Pill Track Navbar (580px x 72px) */}
      <nav
        className="tab3-track-container"
        role="tablist"
        aria-label="Liquid Glass Dark Navigation"
      >
        {TABS.map((tab, index) => {
          const isActive = activeIndex === index;
          return (
            <motion.button
              key={tab.id}
              role="tab"
              id={`tab3-btn-${tab.id}`}
              aria-selected={isActive}
              aria-label={tab.label}
              tabIndex={isActive ? 0 : -1}
              className={`tab3-item-btn ${isActive ? 'active' : ''}`}
              onClick={() => setActiveIndex(index)}
              whileTap={{ scale: 0.94 }}
              transition={{ type: 'spring', stiffness: 500, damping: 25 }}
            >
              {/* Ultra-realistic 3D Refractive Liquid Glass Lens Indicator with Soft, Refined Spring */}
              {isActive && (
                <motion.div
                  layoutId="tab3GlassLens"
                  className="tab3-glass-lens"
                  transition={{
                    type: 'spring',
                    stiffness: 380,
                    damping: 28,
                    mass: 0.8,
                  }}
                />
              )}

              {/* Tab Content: Glowing Icon + Text Label */}
              <div className="tab3-content-wrapper">
                <motion.span
                  className="tab3-icon-wrap"
                  animate={{
                    y: isActive ? -1 : 0,
                    scale: isActive ? 1.06 : 1,
                  }}
                  transition={{
                    type: 'spring',
                    stiffness: 400,
                    damping: 24,
                  }}
                >
                  {tab.icon}
                </motion.span>

                {/* Text Label appears cleanly inside active lens */}
                {isActive && (
                  <motion.span
                    className="tab3-label-text"
                    initial={{ opacity: 0, y: 2, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 1 }}
                    transition={{
                      duration: 0.18,
                      ease: 'easeOut',
                    }}
                  >
                    {tab.label}
                  </motion.span>
                )}
              </div>
            </motion.button>
          );
        })}
      </nav>
    </div>
  );
};

export default Tab3;
