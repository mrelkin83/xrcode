import React from 'react';
import Tab1 from './tab1.jsx';
import Tab2 from './tab2.jsx';
import Tab3 from './tab3.jsx';

function App() {
  return (
    <div className="main-app-container">
      {/* 1st Tab: White Curved Nav with Flying Pearl Dot */}
      <Tab1 />

      {/* 2nd Tab: Glassmorphic Capsule Nav with Glowing Blue Bubble */}
      <Tab2 />

      {/* 3rd Tab: Dark Pill with 3D Liquid Glass Refractive Lens */}
      <Tab3 />
    </div>
  );
}

export default App;
