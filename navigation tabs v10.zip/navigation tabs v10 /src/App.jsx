import Tab1 from './tab1'
import Tab2 from './tab2'
import Tab3 from './tab3'
import './App.css'

function App() {
  return (
    <main className="app-container">
      <Tab1 />
      <Tab2 />
      <Tab3 />
    </main>
  )
}

export default App
