import React, { useState } from 'react';
import { Home, CheckCircle2, MessageCircle, Layers, Search } from 'lucide-react';
import { motion } from 'framer-motion';
import './tab3.css';

const TABS = [
  { id: 'home', label: 'Home', Icon: Home },
  { id: 'tasks', label: 'Tasks', Icon: CheckCircle2 },
  { id: 'chat', label: 'Chat', Icon: MessageCircle },
  { id: 'library', label: 'Library', Icon: Layers },
];

export default function Tab3({ defaultTab = 'tasks', onTabChange, onSearchClick }) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
    if (onTabChange) {
      onTabChange(tabId);
    }
  };

  return (
    <div className="tab3-section">
      <nav className="tab3-nav-wrapper" aria-label="Glassmorphic Navigation">
        {/* Main Glass Capsule */}
        <div className="tab3-glass-capsule" role="tablist">
          {TABS.map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.Icon;

            return (
              <button
                key={tab.id}
                type="button"
                className={`tab3-item-btn ${isActive ? 'active' : ''}`}
                onClick={() => handleTabClick(tab.id)}
                role="tab"
                aria-selected={isActive}
              >
                {/* Active Floating Glass Pill */}
                {isActive && (
                  <motion.div
                    layoutId="tab3-active-glass-pill"
                    className="tab3-active-glass-pill"
                    transition={{
                      type: 'spring',
                      stiffness: 400,
                      damping: 30,
                    }}
                  />
                )}

                <div className="tab3-icon-wrapper">
                  <Icon size={22} strokeWidth={1.9} />
                </div>
                <span className="tab3-item-label">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Separate Glass Circle Search Button */}
        <motion.button
          type="button"
          className="tab3-search-btn"
          aria-label="Search"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onSearchClick}
        >
          <Search size={24} strokeWidth={2.1} className="tab3-search-icon" />
        </motion.button>
      </nav>
    </div>
  );
}

export { Tab3 };
