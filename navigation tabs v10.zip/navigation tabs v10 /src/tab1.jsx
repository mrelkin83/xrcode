import { useState } from 'react';
import { motion } from 'framer-motion';
import './tab1.css';

const TABS = ['Home', 'Cart', 'About', 'Services'];

function getTabStyles(tab, activeTab) {
  const isActive = tab === activeTab;
  const activeIndex = TABS.indexOf(activeTab);
  const tabIndex = TABS.indexOf(tab);

  if (isActive) {
    return {
      bg: '#1380ff',
      topLeft: '15px',
      topRight: '15px',
      bottomRight: '15px',
      bottomLeft: '15px',
      marginRight: tabIndex === TABS.length - 1 ? 28 : 36,
      padding: '0 32px',
    };
  }

  // Inactive tab
  const isLeftGroup = tabIndex < activeIndex;
  const groupStartIndex = isLeftGroup ? 0 : activeIndex + 1;
  const groupEndIndex = isLeftGroup ? activeIndex - 1 : TABS.length - 1;

  const isFirstInGroup = tabIndex === groupStartIndex;
  const isLastInGroup = tabIndex === groupEndIndex;

  let topLeft = '0px';
  let topRight = '0px';
  let bottomRight = '0px';
  let bottomLeft = '0px';

  if (isFirstInGroup && isLastInGroup) {
    topLeft = topRight = bottomRight = bottomLeft = '15px';
  } else if (isFirstInGroup) {
    topLeft = bottomLeft = '15px';
    topRight = bottomRight = '0px';
  } else if (isLastInGroup) {
    topRight = bottomRight = '15px';
    topLeft = bottomLeft = '0px';
  }

  const marginRight = isLastInGroup && tabIndex < TABS.length - 1 ? 36 : 0;

  return {
    bg: '#000000',
    topLeft,
    topRight,
    bottomRight,
    bottomLeft,
    marginRight,
    padding: '0 20px',
  };
}

export default function Tab1({
  tabs = TABS,
  defaultTab = 'Home',
  onTabChange,
}) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const handleTabClick = (clickedTab) => {
    if (clickedTab === activeTab) return;
    if (onTabChange) {
      onTabChange(clickedTab);
    }
    setActiveTab(clickedTab);
  };

  return (
    <nav className="tab1-nav" aria-label="Tabs Navigation">
      <div className="tab1-container">
        {tabs.map((tab) => {
          const styles = getTabStyles(tab, activeTab);
          return (
            <motion.button
              key={tab}
              layout
              type="button"
              className="tab1-pill-btn"
              animate={{
                backgroundColor: styles.bg,
                borderTopLeftRadius: styles.topLeft,
                borderTopRightRadius: styles.topRight,
                borderBottomRightRadius: styles.bottomRight,
                borderBottomLeftRadius: styles.bottomLeft,
                marginRight: `${styles.marginRight}px`,
                padding: styles.padding,
              }}
              transition={{
                layout: { duration: 0.35, ease: [0.16, 1, 0.3, 1] },
                backgroundColor: { duration: 0.25, ease: 'easeOut' },
                borderTopLeftRadius: { duration: 0.22, ease: 'easeOut' },
                borderTopRightRadius: { duration: 0.22, ease: 'easeOut' },
                borderBottomRightRadius: { duration: 0.22, ease: 'easeOut' },
                borderBottomLeftRadius: { duration: 0.22, ease: 'easeOut' },
                marginRight: { duration: 0.35, ease: [0.16, 1, 0.3, 1] },
                padding: { duration: 0.25, ease: 'easeOut' },
              }}
              onClick={() => handleTabClick(tab)}
              role="tab"
              aria-selected={tab === activeTab}
            >
              <span className="tab1-pill-text">{tab}</span>
            </motion.button>
          );
        })}
      </div>
    </nav>
  );
}

export { Tab1 };
