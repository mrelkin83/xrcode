import { useState } from 'react';
import Login from './Login.jsx';

function App() {
  const [currentView, setCurrentView] = useState('login');

  return (
    <div className="app-container">
      {currentView === 'login' ? (
        <Login
          onLoginSuccess={() => setCurrentView('dashboard')}
          onGoToDashboard={() => setCurrentView('dashboard')}
        />
      ) : (
        <div style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'linear-gradient(135deg, #090a0f 0%, #151824 100%)',
          color: '#fff',
          fontFamily: "'Inter', sans-serif",
          padding: '24px',
          textAlign: 'center'
        }}>
          <div style={{
            padding: '36px 44px',
            background: 'rgba(255, 255, 255, 0.05)',
            backdropFilter: 'blur(20px)',
            border: '1px solid rgba(255, 255, 255, 0.15)',
            borderRadius: '24px',
            boxShadow: '0 25px 60px rgba(0,0,0,0.7)',
            maxWidth: '460px',
            width: '100%'
          }}>
            <h1 style={{ fontSize: '28px', marginBottom: '12px', fontWeight: '700' }}>CodeXr Dashboard</h1>
            <p style={{ color: 'rgba(255, 255, 255, 0.75)', fontSize: '14px', lineHeight: '1.6', marginBottom: '28px' }}>
              Welcome back! Authentication successful. Your session is active and secured.
            </p>
            <button
              type="button"
              onClick={() => setCurrentView('login')}
              style={{
                padding: '12px 28px',
                borderRadius: '30px',
                background: 'rgba(255, 255, 255, 0.14)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                color: '#fff',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              ← Back to Login
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
