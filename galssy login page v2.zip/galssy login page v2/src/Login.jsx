import { useState } from 'react';
import './Login.css';
import bgImage from './assets/image.png';

const Login = ({ onLoginSuccess, onGoToDashboard }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState(null);

  // Form states
  const [loginUsername, setLoginUsername] = useState('codexr_admin');
  const [loginPassword, setLoginPassword] = useState('••••••••••••');

  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');

  const triggerToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const toggleMode = (mode) => {
    if (isAnimating) return;
    setIsAnimating(true);
    setIsLogin(mode === 'login');
    setTimeout(() => setIsAnimating(false), 850);
  };

  const handleLogin = (e) => {
    e.preventDefault();
    setLoading(true);
    triggerToast('Authenticating with CodeXr Security Gateway...');
    setTimeout(() => {
      setLoading(false);
      triggerToast('✓ Access Granted! Redirecting to Dashboard...');
      setTimeout(() => {
        if (onLoginSuccess) onLoginSuccess();
      }, 650);
    }, 850);
  };

  const handleSignUp = (e) => {
    e.preventDefault();
    setLoading(true);
    triggerToast('Creating your CodeXr Glass account...');
    setTimeout(() => {
      setLoading(false);
      triggerToast('✓ Account created successfully! Logging in...');
      setTimeout(() => {
        if (onLoginSuccess) onLoginSuccess();
      }, 650);
    }, 950);
  };

  return (
    <div
      className={`login-root ${isLogin ? 'mode-login' : 'mode-signup'}`}
      style={{
        backgroundImage: `radial-gradient(circle at 50% 50%, rgba(10, 12, 16, 0.45) 0%, rgba(5, 6, 8, 0.82) 100%), url(${bgImage})`,
      }}
    >
      {/* Ambient Glass Lights */}
      <div className="login-ambient-light" />

      {/* Floating Top Navigation Header */}
      <header className="login-top-nav">
        <div className="login-brand">
          <div className="login-brand-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" width="18" height="18">
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <span>CodeXr Glass</span>
        </div>

        {onGoToDashboard && (
          <button
            type="button"
            className="login-switch-btn"
            onClick={onGoToDashboard}
          >
            <span>View Dashboard</span>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="15" height="15">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </button>
        )}
      </header>

      {/* Main Glass Auth Card */}
      <main className="auth-card-wrapper">
        <div className={`auth-card ${isLogin ? 'mode-login' : 'mode-signup'}`}>
          {/* Sweeping Diagonal Frosted Glass Panel */}
          <div className="bg-shape-motion" />

          <div className="content-wrapper">
            {/* Form 1: LOGIN PANEL (Left) */}
            <div className={`form-container login-panel ${!isLogin ? 'panel-inactive' : ''}`}>
              <form onSubmit={handleLogin} autoComplete="off">
                <h2 className="form-title">Login</h2>

                {/* Username Input */}
                <div className="input-field-wrap">
                  <svg className="input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                  <input
                    type="text"
                    required
                    placeholder="Username"
                    className="glass-underline-input"
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                  />
                </div>

                {/* Password Input */}
                <div className="input-field-wrap">
                  <svg className="input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M7 11V7a5 5 0 0110 0v4" />
                  </svg>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Password"
                    className="glass-underline-input"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="password-toggle-btn"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label="Toggle password visibility"
                  >
                    {showPassword ? (
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" />
                        <line x1="1" y1="1" x2="23" y2="23" />
                      </svg>
                    ) : (
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                    )}
                  </button>
                </div>

                {/* Submit Pill Button */}
                <button
                  type="submit"
                  className="auth-submit-pill"
                  disabled={loading || isAnimating}
                >
                  {loading ? 'Authenticating...' : 'Login'}
                </button>

                {/* Footer Links */}
                <div className="auth-links">
                  <div>
                    Don't have an account?{' '}
                    <button
                      type="button"
                      className="auth-link-action"
                      onClick={() => toggleMode('signup')}
                      disabled={isAnimating}
                    >
                      Sign Up
                    </button>
                  </div>
                  <button
                    type="button"
                    className="auth-forgot-link"
                    onClick={() => triggerToast('Reset verification link sent to registered email.')}
                  >
                    Forgot Password?
                  </button>
                </div>
              </form>
            </div>

            {/* Form 2: SIGN UP PANEL (Right) */}
            <div className={`form-container signup-panel ${isLogin ? 'panel-inactive' : ''}`}>
              <form onSubmit={handleSignUp} autoComplete="off">
                <h2 className="form-title">Create Account</h2>

                {/* Full Name Input */}
                <div className="input-field-wrap">
                  <svg className="input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                  <input
                    type="text"
                    required
                    placeholder="Full Name"
                    className="glass-underline-input"
                    value={signupName}
                    onChange={(e) => setSignupName(e.target.value)}
                  />
                </div>

                {/* Email Input */}
                <div className="input-field-wrap">
                  <svg className="input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                    <polyline points="22,6 12,13 2,6" />
                  </svg>
                  <input
                    type="email"
                    required
                    placeholder="Work Email"
                    className="glass-underline-input"
                    value={signupEmail}
                    onChange={(e) => setSignupEmail(e.target.value)}
                  />
                </div>

                {/* Password Input */}
                <div className="input-field-wrap">
                  <svg className="input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M7 11V7a5 5 0 0110 0v4" />
                  </svg>
                  <input
                    type="password"
                    required
                    placeholder="Create Password"
                    className="glass-underline-input"
                    value={signupPassword}
                    onChange={(e) => setSignupPassword(e.target.value)}
                  />
                </div>

                {/* Submit Pill Button */}
                <button
                  type="submit"
                  className="auth-submit-pill"
                  disabled={loading || isAnimating}
                >
                  {loading ? 'Creating Account...' : 'Sign Up'}
                </button>

                {/* Footer Links */}
                <div className="auth-links">
                  <div>
                    Already a Member?{' '}
                    <button
                      type="button"
                      className="auth-link-action"
                      onClick={() => toggleMode('login')}
                      disabled={isAnimating}
                    >
                      Login
                    </button>
                  </div>
                </div>
              </form>
            </div>

            {/* Welcome Panel 1: WELCOME LOGIN (Right side during Login mode) */}
            <div className="welcome-container welcome-login">
              <h1 className="welcome-heading">
                HELLO,<br />FRIEND!
              </h1>
              <p className="welcome-desc">
                Enter your personal details<br />and start your journey<br />with us.
              </p>
              <button
                type="button"
                className="banner-toggle-btn"
                onClick={() => toggleMode('signup')}
                disabled={isAnimating}
              >
                Create Account &rarr;
              </button>
            </div>

            {/* Welcome Panel 2: WELCOME SIGNUP (Left side during SignUp mode) */}
            <div className="welcome-container welcome-signup">
              <h1 className="welcome-heading">
                WELCOME<br />BACK!
              </h1>
              <p className="welcome-desc">
                Already a Member? Please Login<br />with your credentials.
              </p>
              <button
                type="button"
                className="banner-toggle-btn"
                onClick={() => toggleMode('login')}
                disabled={isAnimating}
              >
                Sign In &rarr;
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Floating Status Toast */}
      {toast && (
        <div className="auth-status-toast">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" width="16" height="16">
            <polyline points="20 6 9 17 4 12" />
          </svg>
          <span>{toast}</span>
        </div>
      )}
    </div>
  );
};

export default Login;
