import React, { useState } from 'react';
import Dashboard1 from './dashbord1';
import Dashboard2 from './dashbord2';
import Dashboard3 from './dashbord3';

function App() {
  const [currentDashboard, setCurrentDashboard] = useState(3);

  return (
    <div>
      {/* Floating Dashboard Switcher for easy navigation */}
      <div
        style={{
          position: 'fixed',
          top: '16px',
          right: '24px',
          zIndex: 9999,
          background: 'rgba(15, 23, 42, 0.92)',
          backdropFilter: 'blur(8px)',
          padding: '6px',
          borderRadius: '9999px',
          display: 'flex',
          gap: '6px',
          boxShadow: '0 8px 30px rgba(0,0,0,0.25)',
        }}
      >
        <button
          onClick={() => setCurrentDashboard(1)}
          style={{
            border: 'none',
            background: currentDashboard === 1 ? '#5c56e0' : 'transparent',
            color: '#ffffff',
            padding: '6px 14px',
            borderRadius: '9999px',
            cursor: 'pointer',
            fontSize: '12px',
            fontWeight: 700,
            transition: 'all 0.2s',
          }}
        >
          Dashboard 1
        </button>
        <button
          onClick={() => setCurrentDashboard(2)}
          style={{
            border: 'none',
            background: currentDashboard === 2 ? '#74c022' : 'transparent',
            color: '#ffffff',
            padding: '6px 14px',
            borderRadius: '9999px',
            cursor: 'pointer',
            fontSize: '12px',
            fontWeight: 700,
            transition: 'all 0.2s',
          }}
        >
          Dashboard 2
        </button>
        <button
          onClick={() => setCurrentDashboard(3)}
          style={{
            border: 'none',
            background: currentDashboard === 3 ? '#7064f7' : 'transparent',
            color: '#ffffff',
            padding: '6px 14px',
            borderRadius: '9999px',
            cursor: 'pointer',
            fontSize: '12px',
            fontWeight: 700,
            transition: 'all 0.2s',
          }}
        >
          Dashboard 3
        </button>
      </div>

      {/* Render selected dashboard */}
      {currentDashboard === 1 && <Dashboard1 />}
      {currentDashboard === 2 && <Dashboard2 />}
      {currentDashboard === 3 && <Dashboard3 />}
    </div>
  );
}

export default App;
