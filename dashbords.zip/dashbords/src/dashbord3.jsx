import React, { useState } from 'react';
import './dashbord3.css';

export default function Dashboard3() {
  const [activeNav, setActiveNav] = useState('Dashboard');
  const [theme, setTheme] = useState('light');

  return (
    <div className="dash3-app-wrapper">
      <div className="dash3-window-container">
        {/* =================================================================
            LEFT SIDEBAR
            ================================================================= */}
        <aside className="dash3-sidebar">
          {/* Logo Brand Header */}
          <div className="dash3-brand-row">
            <div className="dash3-brand-left">
              {/* FinSet Swirl Logo */}
              <div className="dash3-logo-badge">
                <svg width="34" height="34" viewBox="0 0 36 36" fill="none">
                  <circle cx="18" cy="18" r="18" fill="#111827" />
                  <path d="M12 11h12c0 3-2 5-5 5h-7v10" stroke="#7064f7" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M12 18h8" stroke="#38bdf8" strokeWidth="3" strokeLinecap="round" />
                  <circle cx="18" cy="18" r="2" fill="#ec4899" />
                </svg>
              </div>
              <span className="dash3-brand-text">FinSet</span>
            </div>
            {/* Collapse Icon */}
            <button className="dash3-collapse-btn" aria-label="Collapse Sidebar">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 18 9 12 15 6" />
              </svg>
            </button>
          </div>

          {/* Main Navigation */}
          <nav className="dash3-main-nav">
            {/* Dashboard (Active) */}
            <button
              className={`dash3-nav-item ${activeNav === 'Dashboard' ? 'dash3-nav-active' : ''}`}
              onClick={() => setActiveNav('Dashboard')}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="7" height="7" rx="1.5" />
                <rect x="14" y="3" width="7" height="7" rx="1.5" />
                <rect x="14" y="14" width="7" height="7" rx="1.5" />
                <rect x="3" y="14" width="7" height="7" rx="1.5" />
              </svg>
              <span>Dashboard</span>
            </button>

            {/* Transactions */}
            <button
              className={`dash3-nav-item ${activeNav === 'Transactions' ? 'dash3-nav-active' : ''}`}
              onClick={() => setActiveNav('Transactions')}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="17 1 21 5 17 9" />
                <path d="M3 11V9a4 4 0 0 1 4-4h14" />
                <polyline points="7 23 3 19 7 15" />
                <path d="M21 13v2a4 4 0 0 1-4 4H3" />
              </svg>
              <span>Transactions</span>
            </button>

            {/* Wallet */}
            <button
              className={`dash3-nav-item ${activeNav === 'Wallet' ? 'dash3-nav-active' : ''}`}
              onClick={() => setActiveNav('Wallet')}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4" />
                <path d="M4 6v12c0 1.1.9 2 2 2h14v-4" />
                <path d="M18 12a2 2 0 0 0-2 2c0 1.1.9 2 2 2h4v-4h-4z" />
              </svg>
              <span>Wallet</span>
            </button>

            {/* Goals */}
            <button
              className={`dash3-nav-item ${activeNav === 'Goals' ? 'dash3-nav-active' : ''}`}
              onClick={() => setActiveNav('Goals')}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <circle cx="12" cy="12" r="6" />
                <circle cx="12" cy="12" r="2" />
              </svg>
              <span>Goals</span>
            </button>

            {/* Budget */}
            <button
              className={`dash3-nav-item ${activeNav === 'Budget' ? 'dash3-nav-active' : ''}`}
              onClick={() => setActiveNav('Budget')}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <path d="M12 6v12M15 9.5a2.5 2.5 0 0 0-5 0c0 3 5 2 5 5a2.5 2.5 0 0 1-5 0" />
              </svg>
              <span>Budget</span>
            </button>

            {/* Analytics */}
            <button
              className={`dash3-nav-item ${activeNav === 'Analytics' ? 'dash3-nav-active' : ''}`}
              onClick={() => setActiveNav('Analytics')}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="20" x2="18" y2="10" />
                <line x1="12" y1="20" x2="12" y2="4" />
                <line x1="6" y1="20" x2="6" y2="14" />
                <polyline points="4 8 10 2 14 6 20 0" />
              </svg>
              <span>Analytics</span>
            </button>

            {/* Settings */}
            <button
              className={`dash3-nav-item ${activeNav === 'Settings' ? 'dash3-nav-active' : ''}`}
              onClick={() => setActiveNav('Settings')}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="3" />
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
              </svg>
              <span>Settings</span>
            </button>
          </nav>

          {/* Bottom Nav Items */}
          <div className="dash3-sidebar-bottom">
            <button className="dash3-nav-item">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                <line x1="12" y1="17" x2="12.01" y2="17" />
              </svg>
              <span>Help</span>
            </button>

            <button className="dash3-nav-item">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <polyline points="16 17 21 12 16 7" />
                <line x1="21" y1="12" x2="9" y2="12" />
              </svg>
              <span>Log out</span>
            </button>

            {/* Light / Dark Mode Toggle Pill */}
            <div className="dash3-theme-toggle-pill">
              <button
                className={`dash3-theme-btn ${theme === 'light' ? 'dash3-theme-active' : ''}`}
                onClick={() => setTheme('light')}
                aria-label="Light mode"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="5" />
                  <line x1="12" y1="1" x2="12" y2="3" />
                  <line x1="12" y1="21" x2="12" y2="23" />
                  <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                  <line x1="1" y1="12" x2="3" y2="12" />
                  <line x1="21" y1="12" x2="23" y2="12" />
                  <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                </svg>
              </button>
              <button
                className={`dash3-theme-btn ${theme === 'dark' ? 'dash3-theme-active' : ''}`}
                onClick={() => setTheme('dark')}
                aria-label="Dark mode"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                </svg>
              </button>
            </div>
          </div>
        </aside>

        {/* =================================================================
            MAIN CONTENT AREA
            ================================================================= */}
        <main className="dash3-main-content">
          {/* Top Header Row */}
          <header className="dash3-top-header">
            <div className="dash3-welcome-block">
              <h1 className="dash3-welcome-title">Welcome back, Adaline!</h1>
              <p className="dash3-welcome-sub">It is the best time to manage your finances</p>
            </div>

            <div className="dash3-header-right">
              {/* Search Button */}
              <button className="dash3-circle-btn" aria-label="Search">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4b5563" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                </svg>
              </button>

              {/* Notification Button with Badge */}
              <div className="dash3-notif-wrapper">
                <button className="dash3-circle-btn" aria-label="Notifications">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4b5563" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                  </svg>
                </button>
                <span className="dash3-notif-badge">3</span>
              </div>

              {/* User Profile Pill */}
              <div className="dash3-user-pill">
                <img
                  src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&auto=format&fit=crop&q=80"
                  alt="Adaline Lively"
                  className="dash3-user-avatar"
                />
                <div className="dash3-user-details">
                  <span className="dash3-user-name">Adaline Lively</span>
                  <span className="dash3-user-email">adalineal@gmail.com</span>
                </div>
              </div>
            </div>
          </header>

          {/* Sub-Header Row: Filter & Action Buttons */}
          <div className="dash3-sub-header-row">
            <button className="dash3-date-filter-pill">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4b5563" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="4" width="18" height="18" rx="2" />
                <line x1="16" y1="2" x2="16" y2="6" />
                <line x1="8" y1="2" x2="8" y2="6" />
                <line x1="3" y1="10" x2="21" y2="10" />
              </svg>
              <span>This month</span>
            </button>

            <div className="dash3-sub-header-actions">
              <button className="dash3-manage-widgets-btn">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="7" height="7" rx="1" />
                  <rect x="14" y="3" width="7" height="7" rx="1" />
                  <rect x="14" y="14" width="7" height="7" rx="1" />
                  <rect x="3" y="14" width="7" height="7" rx="1" />
                </svg>
                <span>Manage widgets</span>
              </button>

              <button className="dash3-add-widget-btn">
                <span className="dash3-plus-icon">+</span>
                <span>Add new widget</span>
              </button>
            </div>
          </div>

          {/* Row 1: 4 Stat Cards */}
          <section className="dash3-stat-cards-grid">
            {/* Card 1: Total balance */}
            <div className="dash3-stat-card">
              <div className="dash3-stat-top">
                <span className="dash3-stat-label">Total balance</span>
                <button className="dash3-card-corner-arrow" aria-label="Details">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="7" y1="17" x2="17" y2="7" />
                    <polyline points="7 7 17 7 17 17" />
                  </svg>
                </button>
              </div>
              <div className="dash3-stat-value">
                $15,700<span className="dash3-cents">.00</span>
              </div>
              <div className="dash3-stat-badge-row">
                <span className="dash3-badge-growth green-text">
                  <span className="arrow-sym">↑</span> 12.1%
                </span>
                <span className="dash3-badge-sub">vs last month</span>
              </div>
            </div>

            {/* Card 2: Income */}
            <div className="dash3-stat-card">
              <div className="dash3-stat-top">
                <span className="dash3-stat-label">Income</span>
                <button className="dash3-card-corner-arrow" aria-label="Details">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="7" y1="17" x2="17" y2="7" />
                    <polyline points="7 7 17 7 17 17" />
                  </svg>
                </button>
              </div>
              <div className="dash3-stat-value">
                $8,500<span className="dash3-cents">.00</span>
              </div>
              <div className="dash3-stat-badge-row">
                <span className="dash3-badge-growth green-text">
                  <span className="arrow-sym">↑</span> 6.3%
                </span>
                <span className="dash3-badge-sub">vs last month</span>
              </div>
            </div>

            {/* Card 3: Expense */}
            <div className="dash3-stat-card">
              <div className="dash3-stat-top">
                <span className="dash3-stat-label">Expense</span>
                <button className="dash3-card-corner-arrow" aria-label="Details">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="7" y1="17" x2="17" y2="7" />
                    <polyline points="7 7 17 7 17 17" />
                  </svg>
                </button>
              </div>
              <div className="dash3-stat-value">
                $6,222<span className="dash3-cents">.00</span>
              </div>
              <div className="dash3-stat-badge-row">
                <span className="dash3-badge-growth red-text">
                  <span className="arrow-sym">↑</span> 2.4%
                </span>
                <span className="dash3-badge-sub">vs last month</span>
              </div>
            </div>

            {/* Card 4: Total savings */}
            <div className="dash3-stat-card">
              <div className="dash3-stat-top">
                <span className="dash3-stat-label">Total savings</span>
                <button className="dash3-card-corner-arrow" aria-label="Details">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="7" y1="17" x2="17" y2="7" />
                    <polyline points="7 7 17 7 17 17" />
                  </svg>
                </button>
              </div>
              <div className="dash3-stat-value">
                $32,913<span className="dash3-cents">.00</span>
              </div>
              <div className="dash3-stat-badge-row">
                <span className="dash3-badge-growth green-text">
                  <span className="arrow-sym">↑</span> 12.1%
                </span>
                <span className="dash3-badge-sub">vs last month</span>
              </div>
            </div>
          </section>

          {/* Row 2: Money Flow & Budget */}
          <section className="dash3-charts-row">
            {/* Left Card: Money Flow */}
            <div className="dash3-card dash3-money-flow-card">
              <div className="dash3-card-header">
                <h3 className="dash3-card-heading">Money flow</h3>

                {/* Legend */}
                <div className="dash3-money-legend">
                  <span className="dash3-legend-item">
                    <span className="dash3-legend-dot dot-income"></span>
                    <span>Income</span>
                  </span>
                  <span className="dash3-legend-item">
                    <span className="dash3-legend-dot dot-expense"></span>
                    <span>Expense</span>
                  </span>
                </div>

                {/* Dropdowns */}
                <div className="dash3-card-dropdowns">
                  <button className="dash3-pill-dropdown">
                    <span>All accounts</span>
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  </button>
                  <button className="dash3-pill-dropdown">
                    <span>This year</span>
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Bar Chart Area */}
              <div className="dash3-barchart-container">
                {/* Y-Axis */}
                <div className="dash3-barchart-yaxis">
                  <span>$15,000</span>
                  <span>$10,000</span>
                  <span>$5,000</span>
                  <span>$1,000</span>
                </div>

                {/* Chart Bars */}
                <div className="dash3-barchart-graph">
                  {/* Grid Lines */}
                  <div className="dash3-grid-line" style={{ top: '10%' }}></div>
                  <div className="dash3-grid-line" style={{ top: '38%' }}></div>
                  <div className="dash3-grid-line" style={{ top: '68%' }}></div>
                  <div className="dash3-grid-line" style={{ top: '96%' }}></div>

                  {/* Month Columns */}
                  <div className="dash3-bar-columns-track">
                    {/* Jan */}
                    <div className="dash3-bar-group">
                      <div className="bars-pair">
                        <div className="bar bar-income" style={{ height: '62%' }}></div>
                        <div className="bar bar-expense" style={{ height: '55%' }}></div>
                      </div>
                      <span className="month-lbl">Jan</span>
                    </div>

                    {/* Feb */}
                    <div className="dash3-bar-group">
                      <div className="bars-pair">
                        <div className="bar bar-income" style={{ height: '70%' }}></div>
                        <div className="bar bar-expense" style={{ height: '80%' }}></div>
                      </div>
                      <span className="month-lbl">Feb</span>
                    </div>

                    {/* Mar (Highlighted with $10,000 tooltip) */}
                    <div className="dash3-bar-group highlighted-group">
                      {/* Tooltip Badge */}
                      <div className="dash3-mar-tooltip">$10,000</div>
                      <div className="bars-pair">
                        <div className="bar bar-income" style={{ height: '76%' }}>
                          <span className="bar-top-dot"></span>
                        </div>
                        <div className="bar bar-expense" style={{ height: '68%' }}></div>
                      </div>
                      <span className="month-lbl">Mar</span>
                    </div>

                    {/* Apr */}
                    <div className="dash3-bar-group">
                      <div className="bars-pair">
                        <div className="bar bar-income" style={{ height: '90%' }}></div>
                        <div className="bar bar-expense" style={{ height: '82%' }}></div>
                      </div>
                      <span className="month-lbl">Apr</span>
                    </div>

                    {/* May */}
                    <div className="dash3-bar-group">
                      <div className="bars-pair">
                        <div className="bar bar-income" style={{ height: '86%' }}></div>
                        <div className="bar bar-expense" style={{ height: '78%' }}></div>
                      </div>
                      <span className="month-lbl">May</span>
                    </div>

                    {/* Jun */}
                    <div className="dash3-bar-group">
                      <div className="bars-pair">
                        <div className="bar bar-income" style={{ height: '48%' }}></div>
                        <div className="bar bar-expense" style={{ height: '38%' }}></div>
                      </div>
                      <span className="month-lbl">Jun</span>
                    </div>

                    {/* Jul */}
                    <div className="dash3-bar-group">
                      <div className="bars-pair">
                        <div className="bar bar-income" style={{ height: '58%' }}></div>
                        <div className="bar bar-expense" style={{ height: '46%' }}></div>
                      </div>
                      <span className="month-lbl">Jul</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Card: Budget */}
            <div className="dash3-card dash3-budget-card">
              <div className="dash3-card-header">
                <h3 className="dash3-card-heading">Budget</h3>
                <button className="dash3-card-corner-arrow" aria-label="Details">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="7" y1="17" x2="17" y2="7" />
                    <polyline points="7 7 17 7 17 17" />
                  </svg>
                </button>
              </div>

              <div className="dash3-budget-body">
                {/* Category List */}
                <div className="dash3-budget-categories">
                  <div className="dash3-cat-item">
                    <span className="cat-dot" style={{ backgroundColor: '#7064f7' }}></span>
                    <span>Cafe & Restaurants</span>
                  </div>
                  <div className="dash3-cat-item">
                    <span className="cat-dot" style={{ backgroundColor: '#b4aefb' }}></span>
                    <span>Entertainment</span>
                  </div>
                  <div className="dash3-cat-item">
                    <span className="cat-dot" style={{ backgroundColor: '#e2e8f0' }}></span>
                    <span>Investments</span>
                  </div>
                  <div className="dash3-cat-item">
                    <span className="cat-dot" style={{ backgroundColor: '#334155' }}></span>
                    <span>Food & Groceries</span>
                  </div>
                  <div className="dash3-cat-item">
                    <span className="cat-dot" style={{ backgroundColor: '#64748b' }}></span>
                    <span>Health & Beauty</span>
                  </div>
                  <div className="dash3-cat-item">
                    <span className="cat-dot" style={{ backgroundColor: '#94a3b8' }}></span>
                    <span>Traveling</span>
                  </div>
                </div>

                {/* Donut Chart with Callout Tag */}
                <div className="dash3-donut-container">
                  {/* Floating Callout: 7% / $400 */}
                  <div className="dash3-callout-tag">
                    <span className="callout-percent">7%</span>
                    <span className="callout-amount">$400</span>
                  </div>

                  <div className="dash3-donut-wrapper">
                    <svg viewBox="0 0 140 140" className="dash3-donut-svg">
                      {/* Dark charcoal segment (Food & Groceries) */}
                      <circle
                        cx="70"
                        cy="70"
                        r="52"
                        fill="none"
                        stroke="#334155"
                        strokeWidth="11"
                        strokeDasharray="90 327"
                        strokeDashoffset="0"
                      />
                      {/* Purple segment (Cafe & Restaurants) */}
                      <circle
                        cx="70"
                        cy="70"
                        r="52"
                        fill="none"
                        stroke="#7064f7"
                        strokeWidth="11"
                        strokeDasharray="130 327"
                        strokeDashoffset="-90"
                      />
                      {/* Lavender segment (Entertainment) */}
                      <circle
                        cx="70"
                        cy="70"
                        r="52"
                        fill="none"
                        stroke="#b4aefb"
                        strokeWidth="11"
                        strokeDasharray="60 327"
                        strokeDashoffset="-220"
                      />
                      {/* Light gray segment */}
                      <circle
                        cx="70"
                        cy="70"
                        r="52"
                        fill="none"
                        stroke="#e2e8f0"
                        strokeWidth="11"
                        strokeDasharray="47 327"
                        strokeDashoffset="-280"
                      />
                    </svg>

                    {/* Donut Center Text */}
                    <div className="dash3-donut-center-info">
                      <span className="center-lbl">Total for month</span>
                      <span className="center-val">
                        $5,950<span className="dash3-cents">.00</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Row 3: Recent Transactions & Saving Goals */}
          <section className="dash3-bottom-row">
            {/* Left Card: Recent Transactions */}
            <div className="dash3-card dash3-transactions-card">
              <div className="dash3-card-header">
                <h3 className="dash3-card-heading">Recent transactions</h3>
                <div className="dash3-card-dropdowns">
                  <button className="dash3-pill-dropdown">
                    <span>All accounts</span>
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  </button>
                  <button className="dash3-see-all-btn">
                    <span>See all</span>
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="9 18 15 12 9 6" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Transactions Table */}
              <div className="dash3-table-wrapper">
                <table className="dash3-trans-table">
                  <thead>
                    <tr>
                      <th>DATE</th>
                      <th>AMOUNT</th>
                      <th>PAYMENT NAME</th>
                      <th>METHOD</th>
                      <th>CATEGORY</th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* Row 1: YouTube */}
                    <tr>
                      <td className="date-cell">25 Jul 12:30</td>
                      <td className="amount-cell">- $10</td>
                      <td className="payment-cell">
                        <div className="payment-brand">
                          {/* YouTube Red Icon */}
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="#ef4444">
                            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                          </svg>
                          <span>YouTube</span>
                        </div>
                      </td>
                      <td className="method-cell">VISA **3254</td>
                      <td className="category-cell">Subscription</td>
                    </tr>

                    {/* Row 2: Reserved */}
                    <tr>
                      <td className="date-cell">26 Jul 15:00</td>
                      <td className="amount-cell">- $150</td>
                      <td className="payment-cell">
                        <div className="payment-brand">
                          <span className="reserved-brand-icon">••••••••</span>
                          <span>Reserved</span>
                        </div>
                      </td>
                      <td className="method-cell">Mastercard **2154</td>
                      <td className="category-cell">Shopping</td>
                    </tr>

                    {/* Row 3: Yaposhka */}
                    <tr>
                      <td className="date-cell">27 Jul 9:00</td>
                      <td className="amount-cell">- $80</td>
                      <td className="payment-cell">
                        <div className="payment-brand">
                          {/* Yaposhka emoji/icon */}
                          <span className="yaposhka-avatar-icon">🍧</span>
                          <span>Yaposhka</span>
                        </div>
                      </td>
                      <td className="method-cell">Mastercard **2154</td>
                      <td className="category-cell">Cafe & Restaurants</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right Card: Saving Goals */}
            <div className="dash3-card dash3-saving-goals-card">
              <div className="dash3-card-header">
                <h3 className="dash3-card-heading">Saving goals</h3>
                <button className="dash3-card-corner-arrow" aria-label="Details">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="7" y1="17" x2="17" y2="7" />
                    <polyline points="7 7 17 7 17 17" />
                  </svg>
                </button>
              </div>

              <div className="dash3-goals-list">
                {/* Goal 1: MacBook Pro */}
                <div className="dash3-goal-item">
                  <div className="dash3-goal-text-row">
                    <span className="goal-name">MacBook Pro</span>
                    <span className="goal-amount">$1,650</span>
                  </div>
                  <div className="dash3-goal-bar-track">
                    <div className="dash3-goal-bar-fill" style={{ width: '25%' }}>
                      <span className="goal-percent-text">25%</span>
                    </div>
                  </div>
                </div>

                {/* Goal 2: New car */}
                <div className="dash3-goal-item">
                  <div className="dash3-goal-text-row">
                    <span className="goal-name">New car</span>
                    <span className="goal-amount">$60,000</span>
                  </div>
                  <div className="dash3-goal-bar-track">
                    <div className="dash3-goal-bar-fill" style={{ width: '42%' }}>
                      <span className="goal-percent-text">42%</span>
                    </div>
                  </div>
                </div>

                {/* Goal 3: New house */}
                <div className="dash3-goal-item">
                  <div className="dash3-goal-text-row">
                    <span className="goal-name">New house</span>
                    <span className="goal-amount">$150,000</span>
                  </div>
                  <div className="dash3-goal-bar-track">
                    <div className="dash3-goal-bar-fill" style={{ width: '14%' }}>
                      <span className="goal-percent-text">3%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
