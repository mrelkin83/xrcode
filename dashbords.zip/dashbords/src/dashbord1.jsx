import React, { useState } from 'react';
import './dashbord1.css';

export default function Dashboard1() {
  const [theme, setTheme] = useState('light');
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [activeAssignmentTag, setActiveAssignmentTag] = useState('Motion design');

  return (
    <div className="dashboard-app-wrapper">
      <div className="dashboard-window">
        {/* LEFT ORGANIC CURVED DOCK */}
        <aside className="left-dock-container">
          <div className="curved-dock-shape">
            {/* SVG Organic Shape Background */}
            <svg className="dock-svg-background" viewBox="0 0 68 530" fill="none" preserveAspectRatio="none">
              <path
                d="M 0,0 C 0,35 68,25 68,60 L 68,470 C 68,505 0,495 0,530 Z"
                fill="#5c56e0"
              />
            </svg>

            {/* Dock Navigation Icons */}
            <div className="dock-nav-items">
              {/* Top Active App Icon */}
              <button className="dock-icon-btn dock-icon-active" aria-label="Dashboard Grid">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="7" height="7" rx="2" fill="currentColor" />
                  <rect x="14" y="3" width="7" height="7" rx="2" fill="currentColor" />
                  <rect x="14" y="14" width="7" height="7" rx="2" fill="currentColor" />
                  <rect x="3" y="14" width="7" height="7" rx="2" fill="currentColor" />
                </svg>
              </button>

              {/* Profile Icon */}
              <button className="dock-icon-btn" aria-label="Profile">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </button>

              {/* Night Mode / Pro Badge Icon */}
              <div className="dock-icon-with-badge">
                <button className="dock-icon-btn" aria-label="Pro Mode">
                  <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                  </svg>
                </button>
                <span className="dock-pro-badge">PRO</span>
              </div>

              {/* Bell Icon */}
              <button className="dock-icon-btn" aria-label="Notifications">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                  <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                </svg>
              </button>

              {/* Calendar Icon */}
              <button className="dock-icon-btn" aria-label="Calendar">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="4" width="18" height="18" rx="3" />
                  <line x1="16" y1="2" x2="16" y2="6" />
                  <line x1="8" y1="2" x2="8" y2="6" />
                  <line x1="3" y1="10" x2="21" y2="10" />
                </svg>
              </button>

              {/* Note/Checklist Icon */}
              <button className="dock-icon-btn" aria-label="Notes">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                  <polyline points="14 2 14 8 20 8" />
                  <polyline points="9 15 11 17 15 13" />
                </svg>
              </button>

              {/* Edit Notepad Icon */}
              <button className="dock-icon-btn" aria-label="Tasks">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 20h9" />
                  <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 9.5-9.5z" />
                </svg>
              </button>

              {/* Chat Bubble Icon */}
              <button className="dock-icon-btn" aria-label="Chat">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                </svg>
              </button>
            </div>
          </div>
        </aside>

        {/* MAIN DASHBOARD CONTENT */}
        <main className="dashboard-main-content">
          {/* TOP HEADER */}
          <header className="dashboard-header">
            {/* Left Nav Tabs */}
            <nav className="header-nav-tabs">
              <button
                className={`header-tab-link ${activeTab === 'Dashboard' ? 'tab-active' : ''}`}
                onClick={() => setActiveTab('Dashboard')}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                  <rect x="3" y="3" width="7" height="7" rx="1.5" />
                  <rect x="14" y="3" width="7" height="7" rx="1.5" />
                  <rect x="14" y="14" width="7" height="7" rx="1.5" />
                  <rect x="3" y="14" width="7" height="7" rx="1.5" />
                </svg>
                <span>Dashboard</span>
              </button>

              <button
                className={`header-tab-link ${activeTab === 'Workflows' ? 'tab-active' : ''}`}
                onClick={() => setActiveTab('Workflows')}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <circle cx="6" cy="6" r="3" />
                  <circle cx="6" cy="18" r="3" />
                  <circle cx="18" cy="12" r="3" />
                  <path d="M9 6h4a5 5 0 0 1 5 5v1" />
                  <line x1="6" y1="9" x2="6" y2="15" />
                </svg>
                <span>Workflows</span>
              </button>

              <button
                className={`header-tab-link ${activeTab === 'Integrations' ? 'tab-active' : ''}`}
                onClick={() => setActiveTab('Integrations')}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <polygon points="12 2 2 7 12 12 22 7 12 2" />
                  <polyline points="2 17 12 22 22 17" />
                  <polyline points="2 12 12 17 22 12" />
                </svg>
                <span>Integrations</span>
              </button>
            </nav>

            {/* Middle Search Input */}
            <div className="header-search-box">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8c94a8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input type="text" placeholder="Search or type command" aria-label="Search or type command" />
            </div>

            {/* Right Controls */}
            <div className="header-right-actions">
              {/* Light/Dark Toggle */}
              <div className="theme-toggle-pill">
                <button
                  className={`theme-toggle-btn ${theme === 'light' ? 'theme-active' : ''}`}
                  onClick={() => setTheme('light')}
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                    <circle cx="12" cy="12" r="5" />
                    <line x1="12" y1="1" x2="12" y2="3" />
                    <line x1="12" y1="21" x2="12" y2="23" />
                    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                    <line x1="1" y1="12" x2="3" y2="12" />
                    <line x1="21" y1="12" x2="23" y2="12" />
                    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                  </svg>
                  <span>Light</span>
                </button>
                <button
                  className={`theme-toggle-btn ${theme === 'dark' ? 'theme-active' : ''}`}
                  onClick={() => setTheme('dark')}
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                  </svg>
                  <span>Dark</span>
                </button>
              </div>

              {/* Notification Bell */}
              <button className="header-icon-action-btn" aria-label="Notifications">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#475569" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                  <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                </svg>
              </button>

              {/* Settings Cog */}
              <button className="header-icon-action-btn" aria-label="Settings">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#475569" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3" />
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
                </svg>
              </button>

              {/* Export Data Button */}
              <button className="header-export-btn">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <polyline points="19 12 12 19 5 12" />
                </svg>
                <span>Export data</span>
                <span className="xls-tag">.xls</span>
              </button>

              {/* Add New Board Button */}
              <button className="header-add-board-btn">
                Add new board
              </button>
            </div>
          </header>

          {/* TOP SECTION: GREETING & 4 FEATURE CARDS */}
          <section className="dashboard-top-section">
            {/* Greeting Banner */}
            <div className="greeting-banner">
              <div className="greeting-title-line">
                <h1 className="greeting-heading">Hi, James!</h1>
                {/* 2 Circular Badge Stickers */}
                <div className="greeting-stickers">
                  <div className="sticker sticker-blue">
                    <svg viewBox="0 0 32 32" width="24" height="24">
                      <circle cx="16" cy="16" r="14" fill="#6366f1" />
                      <circle cx="16" cy="16" r="9" fill="none" stroke="#ffffff" strokeWidth="2" />
                      <circle cx="16" cy="16" r="4" fill="#ffffff" />
                    </svg>
                  </div>
                  <div className="sticker sticker-purple">
                    <svg viewBox="0 0 32 32" width="24" height="24">
                      <circle cx="16" cy="16" r="14" fill="#a5b4fc" />
                      <path d="M16 7 A9 9 0 0 1 25 16" stroke="#4f46e5" strokeWidth="2" fill="none" strokeLinecap="round" />
                      <path d="M16 25 A9 9 0 0 1 7 16" stroke="#4f46e5" strokeWidth="2" fill="none" strokeLinecap="round" />
                      <circle cx="16" cy="16" r="3" fill="#4f46e5" />
                    </svg>
                  </div>
                </div>
              </div>
              <h2 className="greeting-subheading">
                What are your<br />planes for today?
              </h2>
              <p className="greeting-desc">
                This platform is designed to revolutionize the<br />way you organize and access your notes
              </p>
            </div>

            {/* 4 Feature Action Cards */}
            <div className="feature-cards-track">
              {/* Card 0: Empty Lavender Card with Plus */}
              <div className="feature-card feature-card-blank">
                <button className="blank-card-add-btn" aria-label="Create note">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
                    <line x1="12" y1="5" x2="12" y2="19" />
                    <line x1="5" y1="12" x2="19" y2="12" />
                  </svg>
                </button>
              </div>

              {/* Card 1: Stay Organized */}
              <div className="feature-card">
                <div className="feature-card-illustration">
                  <svg width="84" height="84" viewBox="0 0 100 100" fill="none">
                    {/* Spiral rings */}
                    <path d="M34 16v10 M50 16v10 M66 16v10" stroke="#1e293b" strokeWidth="2.4" strokeLinecap="round" />
                    {/* Calendar body */}
                    <rect x="24" y="22" width="52" height="54" rx="8" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
                    <line x1="32" y1="36" x2="68" y2="36" stroke="#cbd5e1" strokeWidth="1.8" strokeLinecap="round" />
                    {/* Checked item */}
                    <rect x="32" y="44" width="11" height="11" rx="2.5" fill="#5c56e0" />
                    <path d="M35 49.5l2 2 4-4" stroke="#ffffff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    <line x1="48" y1="48" x2="68" y2="48" stroke="#64748b" strokeWidth="1.8" strokeLinecap="round" />
                    <line x1="48" y1="54" x2="62" y2="54" stroke="#94a3b8" strokeWidth="1.8" strokeLinecap="round" />
                    {/* Mouse cursor pointer */}
                    <path d="M60 58l8 13-3 1-4-9-4 4V58h3z" fill="#ffffff" stroke="#1e293b" strokeWidth="1.8" strokeLinejoin="round" />
                  </svg>
                </div>
                <h3 className="feature-card-title">Stay organized</h3>
                <p className="feature-card-sub">A clear structure for your notes</p>
              </div>

              {/* Card 2: Sync your notes */}
              <div className="feature-card">
                <div className="feature-card-illustration">
                  <svg width="84" height="84" viewBox="0 0 100 100" fill="none">
                    {/* Clothesline Wire */}
                    <path d="M10 24 Q 50 34 90 24" stroke="#1e293b" strokeWidth="1.8" strokeLinecap="round" />
                    {/* Pegs */}
                    <line x1="28" y1="25" x2="28" y2="32" stroke="#5c56e0" strokeWidth="2.2" />
                    <line x1="50" y1="28" x2="50" y2="35" stroke="#5c56e0" strokeWidth="2.2" />
                    <line x1="74" y1="25" x2="74" y2="32" stroke="#5c56e0" strokeWidth="2.2" />
                    {/* Note 1 */}
                    <rect x="20" y="32" width="17" height="24" rx="2.5" fill="#ffffff" stroke="#1e293b" strokeWidth="1.6" transform="rotate(-6 20 32)" />
                    <line x1="23" y1="39" x2="33" y2="38" stroke="#cbd5e1" strokeWidth="1.4" />
                    <line x1="23" y1="45" x2="31" y2="44" stroke="#cbd5e1" strokeWidth="1.4" />
                    {/* Note 2 */}
                    <rect x="42" y="35" width="17" height="26" rx="2.5" fill="#ffffff" stroke="#1e293b" strokeWidth="1.6" transform="rotate(4 42 35)" />
                    <circle cx="50" cy="46" r="3.5" fill="#edeefc" />
                    {/* Hanging Phone */}
                    <rect x="66" y="32" width="17" height="30" rx="3.5" fill="#ffffff" stroke="#1e293b" strokeWidth="1.6" transform="rotate(-3 66 32)" />
                    <rect x="69" y="37" width="11" height="18" rx="2" fill="#f1f5f9" />
                    <circle cx="74.5" cy="58" r="1.3" fill="#5c56e0" />
                  </svg>
                </div>
                <h3 className="feature-card-title">Sync your notes</h3>
                <p className="feature-card-sub">Ensure that notes are synced</p>
              </div>

              {/* Card 3: Collaborate and share */}
              <div className="feature-card">
                <div className="feature-card-illustration">
                  <svg width="84" height="84" viewBox="0 0 100 100" fill="none">
                    {/* Top corner tag: -8x */}
                    <text x="66" y="22" fill="#5c56e0" fontSize="11" fontWeight="bold" fontFamily="sans-serif">-8x</text>
                    {/* Retro Cassette Deck */}
                    <rect x="22" y="26" width="56" height="42" rx="7" fill="#ffffff" stroke="#1e293b" strokeWidth="1.8" />
                    {/* Cassette window */}
                    <rect x="32" y="36" width="36" height="18" rx="3.5" fill="#f8fafc" stroke="#1e293b" strokeWidth="1.6" />
                    <circle cx="41" cy="45" r="3.8" stroke="#5c56e0" strokeWidth="1.8" />
                    <circle cx="59" cy="45" r="3.8" stroke="#5c56e0" strokeWidth="1.8" />
                    <line x1="45" y1="45" x2="55" y2="45" stroke="#cbd5e1" strokeWidth="1.8" />
                    {/* Bottom deck buttons */}
                    <circle cx="34" cy="60" r="1.8" fill="#1e293b" />
                    <circle cx="42" cy="60" r="1.8" fill="#1e293b" />
                    <circle cx="50" cy="60" r="1.8" fill="#1e293b" />
                  </svg>
                </div>
                <h3 className="feature-card-title">Collaborate and share</h3>
                <p className="feature-card-sub">Share notes with colleagues</p>
              </div>
            </div>
          </section>

          {/* MIDDLE SECTION: 3 CARDS (Notifications, Assignments, Calendar) */}
          <section className="dashboard-grid-row middle-row">
            {/* CARD 1: Notifications */}
            <div className="dash-card notifications-card">
              <div className="card-header-bar">
                <h3 className="card-main-title">Notifications</h3>
                <button className="card-header-action-btn">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="3 6 5 6 21 6" />
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                  </svg>
                  <span>Clear</span>
                </button>
              </div>

              {/* Subcard 1: Floating elevated event card with action buttons */}
              <div className="notif-elevated-wrapper">
                <div className="notif-floating-card">
                  <div className="notif-card-top">
                    <div className="notif-event-title">
                      <span>Upcoming event</span>
                      <span className="notif-status-dot"></span>
                    </div>
                    <button className="card-more-menu-btn" aria-label="Options">•••</button>
                  </div>
                  <p className="notif-meeting-desc">Landing design meeting | Time: 120 min</p>
                  <div className="notif-badges-row">
                    <span className="notif-meta-tag">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" />
                        <line x1="16" y1="2" x2="16" y2="6" />
                        <line x1="8" y1="2" x2="8" y2="6" />
                        <line x1="3" y1="10" x2="21" y2="10" />
                      </svg>
                      <span>Sat, 10 May</span>
                    </span>
                    <span className="notif-meta-tag">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="10" />
                        <polyline points="12 6 12 12 16 14" />
                      </svg>
                      <span>11 AM - 11:45 AM</span>
                    </span>
                  </div>
                </div>

                {/* Right side floating action icons */}
                <div className="notif-floating-actions">
                  <button className="notif-quick-btn" aria-label="Delete">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="3 6 5 6 21 6" />
                      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                    </svg>
                  </button>
                  <button className="notif-quick-btn" aria-label="Edit">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Subcard 2: Message preview card */}
              <div className="notif-msg-card">
                <div className="notif-msg-header">
                  <span className="notif-msg-title">Message | Product design</span>
                  <button className="card-more-menu-btn" aria-label="Options">•••</button>
                </div>
                <div className="notif-sender-line">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                    <polyline points="22,6 12,13 2,6" />
                  </svg>
                  <span>Message from Ken Smith</span>
                </div>
                <div className="notif-msg-bubble">
                  Hey team, just wanted to check in and see how is...
                </div>
              </div>
            </div>

            {/* CARD 2: Assignments */}
            <div className="dash-card assignments-card">
              <div className="card-header-bar">
                <h3 className="card-main-title">Assignments</h3>
                <button className="card-header-action-btn">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                  </svg>
                  <span>Edit</span>
                </button>
              </div>

              {/* Assignment Category Tabs */}
              <div className="assignments-tab-bar">
                <div className="assignments-tab-left">
                  <button
                    className={`assign-tab ${activeAssignmentTag === 'Motion design' ? 'assign-tab-active' : ''}`}
                    onClick={() => setActiveAssignmentTag('Motion design')}
                  >
                    Motion design
                  </button>
                  <button
                    className={`assign-tab ${activeAssignmentTag === 'Logo' ? 'assign-tab-active' : ''}`}
                    onClick={() => setActiveAssignmentTag('Logo')}
                  >
                    Logo
                  </button>
                </div>
                <button className="card-more-menu-btn" aria-label="Options">•••</button>
              </div>

              {/* Assignment Main Content Box */}
              <div className="assignment-detail-box">
                <div className="assignment-title-row">
                  <h4 className="assignment-heading">Design a packaging concept for a new product</h4>
                  <span className="priority-badge-high">High</span>
                </div>

                <div className="assignment-footer-row">
                  <span className="assignment-pill-tag">Package design</span>
                  <div className="assignment-assignee">
                    <span className="assignee-name">Rachel Lee</span>
                    <img
                      src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&auto=format&fit=crop&q=80"
                      alt="Rachel Lee"
                      className="assignee-avatar"
                    />
                  </div>
                </div>
              </div>

              {/* Add New Assignment Button */}
              <button className="add-assignment-btn">
                <span className="add-assignment-plus-icon">+</span>
                <span>Add new assignment</span>
              </button>
            </div>

            {/* CARD 3: May 2021 Calendar & Schedule */}
            <div className="dash-card calendar-card">
              <div className="card-header-bar">
                <h3 className="card-main-title">May 2021</h3>
                <div className="cal-nav-arrows">
                  <button className="cal-arrow-btn" aria-label="Previous">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="15 18 9 12 15 6" />
                    </svg>
                  </button>
                  <button className="cal-arrow-btn" aria-label="Next">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="9 18 15 12 9 6" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Day & Date Strip */}
              <div className="calendar-week-strip">
                <div className="cal-col">
                  <span className="cal-day">Mon</span>
                  <span className="cal-date">14</span>
                </div>
                <div className="cal-col">
                  <span className="cal-day">Tue</span>
                  <span className="cal-date">15</span>
                </div>
                <div className="cal-col">
                  <span className="cal-day">Wed</span>
                  <span className="cal-date">16</span>
                </div>
                <div className="cal-col">
                  <span className="cal-day">Thr</span>
                  <span className="cal-date">17</span>
                </div>
                <div className="cal-col cal-col-active">
                  <span className="cal-day">Fr</span>
                  <span className="cal-date-bubble">18</span>
                </div>
                <div className="cal-col">
                  <span className="cal-day">Sat</span>
                  <span className="cal-date">19</span>
                </div>
                <div className="cal-col">
                  <span className="cal-day">Sun</span>
                  <span className="cal-date">20</span>
                </div>
              </div>

              {/* Schedule Slots */}
              <div className="schedule-events-list">
                {/* Event 1 */}
                <div className="schedule-event-block">
                  <div className="slot-time-header">
                    <span>04:30-05:00 PM</span>
                    <div className="slot-dash-line"></div>
                  </div>
                  <div className="event-item-card">
                    <div className="event-icon-circle event-icon-purple">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                        <circle cx="9" cy="7" r="4" />
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                      </svg>
                    </div>
                    <div className="event-item-info">
                      <h5 className="event-item-title">Team meeting</h5>
                      <span className="event-item-subtitle">12:00 - 12:30 • UX/UI design</span>
                    </div>
                    <button className="card-more-menu-btn" aria-label="Event options">⋮</button>
                  </div>
                </div>

                {/* Event 2 */}
                <div className="schedule-event-block">
                  <div className="slot-time-header">
                    <span>11:30-12:30 PM</span>
                    <div className="slot-dash-line"></div>
                  </div>
                  <div className="event-item-card">
                    <div className="event-icon-circle event-icon-lavender">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#5c56e0" strokeWidth="2">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" />
                        <line x1="3" y1="6" x2="21" y2="6" />
                        <path d="M16 10a4 4 0 0 1-8 0" />
                      </svg>
                    </div>
                    <div className="event-item-info">
                      <h5 className="event-item-title">Meeting with new client</h5>
                      <span className="event-item-subtitle">12:30 - 01:30 PM • Job interview</span>
                    </div>
                    <button className="card-more-menu-btn" aria-label="Event options">⋮</button>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* BOTTOM SECTION: 3 COLUMNS (Today Tasks, Go Premium, Stats & Meeting) */}
          <section className="dashboard-grid-row bottom-row">
            {/* COLUMN 1: Today tasks (Wide Card) */}
            <div className="dash-card today-tasks-card">
              <div className="today-tasks-header">
                <div className="today-tasks-left">
                  <h3 className="card-main-title">Today tasks</h3>
                  {/* User avatars stack */}
                  <div className="avatar-stack">
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                      alt="Member 1"
                      className="stacked-avatar"
                    />
                    <img
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80"
                      alt="Member 2"
                      className="stacked-avatar"
                    />
                    <img
                      src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80"
                      alt="Member 3"
                      className="stacked-avatar"
                    />
                    <div className="stacked-avatar-add">+</div>
                  </div>
                </div>

                <div className="today-tasks-right">
                  {/* View pill */}
                  <div className="tasks-view-pill">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor">
                      <rect x="3" y="3" width="7" height="7" rx="1.5" />
                      <rect x="14" y="3" width="7" height="7" rx="1.5" />
                      <rect x="14" y="14" width="7" height="7" rx="1.5" />
                      <rect x="3" y="14" width="7" height="7" rx="1.5" />
                    </svg>
                    <span>08</span>
                  </div>
                  <button className="card-header-action-btn">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                    </svg>
                    <span>Edit</span>
                  </button>
                  <button className="card-header-action-btn">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="7" y1="17" x2="17" y2="7" />
                      <polyline points="7 7 17 7 17 17" />
                    </svg>
                    <span>Share</span>
                  </button>
                </div>
              </div>

              {/* Tasks List */}
              <div className="tasks-table-list">
                {/* Task Item 1 */}
                <div className="task-row-item">
                  <div className="task-primary-info">
                    <h5 className="task-title">Conduct research</h5>
                    <span className="task-date-sub">4 May, 09:20 AM</span>
                  </div>
                  <div className="task-duration-info">
                    <span className="task-label-dim">Duration</span>
                    <span className="task-val-bold">02 h 45 m</span>
                  </div>
                  <div className="task-progress-col">
                    <span className="task-percent-num">90%</span>
                    <div className="task-progress-bar">
                      <div className="task-progress-fill" style={{ width: '90%' }}></div>
                    </div>
                  </div>
                  <div className="task-meta-icons">
                    <span className="meta-pair">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
                      </svg>
                      <span>4</span>
                    </span>
                    <span className="meta-bullet">•</span>
                    <span className="meta-pair">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                        <circle cx="12" cy="7" r="4" />
                      </svg>
                      <span>16</span>
                    </span>
                  </div>
                </div>

                {/* Task Item 2 */}
                <div className="task-row-item">
                  <div className="task-primary-info">
                    <h5 className="task-title">Schedule a meeting</h5>
                    <span className="task-date-sub">14 May, 12:45 AM</span>
                  </div>
                  <div className="task-duration-info">
                    <span className="task-label-dim">Duration</span>
                    <span className="task-val-bold">06 h 55 m</span>
                  </div>
                  <div className="task-progress-col">
                    <span className="task-percent-num">50%</span>
                    <div className="task-progress-bar">
                      <div className="task-progress-fill" style={{ width: '50%' }}></div>
                    </div>
                  </div>
                  <div className="task-meta-icons">
                    <span className="meta-pair">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
                      </svg>
                      <span>4</span>
                    </span>
                    <span className="meta-bullet">•</span>
                    <span className="meta-pair">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" />
                        <line x1="16" y1="2" x2="16" y2="6" />
                        <line x1="8" y1="2" x2="8" y2="6" />
                        <line x1="3" y1="10" x2="21" y2="10" />
                      </svg>
                      <span>3 June</span>
                    </span>
                  </div>
                </div>

                {/* Task Item 3 */}
                <div className="task-row-item">
                  <div className="task-primary-info">
                    <h5 className="task-title">Send out reminders</h5>
                    <span className="task-date-sub">21 May, 10:30 AM</span>
                  </div>
                  <div className="task-duration-info">
                    <span className="task-label-dim">Duration</span>
                    <span className="task-val-bold">01 h 30 m</span>
                  </div>
                  <div className="task-progress-col">
                    <span className="task-percent-num">10%</span>
                    <div className="task-progress-bar">
                      <div className="task-progress-fill" style={{ width: '10%' }}></div>
                    </div>
                  </div>
                  <div className="task-meta-icons">
                    <span className="meta-pair">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
                      </svg>
                      <span>16</span>
                    </span>
                    <span className="meta-bullet">•</span>
                    <span className="meta-pair">
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" />
                        <line x1="16" y1="2" x2="16" y2="6" />
                        <line x1="8" y1="2" x2="8" y2="6" />
                        <line x1="3" y1="10" x2="21" y2="10" />
                      </svg>
                      <span>3 June</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* COLUMN 2: Go Premium! Card */}
            <div className="dash-card go-premium-card">
              {/* Hands Offering Gift Box Doodle */}
              <div className="premium-illustration">
                <svg width="110" height="80" viewBox="0 0 120 90" fill="none">
                  {/* Sparkles / Confetti */}
                  <path d="M30 18l3-5 3 5-5-3 5-3-5 3z" fill="#ffffff" />
                  <path d="M88 16l3-5 3 5-5-3 5-3-5 3z" fill="#ffffff" />
                  <circle cx="20" cy="36" r="1.8" fill="#c7d2fe" />
                  <circle cx="100" cy="30" r="2.2" fill="#c7d2fe" />
                  <path d="M60 8l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#ffffff" />

                  {/* Gift Box Body */}
                  <rect x="42" y="30" width="36" height="30" rx="5" fill="#141938" stroke="#ffffff" strokeWidth="2" />
                  {/* Gift Ribbon Vertical */}
                  <rect x="57" y="30" width="6" height="30" fill="#818cf8" stroke="#ffffff" strokeWidth="1" />
                  {/* Gift Ribbon Horizontal */}
                  <rect x="42" y="42" width="36" height="6" fill="#818cf8" stroke="#ffffff" strokeWidth="1" />
                  {/* Ribbon Bow */}
                  <path d="M54 26 C48 20 42 26 57 30 C62 24 68 20 66 26 C64 30 57 30 57 30" stroke="#ffffff" strokeWidth="1.8" fill="none" />

                  {/* Left Hand Holding Box */}
                  <path d="M26 66 C32 58 40 54 46 52 C46 56 44 62 36 70" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" fill="none" />
                  <path d="M32 70 C38 66 44 62 48 58" stroke="#ffffff" strokeWidth="1.8" strokeLinecap="round" />

                  {/* Right Hand Holding Box */}
                  <path d="M94 66 C88 58 80 54 74 52 C74 56 76 62 84 70" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" fill="none" />
                  <path d="M88 70 C82 66 76 62 72 58" stroke="#ffffff" strokeWidth="1.8" strokeLinecap="round" />
                </svg>
              </div>

              <div className="premium-text-content">
                <h4 className="premium-title">Go premium!</h4>
                <p className="premium-desc">
                  Gain access to a range of benefits designed to enhance your user experience
                </p>
              </div>

              <button className="premium-action-btn">
                Find out more
              </button>
            </div>

            {/* COLUMN 3: Donut Stats & Board Meeting Card */}
            <div className="right-stats-column">
              {/* Row of 2 Donut Stat Cards */}
              <div className="donuts-row">
                {/* Donut 1: Data Research / Marketing */}
                <div className="donut-stat-card">
                  <div className="donut-chart-wrapper">
                    <svg viewBox="0 0 36 36" className="donut-svg">
                      <path
                        className="donut-bg-ring"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="#eef2f6"
                        strokeWidth="3.2"
                      />
                      <path
                        className="donut-fill-ring donut-green"
                        strokeDasharray="90, 100"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="#10b981"
                        strokeWidth="3.2"
                        strokeLinecap="round"
                      />
                    </svg>
                    <span className="donut-center-text">90%</span>
                  </div>

                  <div className="donut-card-body">
                    <span className="donut-mini-label label-green">DATA RESEARCH</span>
                    <h5 className="donut-main-heading">Marketing</h5>
                    <div className="donut-footer-text">
                      <p className="sub-marked">You marked 5/5</p>
                      <p className="sub-done">All assignments are done!</p>
                    </div>
                  </div>
                </div>

                {/* Donut 2: Typography */}
                <div className="donut-stat-card">
                  <div className="donut-chart-wrapper">
                    <svg viewBox="0 0 36 36" className="donut-svg">
                      <path
                        className="donut-bg-ring"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="#eef2f6"
                        strokeWidth="3.2"
                      />
                      <path
                        className="donut-fill-ring donut-coral"
                        strokeDasharray="65, 100"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="#f43f5e"
                        strokeWidth="3.2"
                        strokeLinecap="round"
                      />
                    </svg>
                    <span className="donut-center-text">65%</span>
                  </div>

                  <div className="donut-card-body">
                    <span className="donut-mini-label label-coral">UX/UI DESIGN</span>
                    <h5 className="donut-main-heading">Typography</h5>
                    <div className="donut-footer-row-btn">
                      <div>
                        <p className="sub-marked">You marked 3/5</p>
                        <p className="sub-done">2 assignments left</p>
                      </div>
                      <button className="donut-check-btn">Check</button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Card: Board meeting */}
              <div className="dash-card board-meeting-card">
                <div className="card-header-bar">
                  <h3 className="card-main-title">Board meeting</h3>
                  <button className="card-header-action-btn">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                    </svg>
                    <span>Edit</span>
                  </button>
                </div>

                <div className="meeting-date-row">
                  <span className="purple-dot"></span>
                  <span className="meeting-date-text">March 24 at 4:00 PM</span>
                </div>

                <div className="meeting-location-details">
                  <p>Meeting with John Smith,</p>
                  <p>4th floor, room 159</p>
                </div>

                <div className="meeting-actions-row">
                  <button className="meeting-reschedule-btn">Reschedule</button>
                  <button className="meeting-accept-btn">Accept invite</button>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
