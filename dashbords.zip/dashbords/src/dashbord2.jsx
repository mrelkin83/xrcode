import React, { useState } from 'react';
import './dashbord2.css';

export default function Dashboard2() {
  const [activeNav, setActiveNav] = useState('Dashboard');

  return (
    <div className="dash2-app-wrapper">
      <div className="dash2-window-container">
        {/* =================================================================
            LEFT SIDEBAR (White Navigation)
            ================================================================= */}
        <aside className="dash2-sidebar">
          {/* Logo */}
          <div className="dash2-brand">
            <div className="dash2-brand-icon">
              <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
                <rect width="28" height="28" rx="8" fill="#74c022" />
                <path d="M19 10C18 8.5 16.2 8 14 8C10.7 8 8 10.7 8 14C8 17.3 10.7 20 14 20C16.2 20 18 19.5 19 18" stroke="#ffffff" strokeWidth="2.8" strokeLinecap="round" />
              </svg>
            </div>
            <span className="dash2-brand-name">Creativilo</span>
          </div>

          {/* Overview Section */}
          <div className="dash2-nav-group">
            <span className="dash2-nav-label">Overview</span>
            <nav className="dash2-nav-list">
              {/* Dashboard Item (Active) */}
              <button
                className={`dash2-nav-item ${activeNav === 'Dashboard' ? 'nav-item-active' : ''}`}
                onClick={() => setActiveNav('Dashboard')}
              >
                <svg className="dash2-nav-svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <rect x="3" y="3" width="7" height="7" rx="1.5" />
                  <rect x="14" y="3" width="7" height="7" rx="1.5" />
                  <rect x="14" y="14" width="7" height="7" rx="1.5" />
                  <rect x="3" y="14" width="7" height="7" rx="1.5" />
                </svg>
                <span>Dashboard</span>
              </button>

              {/* Projects */}
              <button
                className={`dash2-nav-item ${activeNav === 'Projects' ? 'nav-item-active' : ''}`}
                onClick={() => setActiveNav('Projects')}
              >
                <svg className="dash2-nav-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                </svg>
                <span>Projects</span>
              </button>

              {/* Analytics */}
              <button
                className={`dash2-nav-item ${activeNav === 'Analytics' ? 'nav-item-active' : ''}`}
                onClick={() => setActiveNav('Analytics')}
              >
                <svg className="dash2-nav-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
                  <path d="M22 12A10 10 0 0 0 12 2v10z" />
                </svg>
                <span>Analytics</span>
              </button>

              {/* Reports */}
              <button
                className={`dash2-nav-item ${activeNav === 'Reports' ? 'nav-item-active' : ''}`}
                onClick={() => setActiveNav('Reports')}
              >
                <svg className="dash2-nav-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                  <polyline points="14 2 14 8 20 8" />
                  <line x1="16" y1="13" x2="8" y2="13" />
                  <line x1="16" y1="17" x2="8" y2="17" />
                  <polyline points="10 9 9 9 8 9" />
                </svg>
                <span>Reports</span>
              </button>
            </nav>
          </div>

          {/* Business Section */}
          <div className="dash2-nav-group">
            <span className="dash2-nav-label">Business</span>
            <nav className="dash2-nav-list">
              {/* Store */}
              <button
                className={`dash2-nav-item ${activeNav === 'Store' ? 'nav-item-active' : ''}`}
                onClick={() => setActiveNav('Store')}
              >
                <svg className="dash2-nav-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="9" cy="21" r="1" />
                  <circle cx="20" cy="21" r="1" />
                  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                </svg>
                <span>Store</span>
              </button>

              {/* Outlet */}
              <button
                className={`dash2-nav-item ${activeNav === 'Outlet' ? 'nav-item-active' : ''}`}
                onClick={() => setActiveNav('Outlet')}
              >
                <svg className="dash2-nav-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                  <polyline points="9 22 9 12 15 12 15 22" />
                </svg>
                <span>Outlet</span>
              </button>

              {/* Products */}
              <button
                className={`dash2-nav-item ${activeNav === 'Products' ? 'nav-item-active' : ''}`}
                onClick={() => setActiveNav('Products')}
              >
                <svg className="dash2-nav-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="16.5" y1="9.4" x2="7.5" y2="4.21" />
                  <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                  <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
                  <line x1="12" y1="22.08" x2="12" y2="12" />
                </svg>
                <span>Products</span>
              </button>

              {/* Chat */}
              <button
                className={`dash2-nav-item ${activeNav === 'Chat' ? 'nav-item-active' : ''}`}
                onClick={() => setActiveNav('Chat')}
              >
                <div className="dash2-chat-icon-wrap">
                  <svg className="dash2-nav-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                  </svg>
                  <span className="dash2-chat-red-dot"></span>
                </div>
                <span>Chat</span>
              </button>
            </nav>
          </div>

          {/* Bottom Logout & Footer Watermark */}
          <div className="dash2-sidebar-footer">
            <button className="dash2-logout-btn">
              <svg className="dash2-nav-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <polyline points="16 17 21 12 16 7" />
                <line x1="21" y1="12" x2="9" y2="12" />
              </svg>
              <span>Log Out</span>
            </button>
            <span className="dash2-copyright">@ARSoft.com 2022</span>
          </div>
        </aside>

        {/* =================================================================
            CENTER MAIN CONTENT AREA
            ================================================================= */}
        <main className="dash2-main-area">
          {/* Header */}
          <header className="dash2-header">
            <div className="dash2-header-titles">
              <h1 className="dash2-heading">Dashboard</h1>
              <p className="dash2-subheading">All dwtails about your selling products are here..</p>
            </div>
            <div className="dash2-search-box">
              <input type="text" placeholder="Search" aria-label="Search" />
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#9aa1b4" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
            </div>
          </header>

          {/* Top Lime Stats Banner Card */}
          <section className="dash2-stats-banner">
            {/* Sub-card 1: Total Visits */}
            <div className="dash2-stat-subcard">
              <span className="dash2-stat-title">Total Visits</span>
              <div className="dash2-stat-number-row">
                <span className="dash2-stat-big-num">49.259</span>
              </div>
              <div className="dash2-stat-bottom-row">
                <span className="dash2-growth-pill">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
                    <polyline points="17 6 23 6 23 12" />
                  </svg>
                  <span>+12.05%</span>
                </span>
                <div className="dash2-sparkline-wrap">
                  <svg viewBox="0 0 100 26" className="dash2-sparkline-svg">
                    <path d="M 0 18 Q 15 10 25 18 T 50 14 T 75 8 T 100 16" fill="none" stroke="rgba(255, 255, 255, 0.75)" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Sub-card 2: Bounce Rate */}
            <div className="dash2-stat-subcard">
              <span className="dash2-stat-title">Bounce Rate</span>
              <div className="dash2-stat-number-row">
                <span className="dash2-stat-big-num">21.4</span>
              </div>
              <div className="dash2-stat-bottom-row">
                <span className="dash2-growth-pill">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
                    <polyline points="17 6 23 6 23 12" />
                  </svg>
                  <span>+5.19%</span>
                </span>
                <div className="dash2-sparkline-wrap">
                  <svg viewBox="0 0 100 26" className="dash2-sparkline-svg">
                    <path d="M 0 20 Q 18 16 30 19 T 55 12 T 80 18 T 100 10" fill="none" stroke="rgba(255, 255, 255, 0.75)" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Sub-card 3: Realtime Users */}
            <div className="dash2-stat-subcard">
              <span className="dash2-stat-title">Realtime Users</span>
              <div className="dash2-stat-number-row">
                <span className="dash2-stat-big-num">9.221</span>
              </div>
              <div className="dash2-stat-bottom-row">
                <span className="dash2-growth-pill">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
                    <polyline points="17 6 23 6 23 12" />
                  </svg>
                  <span>+22.01%</span>
                </span>
                <div className="dash2-sparkline-wrap">
                  <svg viewBox="0 0 100 26" className="dash2-sparkline-svg">
                    <path d="M 0 16 Q 16 12 32 18 T 60 8 T 85 18 T 100 12" fill="none" stroke="rgba(255, 255, 255, 0.75)" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
              </div>
            </div>
          </section>

          {/* Middle Row: Revenue & Customers */}
          <section className="dash2-middle-charts-grid">
            {/* Revenue Chart Card */}
            <div className="dash2-card dash2-revenue-card">
              <div className="dash2-card-header">
                <h3 className="dash2-card-title">Revenue</h3>
                <div className="dash2-chart-legend">
                  <span className="legend-item">
                    <span className="legend-dot dot-green"></span>
                    <span>This week</span>
                  </span>
                  <span className="legend-item">
                    <span className="legend-dot dot-orange"></span>
                    <span>Last week</span>
                  </span>
                </div>
              </div>

              {/* Chart SVG */}
              <div className="dash2-revenue-chart-wrap">
                {/* Y-Axis Labels */}
                <div className="dash2-y-axis">
                  <span>50K</span>
                  <span>40K</span>
                  <span>30K</span>
                  <span>20K</span>
                  <span>10K</span>
                  <span>0</span>
                </div>

                {/* Graph Area */}
                <div className="dash2-graph-container">
                  <svg viewBox="0 0 380 150" className="dash2-revenue-svg" preserveAspectRatio="none">
                    {/* Horizontal Grid lines */}
                    <line x1="0" y1="10" x2="380" y2="10" stroke="#f1f5f9" strokeWidth="1" />
                    <line x1="0" y1="38" x2="380" y2="38" stroke="#f1f5f9" strokeWidth="1" />
                    <line x1="0" y1="66" x2="380" y2="66" stroke="#f1f5f9" strokeWidth="1" />
                    <line x1="0" y1="94" x2="380" y2="94" stroke="#f1f5f9" strokeWidth="1" />
                    <line x1="0" y1="122" x2="380" y2="122" stroke="#f1f5f9" strokeWidth="1" />
                    <line x1="0" y1="150" x2="380" y2="150" stroke="#f1f5f9" strokeWidth="1" />

                    {/* Translucent Highlight Bar on Wednesday */}
                    <rect x="180" y="45" width="18" height="105" rx="9" fill="#f0f9e8" />

                    {/* Green Smooth Revenue Curve */}
                    <path
                      d="M 10 108 C 45 110 65 125 100 120 C 135 115 155 52 189 50 C 220 48 240 68 270 56 C 300 45 320 88 360 82"
                      fill="none"
                      stroke="#74c022"
                      strokeWidth="3.2"
                      strokeLinecap="round"
                    />

                    {/* Peak Point on Wednesday */}
                    <circle cx="189" cy="50" r="4.5" fill="#ffffff" stroke="#74c022" strokeWidth="2.5" />
                  </svg>

                  {/* Tooltip Badge: $28.2K */}
                  <div className="dash2-chart-tooltip" style={{ left: '46%', top: '16%' }}>
                    $28.2K
                  </div>

                  {/* X-Axis Labels */}
                  <div className="dash2-x-axis">
                    <span>Sun</span>
                    <span>Mon</span>
                    <span>Tue</span>
                    <span>Wed</span>
                    <span>Thu</span>
                    <span>Fri</span>
                    <span>Sat</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Customers Donut Card */}
            <div className="dash2-card dash2-customers-card">
              <div className="dash2-card-header">
                <h3 className="dash2-card-title">Customers</h3>
              </div>

              {/* Segmented Donut */}
              <div className="dash2-donut-wrapper">
                <div className="dash2-donut-chart">
                  <svg viewBox="0 0 120 120" className="dash2-donut-svg">
                    {/* Background Ring */}
                    <circle cx="60" cy="60" r="45" fill="none" stroke="#f1f5f9" strokeWidth="10" />

                    {/* Orange Arc (New Customers - Top Right) */}
                    <circle
                      cx="60"
                      cy="60"
                      r="45"
                      fill="none"
                      stroke="#f59e0b"
                      strokeWidth="10"
                      strokeDasharray="68 283"
                      strokeDashoffset="-20"
                      strokeLinecap="round"
                    />

                    {/* Green Arc (Current Customers - Left & Bottom) */}
                    <circle
                      cx="60"
                      cy="60"
                      r="45"
                      fill="none"
                      stroke="#74c022"
                      strokeWidth="10"
                      strokeDasharray="115 283"
                      strokeDashoffset="-120"
                      strokeLinecap="round"
                    />
                  </svg>

                  {/* Center Text */}
                  <div className="dash2-donut-center">
                    <span className="dash2-donut-percent">37%</span>
                    <span className="dash2-donut-sub">Total</span>
                  </div>
                </div>

                {/* Legend */}
                <div className="dash2-customers-legend">
                  <span className="legend-item">
                    <span className="legend-dot dot-green"></span>
                    <span>Current Customers</span>
                  </span>
                  <span className="legend-item">
                    <span className="legend-dot dot-orange"></span>
                    <span>New Customers</span>
                  </span>
                </div>
              </div>
            </div>
          </section>

          {/* Bottom Card: Recent Transaction */}
          <section className="dash2-card dash2-transaction-card">
            <div className="dash2-card-header">
              <h3 className="dash2-card-title">Recent Transaction</h3>
              <button className="dash2-view-all-link">View All</button>
            </div>

            <div className="dash2-table-container">
              <table className="dash2-transaction-table">
                <thead>
                  <tr>
                    <th>Transaction ID</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {/* Row 1 */}
                  <tr>
                    <td>
                      <div className="dash2-id-cell">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="12" y1="19" x2="12" y2="5" />
                          <polyline points="5 12 12 5 19 12" />
                        </svg>
                        <span>#2020912</span>
                      </div>
                    </td>
                    <td>Apr 29, 2022, 11:37</td>
                    <td className="amount-val">-$299,89</td>
                    <td>
                      <span className="status-pill status-pending">Pending</span>
                    </td>
                  </tr>

                  {/* Row 2 */}
                  <tr>
                    <td>
                      <div className="dash2-id-cell">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#74c022" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="12" y1="19" x2="12" y2="5" />
                          <polyline points="5 12 12 5 19 12" />
                        </svg>
                        <span>#2020911</span>
                      </div>
                    </td>
                    <td>Apr 29, 2022, 11:37</td>
                    <td className="amount-val">-$130,15</td>
                    <td>
                      <span className="status-pill status-completed">Completed</span>
                    </td>
                  </tr>

                  {/* Row 3 */}
                  <tr>
                    <td>
                      <div className="dash2-id-cell">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#06b6d4" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="12" y1="19" x2="12" y2="5" />
                          <polyline points="5 12 12 5 19 12" />
                        </svg>
                        <span>#2020910</span>
                      </div>
                    </td>
                    <td>Apr 29, 2022, 11:36</td>
                    <td className="amount-val">-$458,13</td>
                    <td>
                      <span className="status-pill status-scheduled">Scheduled</span>
                    </td>
                  </tr>

                  {/* Row 4 */}
                  <tr>
                    <td>
                      <div className="dash2-id-cell">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#74c022" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="12" y1="19" x2="12" y2="5" />
                          <polyline points="5 12 12 5 19 12" />
                        </svg>
                        <span>#2020909</span>
                      </div>
                    </td>
                    <td>Apr 29, 2022, 11:36</td>
                    <td className="amount-val">-$210,99</td>
                    <td>
                      <span className="status-pill status-completed">Completed</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        </main>

        {/* =================================================================
            RIGHT SIDEBAR (Dark Profile & Earnings Panel)
            ================================================================= */}
        <aside className="dash2-profile-sidebar">
          {/* Header */}
          <div className="dash2-profile-header">
            <h3 className="dash2-profile-title">Profile</h3>
            <div className="dash2-profile-top-icons">
              {/* Bell Icon with red dot (No background) */}
              <button className="profile-raw-icon-btn" aria-label="Notifications">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                  <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                </svg>
                <span className="profile-bell-dot"></span>
              </button>

              {/* Gear Icon (No background) */}
              <button className="profile-raw-icon-btn" aria-label="Settings">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3" />
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
                </svg>
              </button>
            </div>
          </div>

          {/* Profile Card / Cover */}
          <div className="dash2-user-profile-block">
            {/* Banner Cover */}
            <div className="dash2-profile-banner">
              <svg viewBox="0 0 240 80" className="banner-pattern-svg">
                <rect width="240" height="80" fill="#74c022" rx="16" />
                {/* Abstract geometric squares */}
                <rect x="20" y="20" width="36" height="36" rx="8" fill="rgba(255, 255, 255, 0.18)" transform="rotate(45 38 38)" />
                <rect x="44" y="10" width="46" height="46" rx="10" fill="rgba(255, 255, 255, 0.22)" transform="rotate(45 67 33)" />
                <line x1="80" y1="10" x2="200" y2="70" stroke="rgba(255, 255, 255, 0.2)" strokeWidth="1.5" />
                <line x1="120" y1="5" x2="230" y2="60" stroke="rgba(255, 255, 255, 0.15)" strokeWidth="1.5" />
                <circle cx="178" cy="40" r="3" fill="rgba(255, 255, 255, 0.5)" />
                <circle cx="195" cy="55" r="4" fill="rgba(255, 255, 255, 0.4)" />
              </svg>
              {/* Camera Icon (No background) */}
              <button className="banner-camera-btn" aria-label="Change banner">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
                  <circle cx="12" cy="13" r="4" />
                </svg>
              </button>
            </div>

            {/* Avatar & User Details */}
            <div className="dash2-avatar-wrap">
              <img
                src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=160&auto=format&fit=crop&q=80"
                alt="John Doe"
                className="dash2-user-avatar"
              />
            </div>

            <h4 className="dash2-user-name">John Doe</h4>
            <p className="dash2-tasks-completed-text">5 from 8 tasks completed</p>

            {/* Segmented Task Progress Bar */}
            <div className="dash2-segmented-progress">
              <span className="seg-dash seg-filled"></span>
              <span className="seg-dash seg-filled"></span>
              <span className="seg-dash seg-filled"></span>
              <span className="seg-dash seg-filled"></span>
              <span className="seg-dash seg-filled"></span>
              <span className="seg-dash seg-empty"></span>
              <span className="seg-dash seg-empty"></span>
              <span className="seg-dash seg-empty"></span>
            </div>

            {/* User Stats (Products, Followers, Sales) */}
            <div className="dash2-user-stats-row">
              <div className="user-stat-col">
                <span className="user-stat-val">1.8K</span>
                <span className="user-stat-lbl">Products</span>
              </div>
              <div className="user-stat-divider"></div>
              <div className="user-stat-col">
                <span className="user-stat-val">3.2M</span>
                <span className="user-stat-lbl">Followers</span>
              </div>
              <div className="user-stat-divider"></div>
              <div className="user-stat-col">
                <span className="user-stat-val">75.2K</span>
                <span className="user-stat-lbl">Sales</span>
              </div>
            </div>

            {/* Edit Profile Button */}
            <button className="dash2-edit-profile-btn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
              </svg>
              <span>Edit Profile</span>
            </button>
          </div>

          {/* Earning Card */}
          <div className="dash2-earning-section">
            <div className="dash2-earning-header">
              <h4 className="dash2-earning-title">Earning</h4>
              {/* Info Icon (No background) */}
              <button className="earning-raw-info-btn" aria-label="Info">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="16" x2="12" y2="12" />
                  <line x1="12" y1="8" x2="12.01" y2="8" />
                </svg>
              </button>
            </div>

            <div className="dash2-earning-inner-card">
              {/* Lime Wallet Icon (NO Background Color on icon!) */}
              <div className="dash2-earning-icon-holder">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#74c022" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="6" width="20" height="14" rx="3" fill="#74c022" fillOpacity="0.15" />
                  <path d="M19 12H15a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h4" />
                  <circle cx="16" cy="14" r="1" fill="#74c022" />
                  <path d="M6 6V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v2" />
                </svg>
              </div>

              <span className="dash2-earning-amount">$95,000</span>
              <span className="dash2-earning-subtext">Your earning this month</span>
            </div>

            <p className="dash2-earning-help-note">Update your payment method in settings</p>

            <button className="dash2-withdraw-btn">
              Withdraw Earning
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}
