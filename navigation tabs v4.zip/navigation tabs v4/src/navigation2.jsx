"use client";

import {
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  AnimatePresence,
} from "framer-motion";
import React, { useEffect, useRef, useState } from "react";
import { cn } from "@/components/lib/utils";

function useDockItemAnimation(
  mouseX,
  baseItemSize,
  magnification,
  distance,
  maxLift,
  ref,
  spring
) {
  const mouseDistance = useTransform(mouseX, (val) => {
    if (typeof val !== "number" || isNaN(val) || !isFinite(val)) {
      return distance * 2;
    }
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return distance * 2;
    const centerX = rect.x + rect.width / 2;
    return val - centerX;
  });

  const targetSize = useTransform(
    mouseDistance,
    [-distance, 0, distance],
    [baseItemSize, magnification, baseItemSize],
    { clamp: true }
  );

  const targetY = useTransform(
    mouseDistance,
    [-distance, 0, distance],
    [0, -maxLift, 0],
    { clamp: true }
  );

  const size = useSpring(targetSize, spring);
  const y = useSpring(targetY, spring);

  return { size, y };
}

function DockItem({
  icon,
  label,
  onClick,
  mouseX,
  baseItemSize,
  magnification,
  distance,
  maxLift = 15,
  spring,
  badgeCount,
  badgeColor = "bg-red-500",
  itemBackground,
  itemBorderColor,
  borderRadius,
  hideLabels = false,
  labelPosition = "top",
  labelBackground,
  labelTextColor,
}) {
  const ref = useRef(null);
  const isHovered = useMotionValue(0);
  const { size, y } = useDockItemAnimation(
    mouseX,
    baseItemSize,
    magnification,
    distance,
    maxLift,
    ref,
    spring
  );
  const [showLabel, setShowLabel] = useState(false);

  useEffect(() => {
    const unsubscribe = isHovered.on("change", (value) =>
      setShowLabel(value === 1)
    );
    return () => unsubscribe();
  }, [isHovered]);

  const labelOffsetStyle =
    labelPosition === "bottom"
      ? { top: "calc(100% + 10px)", bottom: "auto" }
      : { bottom: "calc(100% + 10px)", top: "auto" };

  return (
    <motion.div
      ref={ref}
      style={{ width: size, height: size, y }}
      onHoverStart={() => isHovered.set(1)}
      onHoverEnd={() => isHovered.set(0)}
      onFocus={() => isHovered.set(1)}
      onBlur={() => isHovered.set(0)}
      onClick={onClick}
      className={cn(
        "dock-item relative inline-flex items-center justify-center cursor-pointer select-none shrink-0",
        borderRadius ?? "rounded-full",
        itemBackground ?? "bg-background",
        itemBorderColor ? `border-2 ${itemBorderColor}` : ""
      )}
      tabIndex={0}
      role="button"
      aria-label={label}
      aria-haspopup="true"
    >
      <div className="dock-icon-wrapper flex items-center justify-center w-full h-full">
        {icon}
      </div>

      {/* Optional Badge (only renders if badgeCount is provided) */}
      {badgeCount !== undefined && badgeCount !== null && badgeCount > 0 && (
        <span
          className={cn(
            "dock-badge absolute text-white font-bold leading-none pointer-events-none",
            badgeColor
          )}
        >
          {badgeCount > 99 ? "99+" : badgeCount}
        </span>
      )}

      {/* Tooltip Label — perfectly centered above lifted icon */}
      {!hideLabels && (
        <AnimatePresence>
          {showLabel && (
            <motion.div
              initial={{
                opacity: 0,
                y: labelPosition === "bottom" ? -4 : 4,
                scale: 0.92,
                x: "-50%",
              }}
              animate={{
                opacity: 1,
                y: 0,
                scale: 1,
                x: "-50%",
              }}
              exit={{
                opacity: 0,
                y: labelPosition === "bottom" ? -4 : 4,
                scale: 0.92,
                x: "-50%",
              }}
              transition={{ duration: 0.15, ease: "easeOut" }}
              className={cn(
                "dock-tooltip",
                labelBackground ?? "bg-black",
                labelTextColor ?? "text-white"
              )}
              style={labelOffsetStyle}
              role="tooltip"
            >
              {label}
            </motion.div>
          )}
        </AnimatePresence>
      )}
    </motion.div>
  );
}

export default function Dock({
  items,
  className = "",
  spring = { mass: 0.08, stiffness: 180, damping: 16 },
  magnification = 74,
  distance = 140,
  maxLift = 15,
  panelHeight = 72,
  baseItemSize = 54,
  gap = "gap-3",
  itemBackground,
  itemBorderColor,
  borderRadius,
  badgeColor = "bg-red-500",
  hideLabels = false,
  labelPosition = "top",
  labelBackground,
  labelTextColor,
  blurBackground = false,
  multiBorder = true,
  showSeparator = false,
  separatorIndex,
}) {
  const mouseX = useMotionValue(Infinity);
  const isHovered = useMotionValue(0);

  return (
    <div className="dock-container-wrapper relative flex items-center justify-center">
      <motion.div
        onMouseMove={({ pageX }) => {
          isHovered.set(1);
          mouseX.set(pageX);
        }}
        onMouseLeave={() => {
          isHovered.set(0);
          mouseX.set(Infinity);
        }}
        className={cn(
          "dock-outer-bar flex items-center justify-center w-fit select-none",
          multiBorder ? "dock-multi-border" : "",
          className
        )}
        style={{ height: panelHeight }}
        role="toolbar"
        aria-label="Application dock"
      >
        <div
          className={cn(
            "dock-inner-bar flex items-center w-fit",
            gap,
            multiBorder
              ? "dock-inner-multi"
              : blurBackground
              ? "bg-white/10 backdrop-blur-xl border-2 border-white/20 shadow-md"
              : "bg-background border-2 border-border shadow-md"
          )}
        >
          {items.map((item, index) => (
            <React.Fragment key={index}>
              <DockItem
                icon={item.icon}
                label={item.label}
                onClick={item.onClick}
                mouseX={mouseX}
                baseItemSize={baseItemSize}
                magnification={magnification}
                distance={distance}
                maxLift={maxLift}
                spring={spring}
                badgeCount={item.badgeCount}
                badgeColor={badgeColor}
                itemBackground={itemBackground}
                itemBorderColor={itemBorderColor}
                borderRadius={borderRadius}
                hideLabels={hideLabels}
                labelPosition={labelPosition}
                labelBackground={labelBackground}
                labelTextColor={labelTextColor}
              />
              {showSeparator && separatorIndex === index && (
                <div className="self-center h-8 w-px bg-zinc-300 mx-1 shrink-0" />
              )}
            </React.Fragment>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

export { Dock };
