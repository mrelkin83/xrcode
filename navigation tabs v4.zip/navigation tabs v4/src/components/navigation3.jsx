import React, { useState } from 'react';
import {
  Command,
  BarChart3,
  FileText,
  MessageSquare,
  Bell,
  Settings,
  Maximize2,
  Minimize2,
  Moon,
  Sun,
  RotateCw,
  User,
  LogOut,
  ChevronUp,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import './navigation3.css';

export default function Navigation3() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeTab, setActiveTab] = useState('analytics');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Fullscreen toggle
  const toggleFullscreen = (e) => {
    e.stopPropagation();
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
      setIsFullscreen(false);
    }
  };

  // Theme toggle
  const toggleTheme = (e) => {
    e.stopPropagation();
    setIsDarkMode((prev) => !prev);
    document.documentElement.classList.toggle('dark');
  };

  // Refresh animation
  const handleRefresh = (e) => {
    e.stopPropagation();
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 800);
  };

  const navTabs = [
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'docs', label: 'Documents', icon: FileText },
    { id: 'chat', label: 'Messages', icon: MessageSquare, badge: '3' },
    { id: 'alerts', label: 'Alerts', icon: Bell, badge: '5' },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="dynamic-island-wrapper">
      <motion.div
        layout
        transition={{
          type: 'spring',
          stiffness: 380,
          damping: 28,
          mass: 0.8,
        }}
        className={`dynamic-island ${isExpanded ? 'expanded' : 'compact'}`}
        onClick={() => !isExpanded && setIsExpanded(true)}
        role="region"
        aria-label="Apple Dynamic Island Navigation"
      >
        <AnimatePresence mode="wait">
          {!isExpanded ? (
            /* COMPACT DYNAMIC ISLAND STATE */
            <motion.div
              key="compact-island"
              initial={{ opacity: 0, scale: 0.94 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.94 }}
              transition={{ duration: 0.16 }}
              className="island-compact-content"
            >
              {/* Left: ⌘ Codexr Badge + Green Live Dot */}
              <div className="island-compact-left">
                <span className="compact-cmd-badge">
                  <Command size={12} strokeWidth={2.4} />
                </span>
                <span className="compact-title">Codexr</span>
                <span className="compact-live-dot" />
              </div>

              {/* Center: Interactive Hint */}
              <div className="island-compact-center">
                <span className="compact-subtitle">Dashboard</span>
              </div>

              {/* Right: Quick Action / Avatar Indicator */}
              <div className="island-compact-right">
                <div className="compact-avatar-dot">
                  <User size={12} strokeWidth={2.2} />
                </div>
                <span className="compact-expand-hint">Tap</span>
              </div>
            </motion.div>
          ) : (
            /* EXPANDED DYNAMIC ISLAND STATE */
            <motion.div
              key="expanded-island"
              initial={{ opacity: 0, y: 8, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.96 }}
              transition={{ duration: 0.22, delay: 0.05 }}
              className="island-expanded-content"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Top Row: Workspace Info + Collapse Button */}
              <div className="island-header-row">
                <div className="island-workspace-tag">
                  <div className="island-cmd-icon">
                    <Command size={14} strokeWidth={2.4} />
                  </div>
                  <div className="island-workspace-meta">
                    <span className="island-ws-name">Codexr</span>
                    <span className="island-ws-plan">PRO</span>
                  </div>
                </div>

                <div className="island-header-right">
                  {/* Collapse Button */}
                  <button
                    className="island-collapse-btn"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsExpanded(false);
                    }}
                    title="Collapse Dynamic Island"
                    aria-label="Collapse"
                  >
                    <ChevronUp size={16} strokeWidth={2.4} />
                  </button>
                </div>
              </div>

              {/* Middle Row: Professional Navigation Icon Tabs */}
              <div className="island-nav-tabs-row" role="tablist">
                {navTabs.map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;

                  return (
                    <motion.button
                      key={tab.id}
                      role="tab"
                      aria-selected={isActive}
                      onClick={() => setActiveTab(tab.id)}
                      className={`island-tab-btn ${isActive ? 'active' : ''}`}
                      whileHover={{ scale: 1.06 }}
                      whileTap={{ scale: 0.94 }}
                    >
                      <div className="island-tab-icon-wrap">
                        <Icon size={18} strokeWidth={isActive ? 2.3 : 1.9} />
                        {tab.badge && (
                          <span className="island-tab-badge">{tab.badge}</span>
                        )}
                      </div>
                      <span className="island-tab-label">{tab.label}</span>
                      {isActive && (
                        <motion.div
                          layoutId="island-active-dot"
                          className="island-active-indicator"
                          transition={{
                            type: 'spring',
                            stiffness: 400,
                            damping: 30,
                          }}
                        />
                      )}
                    </motion.button>
                  );
                })}
              </div>

              {/* Bottom Row: Quick Tools & Sign Out */}
              <div className="island-footer-row">
                {/* Left: Quick Island Tools */}
                <div className="island-tools-group">
                  <button
                    className="island-tool-btn"
                    onClick={toggleFullscreen}
                    title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
                    aria-label="Fullscreen"
                  >
                    {isFullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
                  </button>

                  <button
                    className="island-tool-btn"
                    onClick={toggleTheme}
                    title={isDarkMode ? 'Light Mode' : 'Dark Mode'}
                    aria-label="Theme"
                  >
                    {isDarkMode ? <Sun size={15} /> : <Moon size={15} />}
                  </button>

                  <button
                    className="island-tool-btn"
                    onClick={handleRefresh}
                    title="Refresh"
                    aria-label="Reload"
                  >
                    <motion.div
                      animate={isRefreshing ? { rotate: 360 } : { rotate: 0 }}
                      transition={{ duration: 0.6, ease: 'easeInOut' }}
                      className="flex items-center justify-center"
                    >
                      <RotateCw size={15} />
                    </motion.div>
                  </button>
                </div>

                {/* Right: Sign Out User Button */}
                <button
                  className="island-signout-btn"
                  onClick={() => alert('Signed out from Codexr')}
                  title="Sign out"
                  aria-label="Sign out"
                >
                  <div className="island-user-circle">
                    <User size={13} strokeWidth={2.2} />
                  </div>
                  <span className="island-signout-text">Sign out</span>
                  <LogOut size={13} strokeWidth={2.2} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
