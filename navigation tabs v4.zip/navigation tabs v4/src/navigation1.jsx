import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './navigation1.css';

// SVG Icons matching reference design aesthetic
const HomeIcon = ({ active }) => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="currentColor"
    className="nav-icon"
  >
    {active ? (
      <path d="M12 2.6L2.6 10.4C2.3 10.65 2.1 11.05 2.1 11.48V19.8C2.1 20.46 2.64 21 3.3 21H8.8C9.24 21 9.6 20.64 9.6 20.2V15C9.6 14.45 10.05 14 10.6 14H13.4C13.95 14 14.4 14.45 14.4 15V20.2C14.4 20.64 14.76 21 15.2 21H20.7C21.36 21 21.9 20.46 21.9 19.8V11.48C21.9 11.05 21.7 10.65 21.4 10.4L12 2.6Z" />
    ) : (
      <path
        d="M12 3.2L3.5 10.3V19.5C3.5 20.33 4.17 21 5 21H9.4C9.73 21 10 20.73 10 20.4V15.5C10 14.67 10.67 14 11.5 14H12.5C13.33 14 14 14.67 14 15.5V20.4C14 20.73 14.27 21 14.6 21H19C19.83 21 20.5 20.33 20.5 19.5V10.3L12 3.2Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.9"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    )}
  </svg>
);

const SearchIcon = ({ active }) => (
  <div className="nav-search-wrapper">
    <motion.div
      key={active ? 'active-search' : 'idle-search'}
      animate={
        active
          ? {
              scale: [1, 0.72, 1.36, 0.9, 1.12, 1],
              rotate: [0, -18, 14, -8, 4, 0],
            }
          : { scale: 1, rotate: 0 }
      }
      transition={{
        duration: 0.55,
        ease: [0.175, 0.885, 0.32, 1.275],
      }}
      className="nav-search-inner"
    >
      <svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.9"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="nav-icon"
      >
        <circle cx="11" cy="11" r="7" />
        <path d="M21 21L16.2 16.2" strokeWidth="2.1" />
      </svg>
    </motion.div>
  </div>
);

const HeartIcon = ({ active }) => (
  <div className="nav-heart-wrapper">
    <motion.div
      key={active ? 'active-heart' : 'idle-heart'}
      animate={
        active
          ? {
              scale: [1, 0.68, 1.45, 0.88, 1.15, 1],
              rotate: [0, -14, 14, -6, 4, 0],
            }
          : { scale: 1, rotate: 0 }
      }
      transition={{
        duration: 0.55,
        ease: [0.175, 0.885, 0.32, 1.275],
      }}
      className="nav-heart-inner"
    >
      <svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill={active ? 'url(#pinkPurpleGradient)' : 'none'}
        stroke={active ? 'url(#pinkPurpleGradient)' : 'currentColor'}
        strokeWidth="1.9"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="nav-icon"
        style={{
          filter: active
            ? 'drop-shadow(0 0 7px rgba(236, 72, 153, 0.75)) drop-shadow(0 0 12px rgba(168, 85, 247, 0.5))'
            : 'none',
          transition: 'fill 0.25s ease, stroke 0.25s ease',
        }}
      >
        <defs>
          <linearGradient id="pinkPurpleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#f43f5e" />
            <stop offset="40%" stopColor="#ec4899" />
            <stop offset="70%" stopColor="#d946ef" />
            <stop offset="100%" stopColor="#8b5cf6" />
          </linearGradient>
        </defs>
        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
      </svg>
    </motion.div>

    {/* Sparkle burst particles in neon pink and electric purple */}
    {active && (
      <span className="heart-sparkles-wrap" aria-hidden="true">
        {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => {
          const rad = (angle * Math.PI) / 180;
          const dist = 15;
          const x = Math.cos(rad) * dist;
          const y = Math.sin(rad) * dist;
          const colors = [
            '#ec4899',
            '#a855f7',
            '#f43f5e',
            '#c084fc',
            '#d946ef',
            '#8b5cf6',
            '#fb7185',
            '#e879f9',
          ];

          return (
            <motion.span
              key={i}
              initial={{ opacity: 1, scale: 0, x: 0, y: 0 }}
              animate={{ opacity: [1, 1, 0], scale: [0, 1.35, 0], x, y }}
              transition={{ duration: 0.52, ease: 'easeOut' }}
              className="heart-sparkle-dot"
              style={{
                backgroundColor: colors[i % colors.length],
                boxShadow: `0 0 6px ${colors[i % colors.length]}`,
              }}
            />
          );
        })}
      </span>
    )}
  </div>
);

const BellIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.9"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="nav-icon"
  >
    <path d="M6 9C6 5.68 8.69 3 12 3C15.31 3 18 5.68 18 9V14.5L19.5 17H4.5L6 14.5V9Z" />
    <path d="M10 19.5C10.3 20.4 11.1 21 12 21C12.9 21 13.7 20.4 14 19.5" />
  </svg>
);

const BagIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.9"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="nav-icon"
  >
    <path d="M9 8V6.5C9 4.84 10.34 3.5 12 3.5C13.66 3.5 15 4.84 15 6.5V8" />
    <path d="M5.5 8H18.5C19.5 8 20.35 8.9 20.15 9.9L19.05 18.2C18.85 19.5 17.7 20.5 16.4 20.5H7.6C6.3 20.5 5.15 19.5 4.95 18.2L3.85 9.9C3.65 8.9 4.5 8 5.5 8Z" />
    <circle cx="10" cy="14.2" r="0.9" fill="currentColor" stroke="none" />
    <circle cx="14.2" cy="14.2" r="0.9" fill="currentColor" stroke="none" />
  </svg>
);

const UserIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.9"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="nav-icon"
  >
    <circle cx="12" cy="7.2" r="3.6" />
    <rect x="6.2" y="14.8" width="11.6" height="5.4" rx="2.7" />
  </svg>
);

const NAV_ITEMS = [
  { id: 'home', label: 'Home', icon: HomeIcon },
  { id: 'search', label: 'Explore', icon: SearchIcon },
  { id: 'likes', label: 'Likes', icon: HeartIcon },
  { id: 'notifications', label: 'Alerts', icon: BellIcon },
  { id: 'bag', label: 'Bag', icon: BagIcon },
  { id: 'profile', label: 'Profile', icon: UserIcon },
];

export default function Navigation1() {
  const [activeTab, setActiveTab] = useState('home');

  return (
    <div className="nav-wrapper">
      <nav
        className="nav-container"
        role="tablist"
        aria-label="Navigation Tabs"
      >
        {NAV_ITEMS.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;

          return (
            <motion.button
              key={tab.id}
              role="tab"
              aria-selected={isActive}
              tabIndex={0}
              className={`nav-tab-btn ${isActive ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
              layout
              transition={{
                layout: {
                  type: 'spring',
                  stiffness: 400,
                  damping: 34,
                },
              }}
              whileTap={{ scale: 0.94 }}
            >
              {/* Sliding Dark Pill Background */}
              {isActive && (
                <motion.div
                  layoutId="active-nav-indicator"
                  className={`nav-active-pill ${tab.id === 'likes' ? 'likes-active' : ''}`}
                  transition={{
                    type: 'spring',
                    stiffness: 420,
                    damping: 34,
                  }}
                />
              )}

              {/* Tab Content Layer */}
              <div className="nav-content-layer">
                <span className="nav-icon-wrapper">
                  <Icon active={isActive} />
                </span>

                <AnimatePresence mode="popLayout" initial={false}>
                  {isActive && (
                    <motion.span
                      className="nav-label"
                      initial={{ opacity: 0, scale: 0.9, x: -4 }}
                      animate={{ opacity: 1, scale: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.9, x: -4 }}
                      transition={{
                        duration: 0.18,
                        ease: [0.16, 1, 0.3, 1],
                      }}
                    >
                      {tab.label}
                    </motion.span>
                  )}
                </AnimatePresence>
              </div>
            </motion.button>
          );
        })}
      </nav>
    </div>
  );
}
