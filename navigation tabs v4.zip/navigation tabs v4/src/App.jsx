import Navigation1 from './navigation1';
import Dock from './navigation2';
import Navigation3 from './components/navigation3';
import {
  Home,
  FileText,
  Mail,
  Calendar,
  Music,
  LayoutGrid,
  Settings,
  User,
} from 'lucide-react';
import './navigation2.css';
import './App.css';

const dockItems = [
  { icon: <Home />, label: 'Home', onClick: () => {} },
  { icon: <FileText />, label: 'Documents', onClick: () => {} },
  { icon: <Mail />, label: 'Messages', onClick: () => {} },
  { icon: <Calendar />, label: 'Calendar', onClick: () => {} },
  { icon: <Music />, label: 'Music', onClick: () => {} },
  { icon: <LayoutGrid />, label: 'Apps', onClick: () => {} },
  { icon: <Settings />, label: 'Settings', onClick: () => {} },
  { icon: <User />, label: 'Profile', onClick: () => {} },
];

function App() {
  return (
    <main className="app-layout">
      {/* 1st Navigation */}
      <section className="nav-section">
        <Navigation1 />
      </section>

      {/* 2nd Navigation (Dock) */}
      <section className="dock-section">
        <Dock
          items={dockItems}
          showSeparator={false}
          baseItemSize={54}
          magnification={74}
          maxLift={15}
          distance={140}
        />
      </section>

      {/* 3rd Navigation: Apple Dynamic Island (Below 2nd Navigation) */}
      <section className="dynamic-island-section">
        <Navigation3 />
      </section>
    </main>
  );
}

export default App;
