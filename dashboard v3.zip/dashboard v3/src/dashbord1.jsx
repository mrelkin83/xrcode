import { useState } from 'react';
import MacDock from './MacDock.jsx';
import './dashbord1.css';

export default function Dashbord1({ onSwitchToDashboard2 }) {
  // Navigation & View routing state
  // views: 'projects' | 'home' | 'invoices' | 'settings' | 'messages' | 'downloads' | 'bookmarks' | 'location' | 'favorites'
  const [currentView, setCurrentView] = useState('projects');
  const [viewHistory, setViewHistory] = useState(['projects']);

  // View Navigation helper
  const navigateTo = (viewName, label) => {
    setCurrentView(viewName);
    setViewHistory(prev => [...prev, viewName]);
    if (label) showToast(`Navigated to ${label}`);
  };

  const handleBack = () => {
    if (viewHistory.length > 1) {
      const newHistory = [...viewHistory];
      newHistory.pop();
      const prevView = newHistory[newHistory.length - 1];
      setViewHistory(newHistory);
      setCurrentView(prevView);
      showToast(`Returned to ${getViewTitle(prevView)}`);
    } else {
      setCurrentView('projects');
      showToast('Returned to My Profile');
    }
  };

  const getViewTitle = (view) => {
    switch (view) {
      case 'home': return 'Dashboard Overview';
      case 'projects': return 'My Profile & Projects';
      case 'invoices': return 'Invoices & Financials';
      case 'settings': return 'Account Settings';
      case 'messages': return 'Messages & Inbox';
      case 'downloads': return 'Deliverables & Downloads';
      case 'bookmarks': return 'Saved Bookmarks';
      case 'location': return 'Team Locations & Hubs';
      case 'favorites': return 'Starred & Favorites';
      default: return 'My Profile';
    }
  };

  // Toast feedback state
  const [toast, setToast] = useState({ show: false, message: '', type: 'info' });
  const showToast = (message, type = 'info') => {
    setToast({ show: true, message, type });
    setTimeout(() => {
      setToast({ show: false, message: '', type: 'info' });
    }, 2800);
  };

  // Interactive header states
  const [notificationCount, setNotificationCount] = useState(2);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [menuDrawerOpen, setMenuDrawerOpen] = useState(false);
  const [storageModalOpen, setStorageModalOpen] = useState(false);

  // Projects view interactive states
  const [isOnline, setIsOnline] = useState(true);
  const [statusFilter, setStatusFilter] = useState('Pending');
  const [projectDropdownOpen, setProjectDropdownOpen] = useState(false);
  const [selectedProjectCategory, setSelectedProjectCategory] = useState('Ongoing Projects');
  const [isFavoriteActive, setIsFavoriteActive] = useState(false);
  const [isFilterActive, setIsFilterActive] = useState(false);
  const [meetingsCount, setMeetingsCount] = useState(3);
  const [activeInbox, setActiveInbox] = useState(1);

  // Calendar interactive states
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const [monthIndex, setMonthIndex] = useState(2); // March
  const [selectedDay, setSelectedDay] = useState(5);

  const handlePrevMonth = () => {
    setMonthIndex((prev) => (prev === 0 ? 11 : prev - 1));
    showToast(`Navigated to ${months[monthIndex === 0 ? 11 : monthIndex - 1]}`);
  };

  const handleNextMonth = () => {
    setMonthIndex((prev) => (prev === 11 ? 0 : prev + 1));
    showToast(`Navigated to ${months[monthIndex === 11 ? 0 : monthIndex + 1]}`);
  };

  const calendarDays = [
    { day: 1, type: 'light' },
    { day: 2, type: 'light' },
    { day: 3, type: 'light' },
    { day: 4, type: 'light' },
    { day: 5, type: 'coral' },
    { day: 6, type: 'slate' },
    { day: 7, type: 'charcoal' },
    { day: 8, type: 'charcoal' },
    { day: 9, type: 'light' },
    { day: 10, type: 'light' },
    { day: 11, type: 'light' },
    { day: 12, type: 'blue' },
    { day: 13, type: 'medium-gray' },
    { day: 14, type: 'light' },
    { day: 15, type: 'medium-gray' },
    { day: 16, type: 'light' },
    { day: 17, type: 'charcoal' },
    { day: 18, type: 'medium-gray' },
    { day: 19, type: 'light' },
    { day: 20, type: 'charcoal' },
    { day: 21, type: 'light' },
    { day: 22, type: 'light' },
    { day: 23, type: 'yellow' },
    { day: 24, type: 'light' },
    { day: 25, type: 'charcoal' },
    { day: 26, type: 'light' },
    { day: 27, type: 'indigo' },
    { day: 28, type: 'light' },
  ];

  // Invoices Interactive State
  const [invoiceFilter, setInvoiceFilter] = useState('All');
  const [invoicesList, setInvoicesList] = useState([
    { id: 'INV-2024-001', client: 'Acme Fintech Corp', project: 'Mobile App Redesign', date: 'Mar 02, 2024', due: 'Mar 16, 2024', amount: '$18,500', status: 'Paid' },
    { id: 'INV-2024-002', client: 'Nexus Studio', project: 'Web UI & Prototyping', date: 'Mar 05, 2024', due: 'Mar 19, 2024', amount: '$9,200', status: 'Paid' },
    { id: 'INV-2024-003', client: 'Stephanie Media', project: 'Brand Identity & 3D Assets', date: 'Mar 09, 2024', due: 'Mar 23, 2024', amount: '$4,800', status: 'Pending' },
    { id: 'INV-2024-004', client: 'Horizon AI Labs', project: 'Dashboard Design System', date: 'Mar 11, 2024', due: 'Mar 25, 2024', amount: '$12,500', status: 'Paid' },
    { id: 'INV-2024-005', client: 'William Logistics', project: 'Supply Portal UI Kit', date: 'Mar 14, 2024', due: 'Mar 28, 2024', amount: '$7,400', status: 'Pending' },
  ]);

  // Messages Interactive State
  const [activeChatContact, setActiveChatContact] = useState('Stephanie');
  const [chatInputText, setChatInputText] = useState('');
  const [chatMessages, setChatMessages] = useState({
    'Stephanie': [
      { sender: 'Stephanie', text: 'Hey Robert! Did you check the latest design review feedback for the Mobile App?', time: '10:24 AM', isMe: false },
      { sender: 'Me', text: 'Yes, Stephanie! Reviewed all your annotations. The wireframe hierarchy is ready.', time: '10:26 AM', isMe: true },
      { sender: 'Stephanie', text: 'I got your first assignment. It was quite good 👌 Ready to approve stage 2!', time: '10:30 AM', isMe: false },
    ],
    'Web Designing': [
      { sender: 'Web Designing', text: 'Hey tell me about progress of project? Waiting for your response on typography.', time: '09:15 AM', isMe: false },
      { sender: 'Me', text: 'Sent over the typography hierarchy & tokens in Figma!', time: '09:40 AM', isMe: true }
    ],
    'William': [
      { sender: 'William', text: 'I want some changes in previous work you sent me. Waiting for your reply.', time: 'Yesterday', isMe: false },
      { sender: 'Me', text: 'Noted! I will adjust the layout components by 3 PM.', time: 'Yesterday', isMe: true }
    ],
    'Jessica Vance': [
      { sender: 'Jessica Vance', text: 'The new design tokens are merged into production! Amazing work Robert.', time: 'Mar 12', isMe: false }
    ],
    'Alex Rivera': [
      { sender: 'Alex Rivera', text: 'Can we sync on the animation curves before Monday launch?', time: 'Mar 10', isMe: false }
    ]
  });

  const handleSendMessage = () => {
    if (!chatInputText.trim()) return;
    const newMsg = {
      sender: 'Me',
      text: chatInputText,
      time: 'Just now',
      isMe: true
    };
    setChatMessages(prev => ({
      ...prev,
      [activeChatContact]: [...(prev[activeChatContact] || []), newMsg]
    }));
    setChatInputText('');
    showToast(`Message sent to ${activeChatContact}`);
  };

  // Downloads / Deliverables State
  const [downloadFilter, setDownloadFilter] = useState('All');
  const deliverables = [
    { id: 1, name: 'Fintech_App_Design_v3.fig', type: 'Design', size: '48.2 MB', date: '2 hours ago', icon: 'figma', downloads: 14 },
    { id: 2, name: 'Web_Design_Components_Export.zip', type: 'Archive', size: '128 MB', date: 'Yesterday', icon: 'zip', downloads: 8 },
    { id: 3, name: 'Client_Brand_Guidelines_2024.pdf', type: 'Document', size: '14.5 MB', date: 'Mar 10, 2024', icon: 'pdf', downloads: 22 },
    { id: 4, name: 'Mobile_App_Build_Release.ipa', type: 'Package', size: '84.1 MB', date: 'Mar 08, 2024', icon: 'code', downloads: 5 },
    { id: 5, name: 'Design_System_Tokens.json', type: 'Code', size: '2.4 MB', date: 'Mar 05, 2024', icon: 'code', downloads: 31 },
    { id: 6, name: '3D_Isometric_Product_Renders.zip', type: 'Archive', size: '210 MB', date: 'Mar 02, 2024', icon: 'zip', downloads: 19 },
  ];

  // Bookmarks State
  const [bookmarksList, setBookmarksList] = useState([
    { id: 1, title: 'Linear UI Design System & Component Library', category: 'Inspiration', url: 'linear.app/design', star: true },
    { id: 2, title: 'Tailwind CSS Modern Gradient & Blur Tokens', category: 'Code Snippet', url: 'tailwindcss.com/docs', star: true },
    { id: 3, title: 'Apple Human Interface Guidelines 2024', category: 'Guidelines', url: 'developer.apple.com/design', star: false },
    { id: 4, title: 'Figma Auto-Layout & Smart Animate Cheatsheet', category: 'Design Tools', url: 'figma.com/@resources', star: true },
    { id: 5, title: 'Radix UI Accessible Primitives Architecture', category: 'Code Snippet', url: 'radix-ui.com', star: false },
  ]);

  // Settings State
  const [settingsForm, setSettingsForm] = useState({
    name: 'Robert Smith',
    role: 'Product Designer',
    email: 'robertsmith64@gmail.com',
    phone: '(555) 555-5674',
    location: 'San Francisco, CA',
    bio: 'Senior Product Designer crafting minimal, fluid, and delightful digital experiences.',
    notifications: true,
    emailDigest: true,
    soundEffects: false
  });

  return (
    <div className="dash-canvas">
      <div className="dash-container">
        
        {/* INTERACTIVE TOAST NOTIFICATION */}
        {toast.show && (
          <div className="dash-toast">
            <span className="toast-dot"></span>
            <span>{toast.message}</span>
          </div>
        )}

        {/* TOP HEADER */}
        <header className="dash-header">
          <div className="header-left">
            <button 
              className={`icon-btn header-menu-btn ${menuDrawerOpen ? 'active' : ''}`}
              title="Quick App Menu" 
              aria-label="Menu"
              onClick={() => {
                setMenuDrawerOpen(!menuDrawerOpen);
                setNotificationsOpen(false);
              }}
            >
              <svg width="18" height="15" viewBox="0 0 20 16" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                <line x1="1" y1="2" x2="19" y2="2" />
                <line x1="1" y1="8" x2="14" y2="8" />
                <line x1="1" y1="14" x2="9" y2="14" />
              </svg>
            </button>
            <button 
              className={`icon-btn header-storage-btn ${storageModalOpen ? 'active' : ''}`}
              title="Storage Archive & Drive" 
              aria-label="Storage"
              onClick={() => {
                setStorageModalOpen(!storageModalOpen);
                setMenuDrawerOpen(false);
                showToast('Storage & Archive Explorer opened');
              }}
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="4" width="18" height="16" rx="4" />
                <line x1="9" y1="10" x2="15" y2="10" />
              </svg>
            </button>
          </div>

          {/* TOP NAVIGATION PILLS */}
          <nav className="header-nav-pill">
            <button 
              className={`nav-pill-item ${currentView === 'home' ? 'active' : ''}`}
              onClick={() => navigateTo('home', 'Home Overview')}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                <polyline points="9 22 9 12 15 12 15 22" />
              </svg>
              <span>Home</span>
            </button>

            <button 
              className={`nav-pill-item ${currentView === 'projects' ? 'active' : ''}`}
              onClick={() => navigateTo('projects', 'Projects & Profile')}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="2" y="7" width="20" height="14" rx="3" />
                <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
              </svg>
              <span>Projects</span>
            </button>

            <button 
              className={`nav-pill-item ${currentView === 'invoices' ? 'active' : ''}`}
              onClick={() => navigateTo('invoices', 'Invoices & Financials')}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="4" y="2" width="16" height="20" rx="3" />
                <line x1="8" y1="7" x2="16" y2="7" />
                <line x1="8" y1="12" x2="16" y2="12" />
                <line x1="8" y1="17" x2="12" y2="17" />
              </svg>
              <span>Invoices</span>
            </button>

            <button 
              className={`nav-pill-item ${currentView === 'settings' ? 'active' : ''}`}
              onClick={() => navigateTo('settings', 'Account Settings')}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="3" />
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
              </svg>
              <span>Settings</span>
            </button>
          </nav>

          {/* RIGHT UTILITY BAR */}
          <div className="header-right-pill">
            <button 
              className={`utility-icon-btn ${currentView === 'messages' ? 'active-icon' : ''}`}
              title="Messages & Chat"
              onClick={() => navigateTo('messages', 'Messages & Inbox')}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                <polyline points="22,6 12,13 2,6" />
              </svg>
            </button>

            <button 
              className={`utility-icon-btn with-badge ${notificationsOpen ? 'active-icon' : ''}`}
              title="Notifications"
              onClick={() => {
                setNotificationsOpen(!notificationsOpen);
                setMenuDrawerOpen(false);
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                <path d="M13.73 21a2 2 0 0 1-3.46 0" />
              </svg>
              {notificationCount > 0 && <span className="notification-dot"></span>}
            </button>

            <button 
              className="utility-icon-btn" 
              title="Global Search"
              onClick={() => setSearchModalOpen(true)}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
            </button>

            <div 
              className="header-user-avatar"
              onClick={() => navigateTo('settings', 'Robert Smith Profile')}
              title="Robert Smith (Product Designer)"
            >
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80" 
                alt="Robert Smith" 
              />
            </div>
          </div>
        </header>

        {/* NOTIFICATIONS DROPDOWN PANEL */}
        {notificationsOpen && (
          <div className="notifications-popover">
            <div className="popover-header">
              <span className="popover-title">Notifications</span>
              <button 
                className="mark-read-btn"
                onClick={() => {
                  setNotificationCount(0);
                  showToast('All notifications marked as read');
                }}
              >
                Mark all read
              </button>
            </div>
            <div className="notifications-list">
              <div className="notif-item unread" onClick={() => { navigateTo('messages'); setNotificationsOpen(false); }}>
                <div className="notif-avatar-dot bg-blue"></div>
                <div className="notif-content">
                  <p className="notif-text"><strong>Stephanie</strong> left a review on <em>Mobile App UI</em></p>
                  <span className="notif-time">10 mins ago</span>
                </div>
              </div>
              <div className="notif-item unread" onClick={() => { navigateTo('invoices'); setNotificationsOpen(false); }}>
                <div className="notif-avatar-dot bg-green"></div>
                <div className="notif-content">
                  <p className="notif-text">Invoice <strong>INV-2024-001</strong> of $18,500 was paid</p>
                  <span className="notif-time">1 hour ago</span>
                </div>
              </div>
              <div className="notif-item" onClick={() => { navigateTo('projects'); setNotificationsOpen(false); }}>
                <div className="notif-avatar-dot bg-yellow"></div>
                <div className="notif-content">
                  <p className="notif-text">Upcoming team standup in 15 minutes</p>
                  <span className="notif-time">Today, 11:30 AM</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STORAGE / ARCHIVE QUICK MODAL */}
        {storageModalOpen && (
          <div className="quick-modal-backdrop" onClick={() => setStorageModalOpen(false)}>
            <div className="quick-modal-card" onClick={e => e.stopPropagation()}>
              <div className="modal-header-row">
                <div className="modal-title-wrap">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="4" width="18" height="16" rx="4" />
                    <line x1="9" y1="10" x2="15" y2="10" />
                  </svg>
                  <h3>Cloud Storage & Archive</h3>
                </div>
                <button className="close-btn" onClick={() => setStorageModalOpen(false)}>✕</button>
              </div>
              <div className="storage-stat-bar">
                <div className="storage-text-row">
                  <span>64.2 GB of 100 GB used</span>
                  <span>64.2%</span>
                </div>
                <div className="storage-bar-outer">
                  <div className="storage-bar-inner" style={{ width: '64.2%' }}></div>
                </div>
              </div>
              <div className="storage-folder-grid">
                <div className="storage-folder-item" onClick={() => { navigateTo('downloads'); setStorageModalOpen(false); }}>
                  <span className="folder-icon">🎨</span>
                  <div className="folder-meta">
                    <span className="folder-name">Figma UI Assets</span>
                    <span className="folder-size">34.8 GB • 142 files</span>
                  </div>
                </div>
                <div className="storage-folder-item" onClick={() => { navigateTo('downloads'); setStorageModalOpen(false); }}>
                  <span className="folder-icon">📦</span>
                  <div className="folder-meta">
                    <span className="folder-name">Project Deliverables</span>
                    <span className="folder-size">21.4 GB • 86 files</span>
                  </div>
                </div>
                <div className="storage-folder-item" onClick={() => { navigateTo('downloads'); setStorageModalOpen(false); }}>
                  <span className="folder-icon">📄</span>
                  <div className="folder-meta">
                    <span className="folder-name">Client Contracts</span>
                    <span className="folder-size">8.0 GB • 28 files</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* GLOBAL SEARCH MODAL */}
        {searchModalOpen && (
          <div className="quick-modal-backdrop" onClick={() => setSearchModalOpen(false)}>
            <div className="quick-search-card" onClick={e => e.stopPropagation()}>
              <div className="search-input-header">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                </svg>
                <input 
                  type="text" 
                  placeholder="Search projects, teammates, files, invoices..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                />
                <button className="close-btn" onClick={() => setSearchModalOpen(false)}>ESC</button>
              </div>
              <div className="search-quick-results">
                <span className="search-group-title">QUICK SHORTCUTS</span>
                <div className="search-result-item" onClick={() => { navigateTo('projects'); setSearchModalOpen(false); }}>
                  <span className="result-badge peach">PROJ</span>
                  <span>Web Designing (Prototyping - 90%)</span>
                </div>
                <div className="search-result-item" onClick={() => { navigateTo('messages'); setSearchModalOpen(false); }}>
                  <span className="result-badge blue">CHAT</span>
                  <span>Stephanie (Product Lead) - Active Chat</span>
                </div>
                <div className="search-result-item" onClick={() => { navigateTo('invoices'); setSearchModalOpen(false); }}>
                  <span className="result-badge green">INV</span>
                  <span>INV-2024-001 ($18,500 Acme Fintech)</span>
                </div>
                <div className="search-result-item" onClick={() => { navigateTo('downloads'); setSearchModalOpen(false); }}>
                  <span className="result-badge yellow">FILE</span>
                  <span>Fintech_App_Design_v3.fig (48.2 MB)</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* QUICK APP DRAWER */}
        {menuDrawerOpen && (
          <div className="menu-drawer-popover">
            <span className="drawer-title">Workspaces & Apps</span>
            <div className="drawer-grid">
              <button className="drawer-item" onClick={() => { navigateTo('home', 'Home Overview'); setMenuDrawerOpen(false); }}>
                <span className="drawer-icon">📊</span>
                <span>Overview</span>
              </button>
              <button className="drawer-item" onClick={() => { navigateTo('projects', 'Projects'); setMenuDrawerOpen(false); }}>
                <span className="drawer-icon">📁</span>
                <span>Projects</span>
              </button>
              <button className="drawer-item" onClick={() => { navigateTo('messages', 'Messages'); setMenuDrawerOpen(false); }}>
                <span className="drawer-icon">💬</span>
                <span>Messages</span>
              </button>
              <button className="drawer-item" onClick={() => { navigateTo('invoices', 'Invoices'); setMenuDrawerOpen(false); }}>
                <span className="drawer-icon">💳</span>
                <span>Invoices</span>
              </button>
              <button className="drawer-item" onClick={() => { navigateTo('downloads', 'Deliverables'); setMenuDrawerOpen(false); }}>
                <span className="drawer-icon">⬇️</span>
                <span>Downloads</span>
              </button>
              <button className="drawer-item" onClick={() => { navigateTo('bookmarks', 'Bookmarks'); setMenuDrawerOpen(false); }}>
                <span className="drawer-icon">🔖</span>
                <span>Bookmarks</span>
              </button>
              <button className="drawer-item" onClick={() => { navigateTo('location', 'Locations'); setMenuDrawerOpen(false); }}>
                <span className="drawer-icon">🌍</span>
                <span>Hubs</span>
              </button>
              <button className="drawer-item" onClick={() => { navigateTo('favorites', 'Favorites'); setMenuDrawerOpen(false); }}>
                <span className="drawer-icon">⭐</span>
                <span>Favorites</span>
              </button>
              <button className="drawer-item" onClick={() => { navigateTo('settings', 'Settings'); setMenuDrawerOpen(false); }}>
                <span className="drawer-icon">⚙️</span>
                <span>Settings</span>
              </button>
            </div>
          </div>
        )}

        {/* SUBHEADER TITLE BAR */}
        <div className="dash-title-row">
          <div className="title-left">
            <button 
              className="back-arrow-btn" 
              title="Go back"
              onClick={handleBack}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="19" y1="12" x2="5" y2="12" />
                <polyline points="12 19 5 12 12 5" />
              </svg>
            </button>
            <h1 className="page-title">{getViewTitle(currentView)}</h1>
          </div>

          <div className="title-right">
            <button 
              className="white-pill-btn"
              onClick={() => {
                const nextStatus = statusFilter === 'Pending' ? 'Active' : statusFilter === 'Active' ? 'Completed' : 'Pending';
                setStatusFilter(nextStatus);
                showToast(`Filter set to ${nextStatus}`);
              }}
            >
              <span className="status-pill-dot"></span>
              <span>{statusFilter}</span>
            </button>
            <button 
              className="white-pill-btn with-icon"
              onClick={() => showToast(`Selected Timeline: ${months[monthIndex]}, 2024`)}
            >
              <span>{months[monthIndex]}, 2024</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                <line x1="16" y1="2" x2="16" y2="6" />
                <line x1="8" y1="2" x2="8" y2="6" />
                <line x1="3" y1="10" x2="21" y2="10" />
              </svg>
            </button>
          </div>
        </div>

        {/* MAIN BODY: SIDE DOCK + DYNAMIC CONTENT VIEW */}
        <div className="dash-body-layout">
          
          {/* LEFT FLOATING MAC DOCK NAVIGATION WITH CONTINUOUS MAGNIFICATION */}
          <MacDock currentView={currentView} onNavigate={navigateTo} />

          {/* DYNAMIC VIEW CONTAINER */}
          <div className="dash-view-content">

            {/* ================================================================= */}
            {/* VIEW 1: PROJECTS & PROFILE VIEW (PRIMARY SHOWCASE) */}
            {/* ================================================================= */}
            {currentView === 'projects' && (
              <div className="dash-grid-container">
                {/* LEFT COLUMN */}
                <div className="dash-col-left">
                  {/* TOP PROFILE CARD */}
                  <div className="card profile-card">
                    <div className="profile-header-row">
                      <div className="profile-avatar-wrapper">
                        <img 
                          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80" 
                          alt="Robert Smith" 
                          className="profile-avatar-img"
                        />
                      </div>
                      <div className="profile-name-info">
                        <h2 className="profile-name">Robert Smith</h2>
                        <p className="profile-role">Product Designer</p>
                      </div>
                      <button 
                        className="card-options-btn" 
                        title="Profile Options"
                        onClick={() => { navigateTo('settings'); showToast('Opening profile settings...'); }}
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                          <circle cx="12" cy="5" r="1" />
                          <circle cx="12" cy="12" r="1" />
                          <circle cx="12" cy="19" r="1" />
                        </svg>
                      </button>
                    </div>

                    {/* ACTION CIRCLES ROW */}
                    <div className="profile-action-buttons">
                      <button 
                        className="action-circle-btn black-btn" 
                        title="Send Email"
                        onClick={() => showToast('Drafting email to robertsmith64@gmail.com...')}
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                          <polyline points="22,6 12,13 2,6" />
                        </svg>
                      </button>
                      <button 
                        className="action-circle-btn light-btn" 
                        title="Direct Phone Call"
                        onClick={() => showToast('Calling (555) 555-5674...')}
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                        </svg>
                      </button>
                      <button 
                        className="action-circle-btn light-btn" 
                        title="Open Chat"
                        onClick={() => navigateTo('messages', 'Messages with Stephanie')}
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                        </svg>
                      </button>
                      <button 
                        className="action-circle-btn light-btn" 
                        title="Start Video Meeting"
                        onClick={() => showToast('Launching Google Meet conference room...')}
                      >
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <polygon points="23 7 16 12 23 17 23 7" />
                          <rect x="1" y="5" width="15" height="14" rx="3" ry="3" />
                        </svg>
                      </button>
                    </div>

                    {/* TIME SLOTS ROW */}
                    <div className="time-slots-section">
                      <span className="slots-label">Time Slots</span>
                      <div className="slots-row">
                        <button 
                          className="time-slot-pill"
                          onClick={() => showToast('Time slots for April, 2024 loaded')}
                        >
                          <span>April, 2024</span>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                            <line x1="16" y1="2" x2="16" y2="6" />
                            <line x1="8" y1="2" x2="8" y2="6" />
                            <line x1="3" y1="10" x2="21" y2="10" />
                          </svg>
                        </button>

                        <button 
                          className="meetings-badge-pill"
                          onClick={() => {
                            setMeetingsCount((c) => c + 1);
                            showToast('New meeting scheduled for Robert!');
                          }}
                        >
                          <span>Meetings</span>
                          <span className="meetings-count-circle">{meetingsCount}</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* BOTTOM DETAILED INFORMATION CARD */}
                  <div className="card details-card">
                    <h2 className="details-title">Detailed Information</h2>

                    <div className="details-list">
                      {/* Item 1: Full Name */}
                      <div 
                        className="detail-item-row"
                        onClick={() => {
                          setIsOnline(!isOnline);
                          showToast(`Status toggled to ${!isOnline ? 'Online' : 'Away'}`);
                        }}
                      >
                        <div className="detail-left">
                          <div className="radio-dot-icon">
                            <div className="inner-dot"></div>
                          </div>
                          <div className="detail-text">
                            <span className="detail-label">Full Name</span>
                            <span className="detail-value">Robert Smith</span>
                          </div>
                        </div>
                        <div className="detail-right">
                          <span className={`online-badge ${isOnline ? 'online' : 'offline'}`}>
                            {isOnline ? 'Online' : 'Away'}
                          </span>
                        </div>
                      </div>

                      {/* Item 2: Email Address */}
                      <div 
                        className="detail-item-row"
                        onClick={() => {
                          navigator.clipboard?.writeText('robertsmith64@gmail.com');
                          showToast('Email address copied to clipboard!');
                        }}
                      >
                        <div className="detail-left">
                          <div className="radio-dot-icon">
                            <div className="inner-dot"></div>
                          </div>
                          <div className="detail-text">
                            <span className="detail-label">Email Address</span>
                            <span className="detail-value">robertsmith64@gmail.com</span>
                          </div>
                        </div>
                        <div className="detail-right">
                          <button className="detail-action-circle" title="Copy Email">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                              <polyline points="22,6 12,13 2,6" />
                            </svg>
                          </button>
                        </div>
                      </div>

                      {/* Item 3: Contact Number */}
                      <div 
                        className="detail-item-row"
                        onClick={() => showToast('Calling (555) 555-5674...')}
                      >
                        <div className="detail-left">
                          <div className="radio-dot-icon">
                            <div className="inner-dot"></div>
                          </div>
                          <div className="detail-text">
                            <span className="detail-label">Contact Number</span>
                            <span className="detail-value">(555) 555-5674</span>
                          </div>
                        </div>
                        <div className="detail-right">
                          <button className="detail-action-circle" title="Call">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                            </svg>
                          </button>
                        </div>
                      </div>

                      {/* Item 4: Designation */}
                      <div 
                        className="detail-item-row"
                        onClick={() => showToast('Role: Senior Product Designer')}
                      >
                        <div className="detail-left">
                          <div className="radio-dot-icon">
                            <div className="inner-dot"></div>
                          </div>
                          <div className="detail-text">
                            <span className="detail-label">Designation</span>
                            <span className="detail-value">Product Designer</span>
                          </div>
                        </div>
                        <div className="detail-right">
                          <button className="detail-action-circle" title="View Details">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                              <circle cx="12" cy="12" r="10" />
                              <line x1="12" y1="16" x2="12" y2="12" />
                              <line x1="12" y1="8" x2="12.01" y2="8" />
                            </svg>
                          </button>
                        </div>
                      </div>

                      {/* Item 5: Availability */}
                      <div 
                        className="detail-item-row"
                        onClick={() => showToast('Opening appointment calendar scheduler...')}
                      >
                        <div className="detail-left">
                          <div className="radio-dot-icon">
                            <div className="inner-dot"></div>
                          </div>
                          <div className="detail-text">
                            <span className="detail-label">Availability</span>
                            <span className="detail-value">Schedule the time slot</span>
                          </div>
                        </div>
                        <div className="detail-right">
                          <button className="detail-action-circle" title="Schedule">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                              <line x1="16" y1="2" x2="16" y2="6" />
                              <line x1="8" y1="2" x2="8" y2="6" />
                              <line x1="3" y1="10" x2="21" y2="10" />
                            </svg>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* RIGHT COLUMN */}
                <div className="dash-col-right">
                  {/* ONGOING PROJECTS SECTION */}
                  <div className="ongoing-projects-section">
                    {/* PROJECTS BAR HEADER */}
                    <div className="projects-header-row">
                      <div className="dropdown-wrapper">
                        <button 
                          className="ongoing-dropdown-btn"
                          onClick={() => setProjectDropdownOpen(!projectDropdownOpen)}
                        >
                          <span>{selectedProjectCategory}</span>
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="6 9 12 15 18 9" />
                          </svg>
                        </button>
                        {projectDropdownOpen && (
                          <div className="project-dropdown-menu">
                            {['Ongoing Projects', 'Completed Projects', 'Pending Approvals', 'All Projects'].map((cat) => (
                              <div 
                                key={cat}
                                className="project-dropdown-item"
                                onClick={() => {
                                  setSelectedProjectCategory(cat);
                                  setProjectDropdownOpen(false);
                                  showToast(`Filtered by ${cat}`);
                                }}
                              >
                                {cat}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="projects-action-icons">
                        <button 
                          className="proj-icon-circle-btn" 
                          title="Create New Project"
                          onClick={() => showToast('Create New Project modal opened')}
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="12" cy="12" r="10" />
                            <line x1="12" y1="8" x2="12" y2="16" />
                            <line x1="8" y1="12" x2="16" y2="12" />
                          </svg>
                        </button>
                        <button 
                          className={`proj-icon-circle-btn ${isFilterActive ? 'active-icon' : ''}`} 
                          title="Filter Projects"
                          onClick={() => {
                            setIsFilterActive(!isFilterActive);
                            showToast(`Projects filter ${!isFilterActive ? 'applied' : 'cleared'}`);
                          }}
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
                          </svg>
                        </button>
                        <button 
                          className={`proj-icon-circle-btn ${isFavoriteActive ? 'active-icon' : ''}`} 
                          title="Favorite Projects"
                          onClick={() => {
                            setIsFavoriteActive(!isFavoriteActive);
                            showToast(`Favorite filter ${!isFavoriteActive ? 'activated' : 'deactivated'}`);
                          }}
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill={isFavoriteActive ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                          </svg>
                        </button>
                      </div>
                    </div>

                    {/* 3 PASTEL PROJECT CARDS */}
                    <div className="project-cards-grid">
                      {/* CARD 1: YELLOW / PEACH */}
                      <div 
                        className="project-card peach-card"
                        onClick={() => showToast('Web Designing project selected (90% completed)')}
                      >
                        <div className="proj-card-top">
                          <span className="proj-date-pill">March 05, 2024</span>
                          <button 
                            className="proj-more-btn"
                            onClick={(e) => { e.stopPropagation(); showToast('Web Designing options opened'); }}
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                              <circle cx="12" cy="5" r="1" />
                              <circle cx="12" cy="12" r="1" />
                              <circle cx="12" cy="19" r="1" />
                            </svg>
                          </button>
                        </div>

                        <div className="proj-title-row">
                          <h3 className="proj-title">Web Designing</h3>
                          <button className="proj-info-icon" title="Info">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                              <circle cx="12" cy="12" r="10" />
                              <line x1="12" y1="16" x2="12" y2="12" />
                              <line x1="12" y1="8" x2="12.01" y2="8" />
                            </svg>
                          </button>
                        </div>

                        <div className="proj-stage-row">
                          <span className="proj-stage-text">Prototyping</span>
                          <div className="proj-progress-tag">
                            <span className="prog-percent-bubble">90%</span>
                            <span className="prog-text">Progress</span>
                          </div>
                        </div>

                        <div className="proj-progress-bar-bg peach-bar-bg">
                          <div className="proj-progress-fill peach-fill" style={{ width: '90%' }}></div>
                        </div>

                        <div className="proj-card-footer">
                          <div className="avatar-stack">
                            <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                            <img src="https://images.unsplash.com/photo-1517841905240-472988babdf9?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                            <img src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                            <div className="stack-avatar stack-more-avatar peach-more">+</div>
                          </div>
                          <span className="days-left-pill">2 Days Left</span>
                        </div>
                      </div>

                      {/* CARD 2: LIGHT BLUE */}
                      <div 
                        className="project-card blue-card"
                        onClick={() => showToast('Mobile App project selected (50% completed)')}
                      >
                        <div className="proj-card-top">
                          <span className="proj-date-pill">March 08, 2024</span>
                          <button 
                            className="proj-more-btn"
                            onClick={(e) => { e.stopPropagation(); showToast('Mobile App options opened'); }}
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                              <circle cx="12" cy="5" r="1" />
                              <circle cx="12" cy="12" r="1" />
                              <circle cx="12" cy="19" r="1" />
                            </svg>
                          </button>
                        </div>

                        <div className="proj-title-row">
                          <h3 className="proj-title">Mobile App</h3>
                          <button className="proj-info-icon" title="Info">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                              <circle cx="12" cy="12" r="10" />
                              <line x1="12" y1="16" x2="12" y2="12" />
                              <line x1="12" y1="8" x2="12.01" y2="8" />
                            </svg>
                          </button>
                        </div>

                        <div className="proj-stage-row">
                          <span className="proj-stage-text">Design</span>
                          <div className="proj-progress-tag">
                            <span className="prog-percent-bubble">50%</span>
                            <span className="prog-text">Progress</span>
                          </div>
                        </div>

                        <div className="proj-progress-bar-bg blue-bar-bg">
                          <div className="proj-progress-fill blue-fill" style={{ width: '50%' }}></div>
                        </div>

                        <div className="proj-card-footer">
                          <div className="avatar-stack">
                            <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                            <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                            <div className="stack-avatar stack-more-avatar blue-more">+</div>
                          </div>
                          <span className="days-left-pill">5 Days Left</span>
                        </div>
                      </div>

                      {/* CARD 3: LIGHT CORAL / PINK */}
                      <div 
                        className="project-card pink-card"
                        onClick={() => showToast('Dashboard project selected (70% completed)')}
                      >
                        <div className="proj-card-top">
                          <span className="proj-date-pill">March 12, 2024</span>
                          <button 
                            className="proj-more-btn"
                            onClick={(e) => { e.stopPropagation(); showToast('Dashboard project options opened'); }}
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                              <circle cx="12" cy="5" r="1" />
                              <circle cx="12" cy="12" r="1" />
                              <circle cx="12" cy="19" r="1" />
                            </svg>
                          </button>
                        </div>

                        <div className="proj-title-row">
                          <h3 className="proj-title">Dashboard</h3>
                          <button className="proj-info-icon" title="Info">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                              <circle cx="12" cy="12" r="10" />
                              <line x1="12" y1="16" x2="12" y2="12" />
                              <line x1="12" y1="8" x2="12.01" y2="8" />
                            </svg>
                          </button>
                        </div>

                        <div className="proj-stage-row">
                          <span className="proj-stage-text">Wireframe</span>
                          <div className="proj-progress-tag">
                            <span className="prog-percent-bubble">70%</span>
                            <span className="prog-text">Progress</span>
                          </div>
                        </div>

                        <div className="proj-progress-bar-bg pink-bar-bg">
                          <div className="proj-progress-fill pink-fill" style={{ width: '70%' }}></div>
                        </div>

                        <div className="proj-card-footer">
                          <div className="avatar-stack">
                            <img src="https://images.unsplash.com/photo-1517841905240-472988babdf9?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                            <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                            <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                            <div className="stack-avatar stack-more-avatar pink-more">+</div>
                          </div>
                          <span className="days-left-pill">8 Days Left</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* BOTTOM SPLIT ROW: CALENDAR & INBOX */}
                  <div className="calendar-inbox-row">
                    {/* CALENDER CARD */}
                    <div className="card calendar-card">
                      <div className="card-top-header">
                        <div className="header-title-group">
                          <span className="card-section-title">Calender</span>
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="section-title-icon">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                            <line x1="16" y1="2" x2="16" y2="6" />
                            <line x1="8" y1="2" x2="8" y2="6" />
                            <line x1="3" y1="10" x2="21" y2="10" />
                          </svg>
                        </div>
                        <button 
                          className="card-options-btn" 
                          title="Calendar Options"
                          onClick={() => showToast('Calendar settings opened')}
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                            <circle cx="12" cy="5" r="1" />
                            <circle cx="12" cy="12" r="1" />
                            <circle cx="12" cy="19" r="1" />
                          </svg>
                        </button>
                      </div>

                      {/* Month Switcher */}
                      <div className="month-switcher-row">
                        <button className="month-arrow-btn" title="Previous Month" onClick={handlePrevMonth}>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="15 18 9 12 15 6" />
                          </svg>
                        </button>
                        <span className="current-month-name">{months[monthIndex]}</span>
                        <button className="month-arrow-btn" title="Next Month" onClick={handleNextMonth}>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="9 18 15 12 9 6" />
                          </svg>
                        </button>
                      </div>

                      {/* Calendar Matrix */}
                      <div className="calendar-grid-matrix">
                        {calendarDays.map((item, idx) => (
                          <div 
                            key={idx} 
                            className={`cal-day-cell cal-${item.type} ${selectedDay === item.day ? 'selected-date' : ''}`}
                            onClick={() => {
                              setSelectedDay(item.day);
                              showToast(`Selected date: ${months[monthIndex]} ${item.day < 10 ? '0' + item.day : item.day}, 2024`);
                            }}
                          >
                            {item.day}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* INBOX CARD */}
                    <div className="card inbox-card">
                      <div className="card-top-header">
                        <div className="header-title-group">
                          <span className="card-section-title">Inbox</span>
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="section-title-icon">
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                          </svg>
                        </div>
                        <button 
                          className="view-all-link"
                          onClick={() => navigateTo('messages', 'Messages & Inbox')}
                        >
                          View all
                        </button>
                      </div>

                      <div className="inbox-messages-list">
                        {/* Message 1 */}
                        <div 
                          className={`inbox-msg-item ${activeInbox === 0 ? 'active-dark' : ''}`}
                          onClick={() => {
                            setActiveInbox(0);
                            setActiveChatContact('Web Designing');
                            showToast('Viewing message from Web Designing');
                          }}
                        >
                          <img 
                            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&auto=format&fit=crop&q=80" 
                            alt="Web Designing" 
                            className="inbox-sender-avatar"
                          />
                          <div className="inbox-msg-content">
                            <div className="inbox-msg-sender">Web Designing</div>
                            <div className="inbox-msg-snippet">
                              Hey tell me about progress of project? Waiting for your response
                            </div>
                          </div>
                          <button 
                            className="inbox-action-btn" 
                            title="Reply / Chat"
                            onClick={(e) => { e.stopPropagation(); navigateTo('messages'); }}
                          >
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <polyline points="7 10 12 15 17 10" />
                              <line x1="12" y1="15" x2="12" y2="3" />
                              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                            </svg>
                          </button>
                        </div>

                        {/* Message 2 (Active Dark Item) */}
                        <div 
                          className={`inbox-msg-item ${activeInbox === 1 ? 'active-dark' : ''}`}
                          onClick={() => {
                            setActiveInbox(1);
                            setActiveChatContact('Stephanie');
                            showToast('Viewing message from Stephanie');
                          }}
                        >
                          <div className="stephanie-avatar-wrap">
                            <img 
                              src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&auto=format&fit=crop&q=80" 
                              alt="Stephanie" 
                              className="inbox-sender-avatar"
                            />
                          </div>
                          <div className="inbox-msg-content">
                            <div className="inbox-msg-sender">Stephanie</div>
                            <div className="inbox-msg-snippet">
                              I got your first assignment. I t was quite good👌
                            </div>
                          </div>
                          <button 
                            className="inbox-action-btn" 
                            title="Reply / Chat"
                            onClick={(e) => { e.stopPropagation(); navigateTo('messages'); }}
                          >
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <polyline points="7 10 12 15 17 10" />
                              <line x1="12" y1="15" x2="12" y2="3" />
                              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                            </svg>
                          </button>
                        </div>

                        {/* Message 3 */}
                        <div 
                          className={`inbox-msg-item ${activeInbox === 2 ? 'active-dark' : ''}`}
                          onClick={() => {
                            setActiveInbox(2);
                            setActiveChatContact('William');
                            showToast('Viewing message from William');
                          }}
                        >
                          <img 
                            src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&auto=format&fit=crop&q=80" 
                            alt="William" 
                            className="inbox-sender-avatar"
                          />
                          <div className="inbox-msg-content">
                            <div className="inbox-msg-sender">William</div>
                            <div className="inbox-msg-snippet">
                              I want some changes in previous work you sent me. Waiting for your reply.
                            </div>
                          </div>
                          <button 
                            className="inbox-action-btn" 
                            title="Reply / Chat"
                            onClick={(e) => { e.stopPropagation(); navigateTo('messages'); }}
                          >
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <polyline points="7 10 12 15 17 10" />
                              <line x1="12" y1="15" x2="12" y2="3" />
                              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                            </svg>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================= */}
            {/* VIEW 2: HOME OVERVIEW VIEW */}
            {/* ================================================================= */}
            {currentView === 'home' && (
              <div className="view-page-layout home-overview-layout">
                {/* 4 TOP STAT KPI METRICS */}
                <div className="kpi-metrics-row">
                  <div className="card kpi-metric-card" onClick={() => navigateTo('invoices')}>
                    <div className="kpi-icon-wrap bg-green-light">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2.2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                    </div>
                    <div className="kpi-meta">
                      <span className="kpi-label">Total Revenue</span>
                      <h3 className="kpi-val">$48,250</h3>
                      <span className="kpi-trend positive">+14.2% this month</span>
                    </div>
                  </div>

                  <div className="card kpi-metric-card" onClick={() => navigateTo('projects')}>
                    <div className="kpi-icon-wrap bg-blue-light">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0284c7" strokeWidth="2.2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
                    </div>
                    <div className="kpi-meta">
                      <span className="kpi-label">Active Projects</span>
                      <h3 className="kpi-val">12 Active</h3>
                      <span className="kpi-trend neutral">3 due this week</span>
                    </div>
                  </div>

                  <div className="card kpi-metric-card" onClick={() => navigateTo('downloads')}>
                    <div className="kpi-icon-wrap bg-peach-light">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#d97706" strokeWidth="2.2"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
                    </div>
                    <div className="kpi-meta">
                      <span className="kpi-label">Tasks Finished</span>
                      <h3 className="kpi-val">148 / 160</h3>
                      <span className="kpi-trend positive">92.5% success rate</span>
                    </div>
                  </div>

                  <div className="card kpi-metric-card" onClick={() => navigateTo('settings')}>
                    <div className="kpi-icon-wrap bg-purple-light">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" strokeWidth="2.2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                    </div>
                    <div className="kpi-meta">
                      <span className="kpi-label">Client Rating</span>
                      <h3 className="kpi-val">4.98 / 5.0</h3>
                      <span className="kpi-trend positive">38 reviews (100% positive)</span>
                    </div>
                  </div>
                </div>

                {/* BOTTOM SPLIT: PRODUCTIVITY CHART & LIVE TEAM FEED */}
                <div className="home-split-grid">
                  {/* CHART CARD */}
                  <div className="card home-chart-card">
                    <div className="card-top-header">
                      <span className="card-section-title">Weekly Productivity & Billable Hours</span>
                      <span className="chart-badge-pill">March 2024</span>
                    </div>

                    <div className="svg-chart-container">
                      <svg viewBox="0 0 500 130" className="productivity-svg">
                        <defs>
                          <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#111413" stopOpacity="0.3" />
                            <stop offset="100%" stopColor="#111413" stopOpacity="0.0" />
                          </linearGradient>
                        </defs>
                        {/* Grid lines */}
                        <line x1="0" y1="30" x2="500" y2="30" stroke="#f0f0f2" strokeDasharray="3 3" />
                        <line x1="0" y1="70" x2="500" y2="70" stroke="#f0f0f2" strokeDasharray="3 3" />
                        <line x1="0" y1="110" x2="500" y2="110" stroke="#f0f0f2" />

                        {/* Area */}
                        <path d="M 30,95 Q 100,45 170,60 T 310,25 T 450,40 L 450,110 L 30,110 Z" fill="url(#chartGrad)" />
                        {/* Stroke curve */}
                        <path d="M 30,95 Q 100,45 170,60 T 310,25 T 450,40" fill="none" stroke="#111413" strokeWidth="3" strokeLinecap="round" />

                        {/* Data points */}
                        <circle cx="30" cy="95" r="4.5" fill="#ffffff" stroke="#111413" strokeWidth="2.5" />
                        <circle cx="100" cy="55" r="4.5" fill="#ffffff" stroke="#111413" strokeWidth="2.5" />
                        <circle cx="170" cy="60" r="4.5" fill="#ffffff" stroke="#111413" strokeWidth="2.5" />
                        <circle cx="240" cy="40" r="4.5" fill="#ffffff" stroke="#111413" strokeWidth="2.5" />
                        <circle cx="310" cy="25" r="5.5" fill="#22c55e" stroke="#111413" strokeWidth="2.5" />
                        <circle cx="380" cy="50" r="4.5" fill="#ffffff" stroke="#111413" strokeWidth="2.5" />
                        <circle cx="450" cy="40" r="4.5" fill="#ffffff" stroke="#111413" strokeWidth="2.5" />

                        {/* Day labels */}
                        <text x="30" y="125" textAnchor="middle" fill="#71717a" fontSize="10">Mon</text>
                        <text x="100" y="125" textAnchor="middle" fill="#71717a" fontSize="10">Tue</text>
                        <text x="170" y="125" textAnchor="middle" fill="#71717a" fontSize="10">Wed</text>
                        <text x="240" y="125" textAnchor="middle" fill="#71717a" fontSize="10">Thu</text>
                        <text x="310" y="125" textAnchor="middle" fill="#111413" fontWeight="bold" fontSize="10">Fri (8.5h)</text>
                        <text x="380" y="125" textAnchor="middle" fill="#71717a" fontSize="10">Sat</text>
                        <text x="450" y="125" textAnchor="middle" fill="#71717a" fontSize="10">Sun</text>
                      </svg>
                    </div>
                  </div>

                  {/* RECENT ACTIVITY CARD */}
                  <div className="card home-activity-card">
                    <div className="card-top-header">
                      <span className="card-section-title">Live Team Activity</span>
                      <button className="view-all-link" onClick={() => navigateTo('projects')}>View Projects</button>
                    </div>
                    <div className="feed-list">
                      <div className="feed-item" onClick={() => navigateTo('messages')}>
                        <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&auto=format&fit=crop&q=80" alt="Stephanie" className="feed-avatar" />
                        <div className="feed-details">
                          <p><strong>Stephanie</strong> approved <em>Mobile App UI</em></p>
                          <span className="feed-time">12 mins ago • Prototyping</span>
                        </div>
                      </div>
                      <div className="feed-item" onClick={() => navigateTo('invoices')}>
                        <div className="feed-icon-circle bg-green-light">💵</div>
                        <div className="feed-details">
                          <p><strong>Acme Corp</strong> sent payment for <em>INV-2024-001</em></p>
                          <span className="feed-time">1 hour ago • $18,500</span>
                        </div>
                      </div>
                      <div className="feed-item" onClick={() => navigateTo('downloads')}>
                        <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=60&auto=format&fit=crop&q=80" alt="William" className="feed-avatar" />
                        <div className="feed-details">
                          <p><strong>William</strong> uploaded <em>Design_Tokens_v2.json</em></p>
                          <span className="feed-time">3 hours ago • 2.4 MB</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================= */}
            {/* VIEW 3: INVOICES & FINANCIALS VIEW */}
            {/* ================================================================= */}
            {currentView === 'invoices' && (
              <div className="view-page-layout invoices-page-layout">
                {/* TOP STAT BAR */}
                <div className="invoices-summary-row">
                  <div className="card invoice-sum-card">
                    <span className="sum-label">Total Billed</span>
                    <h3 className="sum-val">$64,500</h3>
                    <span className="sum-sub">5 total invoices</span>
                  </div>
                  <div className="card invoice-sum-card">
                    <span className="sum-label">Paid Received</span>
                    <h3 className="sum-val text-green">$52,300</h3>
                    <span className="sum-sub">3 invoices cleared</span>
                  </div>
                  <div className="card invoice-sum-card">
                    <span className="sum-label">Pending Approval</span>
                    <h3 className="sum-val text-yellow">$12,200</h3>
                    <span className="sum-sub">2 invoices awaiting</span>
                  </div>
                  <div className="card invoice-sum-card">
                    <button 
                      className="new-invoice-btn"
                      onClick={() => showToast('Create Invoice dialog ready')}
                    >
                      + Create Invoice
                    </button>
                  </div>
                </div>

                {/* INVOICES TABLE CARD */}
                <div className="card invoices-table-card">
                  <div className="table-filter-bar">
                    <div className="tab-pill-group">
                      {['All', 'Paid', 'Pending'].map(tab => (
                        <button 
                          key={tab} 
                          className={`tab-filter-btn ${invoiceFilter === tab ? 'active' : ''}`}
                          onClick={() => {
                            setInvoiceFilter(tab);
                            showToast(`Filtered invoices: ${tab}`);
                          }}
                        >
                          {tab}
                        </button>
                      ))}
                    </div>
                    <span className="table-count-label">Showing {invoicesList.filter(i => invoiceFilter === 'All' || i.status === invoiceFilter).length} invoices</span>
                  </div>

                  <div className="invoices-table-container">
                    <table className="invoices-table">
                      <thead>
                        <tr>
                          <th>Invoice #</th>
                          <th>Client</th>
                          <th>Project</th>
                          <th>Issue Date</th>
                          <th>Due Date</th>
                          <th>Amount</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {invoicesList
                          .filter(inv => invoiceFilter === 'All' || inv.status === invoiceFilter)
                          .map((inv) => (
                            <tr key={inv.id}>
                              <td className="font-bold">{inv.id}</td>
                              <td>{inv.client}</td>
                              <td className="text-muted">{inv.project}</td>
                              <td>{inv.date}</td>
                              <td>{inv.due}</td>
                              <td className="font-bold">{inv.amount}</td>
                              <td>
                                <span className={`status-tag-badge ${inv.status.toLowerCase()}`}>
                                  {inv.status}
                                </span>
                              </td>
                              <td>
                                <button 
                                  className="table-action-btn"
                                  onClick={() => showToast(`Downloading PDF for ${inv.id}...`)}
                                  title="Download PDF"
                                >
                                  PDF ↓
                                </button>
                              </td>
                            </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================= */}
            {/* VIEW 4: MESSAGES & CHAT VIEW */}
            {/* ================================================================= */}
            {currentView === 'messages' && (
              <div className="view-page-layout messages-hub-layout">
                {/* LEFT CONVERSATIONS LIST */}
                <div className="card messages-contacts-card">
                  <div className="contacts-header">
                    <h3 className="card-section-title">Messages</h3>
                    <span className="unread-counter-pill">3 new</span>
                  </div>

                  <div className="contacts-list">
                    {Object.keys(chatMessages).map((contact) => (
                      <div 
                        key={contact}
                        className={`contact-item ${activeChatContact === contact ? 'active-contact' : ''}`}
                        onClick={() => {
                          setActiveChatContact(contact);
                          showToast(`Opened chat with ${contact}`);
                        }}
                      >
                        <div className="contact-avatar-wrap">
                          <img 
                            src={
                              contact === 'Stephanie' ? 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&auto=format&fit=crop&q=80' :
                              contact === 'Web Designing' ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&auto=format&fit=crop&q=80' :
                              contact === 'William' ? 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&auto=format&fit=crop&q=80' :
                              contact === 'Jessica Vance' ? 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=80&auto=format&fit=crop&q=80' :
                              'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=80&auto=format&fit=crop&q=80'
                            } 
                            alt={contact} 
                            className="contact-avatar"
                          />
                          <span className="contact-online-dot"></span>
                        </div>
                        <div className="contact-info-col">
                          <div className="contact-name-row">
                            <span className="contact-name">{contact}</span>
                            <span className="contact-last-time">10:30 AM</span>
                          </div>
                          <p className="contact-preview-text">
                            {chatMessages[contact]?.[chatMessages[contact].length - 1]?.text || 'No messages yet'}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* RIGHT CHAT THREAD */}
                <div className="card active-chat-card">
                  {/* CHAT HEADER */}
                  <div className="chat-thread-header">
                    <div className="chat-recipient-info">
                      <div className="chat-recipient-avatar-wrap">
                        <img 
                          src={
                            activeChatContact === 'Stephanie' ? 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&auto=format&fit=crop&q=80' :
                            activeChatContact === 'Web Designing' ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&auto=format&fit=crop&q=80' :
                            'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&auto=format&fit=crop&q=80'
                          } 
                          alt={activeChatContact} 
                          className="chat-recipient-img"
                        />
                      </div>
                      <div>
                        <h4 className="chat-recipient-name">{activeChatContact}</h4>
                        <span className="chat-recipient-status">Active now • Product Lead</span>
                      </div>
                    </div>

                    <div className="chat-header-actions">
                      <button className="chat-header-btn" title="Start Call" onClick={() => showToast(`Calling ${activeChatContact}...`)}>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                      </button>
                      <button className="chat-header-btn" title="Video Meeting" onClick={() => showToast(`Starting video meeting with ${activeChatContact}...`)}>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="3" ry="3"/></svg>
                      </button>
                    </div>
                  </div>

                  {/* CHAT MESSAGES BODY */}
                  <div className="chat-bubbles-container">
                    {(chatMessages[activeChatContact] || []).map((msg, i) => (
                      <div key={i} className={`chat-bubble-row ${msg.isMe ? 'me' : 'them'}`}>
                        <div className={`chat-bubble ${msg.isMe ? 'bubble-me' : 'bubble-them'}`}>
                          <p>{msg.text}</p>
                          <span className="bubble-time">{msg.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* CHAT INPUT AREA */}
                  <div className="chat-input-row">
                    <button className="chat-attach-btn" onClick={() => showToast('Attachment browser opened')}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                    </button>
                    <input 
                      type="text" 
                      placeholder={`Message ${activeChatContact}...`}
                      value={chatInputText}
                      onChange={(e) => setChatInputText(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    />
                    <button className="chat-send-btn" onClick={handleSendMessage}>
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================= */}
            {/* VIEW 5: DELIVERABLES & DOWNLOADS VIEW */}
            {/* ================================================================= */}
            {currentView === 'downloads' && (
              <div className="view-page-layout downloads-page-layout">
                {/* TOP STORAGE CARD */}
                <div className="card storage-overview-card">
                  <div className="storage-header">
                    <div>
                      <span className="card-section-title">Deliverables & Downloads Vault</span>
                      <p className="sub-text">Exported Figma assets, iOS builds, PDFs, and token packages</p>
                    </div>
                    <div className="storage-badge-pill">64.2 GB / 100 GB Available</div>
                  </div>
                  <div className="storage-bar-outer">
                    <div className="storage-bar-inner" style={{ width: '64.2%' }}></div>
                  </div>
                </div>

                {/* DELIVERABLES GRID */}
                <div className="deliverables-grid">
                  {deliverables.map((item) => (
                    <div key={item.id} className="card deliverable-card">
                      <div className="deliverable-top">
                        <div className="file-icon-box">
                          {item.icon === 'figma' ? '🎨' : item.icon === 'zip' ? '📦' : item.icon === 'pdf' ? '📄' : '⚙️'}
                        </div>
                        <span className="file-type-pill">{item.type}</span>
                      </div>
                      <h4 className="deliverable-filename">{item.name}</h4>
                      <div className="deliverable-meta">
                        <span>{item.size}</span>
                        <span>•</span>
                        <span>{item.date}</span>
                      </div>
                      <button 
                        className="download-file-btn"
                        onClick={() => showToast(`Downloading ${item.name} (${item.size})...`)}
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                        <span>Download Asset</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ================================================================= */}
            {/* VIEW 6: SAVED BOOKMARKS VIEW */}
            {/* ================================================================= */}
            {currentView === 'bookmarks' && (
              <div className="view-page-layout bookmarks-page-layout">
                <div className="card bookmarks-main-card">
                  <div className="card-top-header">
                    <span className="card-section-title">Saved Resources & Design References</span>
                    <button className="new-invoice-btn" onClick={() => showToast('Bookmark modal opened')}>
                      + Add Bookmark
                    </button>
                  </div>

                  <div className="bookmarks-list-container">
                    {bookmarksList.map(bm => (
                      <div key={bm.id} className="bookmark-item-row" onClick={() => showToast(`Opening ${bm.url}...`)}>
                        <div className="bookmark-icon-wrap">🔖</div>
                        <div className="bookmark-info-col">
                          <h4 className="bookmark-title">{bm.title}</h4>
                          <span className="bookmark-url">{bm.url}</span>
                        </div>
                        <div className="bookmark-actions">
                          <span className="bookmark-cat-pill">{bm.category}</span>
                          <button 
                            className="bookmark-star-btn"
                            onClick={(e) => {
                              e.stopPropagation();
                              showToast(`Toggled favorite for ${bm.title}`);
                            }}
                          >
                            ⭐
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================= */}
            {/* VIEW 7: TEAM LOCATIONS & HUBS VIEW */}
            {/* ================================================================= */}
            {currentView === 'location' && (
              <div className="view-page-layout locations-page-layout">
                <div className="hubs-grid">
                  {/* Hub 1 */}
                  <div className="card hub-card">
                    <div className="hub-header">
                      <div>
                        <h3 className="hub-city">San Francisco (HQ)</h3>
                        <span className="hub-country">United States • PDT (UTC-7)</span>
                      </div>
                      <span className="hub-time-pill">09:42 AM</span>
                    </div>
                    <p className="hub-weather">☀️ 18°C Sunny • 12 Team members active</p>
                    <div className="avatar-stack mt-8">
                      <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                      <img src="https://images.unsplash.com/photo-1517841905240-472988babdf9?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                      <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                    </div>
                  </div>

                  {/* Hub 2 */}
                  <div className="card hub-card">
                    <div className="hub-header">
                      <div>
                        <h3 className="hub-city">London Studio</h3>
                        <span className="hub-country">United Kingdom • GMT (UTC+0)</span>
                      </div>
                      <span className="hub-time-pill">05:42 PM</span>
                    </div>
                    <p className="hub-weather">⛅ 14°C Partly Cloudy • 8 Team members</p>
                    <div className="avatar-stack mt-8">
                      <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                      <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                    </div>
                  </div>

                  {/* Hub 3 */}
                  <div className="card hub-card">
                    <div className="hub-header">
                      <div>
                        <h3 className="hub-city">Tokyo Innovation Lab</h3>
                        <span className="hub-country">Japan • JST (UTC+9)</span>
                      </div>
                      <span className="hub-time-pill">02:42 AM</span>
                    </div>
                    <p className="hub-weather">🌙 11°C Clear Night • Off duty</p>
                    <div className="avatar-stack mt-8">
                      <img src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                    </div>
                  </div>

                  {/* Hub 4 */}
                  <div className="card hub-card">
                    <div className="hub-header">
                      <div>
                        <h3 className="hub-city">Berlin Design Hub</h3>
                        <span className="hub-country">Germany • CET (UTC+1)</span>
                      </div>
                      <span className="hub-time-pill">06:42 PM</span>
                    </div>
                    <p className="hub-weather">☁️ 13°C Overcast • 6 Team members</p>
                    <div className="avatar-stack mt-8">
                      <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                      <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&auto=format&fit=crop&q=80" alt="team" className="stack-avatar" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================= */}
            {/* VIEW 8: FAVORITES & STARRED VIEW */}
            {/* ================================================================= */}
            {currentView === 'favorites' && (
              <div className="view-page-layout favorites-page-layout">
                <div className="card favorites-container-card">
                  <div className="card-top-header">
                    <span className="card-section-title">⭐ Starred Projects & VIP Teammates</span>
                    <span className="chart-badge-pill">4 items pinned</span>
                  </div>

                  <div className="favorites-list-grid">
                    <div className="favorite-item-card peach-card" onClick={() => navigateTo('projects')}>
                      <span className="fav-tag">PROJECT</span>
                      <h4>Web Designing</h4>
                      <p>90% completed • Due in 2 days</p>
                    </div>

                    <div className="favorite-item-card blue-card" onClick={() => navigateTo('messages')}>
                      <span className="fav-tag">TEAMMATE</span>
                      <h4>Stephanie (Product Lead)</h4>
                      <p>Active conversation • 3 unread</p>
                    </div>

                    <div className="favorite-item-card pink-card" onClick={() => navigateTo('projects')}>
                      <span className="fav-tag">PROJECT</span>
                      <h4>Dashboard UI Redesign</h4>
                      <p>70% completed • Due in 8 days</p>
                    </div>

                    <div className="favorite-item-card" onClick={() => navigateTo('downloads')}>
                      <span className="fav-tag">DELIVERABLE</span>
                      <h4>Fintech_App_Design_v3.fig</h4>
                      <p>48.2 MB • Updated 2 hours ago</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ================================================================= */}
            {/* VIEW 9: ACCOUNT SETTINGS VIEW */}
            {/* ================================================================= */}
            {currentView === 'settings' && (
              <div className="view-page-layout settings-page-layout">
                <div className="card settings-card">
                  <div className="settings-header-row">
                    <div>
                      <h3 className="card-section-title">Account & Workspace Settings</h3>
                      <p className="sub-text">Manage your personal profile and workspace preferences</p>
                    </div>
                    <button 
                      className="save-settings-btn"
                      onClick={() => showToast('Profile settings saved successfully!')}
                    >
                      Save Changes
                    </button>
                  </div>

                  <div className="settings-form-grid">
                    <div className="form-group">
                      <label>Full Name</label>
                      <input 
                        type="text" 
                        value={settingsForm.name} 
                        onChange={(e) => setSettingsForm({ ...settingsForm, name: e.target.value })}
                      />
                    </div>

                    <div className="form-group">
                      <label>Job Designation</label>
                      <input 
                        type="text" 
                        value={settingsForm.role} 
                        onChange={(e) => setSettingsForm({ ...settingsForm, role: e.target.value })}
                      />
                    </div>

                    <div className="form-group">
                      <label>Email Address</label>
                      <input 
                        type="email" 
                        value={settingsForm.email} 
                        onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                      />
                    </div>

                    <div className="form-group">
                      <label>Contact Phone</label>
                      <input 
                        type="text" 
                        value={settingsForm.phone} 
                        onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                      />
                    </div>

                    <div className="form-group full-width">
                      <label>Short Bio</label>
                      <input 
                        type="text" 
                        value={settingsForm.bio} 
                        onChange={(e) => setSettingsForm({ ...settingsForm, bio: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>

      </div>
    </div>
  );
}
