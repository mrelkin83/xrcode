import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './dashbord2.css';

export default function Dashbord2({ onSwitchToDashboard1 }) {
  // Navigation State
  // dock icons: 'dashboard' | 'profile' | 'analytics' | 'notifications' | 'calendar' | 'documents' | 'notes' | 'chat'
  const [activeDock, setActiveDock] = useState('dashboard');
  // top nav tabs: 'dashboard' | 'workflows' | 'integrations'
  const [activeNav, setActiveNav] = useState('dashboard');
  
  // Theme state
  const [theme, setTheme] = useState('light');
  const [searchQuery, setSearchQuery] = useState('');

  // Dashboard Overview state
  const [selectedDay, setSelectedDay] = useState(18);
  const [calendarWeekOffset, setCalendarWeekOffset] = useState(0);
  const [activeTab, setActiveTab] = useState('motion');

  // Tasks state
  const [tasks, setTasks] = useState([
    {
      id: 1,
      title: 'Conduct research',
      date: '4 May, 09:20 AM',
      duration: '02 h 45 m',
      progress: 90,
      chats: 4,
      attachments: 16,
      completed: false
    },
    {
      id: 2,
      title: 'Schedule a meeting',
      date: '14 May, 12:45 AM',
      duration: '06 h 55 m',
      progress: 50,
      chats: 4,
      dateLabel: '3 June',
      completed: false
    },
    {
      id: 3,
      title: 'Send out reminders',
      date: '21 May, 10:30 AM',
      duration: '01 h 30 m',
      progress: 10,
      chats: 16,
      dateLabel: '3 June',
      completed: false
    }
  ]);

  // Notifications state
  const [notifications, setNotifications] = useState([
    {
      id: 'event-1',
      type: 'event',
      title: 'Upcoming event',
      subtitle: 'Landing design meeting | Time: 120 min',
      date: 'Sat, 10 May',
      time: '11 AM - 11:45 AM'
    },
    {
      id: 'msg-1',
      type: 'message',
      title: 'Message | Product design',
      sender: 'Ken Smith',
      snippet: 'Hey team, just wanted to check in and see how is the prototype...'
    }
  ]);

  // Chat View State
  const [activeContact, setActiveContact] = useState('ken');
  const [chatMessages, setChatMessages] = useState([
    { id: 1, sender: 'them', text: 'Hey James! Did you check out the new design system tokens?' },
    { id: 2, sender: 'me', text: 'Yes, looking sharp! Just finalizing the typography scale now.' },
    { id: 3, sender: 'them', text: 'Awesome! Let’s review during the 4 PM board meeting.' }
  ]);
  const [newChatInput, setNewChatInput] = useState('');

  // Toast State
  const [toast, setToast] = useState({ show: false, message: '' });

  const showToast = (message) => {
    setToast({ show: true, message });
    setTimeout(() => {
      setToast({ show: false, message: '' });
    }, 2400);
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    showToast('All notifications cleared');
  };

  const removeNotification = (id) => {
    setNotifications((prev) => prev.filter((item) => item.id !== id));
    showToast('Notification removed');
  };

  const toggleTask = (id) => {
    setTasks((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
    showToast('Task updated');
  };

  const handleSendChatMessage = (e) => {
    e.preventDefault();
    if (!newChatInput.trim()) return;
    const msg = {
      id: Date.now(),
      sender: 'me',
      text: newChatInput.trim()
    };
    setChatMessages((prev) => [...prev, msg]);
    setNewChatInput('');
    showToast('Message sent to ' + (activeContact === 'ken' ? 'Ken Smith' : 'Rachel Lee'));
  };

  // Helper to switch view from dock or top nav
  const switchDockView = (viewKey, label) => {
    setActiveDock(viewKey);
    if (viewKey === 'dashboard') {
      setActiveNav('dashboard');
    }
    showToast(`Opened ${label}`);
  };

  return (
    <div className={`d2-canvas ${theme === 'dark' ? 'd2-theme-dark' : ''}`}>
      {/* QUICK SWITCHER BUTTON TO DASHBOARD 1 */}
      {onSwitchToDashboard1 && (
        <button
          className="d2-dashboard-switcher"
          onClick={onSwitchToDashboard1}
          title="Switch to Dashboard 1 (Mac Dock showcase)"
        >
          <span>← Dashboard 1</span>
        </button>
      )}

      <div className="d2-container">
        {/* ═══════════════════════════════════════════════════════════════
            LEFT CURVED WAVE DOCK (NAVIGATE TO ANY ICON)
            ═══════════════════════════════════════════════════════════════ */}
        <aside className="d2-sidebar-wrapper" aria-label="Sidebar Dock">
          <svg className="d2-sidebar-bg-svg" viewBox="0 0 80 800" preserveAspectRatio="none">
            <path
              d="M 0,0 
                 L 22,0 
                 C 22,100 80,140 80,240 
                 L 80,600 
                 C 80,700 22,740 22,800 
                 L 0,800 Z"
              fill="#595ef2"
            />
          </svg>

          <div className="d2-sidebar-nav">
            {/* 1. DASHBOARD */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              className={`d2-dock-item ${activeDock === 'dashboard' ? 'active' : ''}`}
              onClick={() => switchDockView('dashboard', 'Dashboard Overview')}
              title="Dashboard Overview"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <rect x="3" y="3" width="7" height="7" rx="2" />
                <rect x="14" y="3" width="7" height="7" rx="2" />
                <rect x="3" y="14" width="7" height="7" rx="2" />
                <rect x="14" y="14" width="7" height="7" rx="2" />
              </svg>
            </motion.button>

            {/* 2. PROFILE */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              className={`d2-dock-item ${activeDock === 'profile' ? 'active' : ''}`}
              onClick={() => switchDockView('profile', 'User Profile')}
              title="User Profile"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
            </motion.button>

            {/* 3. ANALYTICS (PRO) */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              className={`d2-dock-item ${activeDock === 'analytics' ? 'active' : ''}`}
              onClick={() => switchDockView('analytics', 'Pro Analytics')}
              title="Pro Analytics"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
                <path d="M22 12A10 10 0 0 0 12 2v10z" />
              </svg>
              <span className="d2-pro-badge">PRO</span>
            </motion.button>

            {/* 4. NOTIFICATIONS */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              className={`d2-dock-item ${activeDock === 'notifications' ? 'active' : ''}`}
              onClick={() => switchDockView('notifications', 'Notifications Center')}
              title="Notifications"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                <path d="M13.73 21a2 2 0 0 1-3.46 0" />
              </svg>
            </motion.button>

            {/* 5. CALENDAR */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              className={`d2-dock-item ${activeDock === 'calendar' ? 'active' : ''}`}
              onClick={() => switchDockView('calendar', 'Calendar Schedule')}
              title="Calendar Schedule"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                <line x1="16" y1="2" x2="16" y2="6" />
                <line x1="8" y1="2" x2="8" y2="6" />
                <line x1="3" y1="10" x2="21" y2="10" />
              </svg>
            </motion.button>

            {/* 6. DOCUMENTS */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              className={`d2-dock-item ${activeDock === 'documents' ? 'active' : ''}`}
              onClick={() => switchDockView('documents', 'Documents & Files')}
              title="Documents & Files"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                <circle cx="12" cy="13" r="1.5" fill="currentColor" />
              </svg>
            </motion.button>

            {/* 7. NOTES */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              className={`d2-dock-item ${activeDock === 'notes' ? 'active' : ''}`}
              onClick={() => switchDockView('notes', 'Notes & Drafts')}
              title="Notes & Drafts"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
                <line x1="16" y1="13" x2="8" y2="13" />
                <line x1="16" y1="17" x2="8" y2="17" />
              </svg>
            </motion.button>

            {/* 8. CHAT */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              className={`d2-dock-item ${activeDock === 'chat' ? 'active' : ''}`}
              onClick={() => switchDockView('chat', 'Team Messages & Chat')}
              title="Team Messages"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
            </motion.button>
          </div>
        </aside>

        {/* ═══════════════════════════════════════════════════════════════
            MAIN WORKSPACE
            ═══════════════════════════════════════════════════════════════ */}
        <main className="d2-main-workspace">
          {/* HEADER BAR */}
          <header className="d2-header">
            <nav className="d2-nav-links">
              <button
                className={`d2-nav-item ${activeNav === 'dashboard' && activeDock === 'dashboard' ? 'active' : ''}`}
                onClick={() => {
                  setActiveNav('dashboard');
                  setActiveDock('dashboard');
                  showToast('Navigated to Dashboard');
                }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                  <rect x="3" y="3" width="7" height="7" rx="1.5" />
                  <rect x="14" y="3" width="7" height="7" rx="1.5" />
                  <rect x="3" y="14" width="7" height="7" rx="1.5" />
                  <rect x="14" y="14" width="7" height="7" rx="1.5" />
                </svg>
                <span>Dashboard</span>
              </button>

              <button
                className={`d2-nav-item ${activeNav === 'workflows' ? 'active' : ''}`}
                onClick={() => {
                  setActiveNav('workflows');
                  showToast('Navigated to Workflows');
                }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="6" height="6" rx="1" />
                  <rect x="15" y="15" width="6" height="6" rx="1" />
                  <path d="M6 9v3a3 3 0 0 0 3 3h6" />
                </svg>
                <span>Workflows</span>
              </button>

              <button
                className={`d2-nav-item ${activeNav === 'integrations' ? 'active' : ''}`}
                onClick={() => {
                  setActiveNav('integrations');
                  showToast('Navigated to Integrations');
                }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="12 2 2 7 12 12 22 7 12 2" />
                  <polyline points="2 17 12 22 22 17" />
                  <polyline points="2 12 12 17 22 12" />
                </svg>
                <span>Integrations</span>
              </button>
            </nav>

            <div className="d2-search-container">
              <svg className="d2-search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input
                type="text"
                className="d2-search-input"
                placeholder="Search or type command"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="d2-header-actions">
              {/* THEME TOGGLE */}
              <div className="d2-theme-toggle">
                <button
                  className={`d2-theme-btn ${theme === 'light' ? 'active' : ''}`}
                  onClick={() => setTheme('light')}
                >
                  <span>☀</span>
                  <span>Light</span>
                </button>
                <button
                  className={`d2-theme-btn ${theme === 'dark' ? 'active' : ''}`}
                  onClick={() => {
                    setTheme('dark');
                    showToast('Dark mode enabled');
                  }}
                >
                  <span>🌙</span>
                  <span>Dark</span>
                </button>
              </div>

              {/* NOTIFICATION BELL */}
              <button
                className="d2-action-icon-btn"
                onClick={() => switchDockView('notifications', 'Notifications Center')}
                title="Notifications"
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                  <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                </svg>
                <span className="d2-action-dot" />
              </button>

              {/* SETTINGS GEAR */}
              <button
                className="d2-action-icon-btn"
                onClick={() => switchDockView('profile', 'Settings & Profile')}
                title="Settings"
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3" />
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
                </svg>
              </button>

              {/* EXPORT DATA */}
              <button
                className="d2-export-btn"
                onClick={() => showToast('Exported 42 records to .xls')}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <polyline points="19 12 12 19 5 12" />
                </svg>
                <span>Export data</span>
                <span className="d2-xls-tag">.xls</span>
              </button>

              {/* ADD NEW BOARD */}
              <button
                className="d2-add-board-btn"
                onClick={() => showToast('New board created successfully!')}
              >
                <span>Add new board</span>
              </button>
            </div>
          </header>

          {/* ═══════════════════════════════════════════════════════════════
              DYNAMIC CONTENT VIEW ROUTER
              ═══════════════════════════════════════════════════════════════ */}
          <div className="d2-view-viewport">
            <AnimatePresence mode="wait">
              {/* VIEW 1: DASHBOARD OVERVIEW (EXACT SCREENSHOT LAYOUT) */}
              {activeDock === 'dashboard' && activeNav === 'dashboard' && (
                <motion.div
                  key="view-dashboard"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                  className="d2-content-rows"
                >
                  {/* ROW 1: GREETINGS & 4 FEATURE CARDS */}
                  <section className="d2-row-top">
                    <div className="d2-greeting-col">
                      <div className="d2-greeting-header">
                        <h2 className="d2-greeting-name">Hi, James!</h2>
                        <div className="d2-avatar-bubbles">
                          <span className="d2-avatar-bubble purple">J</span>
                          <span className="d2-avatar-bubble cyan">✦</span>
                        </div>
                      </div>
                      <h1 className="d2-greeting-question">
                        What are your
                        <br />
                        planes for today?
                      </h1>
                      <p className="d2-greeting-sub">
                        This platform is designed to revolutionize the way you organize and access your notes
                      </p>
                    </div>

                    <div className="d2-feature-cards">
                      {/* CARD 1: ADD BUTTON CARD */}
                      <div
                        className="d2-add-feature-card"
                        onClick={() => showToast('Create new quick note')}
                        title="Create Note"
                      >
                        <div className="d2-add-square-btn">
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
                            <line x1="12" y1="5" x2="12" y2="19" />
                            <line x1="5" y1="12" x2="19" y2="12" />
                          </svg>
                        </div>
                      </div>

                      {/* CARD 2: STAY ORGANIZED */}
                      <div
                        className="d2-feature-card"
                        onClick={() => switchDockView('notes', 'Notes & Structure')}
                      >
                        <div className="d2-feature-illu">
                          <svg width="44" height="44" viewBox="0 0 64 64" fill="none">
                            <rect x="14" y="16" width="36" height="42" rx="4" stroke="#1e293b" strokeWidth="2.5" fill="#ffffff" />
                            <line x1="22" y1="10" x2="22" y2="18" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
                            <line x1="32" y1="10" x2="32" y2="18" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
                            <line x1="42" y1="10" x2="42" y2="18" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
                            <path d="M22 28h20 M22 36h12" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" strokeDasharray="3 3" />
                            <rect x="22" y="42" width="10" height="10" rx="2" fill="#595df5" />
                            <path d="M25 47l2 2 4-4" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="d2-feature-card-title">Stay organized</h3>
                          <p className="d2-feature-card-desc">A clear structure for your notes</p>
                        </div>
                      </div>

                      {/* CARD 3: SYNC YOUR NOTES */}
                      <div
                        className="d2-feature-card"
                        onClick={() => showToast('All cloud notes in sync')}
                      >
                        <div className="d2-feature-illu">
                          <svg width="44" height="44" viewBox="0 0 64 64" fill="none">
                            <line x1="8" y1="20" x2="56" y2="18" stroke="#1e293b" strokeWidth="2" strokeDasharray="4 4" />
                            <g transform="rotate(-6 22 26)">
                              <rect x="18" y="20" width="16" height="24" rx="2" stroke="#1e293b" strokeWidth="2" fill="#ffffff" />
                              <line x1="22" y1="26" x2="30" y2="26" stroke="#94a3b8" strokeWidth="1.5" />
                              <line x1="22" y1="30" x2="28" y2="30" stroke="#94a3b8" strokeWidth="1.5" />
                              <line x1="22" y1="34" x2="31" y2="34" stroke="#94a3b8" strokeWidth="1.5" />
                              <rect x="24" y="17" width="4" height="6" rx="1" fill="#595df5" />
                            </g>
                            <g transform="rotate(10 38 28)">
                              <rect x="36" y="20" width="16" height="24" rx="2" stroke="#1e293b" strokeWidth="2" fill="#ffffff" />
                              <circle cx="44" cy="30" r="3" fill="#38bdf8" />
                              <line x1="40" y1="36" x2="48" y2="36" stroke="#94a3b8" strokeWidth="1.5" />
                              <rect x="42" y="17" width="4" height="6" rx="1" fill="#1e293b" />
                            </g>
                          </svg>
                        </div>
                        <div>
                          <h3 className="d2-feature-card-title">Sync your notes</h3>
                          <p className="d2-feature-card-desc">Ensure that notes are synced</p>
                        </div>
                      </div>

                      {/* CARD 4: COLLABORATE AND SHARE */}
                      <div
                        className="d2-feature-card"
                        onClick={() => showToast('Share invite modal opened')}
                      >
                        <div className="d2-feature-illu">
                          <svg width="44" height="44" viewBox="0 0 64 64" fill="none">
                            <rect x="14" y="18" width="36" height="30" rx="3" stroke="#1e293b" strokeWidth="2.5" fill="#ffffff" />
                            <path d="M22 18V28H42V18" stroke="#1e293b" strokeWidth="2" fill="#f1f5f9" />
                            <line x1="26" y1="23" x2="38" y2="23" stroke="#595df5" strokeWidth="2.5" strokeLinecap="round" />
                            <text x="44" y="14" fill="#595df5" fontSize="10" fontWeight="bold">
                              -6x
                            </text>
                            <circle cx="22" cy="40" r="3" stroke="#1e293b" strokeWidth="2" fill="#ffffff" />
                            <line x1="28" y1="40" x2="42" y2="40" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="d2-feature-card-title">Collaborate and share</h3>
                          <p className="d2-feature-card-desc">Share notes with colleagues</p>
                        </div>
                      </div>
                    </div>
                  </section>

                  {/* ROW 2: NOTIFICATIONS, ASSIGNMENTS, SCHEDULE */}
                  <section className="d2-row-mid">
                    {/* NOTIFICATIONS */}
                    <div className="d2-col-notifications">
                      <div className="d2-card-header">
                        <h3 className="d2-card-title">Notifications</h3>
                        <button className="d2-card-header-btn" onClick={clearAllNotifications}>
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="3 6 5 6 21 6" />
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                          </svg>
                          <span>Clear</span>
                        </button>
                      </div>

                      {notifications.find((item) => item.id === 'event-1') && (
                        <div className="d2-upcoming-card">
                          <div className="d2-upcoming-top">
                            <div className="d2-upcoming-title">
                              <span>Upcoming event</span>
                              <span className="d2-green-status-dot" />
                            </div>
                            <div className="d2-upcoming-actions">
                              <button onClick={() => removeNotification('event-1')} title="Delete">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <polyline points="3 6 5 6 21 6" />
                                  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                                </svg>
                              </button>
                              <button onClick={() => showToast('Edit event')} title="Edit">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                                </svg>
                              </button>
                            </div>
                          </div>
                          <p className="d2-upcoming-desc">Landing design meeting | Time: 120 min</p>
                          <div className="d2-upcoming-pills">
                            <span className="d2-time-pill">
                              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                                <line x1="16" y1="2" x2="16" y2="6" />
                                <line x1="8" y1="2" x2="8" y2="6" />
                              </svg>
                              <span>Sat, 10 May</span>
                            </span>
                            <span className="d2-time-pill">
                              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <circle cx="12" cy="12" r="10" />
                                <polyline points="12 6 12 12 16 14" />
                              </svg>
                              <span>11 AM - 11:45 AM</span>
                            </span>
                          </div>
                        </div>
                      )}

                      {notifications.find((item) => item.id === 'msg-1') && (
                        <div
                          className="d2-msg-notification"
                          onClick={() => switchDockView('chat', 'Chat with Ken Smith')}
                          style={{ cursor: 'pointer' }}
                        >
                          <div className="d2-msg-title-row">
                            <span className="d2-msg-title">Message | Product design</span>
                            <span style={{ color: '#94a3b8', fontSize: '11px' }}>•••</span>
                          </div>
                          <div className="d2-msg-sender">
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                              <polyline points="22,6 12,13 2,6" />
                            </svg>
                            <span>Message from Ken Smith</span>
                          </div>
                          <div className="d2-msg-snippet">Hey team, just wanted to check in and see how is...</div>
                        </div>
                      )}
                    </div>

                    {/* ASSIGNMENTS */}
                    <div className="d2-col-assignments">
                      <div className="d2-card-header">
                        <h3 className="d2-card-title">Assignments</h3>
                        <button className="d2-card-header-btn" onClick={() => showToast('Edit assignments')}>
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                          </svg>
                          <span>Edit</span>
                        </button>
                      </div>

                      <div className="d2-filter-tabs">
                        <button
                          className={`d2-tab-btn ${activeTab === 'motion' ? 'active' : ''}`}
                          onClick={() => setActiveTab('motion')}
                        >
                          Motion design
                        </button>
                        <button
                          className={`d2-tab-btn ${activeTab === 'logo' ? 'active' : ''}`}
                          onClick={() => setActiveTab('logo')}
                        >
                          Logo
                        </button>
                      </div>

                      <div className="d2-assignment-card">
                        <div className="d2-assignment-top-row">
                          <h4 className="d2-assignment-title">Design a packaging concept for a new product</h4>
                          <span className="d2-priority-badge">High</span>
                        </div>
                        <div className="d2-assignment-bottom-row">
                          <span className="d2-package-tag">Package design</span>
                          <div className="d2-assignee-info">
                            <span>Rachel Lee</span>
                            <div className="d2-assignee-avatar" />
                          </div>
                        </div>
                      </div>

                      <button
                        className="d2-add-assignment-btn"
                        onClick={() => showToast('Create new assignment modal')}
                      >
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
                          <line x1="12" y1="5" x2="12" y2="19" />
                          <line x1="5" y1="12" x2="19" y2="12" />
                        </svg>
                        <span>Add new assignment</span>
                      </button>
                    </div>

                    {/* SCHEDULE & CALENDAR */}
                    <div className="d2-col-schedule">
                      <div className="d2-card-header">
                        <h3 className="d2-card-title">
                          {calendarWeekOffset === 0
                            ? 'May 2021'
                            : calendarWeekOffset > 0
                            ? 'June 2021'
                            : 'April 2021'}
                        </h3>
                        <div style={{ display: 'flex', gap: '4px' }}>
                          <button
                            className="d2-card-header-btn"
                            onClick={() => {
                              setCalendarWeekOffset((prev) => prev - 1);
                              showToast('Previous week');
                            }}
                          >
                            &lt;
                          </button>
                          <button
                            className="d2-card-header-btn"
                            onClick={() => {
                              setCalendarWeekOffset((prev) => prev + 1);
                              showToast('Next week');
                            }}
                          >
                            &gt;
                          </button>
                        </div>
                      </div>

                      <div className="d2-calendar-strip">
                        {[
                          { day: 'Mon', num: 14 },
                          { day: 'Tue', num: 15 },
                          { day: 'Wed', num: 16 },
                          { day: 'Thr', num: 17 },
                          { day: 'Fr', num: 18 },
                          { day: 'Sat', num: 19 },
                          { day: 'Sun', num: 20 }
                        ].map((item) => (
                          <div
                            key={item.num}
                            className="d2-day-col"
                            onClick={() => {
                              setSelectedDay(item.num);
                              showToast(`Selected ${item.day} ${item.num}`);
                            }}
                          >
                            <span className="d2-day-name">{item.day}</span>
                            <span className={`d2-day-num ${selectedDay === item.num ? 'active' : ''}`}>
                              {item.num}
                            </span>
                          </div>
                        ))}
                      </div>

                      <div className="d2-timeline-list">
                        <div className="d2-timeline-slot">
                          <div className="d2-time-label-row">
                            <span>04:30-05:00 PM</span>
                            <span className="d2-time-dash" />
                          </div>
                          <div className="d2-event-card">
                            <div className="d2-event-left">
                              <div className="d2-event-icon-box purple">
                                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                                  <circle cx="9" cy="7" r="4" />
                                  <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                                </svg>
                              </div>
                              <div className="d2-event-info">
                                <span className="d2-event-title">Team meeting</span>
                                <span className="d2-event-sub">12:00 - 12:30 • UX/UI design</span>
                              </div>
                            </div>
                            <span style={{ color: '#94a3b8', fontSize: '11px', cursor: 'pointer' }}>•••</span>
                          </div>
                        </div>

                        <div className="d2-timeline-slot">
                          <div className="d2-time-label-row">
                            <span>11:30-12:30 PM</span>
                            <span className="d2-time-dash" />
                          </div>
                          <div className="d2-event-card">
                            <div className="d2-event-left">
                              <div className="d2-event-icon-box slate">
                                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
                                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                                </svg>
                              </div>
                              <div className="d2-event-info">
                                <span className="d2-event-title">Meeting with new client</span>
                                <span className="d2-event-sub">12:30 - 01:30 PM • Job interview</span>
                              </div>
                            </div>
                            <span style={{ color: '#94a3b8', fontSize: '11px', cursor: 'pointer' }}>•••</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>

                  {/* ROW 3: TODAY TASKS, PREMIUM CARD, METRICS & MEETING */}
                  <section className="d2-row-bottom">
                    {/* TODAY TASKS */}
                    <div className="d2-col-today-tasks">
                      <div className="d2-card-header">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <h3 className="d2-card-title">Today tasks</h3>
                          <div className="d2-stacked-avatars">
                            <div className="d2-stacked-avatar" style={{ backgroundColor: '#f97316' }} />
                            <div className="d2-stacked-avatar" style={{ backgroundColor: '#06b6d4' }} />
                            <div className="d2-stacked-avatar" style={{ backgroundColor: '#6366f1', color: '#fff', fontSize: '9px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</div>
                          </div>
                        </div>
                        <div className="d2-today-header-right">
                          <span style={{ fontSize: '10.5px', color: '#94a3b8', fontWeight: 600 }}>38 08</span>
                          <button className="d2-card-header-btn" onClick={() => showToast('Edit today tasks')}>
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                            </svg>
                            <span>Edit</span>
                          </button>
                          <button className="d2-card-header-btn" onClick={() => showToast('Shared task summary')}>
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <circle cx="18" cy="5" r="3" />
                              <circle cx="6" cy="12" r="3" />
                              <circle cx="18" cy="19" r="3" />
                              <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
                              <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
                            </svg>
                            <span>Share</span>
                          </button>
                        </div>
                      </div>

                      {tasks.map((task) => (
                        <div
                          key={task.id}
                          className="d2-task-row"
                          onClick={() => toggleTask(task.id)}
                          style={{ cursor: 'pointer' }}
                        >
                          <div className="d2-task-name-col">
                            <span className="d2-task-name" style={{ textDecoration: task.completed ? 'line-through' : 'none', opacity: task.completed ? 0.6 : 1 }}>
                              {task.title}
                            </span>
                            <span className="d2-task-date">{task.date}</span>
                          </div>
                          <div className="d2-task-duration-col">
                            <span className="d2-task-duration-label">Duration</span>
                            <span>{task.duration}</span>
                          </div>
                          <div className="d2-task-progress-col">
                            <span className="d2-task-pct">{task.progress}%</span>
                            <div className="d2-progress-bar-bg">
                              <div className="d2-progress-bar-fill" style={{ width: `${task.progress}%` }} />
                            </div>
                          </div>
                          <div className="d2-task-meta-col">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                            </svg>
                            <span>{task.chats}</span>
                            {task.attachments && (
                              <>
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
                                </svg>
                                <span>{task.attachments}</span>
                              </>
                            )}
                            {task.dateLabel && <span>{task.dateLabel}</span>}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* PREMIUM CARD */}
                    <div className="d2-premium-card">
                      <div className="d2-premium-illu">
                        <svg width="56" height="56" viewBox="0 0 64 64" fill="none">
                          <rect x="20" y="24" width="24" height="22" rx="3" stroke="#ffffff" strokeWidth="2" fill="rgba(255,255,255,0.12)" />
                          <line x1="32" y1="24" x2="32" y2="46" stroke="#ffffff" strokeWidth="2" />
                          <line x1="20" y1="32" x2="44" y2="32" stroke="#ffffff" strokeWidth="2" />
                          <path d="M26 24C26 20 30 18 32 24C34 18 38 20 38 24" stroke="#ffffff" strokeWidth="2" fill="none" />
                          <path d="M14 16l2 2-2 2-2-2z" fill="#fde047" />
                          <path d="M48 14l2 2-2 2-2-2z" fill="#fde047" />
                          <circle cx="16" cy="30" r="1.5" fill="#ffffff" />
                          <circle cx="48" cy="36" r="1.5" fill="#ffffff" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="d2-premium-title">Go premium!</h3>
                        <p className="d2-premium-desc">Gain access to a range of benefits designed to enhance your user experience</p>
                      </div>
                      <button className="d2-premium-btn" onClick={() => switchDockView('analytics', 'Premium Pro Analytics')}>
                        Find out more
                      </button>
                    </div>

                    {/* METRICS GAUGES & BOARD MEETING */}
                    <div className="d2-col-metrics-meeting">
                      <div className="d2-gauges-card">
                        <div className="d2-gauge-item">
                          <div className="d2-donut-wrapper">
                            <svg className="d2-donut-svg" viewBox="0 0 36 36">
                              <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#e2e8f0" strokeWidth="3.5" />
                              <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#06b6d4" strokeWidth="3.5" strokeDasharray="90, 100" strokeLinecap="round" />
                            </svg>
                            <span className="d2-donut-pct">90%</span>
                          </div>
                          <div className="d2-gauge-info">
                            <span className="d2-gauge-category cyan">DATA RESEARCH</span>
                            <span className="d2-gauge-title">Marketing</span>
                            <span className="d2-gauge-sub">You marked 5/5. All done!</span>
                          </div>
                        </div>

                        <div className="d2-gauge-item">
                          <div className="d2-donut-wrapper">
                            <svg className="d2-donut-svg" viewBox="0 0 36 36">
                              <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#e2e8f0" strokeWidth="3.5" />
                              <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#ef4444" strokeWidth="3.5" strokeDasharray="65, 100" strokeLinecap="round" />
                            </svg>
                            <span className="d2-donut-pct">65%</span>
                          </div>
                          <div className="d2-gauge-info">
                            <span className="d2-gauge-category red">UX/UI DESIGN</span>
                            <span className="d2-gauge-title">Typography</span>
                            <span className="d2-gauge-sub">3/5 marked. 2 left</span>
                            <button className="d2-check-btn" onClick={() => showToast('Assignments reviewed')}>
                              Check
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="d2-board-meeting-card">
                        <div className="d2-meeting-title-row">
                          <h4 className="d2-meeting-title">Board meeting</h4>
                          <button className="d2-card-header-btn" onClick={() => showToast('Edit meeting')}>
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                            </svg>
                            <span>Edit</span>
                          </button>
                        </div>
                        <div className="d2-meeting-time">
                          <span style={{ color: '#595df5', fontSize: '12px' }}>•</span>
                          <span>March 24 at 4:00 PM</span>
                        </div>
                        <p className="d2-meeting-desc">Meeting with John Smith, 4th floor, room 159</p>
                        <div className="d2-meeting-btn-row">
                          <button className="d2-reschedule-btn" onClick={() => showToast('Reschedule modal opened')}>
                            Reschedule
                          </button>
                          <button className="d2-accept-btn" onClick={() => showToast('Meeting invite accepted!')}>
                            Accept invite
                          </button>
                        </div>
                      </div>
                    </div>
                  </section>
                </motion.div>
              )}

              {/* VIEW 2: PROFILE VIEW */}
              {activeDock === 'profile' && (
                <motion.div
                  key="view-profile"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="d2-generic-view"
                >
                  <div className="d2-view-banner">
                    <div className="d2-view-banner-text">
                      <h2>User Profile & Workspace Account</h2>
                      <p>Manage your professional identity, design credentials, and notification settings</p>
                    </div>
                    <button className="d2-banner-btn" onClick={() => showToast('Profile changes saved!')}>
                      Save Changes
                    </button>
                  </div>

                  <div className="d2-generic-grid-2">
                    <div className="d2-view-card">
                      <h3>Personal Information</h3>
                      <div className="d2-info-row">
                        <span className="d2-info-label">Full Name</span>
                        <span className="d2-info-value">James Wilson</span>
                      </div>
                      <div className="d2-info-row">
                        <span className="d2-info-label">Designation</span>
                        <span className="d2-info-value">Lead Product Designer & UI Architect</span>
                      </div>
                      <div className="d2-info-row">
                        <span className="d2-info-label">Email Address</span>
                        <span className="d2-info-value">james.wilson@designhub.studio</span>
                      </div>
                      <div className="d2-info-row">
                        <span className="d2-info-label">Department</span>
                        <span className="d2-info-value">Global Experience Design (UX/UI)</span>
                      </div>
                      <div className="d2-info-row">
                        <span className="d2-info-label">Timezone</span>
                        <span className="d2-info-value">Pacific Standard Time (PST - UTC-8)</span>
                      </div>
                    </div>

                    <div className="d2-view-card">
                      <h3>Performance & Stats</h3>
                      <div className="d2-stat-grid">
                        <div className="d2-stat-item">
                          <span className="d2-stat-num">48</span>
                          <span className="d2-stat-label">Projects Shipped</span>
                        </div>
                        <div className="d2-stat-item">
                          <span className="d2-stat-num">99.2%</span>
                          <span className="d2-stat-label">On-time Delivery</span>
                        </div>
                        <div className="d2-stat-item">
                          <span className="d2-stat-num">14</span>
                          <span className="d2-stat-label">Active Team Members</span>
                        </div>
                        <div className="d2-stat-item">
                          <span className="d2-stat-num">4.9/5</span>
                          <span className="d2-stat-label">Client CSAT Score</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* VIEW 3: PRO ANALYTICS VIEW */}
              {activeDock === 'analytics' && (
                <motion.div
                  key="view-analytics"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="d2-generic-view"
                >
                  <div className="d2-view-banner">
                    <div className="d2-view-banner-text">
                      <h2>Pro Analytics & Insights 📊</h2>
                      <p>Real-time metrics, project velocity, and resource utilization</p>
                    </div>
                    <button className="d2-banner-btn" onClick={() => showToast('Generated full PDF report')}>
                      Export Full Report
                    </button>
                  </div>

                  <div className="d2-kpi-strip">
                    <div className="d2-kpi-card">
                      <div className="d2-kpi-title">Total Revenue</div>
                      <div className="d2-kpi-value">$48,250 <span className="d2-kpi-change up">+14.2%</span></div>
                    </div>
                    <div className="d2-kpi-card">
                      <div className="d2-kpi-title">Active Workspaces</div>
                      <div className="d2-kpi-value">12,840 <span className="d2-kpi-change up">+8.5%</span></div>
                    </div>
                    <div className="d2-kpi-card">
                      <div className="d2-kpi-title">Sprint Completion</div>
                      <div className="d2-kpi-value">94.6% <span className="d2-kpi-change up">+3.1%</span></div>
                    </div>
                    <div className="d2-kpi-card">
                      <div className="d2-kpi-title">Avg Session Time</div>
                      <div className="d2-kpi-value">42m 18s <span className="d2-kpi-change down">-1.4%</span></div>
                    </div>
                  </div>

                  <div className="d2-generic-grid-2">
                    <div className="d2-view-card">
                      <h3>Weekly Task Velocity</h3>
                      <div className="d2-bar-chart">
                        {[
                          { day: 'Mon', h: 65, active: false },
                          { day: 'Tue', h: 80, active: false },
                          { day: 'Wed', h: 45, active: false },
                          { day: 'Thu', h: 90, active: true },
                          { day: 'Fri', h: 75, active: false },
                          { day: 'Sat', h: 30, active: false },
                          { day: 'Sun', h: 20, active: false }
                        ].map((b, idx) => (
                          <div key={idx} className="d2-bar-col" onClick={() => showToast(`${b.day}: ${b.h}% completion`)}>
                            <div className={`d2-bar ${b.active ? 'active' : ''}`} style={{ height: `${b.h}%` }} />
                            <span className="d2-bar-label">{b.day}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="d2-view-card">
                      <h3>Traffic & Work Allocation</h3>
                      <div className="d2-channel-item">
                        <span className="d2-channel-name">UX Design & Wireframing</span>
                        <span className="d2-channel-pct">42%</span>
                      </div>
                      <div className="d2-channel-item">
                        <span className="d2-channel-name">Design Systems & Tokens</span>
                        <span className="d2-channel-pct">28%</span>
                      </div>
                      <div className="d2-channel-item">
                        <span className="d2-channel-name">Client Reviews & Meetings</span>
                        <span className="d2-channel-pct">18%</span>
                      </div>
                      <div className="d2-channel-item">
                        <span className="d2-channel-name">Prototyping & Motion</span>
                        <span className="d2-channel-pct">12%</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* VIEW 4: NOTIFICATIONS VIEW */}
              {activeDock === 'notifications' && (
                <motion.div
                  key="view-notifications"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="d2-generic-view"
                >
                  <div className="d2-view-banner">
                    <div className="d2-view-banner-text">
                      <h2>Notifications Center 🔔</h2>
                      <p>Review updates, meeting reminders, team comments, and system alerts</p>
                    </div>
                    <button className="d2-banner-btn" onClick={() => showToast('All notifications marked as read')}>
                      Mark All as Read
                    </button>
                  </div>

                  <div className="d2-notif-stack">
                    {[
                      { dot: 'purple', title: 'Board meeting today at 4:00 PM', desc: 'Room 159 with John Smith & Design Directors', time: '10 min ago' },
                      { dot: 'green', title: 'Rachel Lee completed Packaging concept', desc: 'Review requested on Figma file #packaging-v2', time: '35 min ago' },
                      { dot: 'blue', title: 'Ken Smith sent a message in Product design', desc: '"Hey team, just wanted to check in on prototype..."', time: '1 hour ago' },
                      { dot: 'amber', title: 'Data Research assignment marked 90%', desc: '5 of 5 checklist items completed successfully', time: '2 hours ago' },
                      { dot: 'gray', title: 'System security update deployed', desc: 'OAuth token refreshed for GitHub and Slack integration', time: 'Yesterday' }
                    ].map((n, i) => (
                      <div key={i} className="d2-notif-center-item" onClick={() => showToast(`Selected: ${n.title}`)} style={{ cursor: 'pointer' }}>
                        <span className={`d2-notif-dot ${n.dot}`} />
                        <div className="d2-notif-center-text">
                          <strong>{n.title}</strong>
                          <span>{n.desc} • {n.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* VIEW 5: CALENDAR VIEW */}
              {activeDock === 'calendar' && (
                <motion.div
                  key="view-calendar"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="d2-generic-view"
                >
                  <div className="d2-view-banner">
                    <div className="d2-view-banner-text">
                      <h2>Calendar & Team Schedule 📅</h2>
                      <p>May 2021 • 6 scheduled events and 2 client deliverables</p>
                    </div>
                    <button className="d2-banner-btn" onClick={() => showToast('New Event Modal opened')}>
                      + Schedule Event
                    </button>
                  </div>

                  <div className="d2-generic-grid-2">
                    <div className="d2-view-card">
                      <h3>Monthly View (May 2021)</h3>
                      <div className="d2-full-calendar">
                        <div className="d2-cal-header-row">
                          <span className="d2-cal-header-cell">Mo</span>
                          <span className="d2-cal-header-cell">Tu</span>
                          <span className="d2-cal-header-cell">We</span>
                          <span className="d2-cal-header-cell">Th</span>
                          <span className="d2-cal-header-cell">Fr</span>
                          <span className="d2-cal-header-cell">Sa</span>
                          <span className="d2-cal-header-cell">Su</span>
                        </div>
                        <div className="d2-cal-body">
                          {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => (
                            <button
                              key={day}
                              className={`d2-cal-cell ${day === selectedDay ? 'today' : ''}`}
                              onClick={() => {
                                setSelectedDay(day);
                                showToast(`Selected May ${day}`);
                              }}
                            >
                              {day}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="d2-view-card">
                      <h3>Agenda for Selected Day (May {selectedDay})</h3>
                      <div className="d2-event-item">
                        <div className="d2-event-time">11:00 AM</div>
                        <div className="d2-event-info">
                          <strong>Landing Design Review</strong>
                          <span>120 min • UX/UI design team</span>
                        </div>
                      </div>
                      <div className="d2-event-item">
                        <div className="d2-event-time">02:30 PM</div>
                        <div className="d2-event-info">
                          <strong>Packaging Prototype Demo</strong>
                          <span>Rachel Lee, Product Manager</span>
                        </div>
                      </div>
                      <div className="d2-event-item">
                        <div className="d2-event-time">04:00 PM</div>
                        <div className="d2-event-info">
                          <strong>Board Meeting (Q2 Strategic Goals)</strong>
                          <span>Room 159 • John Smith & Stakeholders</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* VIEW 6: DOCUMENTS VIEW */}
              {activeDock === 'documents' && (
                <motion.div
                  key="view-documents"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="d2-generic-view"
                >
                  <div className="d2-view-banner">
                    <div className="d2-view-banner-text">
                      <h2>Documents & Design Deliverables 📁</h2>
                      <p>Cloud repository • 34.8 GB of 100 GB used</p>
                    </div>
                    <button className="d2-banner-btn" onClick={() => showToast('Opening file upload...')}>
                      + Upload New File
                    </button>
                  </div>

                  <div className="d2-generic-grid-3">
                    {[
                      { icon: 'fig', ext: 'FIG', name: 'Design_System_v3.fig', meta: '48.2 MB • Updated 2h ago' },
                      { icon: 'xlsx', ext: 'XLSX', name: 'Q2_Revenue_Plan.xlsx', meta: '12.4 MB • Updated Yesterday' },
                      { icon: 'pdf', ext: 'PDF', name: 'Product_Roadmap_2024.pdf', meta: '6.8 MB • Updated 3d ago' },
                      { icon: 'sketch', ext: 'SKETCH', name: 'Brand_Assets_Pack.sketch', meta: '32.1 MB • Updated 4d ago' },
                      { icon: 'docx', ext: 'DOCX', name: 'Quarterly_Brief.docx', meta: '4.2 MB • Updated 5d ago' },
                      { icon: 'zip', ext: 'ZIP', name: 'Exported_Icons_Bundle.zip', meta: '128 MB • Updated 1w ago' }
                    ].map((f, i) => (
                      <div key={i} className="d2-file-card" onClick={() => showToast(`Opened ${f.name}`)}>
                        <div className={`d2-file-icon ${f.icon}`}>{f.ext}</div>
                        <div className="d2-file-name">{f.name}</div>
                        <div className="d2-file-meta">{f.meta}</div>
                        <button className="d2-file-download" onClick={(e) => { e.stopPropagation(); showToast(`Downloading ${f.name}`); }}>
                          Download File ↓
                        </button>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* VIEW 7: NOTES VIEW */}
              {activeDock === 'notes' && (
                <motion.div
                  key="view-notes"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="d2-generic-view"
                >
                  <div className="d2-view-banner">
                    <div className="d2-view-banner-text">
                      <h2>Notes & Ideas Canvas 📝</h2>
                      <p>Quick drafts, architecture notes, and sprint retro points</p>
                    </div>
                    <button className="d2-banner-btn" onClick={() => showToast('New note draft created')}>
                      + Create New Note
                    </button>
                  </div>

                  <div className="d2-generic-grid-3">
                    <div className="d2-note-card" onClick={() => showToast('Editing Note: Design Sprint Goals')}>
                      <div className="d2-note-title">Design Sprint Goals</div>
                      <div className="d2-note-time">Updated 30 mins ago</div>
                      <div className="d2-note-preview">Focus on simplifying the checkout flow and reducing user drop-off by 15% across tablet viewports.</div>
                    </div>

                    <div className="d2-note-card green" onClick={() => showToast('Editing Note: Typography Scale')}>
                      <div className="d2-note-title">Typography Scale v2</div>
                      <div className="d2-note-time">Updated 2 hours ago</div>
                      <div className="d2-note-preview">Adopt Inter variable font with optical sizing. Standardize headings from 18px display down to 10px micro-labels.</div>
                    </div>

                    <div className="d2-note-card blue" onClick={() => showToast('Editing Note: Board Meeting Memo')}>
                      <div className="d2-note-title">Board Meeting Memo</div>
                      <div className="d2-note-time">Updated Yesterday</div>
                      <div className="d2-note-preview">Prepare slide 4 with 90% research completion and Rachel’s packaging mockup review at 4:00 PM.</div>
                    </div>

                    <div className="d2-note-card amber" onClick={() => showToast('Editing Note: Packaging Concepts')}>
                      <div className="d2-note-title">Packaging Concepts</div>
                      <div className="d2-note-time">Updated 2 days ago</div>
                      <div className="d2-note-preview">Eco-friendly cardboard textures with spot UV varnish. High priority prototype for Q3 shelf testing.</div>
                    </div>

                    <div className="d2-note-card red" onClick={() => showToast('Editing Note: Urgent Bug Triage')}>
                      <div className="d2-note-title">Urgent Bug Triage</div>
                      <div className="d2-note-time">Updated 3 days ago</div>
                      <div className="d2-note-preview">Fix SVG overflow in sidebar curved dock when resizing viewport below 1280px screen width.</div>
                    </div>

                    <div className="d2-note-card purple" onClick={() => showToast('Editing Note: Color Token Exploration')}>
                      <div className="d2-note-title">Color Tokens Exploration</div>
                      <div className="d2-note-time">Updated 4 days ago</div>
                      <div className="d2-note-preview">Primary periwinkle #595ef2 paired with dark slate #0f172a for optimal contrast compliance.</div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* VIEW 8: TEAM CHAT VIEW */}
              {activeDock === 'chat' && (
                <motion.div
                  key="view-chat"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="d2-generic-view"
                >
                  <div className="d2-view-banner">
                    <div className="d2-view-banner-text">
                      <h2>Team Messages & Direct Chat 💬</h2>
                      <p>Instant collaboration with design teammates and stakeholders</p>
                    </div>
                    <button className="d2-banner-btn" onClick={() => showToast('New channel modal opened')}>
                      + New Channel
                    </button>
                  </div>

                  <div className="d2-chat-layout">
                    {/* CONTACTS LIST */}
                    <div className="d2-chat-contacts">
                      <button
                        className={`d2-chat-contact-btn ${activeContact === 'ken' ? 'active' : ''}`}
                        onClick={() => { setActiveContact('ken'); showToast('Chat with Ken Smith'); }}
                      >
                        <div className="d2-contact-avatar" style={{ background: '#595ef2' }}>KS</div>
                        <div>
                          <div className="d2-contact-name">Ken Smith</div>
                          <div className="d2-contact-status">Product Lead • Online</div>
                        </div>
                      </button>

                      <button
                        className={`d2-chat-contact-btn ${activeContact === 'rachel' ? 'active' : ''}`}
                        onClick={() => { setActiveContact('rachel'); showToast('Chat with Rachel Lee'); }}
                      >
                        <div className="d2-contact-avatar" style={{ background: '#10b981' }}>RL</div>
                        <div>
                          <div className="d2-contact-name">Rachel Lee</div>
                          <div className="d2-contact-status">Package Designer • Away</div>
                        </div>
                      </button>

                      <button
                        className={`d2-chat-contact-btn ${activeContact === 'david' ? 'active' : ''}`}
                        onClick={() => { setActiveContact('david'); showToast('Chat with David Kim'); }}
                      >
                        <div className="d2-contact-avatar" style={{ background: '#f59e0b' }}>DK</div>
                        <div>
                          <div className="d2-contact-name">David Kim</div>
                          <div className="d2-contact-status">UX Researcher • Active</div>
                        </div>
                      </button>
                    </div>

                    {/* ACTIVE CHAT FEED */}
                    <div className="d2-chat-box">
                      <div className="d2-chat-feed">
                        {chatMessages.map((m) => (
                          <div key={m.id} className={`d2-chat-bubble ${m.sender}`}>
                            {m.text}
                          </div>
                        ))}
                      </div>

                      <form className="d2-chat-input-bar" onSubmit={handleSendChatMessage}>
                        <input
                          type="text"
                          className="d2-chat-input"
                          placeholder="Type your message..."
                          value={newChatInput}
                          onChange={(e) => setNewChatInput(e.target.value)}
                        />
                        <button type="submit" className="d2-chat-send-btn">
                          Send
                        </button>
                      </form>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* VIEW 9: WORKFLOWS (FROM TOP NAV) */}
              {activeNav === 'workflows' && activeDock === 'dashboard' && (
                <motion.div
                  key="view-workflows"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="d2-generic-view"
                >
                  <div className="d2-view-banner">
                    <div className="d2-view-banner-text">
                      <h2>Automated Workflows & Pipelines ⚡</h2>
                      <p>Trigger automated syncs, design exports, and Slack status notifications</p>
                    </div>
                    <button className="d2-banner-btn" onClick={() => showToast('Workflow builder opened')}>
                      + Create Pipeline
                    </button>
                  </div>

                  <div className="d2-generic-grid-3">
                    <div className="d2-view-card">
                      <h3>Figma to GitHub Tokens</h3>
                      <p style={{ fontSize: '11px', color: '#64748b' }}>Automatically commits design tokens when published on Figma Team Library.</p>
                      <span style={{ fontSize: '10px', color: '#10b981', fontWeight: 700 }}>STATUS: ACTIVE • Ran 2h ago</span>
                    </div>

                    <div className="d2-view-card">
                      <h3>Daily Slack Standup Digest</h3>
                      <p style={{ fontSize: '11px', color: '#64748b' }}>Aggregates daily assigned tasks and posts summary to #product-team at 09:30 AM.</p>
                      <span style={{ fontSize: '10px', color: '#10b981', fontWeight: 700 }}>STATUS: ACTIVE • Every Weekday</span>
                    </div>

                    <div className="d2-view-card">
                      <h3>Asset Optimization Pipeline</h3>
                      <p style={{ fontSize: '11px', color: '#64748b' }}>Converts uploaded PNGs and SVGs into optimized WebP and modern SVG sprites.</p>
                      <span style={{ fontSize: '10px', color: '#595ef2', fontWeight: 700 }}>STATUS: IDLE • Ready to trigger</span>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* VIEW 10: INTEGRATIONS (FROM TOP NAV) */}
              {activeNav === 'integrations' && activeDock === 'dashboard' && (
                <motion.div
                  key="view-integrations"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="d2-generic-view"
                >
                  <div className="d2-view-banner">
                    <div className="d2-view-banner-text">
                      <h2>Connected App Integrations 🔌</h2>
                      <p>Connect third-party design and productivity services to your dashboard</p>
                    </div>
                    <button className="d2-banner-btn" onClick={() => showToast('Checking API connection status...')}>
                      Sync All Integrations
                    </button>
                  </div>

                  <div className="d2-generic-grid-3">
                    {[
                      { name: 'Figma', desc: 'Sync files, design tokens & comments', status: 'Connected', connected: true },
                      { name: 'Slack', desc: 'Real-time notifications & bot alerts', status: 'Connected', connected: true },
                      { name: 'GitHub', desc: 'Code repositories and issue tracking', status: 'Connected', connected: true },
                      { name: 'Notion', desc: 'Export notes directly to Notion pages', status: 'Connected', connected: true },
                      { name: 'Jira Software', desc: 'Sync sprint tasks and board tickets', status: 'Connect Now', connected: false },
                      { name: 'Google Drive', desc: 'Cloud deliverable backup storage', status: 'Connect Now', connected: false }
                    ].map((app, i) => (
                      <div key={i} className="d2-view-card">
                        <h3>{app.name}</h3>
                        <p style={{ fontSize: '11px', color: '#64748b' }}>{app.desc}</p>
                        <button
                          style={{
                            marginTop: 'auto',
                            padding: '6px 14px',
                            borderRadius: '8px',
                            border: app.connected ? '1px solid #cbd5e1' : 'none',
                            background: app.connected ? '#ffffff' : '#595ef2',
                            color: app.connected ? '#334155' : '#ffffff',
                            fontSize: '11px',
                            fontWeight: 600,
                            cursor: 'pointer'
                          }}
                          onClick={() => showToast(app.connected ? `${app.name} settings opened` : `Connecting ${app.name}...`)}
                        >
                          {app.status}
                        </button>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* TOAST FEEDBACK */}
      {toast.show && (
        <div className="d2-toast">
          <span>{toast.message}</span>
        </div>
      )}
    </div>
  );
}
