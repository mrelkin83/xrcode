import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './DashboardPiP.css';

export default function DashboardPiP({ activeDashboard, onSwitch }) {
  // Minimize / Expand state for PiP window
  const [isMinimized, setIsMinimized] = useState(false);

  const targetDashboard = activeDashboard === 1 ? 2 : 1;
  const targetTitle = targetDashboard === 2 ? 'Dashboard 2' : 'Dashboard 1';
  const targetSubtitle =
    targetDashboard === 2 ? 'Workspace & Tasks' : 'Mac OS Showcase';

  const handleSwitch = () => {
    onSwitch(targetDashboard);
  };

  return (
    <aside className="pip-floating-root" aria-label="Picture-in-Picture Switcher">
      <AnimatePresence mode="wait">
        {isMinimized ? (
          /* MINIMIZED FLOATING PILL */
          <motion.div
            key="minimized-pill"
            initial={{ opacity: 0, scale: 0.85, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.85, y: 12 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="pip-minimized-pill"
            onClick={handleSwitch}
            title={`Click to shift to ${targetTitle} (or expand preview)`}
          >
            <div className="pip-live-indicator">
              <span className="pip-live-dot" />
            </div>

            <span className="pip-pill-label">
              PiP: Shift to {targetTitle}
            </span>

            <span className="pip-pill-arrow">↗</span>

            <button
              className="pip-expand-btn"
              onClick={(e) => {
                e.stopPropagation();
                setIsMinimized(false);
              }}
              title="Expand PiP Preview"
              aria-label="Expand Preview"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 3 21 3 21 9" />
                <polyline points="9 21 3 21 3 15" />
                <line x1="21" y1="3" x2="14" y2="10" />
                <line x1="3" y1="21" x2="10" y2="14" />
              </svg>
            </button>
          </motion.div>
        ) : (
          /* EXPANDED PICTURE-IN-PICTURE CARD */
          <motion.div
            key="expanded-card"
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 22, stiffness: 280 }}
            className="pip-card"
          >
            {/* PiP HEADER */}
            <div className="pip-card-header">
              <div className="pip-header-left">
                <div className="pip-mac-dots">
                  <span className="pip-dot red" />
                  <span className="pip-dot yellow" />
                  <span className="pip-dot green" />
                </div>
                <span className="pip-badge">PiP LIVE</span>
              </div>

              <div className="pip-header-right">
                <button
                  className="pip-icon-btn"
                  onClick={() => setIsMinimized(true)}
                  title="Minimize PiP"
                  aria-label="Minimize"
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                    <line x1="5" y1="12" x2="19" y2="12" />
                  </svg>
                </button>
              </div>
            </div>

            {/* PREVIEW CONTAINER */}
            <div
              className="pip-preview-container"
              onClick={handleSwitch}
              title={`Click to shift into ${targetTitle}`}
            >
              <div className="pip-target-title-row">
                <span className="pip-target-title">{targetTitle}</span>
                <span className="pip-target-type">{targetSubtitle}</span>
              </div>

              {/* DYNAMIC MINI PREVIEW */}
              {targetDashboard === 2 ? (
                /* MINI DASHBOARD 2 PREVIEW */
                <div className="pip-mini-screen d2-preview">
                  {/* MINI PURPLE DOCK */}
                  <div className="pip-d2-mini-dock">
                    <div className="pip-d2-dock-dot active" />
                    <div className="pip-d2-dock-dot" />
                    <div className="pip-d2-dock-dot" />
                    <div className="pip-d2-dock-dot" />
                  </div>

                  {/* MINI WORKSPACE CONTENT */}
                  <div className="pip-d2-content">
                    <div className="pip-d2-top-bar">
                      <span className="pip-d2-greeting">Hi, James! 👋</span>
                      <span className="pip-d2-badge">Workspace</span>
                    </div>

                    <div className="pip-d2-task-card">
                      <div className="pip-d2-task-title">Conduct research</div>
                      <div className="pip-d2-task-meta">
                        <div className="pip-d2-progress-bar">
                          <div className="pip-d2-progress-fill" style={{ width: '90%' }} />
                        </div>
                        <span className="pip-d2-pct">90%</span>
                      </div>
                    </div>

                    <div className="pip-d2-chips">
                      <span className="pip-d2-chip">📅 Meeting 4 PM</span>
                      <span className="pip-d2-chip">📊 65% Typography</span>
                    </div>
                  </div>

                  {/* HOVER OVERLAY */}
                  <div className="pip-hover-overlay">
                    <div className="pip-overlay-icon">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <line x1="5" y1="12" x2="19" y2="12" />
                        <polyline points="12 5 19 12 12 19" />
                      </svg>
                    </div>
                    <span className="pip-overlay-text">Shift to Dashboard 2</span>
                  </div>
                </div>
              ) : (
                /* MINI DASHBOARD 1 PREVIEW */
                <div className="pip-mini-screen d1-preview">
                  {/* MINI MAC DOCK */}
                  <div className="pip-d1-mini-dock">
                    <div className="pip-d1-dock-circle active" />
                    <div className="pip-d1-dock-circle" />
                    <div className="pip-d1-dock-circle" />
                    <div className="pip-d1-dock-circle" />
                  </div>

                  {/* MINI PROFILE & PROJECTS */}
                  <div className="pip-d1-content">
                    <div className="pip-d1-profile-row">
                      <div className="pip-d1-avatar">S</div>
                      <span className="pip-d1-name">Syeda Rastoo</span>
                    </div>

                    <div className="pip-d1-stat-card">
                      <span className="pip-d1-stat-val">$14,250</span>
                      <span className="pip-d1-stat-tag">+18% MoM</span>
                    </div>

                    <div className="pip-d1-bottom-chips">
                      <span className="pip-d1-chip">6 Projects</span>
                      <span className="pip-d1-chip">Mac OS Dock</span>
                    </div>
                  </div>

                  {/* HOVER OVERLAY */}
                  <div className="pip-hover-overlay">
                    <div className="pip-overlay-icon">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <line x1="5" y1="12" x2="19" y2="12" />
                        <polyline points="12 5 19 12 12 19" />
                      </svg>
                    </div>
                    <span className="pip-overlay-text">Shift to Dashboard 1</span>
                  </div>
                </div>
              )}
            </div>

            {/* PiP FOOTER WITH ACTION BUTTON */}
            <div className="pip-footer">
              <button className="pip-shift-btn" onClick={handleSwitch}>
                <span>Shift to {targetTitle}</span>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="7" y1="17" x2="17" y2="7" />
                  <polyline points="7 7 17 7 17 17" />
                </svg>
              </button>

              <div className="pip-shortcut-hint">
                <span>Tip: Press</span>
                <kbd className="pip-kbd">Alt</kbd>
                <span>+</span>
                <kbd className="pip-kbd">D</kbd>
                <span>to quick switch</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </aside>
  );
}
