import { useState, useEffect } from 'react';
import Dashbord1 from './dashbord1.jsx';
import Dashbord2 from './dashbord2.jsx';
import DashboardPiP from './DashboardPiP.jsx';

function App() {
  const [activeDashboard, setActiveDashboard] = useState(1);

  // Global keyboard shortcut: Alt + D to instantly shift between dashboards
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (
        (e.altKey && e.key.toLowerCase() === 'd') ||
        (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd')
      ) {
        e.preventDefault();
        setActiveDashboard((prev) => (prev === 1 ? 2 : 1));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="dashboard-app-wrapper" style={{ position: 'relative', width: '100vw', height: '100vh', overflow: 'hidden' }}>
      {/* ACTIVE DASHBOARD VIEW */}
      {activeDashboard === 1 ? (
        <Dashbord1 onSwitchToDashboard2={() => setActiveDashboard(2)} />
      ) : (
        <Dashbord2 onSwitchToDashboard1={() => setActiveDashboard(1)} />
      )}

      {/* PICTURE-IN-PICTURE (PiP) FLOATING SWITCHER IN RIGHT BOTTOM */}
      <DashboardPiP
        activeDashboard={activeDashboard}
        onSwitch={(targetId) => setActiveDashboard(targetId)}
      />
    </div>
  );
}

export default App;
