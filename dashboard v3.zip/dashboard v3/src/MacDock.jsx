import { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';

// Dock navigation items configuration
const DOCK_ITEMS = [
  {
    id: 'home',
    label: 'Dashboard Overview',
    title: 'Overview (Home)',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
        <polyline points="9 22 9 12 15 12 15 22" />
      </svg>
    ),
  },
  {
    id: 'messages',
    label: 'Messages & Inbox',
    title: 'Messages & Chat',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
      </svg>
    ),
  },
  {
    id: 'projects',
    label: 'Projects & Profile',
    title: 'Projects Portfolio',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
        <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
      </svg>
    ),
  },
  {
    id: 'downloads',
    label: 'Deliverables & Downloads',
    title: 'Deliverables & Downloads',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
        <polyline points="7 10 12 15 17 10" />
        <line x1="12" y1="15" x2="12" y2="3" />
      </svg>
    ),
  },
  {
    id: 'bookmarks',
    label: 'Saved Bookmarks',
    title: 'Bookmarks & Saved',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
      </svg>
    ),
  },
  {
    id: 'location',
    label: 'Team Locations & Hubs',
    title: 'Team Locations & Hubs',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
        <circle cx="12" cy="10" r="3" />
      </svg>
    ),
  },
  {
    id: 'favorites',
    label: 'Starred & Favorites',
    title: 'Favorites & Starred',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
      </svg>
    ),
  },
];

/**
 * Individual Mac Dock Icon with rich distance-based continuous magnification
 * Perfectly locked to the center axis: zero X movement, zero left/right drift
 */
function MacDockItem({ mouseY, item, isActive, onNavigate }) {
  const itemRef = useRef(null);

  // Compute distance from mouse Y to the vertical center of this dock item
  const distance = useTransform(mouseY, (val) => {
    if (val === Infinity || !itemRef.current) return Infinity;
    const bounds = itemRef.current.getBoundingClientRect();
    return val - (bounds.y + bounds.height / 2);
  });

  // Rich macOS dock magnification curve:
  // - Direct hover (0px): scale reaches 1.62
  // - Immediate neighbor (±45px): scale ~1.32
  // - Secondary neighbor (±90px): scale ~1.10
  // - Distant items (±140px+): scale 1.0
  const scaleSync = useTransform(
    distance,
    [-140, -90, -45, 0, 45, 90, 140],
    [1, 1.10, 1.32, 1.62, 1.32, 1.10, 1]
  );

  // Apple-like spring physics for snappy, smooth bounce and response
  const scale = useSpring(scaleSync, {
    mass: 0.1,
    stiffness: 280,
    damping: 18,
  });

  // Layering priority: whichever icon has higher magnification stays on top
  const zIndex = useTransform(scale, (s) => Math.round(s * 15));

  return (
    <div ref={itemRef} className="dock-item-wrapper">
      <motion.button
        style={{
          scale,
          zIndex,
          originX: 0.5,
          originY: 0.5,
        }}
        className={`dock-btn ${isActive ? 'active' : ''}`}
        onClick={() => onNavigate(item.id, item.label)}
        whileTap={{ scale: 0.90 }}
        title={item.title}
        aria-label={item.title}
      >
        <div className="dock-icon-inner">
          {item.icon}
        </div>
      </motion.button>
    </div>
  );
}

/**
 * Mac-style Magnifying Dock Navigation
 */
export default function MacDock({ currentView, onNavigate }) {
  // Motion value tracking the cursor's Y position
  const mouseY = useMotionValue(Infinity);

  return (
    <motion.aside
      className="side-dock-nav"
      onMouseMove={(e) => mouseY.set(e.clientY)}
      onMouseLeave={() => mouseY.set(Infinity)}
      aria-label="Application Dock"
    >
      {DOCK_ITEMS.map((item) => (
        <MacDockItem
          key={item.id}
          item={item}
          mouseY={mouseY}
          isActive={currentView === item.id}
          onNavigate={onNavigate}
        />
      ))}
    </motion.aside>
  );
}
