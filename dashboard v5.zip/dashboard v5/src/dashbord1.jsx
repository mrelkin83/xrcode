import { useState } from 'react';
import './dashbord1.css';
import deskImg from './assets/desk_setup.jpg';
import {
  ArrowLeft,
  SlidersHorizontal,
  Plus,
  AlertCircle,
  Calendar,
  Clock,
  Wallet,
  ArrowUpRight,
  ArrowUp,
  ArrowDown,
  FileText,
  CreditCard,
  ShoppingBag,
  Bell,
  Settings,
  ChevronDown,
  Search,
  MoreVertical,
  AlignJustify,
  Link2,
} from 'lucide-react';

export default function Dashboard1() {
  const [activeNav, setActiveNav] = useState('Invoices');
  const [activeTab, setActiveTab] = useState('Unpaid');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('INV-1003');
  const [activePaymentMethod, setActivePaymentMethod] = useState('stripe');

  const invoices = [
    {
      id: 'INV-1001',
      due: 'In 2 days',
      status: 'Unsent',
      amount: '$ 68,750.00',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80',
      company: 'ApexStudio',
      customer: 'Sarah Jenkins',
      role: 'Creative Director',
      subTotal: '$ 68,750.00',
      total: '$ 68,750.00',
      balanceDue: '$ 68,750.00',
      items: [
        { label: 'Brand Identity', amount: '$ 24,500.00' },
        { label: 'Web Redesign', amount: '$ 32,250.00' },
        { label: 'Illustration System', amount: '$ 12,000.00' },
      ],
    },
    {
      id: 'INV-1002',
      due: 'In 4 days',
      status: 'Viewed',
      amount: '$ 21,480.00',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
      company: 'NovaCorp',
      customer: 'Alex Turner',
      role: 'Product Lead',
      subTotal: '$ 21,480.00',
      total: '$ 21,480.00',
      balanceDue: '$ 21,480.00',
      items: [
        { label: 'Mobile Prototype', amount: '$ 9,800.00' },
        { label: 'API Integration', amount: '$ 7,400.00' },
        { label: 'Usability Audit', amount: '$ 4,280.00' },
      ],
    },
    {
      id: 'INV-1003',
      due: 'In 5 days',
      status: 'Unsent',
      amount: '$ 47,980.00',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80',
      company: 'BrightWave',
      customer: 'James Carter',
      role: 'Marketing Director',
      subTotal: '$ 47,980.00',
      total: '$ 47,980.00',
      balanceDue: '$ 47,980.00',
      items: [
        { label: 'UI/UX Design', amount: '$ 15,990.00' },
        { label: 'Development', amount: '$ 21,250.00' },
        { label: 'QA & Testing', amount: '$ 10,740.00' },
      ],
    },
    {
      id: 'INV-1004',
      due: 'In 16 days',
      status: 'Viewed',
      amount: '$ 55,230.00',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&auto=format&fit=crop&q=80',
      company: 'Skyline Media',
      customer: 'Elena Rostova',
      role: 'Head of Operations',
      subTotal: '$ 55,230.00',
      total: '$ 55,230.00',
      balanceDue: '$ 55,230.00',
      items: [
        { label: 'Cloud Architecture', amount: '$ 28,000.00' },
        { label: 'Microservices Setup', amount: '$ 18,230.00' },
        { label: 'Security Review', amount: '$ 9,000.00' },
      ],
    },
    {
      id: 'INV-1005',
      due: 'In 19 days',
      status: 'Viewed',
      amount: '$ 6,880.00',
      avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=100&auto=format&fit=crop&q=80',
      company: 'Loomis Co',
      customer: 'David Patel',
      role: 'Founder',
      subTotal: '$ 6,880.00',
      total: '$ 6,880.00',
      balanceDue: '$ 6,880.00',
      items: [
        { label: 'Landing Page', amount: '$ 4,500.00' },
        { label: 'SEO Optimization', amount: '$ 1,500.00' },
        { label: 'Copywriting', amount: '$ 880.00' },
      ],
    },
  ];

  const currentInvoice = invoices.find((inv) => inv.id === selectedInvoiceId) || invoices[2];

  return (
    <div className="dashboard-root">
      {/* ========================================================
          1. TOP NAVBAR
          ======================================================== */}
      <header className="fn-navbar">
        <div className="fn-brand-group">
          <div className="fn-logo-container">
            <svg
              className="fn-logo-svg"
              viewBox="0 0 36 36"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="finnovaGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#4f46e5" />
                  <stop offset="100%" stopColor="#818cf8" />
                </linearGradient>
                <linearGradient id="finnovaGrad2" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#6366f1" />
                  <stop offset="100%" stopColor="#3730a3" />
                </linearGradient>
              </defs>
              <rect x="3" y="10" width="8" height="20" rx="4" fill="url(#finnovaGrad1)" transform="rotate(-20 3 10)" />
              <rect x="15" y="6" width="8" height="24" rx="4" fill="url(#finnovaGrad2)" transform="rotate(-20 15 6)" />
              <rect x="27" y="14" width="8" height="15" rx="4" fill="url(#finnovaGrad1)" transform="rotate(-20 27 14)" opacity="0.8" />
            </svg>
            <div className="fn-brand-info">
              <span className="fn-brand-title">FINNOVA</span>
              <span className="fn-brand-subtitle">Smart Finances, Better Business</span>
            </div>
          </div>
          <span className="fn-badge-pill">80</span>
        </div>

        {/* Center Dark Pill Nav */}
        <nav className="fn-nav-center">
          <button
            className={`fn-nav-item ${activeNav === 'Overview' ? 'active' : ''}`}
            onClick={() => setActiveNav('Overview')}
          >
            + Overview
          </button>
          <button
            className={`fn-nav-item ${activeNav === 'Estimates' ? 'active' : ''}`}
            onClick={() => setActiveNav('Estimates')}
          >
            Estimates
          </button>
          <button
            className={`fn-nav-item ${activeNav === 'Invoices' ? 'active' : ''}`}
            onClick={() => setActiveNav('Invoices')}
          >
            + Invoices
          </button>
          <button
            className={`fn-nav-item ${activeNav === 'Payments' ? 'active' : ''}`}
            onClick={() => setActiveNav('Payments')}
          >
            Payments
          </button>
          <button
            className={`fn-nav-item ${activeNav === 'Recurring' ? 'active' : ''}`}
            onClick={() => setActiveNav('Recurring')}
          >
            Recurring
          </button>
          <button
            className={`fn-nav-item ${activeNav === 'Checkouts' ? 'active' : ''}`}
            onClick={() => setActiveNav('Checkouts')}
          >
            Checkouts
          </button>
        </nav>

        {/* Right Tools & User */}
        <div className="fn-nav-right">
          <button className="fn-icon-btn" title="Documents">
            <FileText size={16} />
          </button>
          <button className="fn-icon-btn" title="Payments">
            <CreditCard size={16} />
          </button>
          <button className="fn-icon-btn" title="Calendar">
            <Calendar size={16} />
          </button>
          <button className="fn-icon-btn" title="Store">
            <ShoppingBag size={16} />
          </button>
          <button className="fn-icon-btn" title="Controls">
            <SlidersHorizontal size={16} />
          </button>
          <button className="fn-icon-btn" title="Notifications">
            <Bell size={16} />
            <span className="fn-notif-dot" />
          </button>
          <button className="fn-icon-btn" title="Settings">
            <Settings size={16} />
          </button>
          <img
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
            alt="Profile"
            className="fn-nav-avatar"
          />
        </div>
      </header>

      {/* ========================================================
          2. SUBHEADER / ACTION BAR
          ======================================================== */}
      <section className="fn-subheader">
        <div className="fn-subheader-left">
          <button className="fn-back-btn" title="Go back">
            <ArrowLeft size={16} />
          </button>
          <div className="fn-page-title-box">
            <h1 className="fn-page-title">Invoices</h1>
            <p className="fn-page-desc">Manage and track all your invoices in one place.</p>
          </div>
        </div>

        <div className="fn-subheader-right">
          <button className="fn-filter-icon-btn" title="Filters">
            <SlidersHorizontal size={16} />
          </button>
          <button className="fn-create-btn">
            <Plus size={16} strokeWidth={2.5} />
            <span>Create an invoice</span>
          </button>
        </div>
      </section>

      {/* ========================================================
          3. METRIC CARDS ROW (4 CARDS)
          ======================================================== */}
      <section className="fn-metrics-grid">
        {/* Card 1: Overdue */}
        <div className="fn-metric-card">
          <div className="fn-card-top">
            <span className="fn-card-label">Overdue</span>
            <div className="fn-card-top-icon red">
              <AlertCircle size={15} strokeWidth={2.2} />
            </div>
          </div>
          <div className="fn-card-mid">
            <div className="fn-card-val-row">
              <span className="fn-card-value">$ 24,850.00</span>
            </div>
            <div className="fn-card-trend">
              <span className="trend-red">
                <ArrowUp size={12} style={{ display: 'inline', verticalAlign: '-1px' }} /> 12.5%
              </span>
              <span className="trend-dim">from last month</span>
            </div>
          </div>
          <div className="fn-desk-container">
            <img src={deskImg} alt="Desk setup" className="fn-desk-img" />
          </div>
        </div>

        {/* Card 2: Due within next month */}
        <div className="fn-metric-card">
          <div className="fn-card-top">
            <span className="fn-card-label">Due within next month</span>
            <div className="fn-card-top-icon purple">
              <Calendar size={15} strokeWidth={2.2} />
            </div>
          </div>
          <div className="fn-card-mid">
            <div className="fn-card-val-row">
              <span className="fn-card-value">$ 142,560.00</span>
            </div>
            <div className="fn-card-trend">
              <span className="trend-purple">
                <ArrowUp size={12} style={{ display: 'inline', verticalAlign: '-1px' }} /> 8.2%
              </span>
              <span className="trend-dim">from last month</span>
            </div>
          </div>
          <div className="fn-barchart-container">
            {[
              { month: 'Jul', h: '30%' },
              { month: 'Aug', h: '50%' },
              { month: 'Sep', h: '70%' },
              { month: 'Sep', h: '88%' },
              { month: 'Oct', h: '65%' },
              { month: 'Nov', h: '90%' },
              { month: 'Dec', h: '100%', highlight: true },
            ].map((bar, i) => (
              <div key={i} className="fn-bar-col">
                <div className="fn-bar-track">
                  <div
                    className={`fn-bar-fill ${bar.highlight ? 'highlight' : ''}`}
                    style={{ height: bar.h }}
                  />
                </div>
                <span className="fn-bar-label">{bar.month}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Card 3: Average time to get paid */}
        <div className="fn-metric-card">
          <div className="fn-card-top">
            <span className="fn-card-label">Average time to get paid</span>
            <div className="fn-card-top-icon teal">
              <Clock size={15} strokeWidth={2.2} />
            </div>
          </div>
          <div className="fn-card-mid">
            <div className="fn-card-val-row">
              <span className="fn-card-value">16</span>
              <span className="fn-card-unit">days</span>
            </div>
            <div className="fn-card-trend">
              <span className="trend-teal">
                <ArrowDown size={12} style={{ display: 'inline', verticalAlign: '-1px' }} /> 2 days
              </span>
              <span className="trend-dim">from last month</span>
            </div>
          </div>
          <div className="fn-linechart-container">
            <svg
              className="fn-linechart-svg"
              viewBox="0 0 240 46"
              preserveAspectRatio="none"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="lineGrad" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#818cf8" />
                  <stop offset="100%" stopColor="#4f46e5" />
                </linearGradient>
              </defs>
              <path
                d="M 5 40 C 30 39, 45 32, 65 30 C 85 29, 95 30, 110 23 C 125 16, 145 19, 160 12 C 175 6, 195 9, 235 2"
                stroke="url(#lineGrad)"
                strokeWidth="2"
                strokeLinecap="round"
              />
              <circle cx="10" cy="39" r="2.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
              <circle cx="45" cy="32" r="2.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
              <circle cx="65" cy="30" r="2.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
              <circle cx="110" cy="23" r="2.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
              <circle cx="135" cy="18" r="2.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
              <circle cx="160" cy="12" r="2.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
              <circle cx="185" cy="7" r="2.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
              <circle cx="215" cy="4" r="2.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
              <circle cx="235" cy="2" r="2.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
            </svg>
          </div>
        </div>

        {/* Card 4: Available for Instant Payout */}
        <div className="fn-metric-card">
          <div className="fn-card-top">
            <span className="fn-card-label">Available for Instant Payout</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div className="fn-card-top-icon green">
                <Wallet size={15} strokeWidth={2.2} />
              </div>
              <button
                className="fn-card-top-icon"
                style={{ background: '#f8fafc', color: '#475569', border: '1px solid #e2e8f0', cursor: 'pointer' }}
                title="Open payout"
              >
                <ArrowUpRight size={14} />
              </button>
            </div>
          </div>
          <div className="fn-card-mid">
            <div className="fn-card-val-row">
              <span className="fn-card-value">$ 186,540.00</span>
              <span className="fn-expects-badge">Expects</span>
            </div>
          </div>
          <div className="fn-payout-methods">
            <div
              className={`fn-pay-card ${activePaymentMethod === 'visa' ? 'active-stripe' : ''}`}
              onClick={() => setActivePaymentMethod('visa')}
            >
              <span className="fn-pay-dots">•••• 4242</span>
              <span className="fn-pay-brand">Visa</span>
            </div>
            <div
              className={`fn-pay-card ${activePaymentMethod === 'stripe' ? 'active-stripe' : ''}`}
              onClick={() => setActivePaymentMethod('stripe')}
            >
              <span className="fn-pay-dots">•••• 6789</span>
              <span className="fn-pay-brand">Stripe</span>
            </div>
            <div
              className={`fn-pay-card ${activePaymentMethod === 'paypal' ? 'active-stripe' : ''}`}
              onClick={() => setActivePaymentMethod('paypal')}
            >
              <span className="fn-pay-dots">•••• 1234</span>
              <span className="fn-pay-brand">PayPal</span>
            </div>
            <button className="fn-payout-now-mini-btn">Payout now</button>
          </div>
        </div>
      </section>

      {/* ========================================================
          4. FILTER BAR ROW
          ======================================================== */}
      <section className="fn-filters-bar">
        <div className="fn-filters-left">
          <div className="fn-active-filters-tag">
            <span>Active filters</span>
            <span className="fn-filters-count">2</span>
          </div>

          <button className="fn-pill-select">
            <span>All customers</span>
            <ChevronDown size={14} color="#64748b" />
          </button>

          <button className="fn-pill-select">
            <span>All statuses</span>
            <ChevronDown size={14} color="#64748b" />
          </button>
        </div>

        <div className="fn-filters-right">
          <button className="fn-pill-date">
            <span>November 2023</span>
            <Calendar size={13} color="#64748b" />
          </button>

          <button className="fn-pill-date">
            <span>December 2023</span>
            <Calendar size={13} color="#64748b" />
          </button>

          <div className="fn-search-pill">
            <input
              type="text"
              placeholder="Enter invoice #"
              className="fn-search-input"
            />
            <Search size={14} color="#94a3b8" />
          </div>
        </div>
      </section>

      {/* ========================================================
          5. LOWER SECTION: EXACT CUTOUT NOTCH & DUAL PANEL
          ======================================================== */}
      <section className="fn-invoices-section">
        {/* The Top Notch Header Bar */}
        <div className="fn-notch-header-row">
          {/* Left Dark Cap with "Unpaid Invoices" */}
          <div className="fn-notch-left">
            <span className="fn-list-header">Unpaid Invoices</span>
          </div>

          {/* Left Inverted Scoop SVG Transition */}
          <svg className="fn-notch-curve-left" viewBox="0 0 24 42" fill="none">
            <path d="M 0 0 C 13 0, 24 16, 24 42 H 0 Z" fill="#151821" />
          </svg>

          {/* Floating Center Tabs on light background */}
          <div className="fn-notch-center-tabs">
            <button
              className={`fn-tab-pill ${activeTab === 'All' ? 'active' : ''}`}
              onClick={() => setActiveTab('All')}
            >
              All Invoices
            </button>
            <button
              className={`fn-tab-pill ${activeTab === 'Draft' ? 'active' : ''}`}
              onClick={() => setActiveTab('Draft')}
            >
              <span>Draft</span>
              <span className="fn-tab-pill-badge">3</span>
            </button>
            <button
              className={`fn-tab-pill ${activeTab === 'Unpaid' ? 'active' : ''}`}
              onClick={() => setActiveTab('Unpaid')}
            >
              <span>Unpaid</span>
              <span className="fn-tab-pill-badge">5</span>
            </button>
          </div>

          {/* Right Inverted Scoop SVG Transition */}
          <svg className="fn-notch-curve-right" viewBox="0 0 24 42" fill="none">
            <path d="M 24 0 C 11 0, 0 16, 0 42 H 24 Z" fill="#151821" />
          </svg>

          {/* Right Dark Shelf with View & More tools */}
          <div className="fn-notch-right">
            <div className="fn-notch-tools">
              <button className="fn-shelf-icon-btn" title="List View">
                <AlignJustify size={14} />
              </button>
              <button className="fn-shelf-icon-btn" title="More Options">
                <MoreVertical size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Content Body Row: Left List + Right Indigo Card */}
        <div className="fn-invoices-body-row">
          {/* Left Side: Unpaid Invoices List */}
          <aside className="fn-invoices-list-panel">
            <div className="fn-invoices-list">
              {invoices.map((inv) => {
                const isActive = inv.id === selectedInvoiceId;
                return (
                  <div
                    key={inv.id}
                    className={`fn-invoice-item ${isActive ? 'active' : ''}`}
                    onClick={() => setSelectedInvoiceId(inv.id)}
                  >
                    <div className="fn-inv-col-left">
                      <img src={inv.avatar} alt={inv.id} className="fn-inv-avatar" />
                      <div className="fn-inv-id-box">
                        <span className="fn-inv-id"># {inv.id}</span>
                        <span className="fn-inv-due">{inv.due}</span>
                      </div>
                    </div>

                    <span className="fn-inv-status-pill">{inv.status}</span>

                    <span className="fn-inv-amount">{inv.amount}</span>
                  </div>
                );
              })}
            </div>
          </aside>

          {/* Right Side: The Rich Indigo Detail Card */}
          <main className="fn-detail-card">
            {/* Top Info Row */}
            <div className="fn-detail-top-row">
              {/* Invoice details */}
              <div>
                <div className="fn-detail-label">Invoice details</div>
                <div className="fn-inv-main-id-row">
                  <span className="fn-inv-main-num"># {currentInvoice.id}</span>
                  <span className="fn-inv-main-unsent">{currentInvoice.status}</span>
                </div>
              </div>

              {/* Company */}
              <div>
                <div className="fn-detail-label">Company</div>
                <div className="fn-company-row">
                  <span className="fn-company-name">{currentInvoice.company}</span>
                  <svg
                    width="22"
                    height="22"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 8C6 6 9 10 12 8C15 6 18 10 21 8"
                      stroke="#ffffff"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                    />
                    <path
                      d="M3 13C6 11 9 15 12 13C15 11 18 15 21 13"
                      stroke="#ffffff"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      opacity="0.8"
                    />
                    <path
                      d="M3 18C6 16 9 20 12 18C15 16 18 20 21 18"
                      stroke="#ffffff"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      opacity="0.6"
                    />
                  </svg>
                </div>
              </div>

              {/* Customer */}
              <div>
                <div className="fn-detail-label">Customer</div>
                <div className="fn-customer-info">
                  <img
                    src={currentInvoice.avatar}
                    alt={currentInvoice.customer}
                    className="fn-customer-avatar"
                  />
                  <div className="fn-cust-name-box">
                    <span className="fn-cust-name">{currentInvoice.customer}</span>
                    <span className="fn-cust-role">{currentInvoice.role}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Middle Line Items Grid */}
            <div className="fn-line-items-grid">
              {currentInvoice.items.map((item, idx) => (
                <div key={idx} className="fn-item-card">
                  <div className="fn-item-card-top">
                    <span className="fn-item-price">{item.amount}</span>
                    <ArrowUpRight size={14} className="fn-item-arrow" />
                  </div>
                  <span className="fn-item-label">{item.label}</span>
                </div>
              ))}

              {/* 4th: Add item card */}
              <div className="fn-item-card add-card">
                <span className="fn-add-icon">＋</span>
                <span className="fn-add-text">Add item</span>
              </div>
            </div>

            {/* Bottom Row Totals & Actions */}
            <div className="fn-detail-bottom-row">
              <div className="fn-totals-group">
                <div className="fn-total-item">
                  <span className="fn-total-title">Sub Total</span>
                  <span className="fn-total-num">{currentInvoice.subTotal}</span>
                </div>
                <div className="fn-total-item">
                  <span className="fn-total-title">Total</span>
                  <span className="fn-total-num">{currentInvoice.total}</span>
                </div>
                <div className="fn-total-item">
                  <span className="fn-total-title">Balance Due</span>
                  <span className="fn-total-num">{currentInvoice.balanceDue}</span>
                </div>
              </div>

              <div className="fn-detail-actions">
                <button className="fn-circle-action-btn" title="Attachment">
                  <Link2 size={15} />
                </button>
                <button className="fn-circle-action-btn" title="Calendar">
                  <Calendar size={15} />
                </button>
                <button className="fn-payout-btn-white">Payout now</button>
              </div>
            </div>
          </main>
        </div>
      </section>
    </div>
  );
}
