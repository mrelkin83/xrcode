import { useState } from 'react';
import Dashboard1 from './dashbord1.jsx';
import Dashboard2 from './dashbord2.jsx';

function App() {
  const [activeDashboard, setActiveDashboard] = useState(2);

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh', overflow: 'hidden' }}>
      {/* Floating Modern Pill Switcher */}
      <div
        style={{
          position: 'fixed',
          top: '12px',
          right: '20px',
          zIndex: 99999,
          background: '#0d1015',
          border: '1px solid rgba(255, 255, 255, 0.16)',
          borderRadius: '9999px',
          padding: '4px',
          display: 'flex',
          gap: '3px',
          boxShadow: '0 6px 20px rgba(0, 0, 0, 0.3)',
        }}
      >
        <button
          onClick={() => setActiveDashboard(1)}
          style={{
            background: activeDashboard === 1 ? '#4f4cf2' : 'transparent',
            color: activeDashboard === 1 ? '#ffffff' : '#94a3b8',
            border: 'none',
            borderRadius: '9999px',
            padding: '5px 14px',
            fontSize: '11.5px',
            fontWeight: 700,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
        >
          Dashboard 1
        </button>

        <button
          onClick={() => setActiveDashboard(2)}
          style={{
            background: activeDashboard === 2 ? '#cbf22f' : 'transparent',
            color: activeDashboard === 2 ? '#0e1113' : '#94a3b8',
            border: 'none',
            borderRadius: '9999px',
            padding: '5px 14px',
            fontSize: '11.5px',
            fontWeight: 700,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
        >
          Dashboard 2 (New)
        </button>
      </div>

      {/* Active Dashboard View */}
      {activeDashboard === 2 ? <Dashboard2 /> : <Dashboard1 />}
    </div>
  );
}

export default App;
