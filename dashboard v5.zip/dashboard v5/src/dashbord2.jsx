import { useState, useRef } from 'react';
import './dashbord2.css';
import {
  Home,
  Wallet,
  BarChart3,
  Calendar,
  MessageSquare,
  Activity,
  HelpCircle,
  Settings,
  ChevronDown,
  Bell,
  Layers,
  Plus,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Check,
  FileText,
  Download,
  Lock,
  Eye,
  Sliders,
  TrendingUp,
  TrendingDown,
  CreditCard,
  ShieldCheck,
  Zap,
  Smartphone,
  Laptop,
  AlertTriangle,
  RefreshCw,
  Paperclip,
  Send,
  Headphones,
  CheckCircle2,
} from 'lucide-react';

export default function Dashboard2() {
  const [activeNav, setActiveNav] = useState('Dashboard');
  const [transferAmount, setTransferAmount] = useState('1000');
  const [selectedContact, setSelectedContact] = useState(0);
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);

  // Spending Box Interactive States
  const [chartType, setChartType] = useState('radar'); // 'radar' | 'bar'
  const [hoveredCategory, setHoveredCategory] = useState(null);
  const [showThisMonth, setShowThisMonth] = useState(true);
  const [showAverage, setShowAverage] = useState(true);

  // Right Header Interactive Flyouts
  const [activeFlyout, setActiveFlyout] = useState(null); // 'notif' | 'reports' | 'profile' | 'financial' | null

  // Cards View State
  const [selectedCardIdx, setSelectedCardIdx] = useState(0);
  const [cardFrozen, setCardFrozen] = useState(false);
  const [showPin, setShowPin] = useState(false);

  // Settings View Toggles
  const [pushNotif, setPushNotif] = useState(true);
  const [emailDigest, setEmailDigest] = useState(true);
  const [smsFraud, setSmsFraud] = useState(true);
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Messages View Active Chat
  const [activeChatId, setActiveChatId] = useState(0);
  const [chatMessage, setChatMessage] = useState('');
  const [messagesList, setMessagesList] = useState([
    { id: 1, sender: 'sarah', text: 'Hi Joseph! I finished calculating your Q2 deductions. We can claim $3,400 in equipment depreciation for your MacBook setup.', time: '10:42 AM' },
    { id: 2, sender: 'me', text: 'Awesome Sarah! Will this offset our estimated tax payment for October?', time: '10:45 AM' },
    { id: 3, sender: 'sarah', text: 'Yes! It reduces your federal liability by approximately $1,150. You can review the attached PDF above.', time: '10:46 AM' },
  ]);

  // Apple Dock Proximity Magnification
  const [hoveredTopIdx, setHoveredTopIdx] = useState(null);
  const [hoveredBottomIdx, setHoveredBottomIdx] = useState(null);
  const carouselRef = useRef(null);

  // Spending data categories
  const spendingCategories = [
    { label: 'Food', amount: '$840.50', pct: 34, color: '#cbf22f', x: 160, y: 42 },
    { label: 'Bills', amount: '$1,250.00', pct: 52, color: '#cbf22f', x: 226, y: 84 },
    { label: 'Sporting goods', amount: '$320.00', pct: 14, color: '#cbf22f', x: 210, y: 148 },
    { label: 'Home goods', amount: '$640.20', pct: 28, color: '#cbf22f', x: 160, y: 180 },
    { label: 'Clothing', amount: '$480.00', pct: 20, color: '#cbf22f', x: 94, y: 136 },
    { label: 'Other', amount: '$260.00', pct: 11, color: '#cbf22f', x: 104, y: 68 },
  ];

  // 12 Diverse Quick Transfer Contacts
  const contacts = [
    { id: 0, name: 'Amara', role: 'Director', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80' },
    { id: 1, name: 'Marcus', role: 'Lead', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80' },
    { id: 2, name: 'Clara', role: 'Marketing', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80' },
    { id: 3, name: 'Sophie', role: 'Designer', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80' },
    { id: 4, name: 'Leo', role: 'Dev', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80' },
    { id: 5, name: 'Elena', role: 'Architect', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&auto=format&fit=crop&q=80' },
    { id: 6, name: 'David', role: 'Founder', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=100&auto=format&fit=crop&q=80' },
    { id: 7, name: 'Sarah', role: 'COO', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&auto=format&fit=crop&q=80' },
    { id: 8, name: 'Alex', role: 'Engineer', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&auto=format&fit=crop&q=80' },
    { id: 9, name: 'Chloe', role: 'Researcher', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&auto=format&fit=crop&q=80' },
    { id: 10, name: 'Daniel', role: 'Analyst', avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=100&auto=format&fit=crop&q=80' },
    { id: 11, name: 'Maya', role: 'Consultant', avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100&auto=format&fit=crop&q=80' },
  ];

  // Transactions list
  const transactions = [
    { id: 1, name: 'Paypal', date: '8 July · 11:55 AM', amount: '- $10.67', type: 'paypal' },
    { id: 2, name: 'Twitch', date: '7 July · 7:50 PM', amount: '- $12.01', type: 'twitch' },
    { id: 3, name: 'Airbnb', date: '6 July · 11:17 AM', amount: '- $112.43', type: 'airbnb' },
    { id: 4, name: 'Dribbble', date: '6 July · 09:35 AM', amount: '- $16.00', type: 'dribbble' },
    { id: 5, name: 'Airbnb', date: '6 July · 11:17 AM', amount: '- $112.43', type: 'airbnb' },
  ];

  // Dock items definitions
  const topDockItems = [
    { id: 'Dashboard', icon: Home, label: 'Dashboard' },
    { id: 'Cards', icon: Wallet, label: 'Cards & Wallet' },
    { id: 'Analytics', icon: BarChart3, label: 'Analytics' },
    { id: 'Calendar', icon: Calendar, label: 'Calendar' },
    { id: 'Messages', icon: MessageSquare, label: 'Messages' },
    { id: 'Activity', icon: Activity, label: 'Activity' },
  ];

  const bottomDockItems = [
    { id: 'Help', icon: HelpCircle, label: 'Help & Support' },
    { id: 'Settings', icon: Settings, label: 'Settings' },
  ];

  // Helper function for Apple Dock Magnification Physics (in-place, strictly NO translateX)
  const getDockScale = (idx, hoveredIdx) => {
    if (hoveredIdx === null) return { transform: 'scale(1)', zIndex: 1 };
    const diff = Math.abs(idx - hoveredIdx);
    if (diff === 0) {
      return { transform: 'scale(1.36)', zIndex: 20 };
    } else if (diff === 1) {
      return { transform: 'scale(1.18)', zIndex: 10 };
    } else if (diff === 2) {
      return { transform: 'scale(1.06)', zIndex: 5 };
    }
    return { transform: 'scale(1)', zIndex: 1 };
  };

  // Carousel scroll
  const scrollCarousel = (direction) => {
    if (carouselRef.current) {
      const scrollAmount = direction === 'left' ? -120 : 120;
      carouselRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  // Handle Send Money
  const handleSend = () => {
    if (isSending || sendSuccess) return;
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setSendSuccess(true);
      setTimeout(() => setSendSuccess(false), 2400);
    }, 800);
  };

  // Send Chat message
  const handleSendMessage = (e) => {
    e?.preventDefault();
    if (!chatMessage.trim()) return;
    setMessagesList((prev) => [
      ...prev,
      { id: Date.now(), sender: 'me', text: chatMessage, time: 'Just now' },
    ]);
    setChatMessage('');
  };

  return (
    <div className="db2-wrapper">
      {/* Background Soft Sage Concentric Blobs */}
      <div className="db2-bg-circle-1" />
      <div className="db2-bg-circle-2" />
      <div className="db2-bg-circle-3" />

      {/* Main Container Card (Rounded Grid Paper Enclosure) */}
      <div className="db2-container">
        {/* ========================================================
            1. LEFT VERTICAL BLACK SIDEBAR (APPLE DOCK MAGNIFICATION)
            ======================================================== */}
        <aside className="db2-sidebar">
          {/* Top Section: Logo + Main Nav */}
          <div className="db2-sidebar-top">
            <button className="db2-logo-btn" title="FinTech OS" onClick={() => setActiveNav('Dashboard')}>
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                <circle
                  cx="16"
                  cy="16"
                  r="11"
                  stroke="#cbf22f"
                  strokeWidth="3.2"
                  strokeDasharray="52 14"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            {/* Nav Icon Group with in-place macOS Dock Magnification */}
            <nav
              className="db2-nav-group"
              onMouseLeave={() => setHoveredTopIdx(null)}
            >
              {topDockItems.map((item, idx) => {
                const IconComponent = item.icon;
                const dockStyle = getDockScale(idx, hoveredTopIdx);
                const isActive = activeNav === item.id;

                return (
                  <div key={item.id} className="db2-dock-item-wrapper">
                    <button
                      className={`db2-nav-icon-btn ${isActive ? 'active' : ''}`}
                      onClick={() => setActiveNav(item.id)}
                      onMouseEnter={() => setHoveredTopIdx(idx)}
                      style={dockStyle}
                    >
                      <IconComponent size={17} />
                    </button>
                    <span className="db2-dock-tooltip">{item.label}</span>
                  </div>
                );
              })}
            </nav>
          </div>

          {/* Bottom Section: Help + Settings with in-place macOS Dock Magnification */}
          <div
            className="db2-sidebar-bottom"
            onMouseLeave={() => setHoveredBottomIdx(null)}
          >
            {bottomDockItems.map((item, idx) => {
              const IconComponent = item.icon;
              const dockStyle = getDockScale(idx, hoveredBottomIdx);
              const isActive = activeNav === item.id;

              return (
                <div key={item.id} className="db2-dock-item-wrapper">
                  <button
                    className={`db2-nav-icon-btn ${isActive ? 'active' : ''}`}
                    onClick={() => setActiveNav(item.id)}
                    onMouseEnter={() => setHoveredBottomIdx(idx)}
                    style={dockStyle}
                  >
                    <IconComponent size={17} />
                  </button>
                  <span className="db2-dock-tooltip">{item.label}</span>
                </div>
              );
            })}
          </div>
        </aside>

        {/* ========================================================
            2. MAIN DASHBOARD CONTENT AREA
            ======================================================== */}
        <main className="db2-content">
          {/* Top Header Row */}
          <header className="db2-header">
            <div className="db2-header-left">
              <h1 className="db2-page-title">
                {activeNav === 'Dashboard' ? 'Dashboard' : activeNav === 'Cards' ? 'Cards & Wallet' : activeNav === 'Calendar' ? 'Financial Calendar' : activeNav}
              </h1>
              <button
                className={`db2-pill-filter ${activeFlyout === 'financial' ? 'active' : ''}`}
                onClick={() => setActiveFlyout(activeFlyout === 'financial' ? null : 'financial')}
              >
                <span>Financial</span>
                <ChevronDown size={13} color="#4b5563" />
              </button>
            </div>

            <div className="db2-header-right">
              {/* Notification Bell */}
              <button
                className={`db2-round-tool-btn ${activeFlyout === 'notif' ? 'active' : ''}`}
                title="Notifications"
                onClick={() => setActiveFlyout(activeFlyout === 'notif' ? null : 'notif')}
              >
                <Bell size={15} />
                <span className="db2-tool-badge-dot" />
              </button>

              {/* Documents & Reports Icon */}
              <button
                className={`db2-round-tool-btn ${activeFlyout === 'reports' ? 'active' : ''}`}
                title="Reports & Statements"
                onClick={() => setActiveFlyout(activeFlyout === 'reports' ? null : 'reports')}
              >
                <Layers size={15} />
              </button>

              {/* User Profile Chip */}
              <div
                className={`db2-user-chip ${activeFlyout === 'profile' ? 'active' : ''}`}
                onClick={() => setActiveFlyout(activeFlyout === 'profile' ? null : 'profile')}
              >
                <span className="db2-user-name">Joseph Mitchell</span>
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80"
                  alt="Joseph Mitchell"
                  className="db2-user-avatar"
                />
              </div>
            </div>
          </header>

          {/* RIGHT ICONS FLYOUTS */}
          {activeFlyout && (
            <>
              <div className="db2-flyout-overlay" onClick={() => setActiveFlyout(null)} />

              {/* 1. Notifications Flyout */}
              {activeFlyout === 'notif' && (
                <div className="db2-flyout-panel">
                  <div className="db2-flyout-header">
                    <h3 className="db2-flyout-title">Notifications (4)</h3>
                    <button className="db2-flyout-close-btn" onClick={() => setActiveFlyout(null)}>✕</button>
                  </div>
                  <div className="db2-flyout-list">
                    <div className="db2-notif-item">
                      <div className="db2-notif-icon-circle" style={{ background: '#e1edff', color: '#0070ba' }}>💳</div>
                      <div className="db2-notif-content">
                        <span className="db2-notif-title">Payment Received</span>
                        <span className="db2-notif-desc">$1,250.00 from ApexStudio</span>
                        <span className="db2-notif-time">2 mins ago</span>
                      </div>
                    </div>
                    <div className="db2-notif-item">
                      <div className="db2-notif-icon-circle" style={{ background: '#ecfdf5', color: '#10b981' }}>📈</div>
                      <div className="db2-notif-content">
                        <span className="db2-notif-title">Limit Upgraded</span>
                        <span className="db2-notif-desc">Visa Platinum credit limit increased to $25,000</span>
                        <span className="db2-notif-time">1 hr ago</span>
                      </div>
                    </div>
                    <div className="db2-notif-item">
                      <div className="db2-notif-icon-circle" style={{ background: '#fef3c7', color: '#d97706' }}>⚠️</div>
                      <div className="db2-notif-content">
                        <span className="db2-notif-title">Budget Alert</span>
                        <span className="db2-notif-desc">82% of monthly Food & Bills budget used</span>
                        <span className="db2-notif-time">Yesterday</span>
                      </div>
                    </div>
                    <div className="db2-notif-item">
                      <div className="db2-notif-icon-circle" style={{ background: '#ede7ff', color: '#9146ff' }}>💸</div>
                      <div className="db2-notif-content">
                        <span className="db2-notif-title">Quick Transfer</span>
                        <span className="db2-notif-desc">Successfully sent $1,000 to Marcus</span>
                        <span className="db2-notif-time">2 days ago</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 2. Reports Flyout */}
              {activeFlyout === 'reports' && (
                <div className="db2-flyout-panel">
                  <div className="db2-flyout-header">
                    <h3 className="db2-flyout-title">Statements & Reports</h3>
                    <button className="db2-flyout-close-btn" onClick={() => setActiveFlyout(null)}>✕</button>
                  </div>
                  <div className="db2-flyout-list">
                    <div className="db2-notif-item">
                      <FileText size={18} color="#2563eb" />
                      <div className="db2-notif-content" style={{ flex: 1 }}>
                        <span className="db2-notif-title">Monthly Statement (June 2026)</span>
                        <span className="db2-notif-desc">PDF · 2.4 MB</span>
                      </div>
                      <Download size={14} color="#64748b" style={{ cursor: 'pointer' }} />
                    </div>
                    <div className="db2-notif-item">
                      <FileText size={18} color="#16a34a" />
                      <div className="db2-notif-content" style={{ flex: 1 }}>
                        <span className="db2-notif-title">Tax Invoice Summary Q2</span>
                        <span className="db2-notif-desc">PDF · 1.1 MB</span>
                      </div>
                      <Download size={14} color="#64748b" style={{ cursor: 'pointer' }} />
                    </div>
                    <div className="db2-notif-item">
                      <FileText size={18} color="#9333ea" />
                      <div className="db2-notif-content" style={{ flex: 1 }}>
                        <span className="db2-notif-title">Full Expenses CSV Export</span>
                        <span className="db2-notif-desc">CSV · 450 KB</span>
                      </div>
                      <Download size={14} color="#64748b" style={{ cursor: 'pointer' }} />
                    </div>
                  </div>
                </div>
              )}

              {/* 3. Profile Flyout */}
              {activeFlyout === 'profile' && (
                <div className="db2-flyout-panel" style={{ width: '280px' }}>
                  <div className="db2-flyout-header">
                    <h3 className="db2-flyout-title">Account Details</h3>
                    <button className="db2-flyout-close-btn" onClick={() => setActiveFlyout(null)}>✕</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 0' }}>
                      <img
                        src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80"
                        alt="Joseph Mitchell"
                        style={{ width: 42, height: 42, borderRadius: '50%' }}
                      />
                      <div>
                        <div style={{ fontWeight: 800, fontSize: 13, color: '#0e1113' }}>Joseph Mitchell</div>
                        <div style={{ fontSize: 10.5, color: '#64748b' }}>joseph.m@finnova.io</div>
                      </div>
                    </div>
                    <div style={{ background: '#f8fafc', padding: '8px 12px', borderRadius: 10, fontSize: 11 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', color: '#64748b', marginBottom: 3 }}>
                        <span>Account Tier</span>
                        <strong style={{ color: '#0e1113' }}>Platina VIP</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', color: '#64748b' }}>
                        <span>2FA Security</span>
                        <span style={{ color: '#16a34a', fontWeight: 700 }}>Enabled ✓</span>
                      </div>
                    </div>
                    <button
                      style={{ background: '#0e1113', color: '#fff', border: 'none', borderRadius: 9999, padding: '7px 0', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}
                      onClick={() => { setActiveFlyout(null); setActiveNav('Settings'); }}
                    >
                      Manage Profile
                    </button>
                  </div>
                </div>
              )}

              {/* 4. Financial Dropdown */}
              {activeFlyout === 'financial' && (
                <div className="db2-flyout-panel" style={{ width: '220px', left: '160px', right: 'auto' }}>
                  <div className="db2-flyout-header">
                    <h3 className="db2-flyout-title">View Mode</h3>
                    <button className="db2-flyout-close-btn" onClick={() => setActiveFlyout(null)}>✕</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {['Financial Overview', 'Personal Expenses', 'Business Accounts', 'Crypto & Assets'].map((mode, i) => (
                      <div
                        key={i}
                        style={{
                          padding: '6px 10px',
                          borderRadius: 8,
                          fontSize: 11.5,
                          fontWeight: i === 0 ? 700 : 500,
                          background: i === 0 ? '#f1f4f8' : 'transparent',
                          color: '#0e1113',
                          cursor: 'pointer',
                        }}
                        onClick={() => setActiveFlyout(null)}
                      >
                        {mode} {i === 0 && '✓'}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {/* ========================================================
              3. CONTENT AREA: ANIMATED SEPARATE FULL VIEWS PER ICON
              ======================================================== */}

          {/* --------------------------------------------------------
              VIEW 1: DASHBOARD (HOME)
              -------------------------------------------------------- */}
          {activeNav === 'Dashboard' && (
            <div key="view-dashboard" className="db2-view-wrapper">
              <div className="db2-grid">
                {/* COLUMN 1, ROW 1: RECENT TRANSACTIONS */}
                <section className="db2-white-card db2-tx-card">
                  <div className="db2-card-header">
                    <h2 className="db2-card-title">Recent transactions</h2>
                    <button className="db2-view-all-btn">
                      <span>View all</span>
                      <ArrowRight size={11} />
                    </button>
                  </div>

                  <div className="db2-tx-list">
                    {transactions.map((tx) => (
                      <div key={tx.id} className="db2-tx-item">
                        <div className="db2-tx-left">
                          <div className={`db2-tx-icon-box ${tx.type}`}>
                            {tx.type === 'paypal' && (
                              <svg width="17" height="17" viewBox="0 0 24 24" fill="#0070ba">
                                <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944 3.72a.789.789 0 0 1 .778-.654h6.813c3.784 0 6.136 1.83 5.496 5.86-.54 3.41-2.778 5.18-5.748 5.18h-2.14l-1.07 6.64a.789.789 0 0 1-.778.654l-1.219-.063z" />
                              </svg>
                            )}
                            {tx.type === 'twitch' && (
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="#9146ff">
                                <path d="M2.149 0l-1.612 4.119v16.037h5.031v3.844h3.844l3.844-3.844h4.743l5.99-5.991v-14.165h-21.84zm19.552 13.045l-3.344 3.344h-5.284l-2.88 2.88v-2.88h-4.321v-14.09h15.829v10.746zm-9.358-6.716h2.388v4.776h-2.388v-4.776zm5.254 0h2.388v4.776h-2.388v-4.776z" />
                              </svg>
                            )}
                            {tx.type === 'airbnb' && (
                              <svg width="17" height="17" viewBox="0 0 24 24" fill="#ff5a5f">
                                <path d="M12 0c-4.4 0-8 3.6-8 8 0 5.4 7.2 14.5 7.6 15 .2.3.6.4.8.4s.6-.1.8-.4c.4-.5 7.6-9.6 7.6-15 0-4.4-3.6-8-8-8zm0 11.5c-1.9 0-3.5-1.6-3.5-3.5s1.6-3.5 3.5-3.5 3.5 1.6 3.5 3.5-1.6 3.5-3.5 3.5z" />
                              </svg>
                            )}
                            {tx.type === 'dribbble' && (
                              <svg width="17" height="17" viewBox="0 0 24 24" fill="#ea4c89">
                                <circle cx="12" cy="12" r="10" stroke="#ea4c89" strokeWidth="2.2" fill="none" />
                                <path d="M4 12c4 1 9 0 14-5M12 2c2 4 4 11 3 18M5 19c3-4 8-8 14-6" stroke="#ea4c89" strokeWidth="2" fill="none" />
                              </svg>
                            )}
                          </div>
                          <div className="db2-tx-details">
                            <span className="db2-tx-name">{tx.name}</span>
                            <span className="db2-tx-date">{tx.date}</span>
                          </div>
                        </div>
                        <span className="db2-tx-amount">{tx.amount}</span>
                      </div>
                    ))}
                  </div>
                </section>

                {/* COLUMN 2, ROW 1: SPENDING GRAPH */}
                <section className="db2-white-card db2-spending-card">
                  <div className="db2-card-header">
                    <h2 className="db2-card-title">Spending</h2>
                    <div className="db2-spending-header-right">
                      <div className="db2-chart-type-toggle">
                        <button
                          className={`db2-chart-type-btn ${chartType === 'radar' ? 'active' : ''}`}
                          onClick={() => setChartType('radar')}
                        >
                          Radar
                        </button>
                        <button
                          className={`db2-chart-type-btn ${chartType === 'bar' ? 'active' : ''}`}
                          onClick={() => setChartType('bar')}
                        >
                          Breakdown
                        </button>
                      </div>

                      <div className="db2-radar-legend">
                        <div
                          className="db2-legend-item"
                          style={{ opacity: showThisMonth ? 1 : 0.4 }}
                          onClick={() => setShowThisMonth(!showThisMonth)}
                        >
                          <span className="db2-legend-dot-lime" />
                          <span>This month</span>
                        </div>
                        <div
                          className="db2-legend-item"
                          style={{ opacity: showAverage ? 1 : 0.4 }}
                          onClick={() => setShowAverage(!showAverage)}
                        >
                          <span className="db2-legend-ring" />
                          <span>Average</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {hoveredCategory && (
                    <div className="db2-spending-tooltip">
                      <span>{hoveredCategory.label}:</span>
                      <span className="db2-spending-tooltip-tag">{hoveredCategory.amount}</span>
                      <span style={{ color: '#94a3b8', fontSize: '9px' }}>({hoveredCategory.pct}% budget)</span>
                    </div>
                  )}

                  {chartType === 'radar' ? (
                    <div className="db2-radar-container">
                      <svg className="db2-radar-svg" viewBox="0 0 320 215" preserveAspectRatio="xMidYMid meet">
                        <defs>
                          <radialGradient id="radarLimeGlow" cx="50%" cy="50%" r="50%">
                            <stop offset="0%" stopColor="#d8fb3b" stopOpacity="0.9" />
                            <stop offset="100%" stopColor="#c5ed24" stopOpacity="0.8" />
                          </radialGradient>
                        </defs>

                        <polygon points="160,25 240,65 240,145 160,185 80,145 80,65" stroke="#eaece6" strokeWidth="1" fill="none" />
                        <polygon points="160,52 213,78 213,132 160,158 107,132 107,78" stroke="#f0f2eb" strokeWidth="0.8" fill="none" />
                        <polygon points="160,78 187,92 187,118 160,132 133,118 133,92" stroke="#f4f5f0" strokeWidth="0.8" fill="none" />

                        <line x1="160" y1="105" x2="160" y2="25" stroke="#e8ebe3" strokeWidth="1" />
                        <line x1="160" y1="105" x2="240" y2="65" stroke="#e8ebe3" strokeWidth="1" />
                        <line x1="160" y1="105" x2="240" y2="145" stroke="#e8ebe3" strokeWidth="1" />
                        <line x1="160" y1="105" x2="160" y2="185" stroke="#e8ebe3" strokeWidth="1" />
                        <line x1="160" y1="105" x2="80" y2="145" stroke="#e8ebe3" strokeWidth="1" />
                        <line x1="160" y1="105" x2="80" y2="65" stroke="#e8ebe3" strokeWidth="1" />

                        {showThisMonth && (
                          <path
                            d="M 160 42 C 185 52, 218 68, 226 84 C 234 100, 222 136, 210 148 C 192 166, 172 178, 160 180 C 138 174, 108 152, 94 136 C 82 118, 92 84, 104 68 C 118 50, 138 40, 160 42 Z"
                            fill="url(#radarLimeGlow)"
                            stroke="none"
                          />
                        )}

                        {showAverage && (
                          <path
                            d="M 160 34 C 190 38, 225 60, 232 94 C 238 126, 212 165, 175 186 C 142 176, 114 162, 104 134 C 94 106, 110 74, 140 48 C 148 40, 154 36, 160 34 Z"
                            fill="none"
                            stroke="#1c1f24"
                            strokeWidth="1.6"
                            strokeLinecap="round"
                          />
                        )}

                        {spendingCategories.map((cat, i) => (
                          <circle
                            key={i}
                            cx={cat.x}
                            cy={cat.y}
                            r="4"
                            fill="#0e1113"
                            stroke="#cbf22f"
                            strokeWidth="1.5"
                            className="db2-radar-node"
                            onMouseEnter={() => setHoveredCategory(cat)}
                            onMouseLeave={() => setHoveredCategory(null)}
                          />
                        ))}

                        <text x="160" y="14" textAnchor="middle" fill="#374151" fontSize="9.5" fontWeight="600" onMouseEnter={() => setHoveredCategory(spendingCategories[0])} onMouseLeave={() => setHoveredCategory(null)} style={{ cursor: 'pointer' }}>Food</text>
                        <text x="256" y="66" textAnchor="start" fill="#374151" fontSize="9" fontWeight="600" onMouseEnter={() => setHoveredCategory(spendingCategories[1])} onMouseLeave={() => setHoveredCategory(null)} style={{ cursor: 'pointer' }}>Bills</text>
                        <text x="252" y="148" textAnchor="start" fill="#374151" fontSize="9" fontWeight="600" onMouseEnter={() => setHoveredCategory(spendingCategories[2])} onMouseLeave={() => setHoveredCategory(null)} style={{ cursor: 'pointer' }}>Sporting</text>
                        <text x="252" y="159" textAnchor="start" fill="#374151" fontSize="9" fontWeight="600" onMouseEnter={() => setHoveredCategory(spendingCategories[2])} onMouseLeave={() => setHoveredCategory(null)} style={{ cursor: 'pointer' }}>goods</text>
                        <text x="160" y="202" textAnchor="middle" fill="#374151" fontSize="9.5" fontWeight="600" onMouseEnter={() => setHoveredCategory(spendingCategories[3])} onMouseLeave={() => setHoveredCategory(null)} style={{ cursor: 'pointer' }}>Home goods</text>
                        <text x="68" y="152" textAnchor="end" fill="#374151" fontSize="9" fontWeight="600" onMouseEnter={() => setHoveredCategory(spendingCategories[4])} onMouseLeave={() => setHoveredCategory(null)} style={{ cursor: 'pointer' }}>Clothing</text>
                        <text x="68" y="66" textAnchor="end" fill="#374151" fontSize="9" fontWeight="600" onMouseEnter={() => setHoveredCategory(spendingCategories[5])} onMouseLeave={() => setHoveredCategory(null)} style={{ cursor: 'pointer' }}>Other</text>
                      </svg>
                    </div>
                  ) : (
                    <div className="db2-bars-view">
                      {spendingCategories.map((item, i) => (
                        <div key={i} className="db2-bar-item" onMouseEnter={() => setHoveredCategory(item)} onMouseLeave={() => setHoveredCategory(null)} style={{ cursor: 'pointer' }}>
                          <span className="db2-bar-label">{item.label}</span>
                          <div className="db2-bar-track">
                            <div className="db2-bar-fill" style={{ width: `${item.pct * 1.7}%` }} />
                          </div>
                          <span className="db2-bar-value">{item.amount}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </section>

                {/* COLUMN 3, ROW 1: QUICK TRANSFER */}
                <section className="db2-white-card db2-transfer-card">
                  <div className="db2-transfer-header">
                    <h2 className="db2-card-title">Quick transfer</h2>
                    <span className="db2-profile-count-pill">{contacts.length} recipients</span>
                  </div>

                  <div className="db2-carousel-container">
                    <button className="db2-carousel-nav-btn left" onClick={() => scrollCarousel('left')} title="Scroll left">
                      <ChevronLeft size={13} />
                    </button>

                    <div className="db2-avatars-track" ref={carouselRef}>
                      {contacts.map((contact) => {
                        const isSelected = selectedContact === contact.id;
                        return (
                          <div key={contact.id} className={`db2-profile-pill-item ${isSelected ? 'active' : ''}`} onClick={() => setSelectedContact(contact.id)}>
                            <div className="db2-transfer-avatar-wrapper">
                              <img src={contact.avatar} alt={contact.name} className="db2-transfer-avatar" />
                            </div>
                            <span className="db2-profile-first-name">{contact.name}</span>
                          </div>
                        );
                      })}
                      <button className="db2-add-contact-btn" title="Add recipient">
                        <Plus size={15} />
                      </button>
                    </div>

                    <button className="db2-carousel-nav-btn right" onClick={() => scrollCarousel('right')} title="Scroll right">
                      <ChevronRight size={13} />
                    </button>
                  </div>

                  <div className="db2-presets-row">
                    {['50', '100', '500', '1000', '2500'].map((amt) => (
                      <button key={amt} className={`db2-preset-btn ${transferAmount === amt ? 'active' : ''}`} onClick={() => setTransferAmount(amt)}>
                        ${amt}
                      </button>
                    ))}
                  </div>

                  <div className="db2-amount-input-box">
                    <span style={{ fontSize: '13px', fontWeight: 700, color: '#6b7280' }}>$</span>
                    <input type="text" value={transferAmount} onChange={(e) => setTransferAmount(e.target.value)} className="db2-amount-input" />
                  </div>

                  <button className={`db2-send-btn ${sendSuccess ? 'success' : ''}`} onClick={handleSend}>
                    {sendSuccess ? (
                      <>
                        <Check size={14} />
                        <span>Sent to {contacts[selectedContact]?.name}!</span>
                      </>
                    ) : isSending ? (
                      <span>Sending...</span>
                    ) : (
                      <span>Send</span>
                    )}
                  </button>
                </section>

                {/* COLUMN 1, ROW 2: CARD & DETAILS */}
                <section className="db2-white-card db2-card-details">
                  <div className="db2-card-tier-bar">
                    <span className="db2-tier-name">Platina</span>
                    <span className="db2-tier-amount">$500.25</span>
                  </div>

                  <div className="db2-visa-card">
                    <div className="db2-visa-top">
                      <span className="db2-visa-brand">Universal</span>
                      <div className="db2-card-chip" />
                    </div>
                    <div className="db2-visa-balance">$8523<span className="db2-visa-balance-cents">.20</span></div>
                    <div className="db2-visa-bottom">
                      <div className="db2-visa-meta"><span>*9423</span><span>06/28</span></div>
                      <span className="db2-visa-logo-text">VISA</span>
                    </div>
                  </div>

                  <div className="db2-meta-list">
                    <div className="db2-meta-row"><span className="db2-meta-label">Credit limit</span><span className="db2-meta-val">$22000.00</span></div>
                    <div className="db2-meta-row"><span className="db2-meta-label">Credit used</span><span className="db2-meta-val">$0.00</span></div>
                    <div className="db2-meta-row"><span className="db2-meta-label">Currency</span><span className="db2-meta-val">USD</span></div>
                  </div>

                  <button className="db2-add-card-btn" onClick={() => setActiveNav('Cards')}>
                    <Plus size={14} />
                    <span>Add new card</span>
                  </button>
                </section>

                {/* COLUMN 2, ROW 2: BUDGET (SPLINE WAVE) */}
                <section className="db2-white-card db2-budget-card">
                  <div className="db2-card-header">
                    <h2 className="db2-card-title">Budget</h2>
                    <button className="db2-month-pill-select">
                      <span>Month</span>
                      <ChevronDown size={12} color="#6b7280" />
                    </button>
                  </div>

                  <div className="db2-spline-container">
                    <svg className="db2-spline-svg" viewBox="0 0 420 170" preserveAspectRatio="none">
                      {[
                        { val: '7k', y: 18 }, { val: '6k', y: 38 }, { val: '5k', y: 58 },
                        { val: '4k', y: 78 }, { val: '3k', y: 98 }, { val: '2k', y: 118 },
                        { val: '1k', y: 138 }, { val: '0', y: 154 },
                      ].map((grid, i) => (
                        <g key={i}>
                          <text x="14" y={grid.y + 3.5} fontSize="8.5" fill="#9ca3af" textAnchor="start" fontFamily="inherit">{grid.val}</text>
                          <line x1="32" y1={grid.y} x2="415" y2={grid.y} stroke="#f3f4f6" strokeDasharray="2 3" strokeWidth="1" />
                        </g>
                      ))}

                      <path
                        d="M 38 126 C 55 90, 68 76, 85 78 C 102 80, 110 135, 126 156 C 140 170, 155 125, 172 96 C 182 82, 192 105, 204 128 C 214 142, 224 100, 230 76 C 238 46, 246 22, 258 24 C 270 26, 278 52, 288 64 C 298 76, 308 18, 322 18 C 338 18, 350 82, 366 128 C 378 152, 395 110, 412 78"
                        fill="none"
                        stroke="#262930"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      />

                      <circle cx="230" cy="76" r="4.5" fill="#cbf22f" stroke="#0e1113" strokeWidth="2" />
                      <g transform="translate(202, 44)">
                        <rect x="0" y="0" width="58" height="20" rx="10" fill="#0e1113" />
                        <text x="29" y="13.5" fill="#ffffff" fontSize="8.5" fontWeight="700" textAnchor="middle" fontFamily="inherit">$26,590.40</text>
                      </g>

                      {[
                        { label: '18 dec', x: 42 }, { label: '25 dec', x: 104 }, { label: '1 jan', x: 166 },
                        { label: '8 jan', x: 230 }, { label: '15 jan', x: 292 }, { label: '22 jan', x: 352 },
                        { label: '29 jan', x: 406 },
                      ].map((lbl, idx) => (
                        <text key={idx} x={lbl.x} y="167" fontSize="8.5" fill="#6b7280" textAnchor="middle" fontFamily="inherit">{lbl.label}</text>
                      ))}
                    </svg>
                  </div>
                </section>

                {/* COLUMN 3, ROW 2: PROMO BANNER */}
                <section className="db2-promo-card">
                  <h2 className="db2-promo-text">
                    How to<br />reduce<br />expenses<br />by <span className="db2-pill-badge-25">25%</span> ?
                  </h2>

                  <div className="db2-piggy-container">
                    <svg className="db2-piggy-svg" viewBox="0 0 240 100" fill="none">
                      <path d="M 175 88 C 190 78, 215 80, 235 84 L 230 96 C 210 92, 185 90, 170 98 Z" stroke="#0e1113" strokeWidth="1.8" fill="none" />
                      <path d="M 180 84 C 195 74, 220 76, 238 80" stroke="#0e1113" strokeWidth="1.4" fill="none" />
                      <ellipse cx="42" cy="88" rx="26" ry="7" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <path d="M 16 88 v 6 c 0 4 12 7 26 7 s 26 -3 26 -7 v -6" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <ellipse cx="42" cy="78" rx="24" ry="6.5" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <path d="M 18 78 v 5 c 0 3.6 11 6.5 24 6.5 s 24 -2.9 24 -6.5 v -5" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <ellipse cx="40" cy="69" rx="22" ry="6" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <path d="M 18 69 v 5 c 0 3.3 10 6 22 6 s 22 -2.7 22 -6 v -5" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <ellipse cx="38" cy="60" rx="20" ry="5.5" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <path d="M 18 60 v 5 c 0 3 9 5.5 20 5.5 s 20 -2.5 20 -5.5 v -5" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <ellipse cx="37" cy="51" rx="18" ry="5" transform="rotate(-6 37 51)" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <path d="M 175 42 C 192 40, 205 52, 205 68 C 205 82, 192 92, 175 92 C 165 92, 158 88, 150 84 L 142 92 L 132 92 L 136 80 C 128 75, 124 65, 124 55 C 124 40, 142 30, 162 30 C 168 30, 172 32, 175 42 Z" stroke="#0e1113" strokeWidth="2.4" fill="#cbf22f" />
                      <path d="M 185 86 v 8 h -8 v -8" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <path d="M 148 82 v 10 h -7 v -7" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <ellipse cx="120" cy="55" rx="7" ry="10" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <circle cx="118" cy="53" r="1.5" fill="#0e1113" />
                      <circle cx="121" cy="57" r="1.5" fill="#0e1113" />
                      <circle cx="138" cy="46" r="3" fill="#0e1113" /><circle cx="137" cy="45" r="1" fill="#ffffff" />
                      <path d="M 152 32 C 148 22, 162 20, 165 30 Z" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <path d="M 170 34 C 172 26, 184 28, 180 38 Z" stroke="#0e1113" strokeWidth="2.2" fill="#cbf22f" />
                      <ellipse cx="166" cy="30" rx="6" ry="1.5" fill="#0e1113" />
                      <path d="M 205 62 C 215 58, 218 68, 212 70" stroke="#0e1113" strokeWidth="2.2" strokeLinecap="round" fill="none" />
                    </svg>
                  </div>

                  <button className="db2-learn-more-btn" onClick={() => setActiveNav('Analytics')}>Learn more</button>
                </section>
              </div>
            </div>
          )}

          {/* --------------------------------------------------------
              VIEW 2: CARDS & WALLET (FULL DENSE CONTENT)
              -------------------------------------------------------- */}
          {activeNav === 'Cards' && (
            <div key="view-cards" className="db2-view-wrapper">
              <div className="db2-cards-layout">
                {/* Left Column: 3 Selectable Cards + Recent Card Activity */}
                <div className="db2-cards-list-col">
                  {/* Card 1: Universal Lime */}
                  <div
                    className={`db2-card-tab-item ${selectedCardIdx === 0 ? 'selected' : ''}`}
                    onClick={() => setSelectedCardIdx(0)}
                  >
                    <div className="db2-visa-card" style={{ height: '110px' }}>
                      <div className="db2-visa-top">
                        <span className="db2-visa-brand">Universal Lime Visa</span>
                        <div className="db2-card-chip" />
                      </div>
                      <div className="db2-visa-balance">$8,523<span className="db2-visa-balance-cents">.20</span></div>
                      <div className="db2-visa-bottom">
                        <div className="db2-visa-meta"><span>•••• 9423</span><span>06/28</span></div>
                        <span className="db2-visa-logo-text">VISA</span>
                      </div>
                    </div>
                  </div>

                  {/* Card 2: Matte Obsidian Mastercard */}
                  <div
                    className={`db2-card-tab-item ${selectedCardIdx === 1 ? 'selected' : ''}`}
                    onClick={() => setSelectedCardIdx(1)}
                  >
                    <div className="db2-black-card" style={{ height: '100px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '12px', fontWeight: 800, color: '#cbf22f' }}>Obsidian Elite Carbon</span>
                        <span style={{ fontSize: '10px', background: 'rgba(255,255,255,0.12)', padding: '2px 8px', borderRadius: 9999 }}>Corporate</span>
                      </div>
                      <div style={{ fontSize: '20px', fontWeight: 800 }}>$14,290.00</div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '10.5px', color: '#cbd5e1' }}>
                        <span>•••• 5128 · 11/29</span>
                        <span style={{ fontWeight: 800, color: '#f59e0b' }}>Mastercard</span>
                      </div>
                    </div>
                  </div>

                  {/* Card 3: Slate Virtual Titanium */}
                  <div
                    className={`db2-card-tab-item ${selectedCardIdx === 2 ? 'selected' : ''}`}
                    onClick={() => setSelectedCardIdx(2)}
                  >
                    <div className="db2-slate-card" style={{ height: '96px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '12px', fontWeight: 700 }}>Virtual Titanium</span>
                        <span style={{ fontSize: '9.5px', background: 'rgba(255,255,255,0.15)', padding: '2px 7px', borderRadius: 9999 }}>Disposable PIN</span>
                      </div>
                      <div style={{ fontSize: '18px', fontWeight: 800 }}>$3,840.50</div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '10.5px' }}>
                        <span>•••• 8812 · 03/27</span>
                        <span style={{ fontStyle: 'italic', fontWeight: 900 }}>VISA</span>
                      </div>
                    </div>
                  </div>

                  {/* Recent Card Purchases */}
                  <div className="db2-white-card" style={{ padding: '10px 14px', gap: 6 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', fontWeight: 700 }}>
                      <span>Recent Purchases on Selected Card</span>
                      <span style={{ color: '#64748b' }}>5 items</span>
                    </div>
                    {[
                      { merchant: 'Apple Store NYC', cat: 'Hardware', amt: '-$2,499.00', time: 'Yesterday' },
                      { merchant: 'Uber Black Ride', cat: 'Transport', amt: '-$64.50', time: '2 days ago' },
                      { merchant: 'Blue Bottle Coffee', cat: 'Dining', amt: '-$28.20', time: '3 days ago' },
                      { merchant: 'Delta Air Lines', cat: 'Flight Ticket', amt: '-$485.00', time: '4 days ago' },
                    ].map((tx, idx) => (
                      <div key={idx} className="db2-mini-tx-row">
                        <div>
                          <strong>{tx.merchant}</strong>
                          <div style={{ fontSize: '9px', color: '#64748b' }}>{tx.cat} · {tx.time}</div>
                        </div>
                        <span style={{ fontWeight: 800, color: '#0e1113' }}>{tx.amt}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right Column: Card Controls & Limits */}
                <div className="db2-white-card" style={{ gap: 12 }}>
                  <div className="db2-card-header">
                    <h3 className="db2-card-title">Card Security & Permissions</h3>
                    <span style={{ fontSize: '11px', color: cardFrozen ? '#ef4444' : '#16a34a', fontWeight: 700 }}>
                      {cardFrozen ? 'Card Frozen ❄️' : 'Protected 🛡️'}
                    </span>
                  </div>

                  {/* Spending Limit Progress */}
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11.5px', fontWeight: 600, marginBottom: 4 }}>
                      <span style={{ color: '#64748b' }}>Monthly Purchase Limit</span>
                      <strong style={{ color: '#0e1113' }}>$8,523 / $22,000 (38%)</strong>
                    </div>
                    <div style={{ height: '8px', background: '#f1f4f8', borderRadius: 9999, overflow: 'hidden' }}>
                      <div style={{ width: '38%', height: '100%', background: '#cbf22f', borderRadius: 9999 }} />
                    </div>
                  </div>

                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11.5px', fontWeight: 600, marginBottom: 4 }}>
                      <span style={{ color: '#64748b' }}>Daily ATM Cash Limit</span>
                      <strong style={{ color: '#0e1113' }}>$1,200 / $2,500 (48%)</strong>
                    </div>
                    <div style={{ height: '8px', background: '#f1f4f8', borderRadius: 9999, overflow: 'hidden' }}>
                      <div style={{ width: '48%', height: '100%', background: '#0e1113', borderRadius: 9999 }} />
                    </div>
                  </div>

                  {/* 4 Quick Card Actions */}
                  <div className="db2-card-controls-grid">
                    <div className="db2-control-btn" onClick={() => setCardFrozen(!cardFrozen)}>
                      <Lock size={15} color={cardFrozen ? '#ef4444' : '#0e1113'} />
                      <span>{cardFrozen ? 'Unfreeze' : 'Freeze'}</span>
                    </div>
                    <div className="db2-control-btn" onClick={() => setShowPin(!showPin)}>
                      <Eye size={15} />
                      <span>{showPin ? '8492' : 'View PIN'}</span>
                    </div>
                    <div className="db2-control-btn">
                      <Sliders size={15} />
                      <span>Limits</span>
                    </div>
                    <div className="db2-control-btn">
                      <Plus size={15} />
                      <span>Add Card</span>
                    </div>
                  </div>

                  {/* Security Toggles */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: '11.5px', borderTop: '1px solid #f1f3f7', paddingTop: 8 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span>Online E-commerce Purchases</span>
                      <div className="db2-switch"><div className="db2-switch-knob" /></div>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span>International Currency Roaming</span>
                      <div className="db2-switch"><div className="db2-switch-knob" /></div>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span>Contactless NFC Tap-to-Pay</span>
                      <div className="db2-switch"><div className="db2-switch-knob" /></div>
                    </div>
                  </div>

                  {/* Linked Bank Accounts */}
                  <div style={{ background: '#f8fafc', padding: '10px 12px', borderRadius: 12, border: '1px solid #edf2f7' }}>
                    <div style={{ fontSize: '10.5px', color: '#64748b', fontWeight: 600, marginBottom: 4 }}>Linked Settlement Account</div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px', fontWeight: 700 }}>
                      <span>Chase Executive Checking (*4242)</span>
                      <span style={{ color: '#16a34a' }}>$32,450.00</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* --------------------------------------------------------
              VIEW 3: ANALYTICS (FULL DENSE CONTENT)
              -------------------------------------------------------- */}
          {activeNav === 'Analytics' && (
            <div key="view-analytics" className="db2-view-wrapper">
              <div className="db2-analytics-layout">
                {/* 5 KPI Metric Cards Row */}
                <div className="db2-kpi-grid" style={{ gridTemplateColumns: 'repeat(5, 1fr)' }}>
                  <div className="db2-kpi-card">
                    <span className="db2-kpi-label">Total Inflow</span>
                    <span className="db2-kpi-val">$68,420.00</span>
                    <span className="db2-kpi-badge"><TrendingUp size={11} style={{ display: 'inline' }} /> +14.2%</span>
                  </div>
                  <div className="db2-kpi-card">
                    <span className="db2-kpi-label">Total Outflow</span>
                    <span className="db2-kpi-val">$24,850.00</span>
                    <span className="db2-kpi-badge" style={{ color: '#ef4444' }}><TrendingDown size={11} style={{ display: 'inline' }} /> -3.5%</span>
                  </div>
                  <div className="db2-kpi-card">
                    <span className="db2-kpi-label">Net Profit</span>
                    <span className="db2-kpi-val">+$43,570.00</span>
                    <span className="db2-kpi-badge"><TrendingUp size={11} style={{ display: 'inline' }} /> +22.8%</span>
                  </div>
                  <div className="db2-kpi-card">
                    <span className="db2-kpi-label">Burn Rate</span>
                    <span className="db2-kpi-val">$815 / day</span>
                    <span className="db2-kpi-badge"><TrendingDown size={11} style={{ display: 'inline' }} /> -6.0%</span>
                  </div>
                  <div className="db2-kpi-card">
                    <span className="db2-kpi-label">Cash Runway</span>
                    <span className="db2-kpi-val">18.4 Mo</span>
                    <span className="db2-kpi-badge" style={{ color: '#16a34a' }}>Healthy ✓</span>
                  </div>
                </div>

                {/* 2 Main Visual Analytics Cards */}
                <div className="db2-analytics-charts-row">
                  {/* Monthly Cash Flow Comparison */}
                  <div className="db2-white-card">
                    <div className="db2-card-header">
                      <div>
                        <h3 className="db2-card-title">Cash Flow: Inflow vs Outflow</h3>
                        <span style={{ fontSize: '10.5px', color: '#64748b' }}>Comparing last 6 months operating volume</span>
                      </div>
                      <div style={{ display: 'flex', gap: 10, fontSize: '10.5px', fontWeight: 600 }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><span style={{ width: 8, height: 8, background: '#0e1113', borderRadius: 2 }} /> Inflow</span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><span style={{ width: 8, height: 8, background: '#cbf22f', borderRadius: 2 }} /> Outflow</span>
                      </div>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', height: '145px', padding: '10px 14px 0' }}>
                      {[
                        { m: 'Jan', in: '65%', out: '30%', inVal: '$52k', outVal: '$24k' },
                        { m: 'Feb', in: '78%', out: '42%', inVal: '$62k', outVal: '$33k' },
                        { m: 'Mar', in: '85%', out: '38%', inVal: '$68k', outVal: '$30k' },
                        { m: 'Apr', in: '60%', out: '45%', inVal: '$48k', outVal: '$36k' },
                        { m: 'May', in: '92%', out: '35%', inVal: '$74k', outVal: '$28k' },
                        { m: 'Jun', in: '100%', out: '28%', inVal: '$80k', outVal: '$22k' },
                      ].map((item, i) => (
                        <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, flex: 1 }}>
                          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, height: '110px' }}>
                            <div style={{ width: 16, height: item.in, background: '#0e1113', borderRadius: '4px 4px 1px 1px' }} title={`Inflow: ${item.inVal}`} />
                            <div style={{ width: 16, height: item.out, background: '#cbf22f', borderRadius: '4px 4px 1px 1px' }} title={`Outflow: ${item.outVal}`} />
                          </div>
                          <span style={{ fontSize: '10px', color: '#64748b', fontWeight: 600 }}>{item.m}</span>
                        </div>
                      ))}
                    </div>

                    <div style={{ background: '#f8fafc', padding: '8px 12px', borderRadius: 10, fontSize: '10.5px', color: '#475569', display: 'flex', justifyContent: 'space-between' }}>
                      <span>💡 <strong>Peak Performance:</strong> June was your highest net operating profit (+34%).</span>
                      <strong style={{ color: '#0e1113' }}>Avg Monthly Burn: $24,850</strong>
                    </div>
                  </div>

                  {/* Revenue Streams Breakdown */}
                  <div className="db2-white-card" style={{ gap: 8 }}>
                    <h3 className="db2-card-title">Inflow & Expense Breakdown</h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', fontWeight: 600 }}>
                          <span>Client Retainers</span>
                          <span>65% · $44,473</span>
                        </div>
                        <div style={{ height: 6, background: '#f1f4f8', borderRadius: 9999, marginTop: 3 }}>
                          <div style={{ width: '65%', height: '100%', background: '#0e1113', borderRadius: 9999 }} />
                        </div>
                      </div>

                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', fontWeight: 600 }}>
                          <span>SaaS & Licensing</span>
                          <span>20% · $13,684</span>
                        </div>
                        <div style={{ height: 6, background: '#f1f4f8', borderRadius: 9999, marginTop: 3 }}>
                          <div style={{ width: '20%', height: '100%', background: '#cbf22f', borderRadius: 9999 }} />
                        </div>
                      </div>

                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', fontWeight: 600 }}>
                          <span>Investment Yield</span>
                          <span>15% · $10,263</span>
                        </div>
                        <div style={{ height: 6, background: '#f1f4f8', borderRadius: 9999, marginTop: 3 }}>
                          <div style={{ width: '15%', height: '100%', background: '#94a3b8', borderRadius: 9999 }} />
                        </div>
                      </div>
                    </div>

                    <div style={{ borderTop: '1px solid #f1f3f7', paddingTop: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
                      <div style={{ fontSize: '10.5px', color: '#64748b', fontWeight: 600 }}>Expense Weight:</div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px' }}>
                        <span>Payroll & Contractors</span>
                        <strong>45%</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px' }}>
                        <span>Cloud Infrastructure</span>
                        <strong>28%</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px' }}>
                        <span>Office & Studio HQ</span>
                        <strong>18%</strong>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* --------------------------------------------------------
              VIEW 4: CALENDAR & SUBSCRIPTIONS (FULL DENSE CONTENT)
              -------------------------------------------------------- */}
          {activeNav === 'Calendar' && (
            <div key="view-calendar" className="db2-view-wrapper">
              <div className="db2-calendar-layout">
                {/* Left: 6 Scheduled Subscriptions */}
                <div className="db2-white-card">
                  <div className="db2-card-header">
                    <div>
                      <h3 className="db2-card-title">Recurring Invoices & Subscriptions</h3>
                      <span style={{ fontSize: '10.5px', color: '#64748b' }}>6 active software & facility contracts</span>
                    </div>
                    <span style={{ fontSize: '11px', background: '#ecfdf5', color: '#16a34a', padding: '3px 8px', borderRadius: 9999, fontWeight: 700 }}>
                      100% Buffer Funded
                    </span>
                  </div>

                  <div className="db2-subs-list">
                    {[
                      { name: 'AWS Cloud Hosting', due: 'In 2 days (2 Oct)', amt: '$420.00', bg: '#f59e0b', initial: 'AWS', cat: 'Cloud' },
                      { name: 'Figma Enterprise Workspace', due: 'In 4 days (4 Oct)', amt: '$180.00', bg: '#0e1113', initial: 'FIG', cat: 'Design' },
                      { name: 'Studio HQ Lease & Utilities', due: 'In 6 days (6 Oct)', amt: '$1,240.00', bg: '#6366f1', initial: 'HQ', cat: 'Rent' },
                      { name: 'GitHub Enterprise Teams', due: 'In 12 days (12 Oct)', amt: '$84.00', bg: '#10b981', initial: 'GH', cat: 'Code' },
                      { name: 'Google Workspace Enterprise', due: 'In 15 days (15 Oct)', amt: '$72.00', bg: '#ef4444', initial: 'G', cat: 'Email' },
                      { name: 'Vercel Pro CDN Team', due: 'In 22 days (22 Oct)', amt: '$140.00', bg: '#3b82f6', initial: 'VER', cat: 'Host' },
                    ].map((sub, i) => (
                      <div key={i} className="db2-sub-item">
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div className="db2-sub-logo" style={{ background: sub.bg }}>{sub.initial}</div>
                          <div>
                            <div style={{ fontSize: '12px', fontWeight: 700, color: '#0e1113' }}>{sub.name}</div>
                            <div style={{ fontSize: '10px', color: '#64748b' }}>{sub.due} · {sub.cat}</div>
                          </div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ fontSize: '13px', fontWeight: 800, color: '#0e1113' }}>{sub.amt}</div>
                          <span style={{ fontSize: '9px', background: '#ecfdf5', color: '#15803d', padding: '1px 6px', borderRadius: 9999 }}>Auto-pay on</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right: Cash Buffer & Optimization */}
                <div className="db2-white-card" style={{ gap: 12 }}>
                  <h3 className="db2-card-title">Cash Buffer & Health</h3>

                  <div style={{ background: '#f8fafc', padding: '12px 14px', borderRadius: 14, border: '1px solid #edf2f7' }}>
                    <div style={{ fontSize: '10.5px', color: '#64748b', fontWeight: 600 }}>Next 7 Days Outflow</div>
                    <div style={{ fontSize: '24px', fontWeight: 900, color: '#0e1113', margin: '2px 0' }}>$1,840.00</div>
                    <div style={{ fontSize: '10px', color: '#16a34a', fontWeight: 700 }}>Covered by Chase Checking ($32,450 available)</div>
                  </div>

                  <div style={{ background: '#f8fafc', padding: '12px 14px', borderRadius: 14, border: '1px solid #edf2f7' }}>
                    <div style={{ fontSize: '10.5px', color: '#64748b', fontWeight: 600 }}>Next 30 Days Outflow</div>
                    <div style={{ fontSize: '22px', fontWeight: 800, color: '#0e1113', margin: '2px 0' }}>$2,136.00</div>
                    <div style={{ fontSize: '10px', color: '#64748b' }}>Total 6 subscriptions active</div>
                  </div>

                  <div className="db2-promo-card" style={{ padding: '12px 14px', borderRadius: 14 }}>
                    <h4 style={{ fontSize: '13px', fontWeight: 800, margin: 0 }}>Smart Savings Insight</h4>
                    <p style={{ fontSize: '10.5px', color: '#0e1113', margin: '4px 0 8px 0', lineHeight: 1.3 }}>
                      You have 2 unused Figma seats. Downscaling could save <strong>$360/year</strong>.
                    </p>
                    <button className="db2-learn-more-btn" style={{ height: '30px', fontSize: '10.5px' }}>
                      Optimize Subscriptions
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* --------------------------------------------------------
              VIEW 5: MESSAGES (FINANCIAL ADVISOR LIVE CHAT)
              -------------------------------------------------------- */}
          {activeNav === 'Messages' && (
            <div key="view-messages" className="db2-view-wrapper">
              <div className="db2-messages-layout">
                {/* Left: Chat Threads List */}
                <div className="db2-white-card">
                  <div className="db2-card-header">
                    <h3 className="db2-card-title">Conversations</h3>
                    <span style={{ fontSize: '10px', background: '#0e1113', color: '#fff', padding: '2px 7px', borderRadius: 9999 }}>2 unread</span>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {[
                      { id: 0, name: 'Sarah Jenkins, CPA', role: 'Lead Tax Advisor', preview: 'We can claim $3,400 in equipment...', time: '10:46 AM', unread: true },
                      { id: 1, name: 'ApexStudio Billing', role: 'INV-1003 Client', preview: 'Thanks Joseph! Payment sent.', time: 'Yesterday', unread: false },
                      { id: 2, name: 'Finnova Concierge', role: 'VIP Priority Support', preview: 'Your wire authorization is cleared.', time: '2d ago', unread: false },
                      { id: 3, name: 'Stripe Merchant Support', role: 'Integration Bot', preview: 'Weekly dispute report: 0 disputes.', time: '3d ago', unread: false },
                    ].map((th) => (
                      <div
                        key={th.id}
                        style={{
                          padding: '8px 10px',
                          borderRadius: 12,
                          background: activeChatId === th.id ? '#0e1113' : '#f8fafc',
                          color: activeChatId === th.id ? '#ffffff' : '#0e1113',
                          cursor: 'pointer',
                          transition: 'all 0.15s',
                        }}
                        onClick={() => setActiveChatId(th.id)}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span style={{ fontSize: '11.5px', fontWeight: 700 }}>{th.name}</span>
                          <span style={{ fontSize: '9px', opacity: 0.7 }}>{th.time}</span>
                        </div>
                        <div style={{ fontSize: '9.5px', opacity: 0.8, marginTop: 2 }}>{th.preview}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right: Full Active Chat Interface */}
                <div className="db2-chat-box">
                  {/* Chat Header */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 8, borderBottom: '1px solid #f1f3f7' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ position: 'relative' }}>
                        <img
                          src="https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&auto=format&fit=crop&q=80"
                          alt="Sarah"
                          style={{ width: 34, height: 34, borderRadius: '50%' }}
                        />
                        <span style={{ position: 'absolute', bottom: 0, right: 0, width: 8, height: 8, background: '#16a34a', borderRadius: '50%', border: '1.5px solid #fff' }} />
                      </div>
                      <div>
                        <div style={{ fontSize: '13px', fontWeight: 800, color: '#0e1113' }}>Sarah Jenkins (CPA & Tax Advisor)</div>
                        <div style={{ fontSize: '9.5px', color: '#16a34a', fontWeight: 600 }}>Active Now · Certified Financial Planner</div>
                      </div>
                    </div>
                    <span style={{ fontSize: '10.5px', color: '#64748b' }}>Response: ~3 mins</span>
                  </div>

                  {/* Chat Bubbles */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, margin: '8px 0', flex: 1, overflowY: 'auto' }}>
                    {messagesList.map((m) => (
                      <div key={m.id} className={`db2-bubble ${m.sender === 'me' ? 'outgoing' : 'incoming'}`}>
                        {m.text}
                        <div style={{ fontSize: '8.5px', opacity: 0.6, marginTop: 3, textAlign: 'right' }}>{m.time}</div>
                      </div>
                    ))}

                    {/* PDF Card Attachment */}
                    <div style={{ padding: '8px 12px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '260px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <FileText size={18} color="#2563eb" />
                        <div>
                          <div style={{ fontSize: '10.5px', fontWeight: 700, color: '#0e1113' }}>Q2_Schedule_C.pdf</div>
                          <div style={{ fontSize: '9px', color: '#64748b' }}>2.4 MB · Verified</div>
                        </div>
                      </div>
                      <Download size={14} color="#64748b" style={{ cursor: 'pointer' }} />
                    </div>
                  </div>

                  {/* Input Form */}
                  <form onSubmit={handleSendMessage} style={{ display: 'flex', gap: 6, alignItems: 'center', borderTop: '1px solid #f1f3f7', paddingTop: 8 }}>
                    <Paperclip size={16} color="#64748b" style={{ cursor: 'pointer' }} />
                    <input
                      type="text"
                      placeholder="Reply to Sarah..."
                      value={chatMessage}
                      onChange={(e) => setChatMessage(e.target.value)}
                      style={{
                        flex: 1,
                        background: '#f1f4f9',
                        border: 'none',
                        borderRadius: 9999,
                        padding: '8px 14px',
                        fontSize: '11.5px',
                        outline: 'none',
                        fontFamily: 'inherit',
                      }}
                    />
                    <button
                      type="submit"
                      style={{ background: '#0e1113', color: '#fff', border: 'none', borderRadius: 9999, padding: '7px 16px', fontSize: '11px', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}
                    >
                      <Send size={12} />
                      <span>Send</span>
                    </button>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* --------------------------------------------------------
              VIEW 6: ACTIVITY & AUDIT LOG (FULL DENSE CONTENT)
              -------------------------------------------------------- */}
          {activeNav === 'Activity' && (
            <div key="view-activity" className="db2-view-wrapper">
              <div className="db2-activity-layout">
                {/* Left: 6 Real-time Event Items */}
                <div className="db2-white-card">
                  <div className="db2-card-header">
                    <h3 className="db2-card-title">Live Transaction & Audit Stream</h3>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <span style={{ fontSize: '9.5px', background: '#f1f4f8', padding: '2px 7px', borderRadius: 9999, fontWeight: 700 }}>All</span>
                      <span style={{ fontSize: '9.5px', background: '#f1f4f8', padding: '2px 7px', borderRadius: 9999 }}>Transfers</span>
                      <span style={{ fontSize: '9.5px', background: '#f1f4f8', padding: '2px 7px', borderRadius: 9999 }}>Cards</span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6, flex: 1, overflowY: 'auto' }}>
                    {[
                      { icon: Zap, label: 'Instant Settlement to Chase', desc: '$4,500.00 wired to Checking (*4242)', time: '12m ago', color: '#16a34a', status: 'Completed' },
                      { icon: CreditCard, label: 'POS Terminal Swipe: Twitch', desc: '$12.01 subscription via Visa (*9423)', time: '1h ago', color: '#6366f1', status: 'Approved' },
                      { icon: ShieldCheck, label: 'Biometric Touch ID Authentication', desc: 'macOS Sonoma 14.5 (IP 192.168.1.1)', time: '3h ago', color: '#0e1113', status: 'Verified' },
                      { icon: TrendingUp, label: 'Q2 Dividend Payout', desc: '$142.50 Vanguard Total Market ETF', time: 'Yesterday', color: '#16a34a', status: 'Credited' },
                      { icon: AlertTriangle, label: 'Suspicious Auth Prevented', desc: '$450.00 foreign POS merchant auto-blocked', time: 'Yesterday', color: '#ef4444', status: 'Blocked 🛡️' },
                      { icon: RefreshCw, label: 'OpenBanking API Sync', desc: 'Balance snapshot updated across 3 accounts', time: '2d ago', color: '#0284c7', status: 'Synced' },
                    ].map((act, i) => {
                      const IconComp = act.icon;
                      return (
                        <div key={i} className="db2-audit-item">
                          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            <div style={{ width: 28, height: 28, borderRadius: '50%', background: '#ffffff', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #e2e8f0', color: act.color }}>
                              <IconComp size={14} />
                            </div>
                            <div>
                              <div style={{ fontSize: '11.5px', fontWeight: 700, color: '#0e1113' }}>{act.label}</div>
                              <div style={{ fontSize: '9.5px', color: '#64748b' }}>{act.desc}</div>
                            </div>
                          </div>
                          <div style={{ textAlign: 'right' }}>
                            <div style={{ fontSize: '9.5px', color: '#94a3b8' }}>{act.time}</div>
                            <span style={{ fontSize: '9px', fontWeight: 700, color: act.color }}>{act.status}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Right: Security Health & Devices */}
                <div className="db2-white-card" style={{ gap: 10 }}>
                  <h3 className="db2-card-title">Security & Device Registry</h3>

                  <div style={{ padding: '10px 12px', background: '#ecfdf5', borderRadius: 12, border: '1px solid #bbf7d0' }}>
                    <div style={{ fontSize: '12px', fontWeight: 800, color: '#166534', display: 'flex', alignItems: 'center', gap: 5 }}>
                      <CheckCircle2 size={14} /> Security Score: 98% (Excellent)
                    </div>
                    <div style={{ fontSize: '10px', color: '#15803d', marginTop: 2 }}>All two-factor protocols and hardware keys verified.</div>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: '11px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px', background: '#f8fafc', borderRadius: 10 }}>
                      <Laptop size={16} color="#0e1113" />
                      <div style={{ flex: 1 }}>
                        <strong>MacBook Pro 16&quot; (M3 Max)</strong>
                        <div style={{ fontSize: '9px', color: '#64748b' }}>San Francisco · Current Session</div>
                      </div>
                      <span style={{ fontSize: '9px', background: '#cbf22f', color: '#0e1113', padding: '1px 6px', borderRadius: 9999, fontWeight: 700 }}>Active</span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px', background: '#f8fafc', borderRadius: 10 }}>
                      <Smartphone size={16} color="#64748b" />
                      <div style={{ flex: 1 }}>
                        <strong>iPhone 15 Pro Max</strong>
                        <div style={{ fontSize: '9px', color: '#64748b' }}>iOS 17.5 · Active 2h ago</div>
                      </div>
                      <span style={{ fontSize: '9px', color: '#64748b' }}>Linked</span>
                    </div>
                  </div>

                  <button
                    style={{ background: '#0e1113', color: '#fff', border: 'none', borderRadius: 9999, padding: '8px 0', fontSize: '11px', fontWeight: 700, cursor: 'pointer' }}
                  >
                    Export Security Audit (CSV / JSON)
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* --------------------------------------------------------
              VIEW 7: HELP & SUPPORT (FULL DENSE CONTENT)
              -------------------------------------------------------- */}
          {activeNav === 'Help' && (
            <div key="view-help" className="db2-view-wrapper">
              <div className="db2-help-layout">
                {/* Left: 5 Categorized FAQs */}
                <div className="db2-white-card">
                  <div className="db2-card-header">
                    <h3 className="db2-card-title">Frequently Asked Questions</h3>
                    <span style={{ fontSize: '10px', color: '#64748b' }}>5 articles</span>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6, flex: 1, overflowY: 'auto' }}>
                    {[
                      { q: 'How do virtual disposable Visa cards work?', a: 'Virtual cards use temporary 16-digit numbers that automatically lock to the first merchant and self-destruct after use.' },
                      { q: 'How do I raise my instant daily transfer limit?', a: 'VIP Tier accounts can increase wire limits up to $100,000 via biometric authorization in the Settings tab.' },
                      { q: 'Can I export Schedule C tax depreciation files?', a: 'Yes! Navigate to Reports or your Advisor Chat with Sarah to download one-click CPA certified tax summaries.' },
                      { q: 'What happens if a recurring bill exceeds my card balance?', a: 'Our Smart Overdraft Shield automatically draws backup funds from your linked Chase Checking account with 0 fees.' },
                      { q: 'Are international currency transfers zero-fee?', a: 'All USD to EUR and GBP conversions use mid-market real-time interbank rates without marked-up spreads.' },
                    ].map((faq, i) => (
                      <div key={i} className="db2-faq-card">
                        <div className="db2-faq-q">
                          <span>{faq.q}</span>
                          <span style={{ color: '#94a3b8' }}>+</span>
                        </div>
                        <div className="db2-faq-a">{faq.a}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right: VIP Concierge Card & Live Helpline */}
                <div className="db2-white-card" style={{ gap: 12 }}>
                  <h3 className="db2-card-title">24/7 Dedicated Concierge</h3>

                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', background: '#f8fafc', borderRadius: 14 }}>
                    <img
                      src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&auto=format&fit=crop&q=80"
                      alt="Emily"
                      style={{ width: 44, height: 44, borderRadius: '50%' }}
                    />
                    <div>
                      <div style={{ fontSize: '13px', fontWeight: 800, color: '#0e1113' }}>Emily Watson</div>
                      <div style={{ fontSize: '10px', color: '#16a34a', fontWeight: 700 }}>Senior Concierge Manager · Online</div>
                      <div style={{ fontSize: '9px', color: '#64748b' }}>Assigned exclusively to your Platina account</div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <button
                      className="db2-send-btn"
                      onClick={() => setActiveNav('Messages')}
                      style={{ gap: 6 }}
                    >
                      <Headphones size={14} />
                      <span>Start Direct Concierge Chat</span>
                    </button>
                    <button
                      style={{ background: '#f1f4f8', color: '#0e1113', border: '1px solid #e2e8f0', borderRadius: 9999, height: 34, fontSize: '11px', fontWeight: 700, cursor: 'pointer' }}
                    >
                      Request Immediate Phone Callback (5 min)
                    </button>
                  </div>

                  <div style={{ padding: '8px 12px', background: '#ecfdf5', borderRadius: 10, fontSize: '10px', color: '#15803d', display: 'flex', justifyContent: 'space-between' }}>
                    <span>Banking Core API Status:</span>
                    <strong>100% Operational</strong>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* --------------------------------------------------------
              VIEW 8: SETTINGS & PREFERENCES (FULL DENSE CONTENT)
              -------------------------------------------------------- */}
          {activeNav === 'Settings' && (
            <div key="view-settings" className="db2-view-wrapper">
              <div className="db2-settings-layout">
                {/* Left: Account & Banking Config */}
                <div className="db2-white-card" style={{ gap: 10 }}>
                  <h3 className="db2-card-title">Account & Business Entity</h3>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: '11.5px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ color: '#64748b' }}>Legal Entity Name</span>
                      <strong style={{ color: '#0e1113' }}>Mitchell Studio LLC</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ color: '#64748b' }}>Registered Address</span>
                      <strong style={{ color: '#0e1113' }}>420 Market St, San Francisco, CA</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ color: '#64748b' }}>Primary Operating Currency</span>
                      <select style={{ border: '1px solid #e2e8f0', borderRadius: 6, padding: '3px 8px', fontSize: '11px', fontWeight: 700 }}>
                        <option>USD ($) - US Dollar</option>
                        <option>EUR (€) - Euro</option>
                        <option>GBP (£) - British Pound</option>
                      </select>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ color: '#64748b' }}>Default Settlement Bank</span>
                      <strong style={{ color: '#0e1113' }}>Chase Checking (*4242)</strong>
                    </div>
                  </div>

                  <div style={{ borderTop: '1px solid #f1f3f7', paddingTop: 8 }}>
                    <div style={{ fontSize: '11px', fontWeight: 700, color: '#0e1113', marginBottom: 4 }}>Automated Tax Reserve Rule</div>
                    <div style={{ fontSize: '10px', color: '#64748b', lineHeight: 1.35 }}>
                      Auto-deposit 20% of every incoming client invoice into High Yield Tax Reserve (4.8% APY).
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                      <span style={{ fontSize: '9px', background: '#ecfdf5', color: '#16a34a', padding: '2px 7px', borderRadius: 9999, fontWeight: 700 }}>Active Rule</span>
                    </div>
                  </div>
                </div>

                {/* Right: Security & Notification Controls */}
                <div className="db2-white-card" style={{ gap: 10 }}>
                  <h3 className="db2-card-title">Security & Notifications Hub</h3>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: '11.5px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <strong>Push Notifications</strong>
                        <div style={{ fontSize: '9.5px', color: '#64748b' }}>Instant alerts for transactions &gt; $50</div>
                      </div>
                      <div className={`db2-switch ${pushNotif ? '' : 'off'}`} onClick={() => setPushNotif(!pushNotif)}>
                        <div className="db2-switch-knob" />
                      </div>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <strong>Daily Balance Email Digest</strong>
                        <div style={{ fontSize: '9.5px', color: '#64748b' }}>Midnight summary of cash balances</div>
                      </div>
                      <div className={`db2-switch ${emailDigest ? '' : 'off'}`} onClick={() => setEmailDigest(!emailDigest)}>
                        <div className="db2-switch-knob" />
                      </div>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <strong>SMS Fraud Block Alert</strong>
                        <div style={{ fontSize: '9.5px', color: '#64748b' }}>Instant SMS verification for wires</div>
                      </div>
                      <div className={`db2-switch ${smsFraud ? '' : 'off'}`} onClick={() => setSmsFraud(!smsFraud)}>
                        <div className="db2-switch-knob" />
                      </div>
                    </div>
                  </div>

                  <div style={{ borderTop: '1px solid #f1f3f7', paddingTop: 8 }}>
                    <button
                      className="db2-send-btn"
                      onClick={() => {
                        setSettingsSaved(true);
                        setTimeout(() => setSettingsSaved(false), 2000);
                      }}
                    >
                      {settingsSaved ? 'Saved Successfully ✓' : 'Save Preferences'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
