import Sidebar from './Sidebar';
import './App.css';

function App() {
  return (
    <div className="app-container">
      <Sidebar />
    </div>
  );
}

export default App;
