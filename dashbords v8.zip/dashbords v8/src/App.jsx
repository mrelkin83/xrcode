import React, { useState } from 'react';
import Dashboard from './dashboard.jsx';
import Dashboard2 from './dashboard2.jsx';
import './dashboard2.css';

function App() {
  // Default to Dashboard 2 so the user can immediately review the new dashboard
  const [currentDashboard, setCurrentDashboard] = useState(2);

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh', overflow: 'hidden' }}>
      {/* Top Floating Dashboard Switcher */}
      <nav className="dashboard-switcher-bar">
        <button
          className={`switcher-tab-btn ${currentDashboard === 1 ? 'active' : ''}`}
          onClick={() => setCurrentDashboard(1)}
        >
          Dashboard 1 (Smart Home)
        </button>

        <button
          className={`switcher-tab-btn ${currentDashboard === 2 ? 'active dark-accent' : ''}`}
          onClick={() => setCurrentDashboard(2)}
        >
          Dashboard 2 (Health & Activity)
        </button>
      </nav>

      {/* Render Selected Dashboard */}
      {currentDashboard === 1 ? <Dashboard /> : <Dashboard2 />}
    </div>
  );
}

export default App;
