import Dashboard from './dashboard.jsx';
import './dashboard1.css';

export default Dashboard;
