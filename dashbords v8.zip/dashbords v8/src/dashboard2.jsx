import React, { useState } from 'react';
import './dashboard2.css';

// --- Clean SVG Icons for Dashboard 2 ---
const HomeIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 10.5L12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-4v6H4a1 1 0 0 1-1-1z" />
  </svg>
);

const CalendarIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
    <line x1="16" y1="2" x2="16" y2="6" />
    <line x1="8" y1="2" x2="8" y2="6" />
    <line x1="3" y1="10" x2="21" y2="10" />
  </svg>
);

const BarChartIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="20" x2="18" y2="10" />
    <line x1="12" y1="20" x2="12" y2="4" />
    <line x1="6" y1="20" x2="6" y2="14" />
  </svg>
);

const SettingsIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </svg>
);

const BellIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </svg>
);

const LogoutIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
    <polyline points="16 17 21 12 16 7" />
    <line x1="21" y1="12" x2="9" y2="12" />
  </svg>
);

const SearchIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8" />
    <line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
);

export default function Dashboard2() {
  const [activeNav, setActiveNav] = useState('home');
  const [activityFilter, setActivityFilter] = useState('All');
  const [selectedDay, setSelectedDay] = useState(15);

  // Calendar dates generation (35 cells: 3 previous month, 1-31 current month, 1 next)
  const calendarDays = [
    { num: 1, type: 'prev-dashed' },
    { num: 2, type: 'prev-dashed' },
    { num: 3, type: 'prev-dashed' },
    ...Array.from({ length: 31 }, (_, i) => ({ num: i + 1, type: 'current' })),
    { num: 1, type: 'prev-dashed' },
  ];

  return (
    <div className="dashboard2-viewport">
      {/* Master Dark Matte Dashboard Panel */}
      <div className="dashboard2-panel">
        {/* Left Sidebar */}
        <aside className="d2-sidebar">
          {/* Logo "H" */}
          <div className="d2-logo-h" title="HealthFit">
            H
          </div>

          {/* Navigation Pill Capsule */}
          <div className="d2-nav-pill-capsule">
            <button
              className={`d2-nav-btn ${activeNav === 'home' ? 'active' : ''}`}
              onClick={() => setActiveNav('home')}
              title="Home"
            >
              <HomeIcon />
            </button>
            <button
              className={`d2-nav-btn ${activeNav === 'calendar' ? 'active' : ''}`}
              onClick={() => setActiveNav('calendar')}
              title="Schedule"
            >
              <CalendarIcon />
            </button>
            <button
              className={`d2-nav-btn ${activeNav === 'stats' ? 'active' : ''}`}
              onClick={() => setActiveNav('stats')}
              title="Analytics"
            >
              <BarChartIcon />
            </button>
            <button
              className={`d2-nav-btn ${activeNav === 'settings' ? 'active' : ''}`}
              onClick={() => setActiveNav('settings')}
              title="Settings"
            >
              <SettingsIcon />
            </button>
            <button
              className={`d2-nav-btn ${activeNav === 'alerts' ? 'active' : ''}`}
              onClick={() => setActiveNav('alerts')}
              title="Notifications"
            >
              <BellIcon />
            </button>
          </div>

          {/* Sidebar Bottom (Exit & Avatar) */}
          <div className="d2-sidebar-bottom">
            <button className="d2-logout-btn" title="Sign Out">
              <LogoutIcon />
            </button>
            <div className="d2-sidebar-avatar" title="Alex">
              <img src="/avatar.png" alt="Alex" />
            </div>
          </div>
        </aside>

        {/* Main Dashboard Workspace */}
        <main className="d2-main-content">
          {/* Top Header */}
          <header className="d2-header">
            <div className="d2-greeting-wrap">
              <h1 className="d2-greeting-title">Hello, Alex!</h1>
              <span className="d2-greeting-sub">Ready for today's challenges?</span>
            </div>

            <div className="d2-header-right">
              <div className="d2-search-pill">
                <SearchIcon />
                <input
                  type="text"
                  placeholder="Search for some activities"
                  className="d2-search-input"
                />
              </div>
              <button className="d2-premium-btn">Premium</button>
            </div>
          </header>

          {/* Main Grid Layout */}
          <div className="d2-grid-layout">
            {/* ROW 1: Physical Activity (Left) & Active Days Calendar (Right) */}
            <div className="d2-row-top">
              {/* Physical Activity Card */}
              <section className="d2-card">
                <div className="d2-card-header">
                  <span className="d2-card-title">Physical Activity</span>
                  <button className="d2-dropdown-pill">Today ▾</button>
                </div>

                <div className="d2-activity-columns-wrap">
                  {/* Column 1: Steps */}
                  <div className="d2-act-col">
                    <div className="d2-wave-chart-container">
                      <svg viewBox="0 0 120 50">
                        {/* Dotted drop line to peak */}
                        <line x1="72" y1="12" x2="72" y2="48" stroke="#c7f240" strokeWidth="1.5" strokeDasharray="2 3" opacity="0.6" />
                        {/* Green Steps Curve */}
                        <path
                          d="M 5 35 Q 25 32 35 24 T 55 28 T 72 12 T 90 28 T 115 22"
                          fill="none"
                          stroke="#c7f240"
                          strokeWidth="2.4"
                          strokeLinecap="round"
                        />
                      </svg>
                      {/* Peak Badge */}
                      <div className="d2-peak-pill-badge" style={{ top: '15%', left: '60%', background: '#c7f240', color: '#121416' }}>
                        7221
                      </div>
                    </div>

                    <div className="d2-act-col-bottom">
                      <div className="d2-act-label">Steps</div>
                      <div className="d2-act-value-large">8 745</div>
                      <div className="d2-goal-avg-row">
                        <span>Goal</span>
                        <span>8 000</span>
                      </div>
                      <div className="d2-goal-avg-row">
                        <span>Average</span>
                        <span>9 450</span>
                      </div>
                    </div>
                  </div>

                  {/* Column 2: Calories burned */}
                  <div className="d2-act-col">
                    <div className="d2-wave-chart-container">
                      <svg viewBox="0 0 120 50">
                        {/* Consumed curve (Purple/slate) */}
                        <path
                          d="M 5 28 Q 28 26 42 34 T 70 20 T 95 32 T 115 26"
                          fill="none"
                          stroke="#9b72cf"
                          strokeWidth="2.2"
                          strokeLinecap="round"
                          opacity="0.85"
                        />
                        {/* Burned curve (Orange) */}
                        <path
                          d="M 5 32 Q 24 30 38 35 T 58 10 T 80 24 T 115 28"
                          fill="none"
                          stroke="#ff9f43"
                          strokeWidth="2.4"
                          strokeLinecap="round"
                        />
                      </svg>
                      {/* Peak Badge */}
                      <div className="d2-peak-pill-badge" style={{ top: '12%', left: '48%', background: '#ff9f43', color: '#ffffff' }}>
                        500
                      </div>
                    </div>

                    <div className="d2-legend-row">
                      <span style={{ color: '#ff9f43' }}>— Burned</span>
                      <span style={{ color: '#9b72cf' }}>— Consumed</span>
                    </div>

                    <div className="d2-act-col-bottom">
                      <div className="d2-act-label">Calories burned</div>
                      <div className="d2-act-value-large">700</div>
                      <div className="d2-goal-avg-row">
                        <span>Goal</span>
                        <span>500</span>
                      </div>
                      <div className="d2-goal-avg-row">
                        <span>Average</span>
                        <span>646</span>
                      </div>
                    </div>
                  </div>

                  {/* Column 3: Activity time */}
                  <div className="d2-act-col">
                    <div className="d2-wave-chart-container">
                      <svg viewBox="0 0 120 50">
                        {/* Shaded indicator bar under peak */}
                        <rect x="70" y="16" width="10" height="30" rx="5" fill="#3b5bf6" opacity="0.25" />
                        {/* Blue Curve */}
                        <path
                          d="M 5 30 Q 25 32 40 28 T 75 14 T 95 24 T 115 20"
                          fill="none"
                          stroke="#4f6bf5"
                          strokeWidth="2.4"
                          strokeLinecap="round"
                        />
                        <circle cx="75" cy="14" r="3" fill="#ffffff" />
                      </svg>
                      {/* Peak Badge */}
                      <div className="d2-peak-pill-badge" style={{ top: '14%', left: '62%', background: '#3b5bf6', color: '#ffffff' }}>
                        6 PM
                      </div>
                    </div>

                    <div className="d2-act-col-bottom">
                      <div className="d2-act-label">Activity time</div>
                      <div className="d2-act-value-large">2h 45min</div>
                      <div className="d2-goal-avg-row">
                        <span>Goal</span>
                        <span>2h</span>
                      </div>
                      <div className="d2-goal-avg-row">
                        <span>Average</span>
                        <span>2h 30min</span>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* Your Active Days Calendar Card (Solid Electric Blue) */}
              <section className="d2-calendar-card">
                <div className="d2-cal-header">
                  <span className="d2-cal-title">Your Active Days</span>
                  <button className="d2-dropdown-pill" style={{ color: 'rgba(255,255,255,0.85)' }}>November ▾</button>
                </div>

                <div className="d2-cal-days-header-row">
                  <span>MON</span>
                  <span>TUE</span>
                  <span>WED</span>
                  <span>THU</span>
                  <span>FRI</span>
                  <span>SAT</span>
                  <span>SUN</span>
                </div>

                <div className="d2-cal-grid">
                  {calendarDays.map((d, index) => {
                    const isSelected = d.num === selectedDay && d.type === 'current';
                    return (
                      <div
                        key={index}
                        className={`d2-cal-cell ${d.type === 'prev-dashed' ? 'inactive-dashed' : ''} ${isSelected ? 'active-green' : ''}`}
                        onClick={() => d.type === 'current' && setSelectedDay(d.num)}
                      >
                        {d.num}
                      </div>
                    );
                  })}
                </div>
              </section>
            </div>

            {/* ROW 2: Sleep Time & Weight Loss (Left) & My Activities (Right) */}
            <div className="d2-row-bottom">
              {/* Left Stack: Sleep Time & Weight Loss Plan */}
              <div className="d2-bottom-left-stack">
                {/* Sleep Time Card */}
                <section className="d2-card d2-sleep-card">
                  <div className="d2-sleep-text-col">
                    <span className="d2-sleep-title">Sleep Time</span>
                    <span className="d2-sleep-sub">You're almost there</span>
                    <span className="d2-sleep-goal">Goal is 8 hours</span>
                  </div>

                  {/* Circular Progress Ring */}
                  <div className="d2-sleep-ring-wrap">
                    <svg width="60" height="60" viewBox="0 0 60 60">
                      <circle cx="30" cy="30" r="24" stroke="#2c3035" strokeWidth="5.5" fill="none" />
                      <circle
                        cx="30"
                        cy="30"
                        r="24"
                        stroke="#c7f240"
                        strokeWidth="5.5"
                        fill="none"
                        strokeDasharray="150"
                        strokeDashoffset="26"
                        strokeLinecap="round"
                      />
                    </svg>
                    <span className="d2-sleep-hours-center">7.45h</span>
                  </div>
                </section>

                {/* Weight Loss Plan Card */}
                <section className="d2-card d2-weight-card">
                  <div className="d2-weight-head">
                    <span className="d2-weight-title">Weight Loss Plan</span>
                    <span className="d2-weight-percent">80% completed</span>
                  </div>

                  <div className="d2-weight-bar-track">
                    <div className="d2-weight-bar-fill"></div>
                  </div>

                  <div className="d2-weight-labels">
                    <span>80kg</span>
                    <span>70kg</span>
                  </div>
                </section>
              </div>

              {/* Right: My Activities Card */}
              <section className="d2-card d2-activities-card">
                <div className="d2-act-header-row">
                  <span className="d2-card-title">My Activities</span>
                  <span style={{ fontSize: '11px', color: 'var(--d2-text-muted)' }}>You have 3 planned activities</span>
                </div>

                <div className="d2-filter-tabs-row">
                  {['All', 'Alone', 'With friends'].map((filter) => (
                    <button
                      key={filter}
                      className={`d2-filter-tab-btn ${activityFilter === filter ? 'active' : ''}`}
                      onClick={() => setActivityFilter(filter)}
                    >
                      {filter}
                    </button>
                  ))}
                </div>

                <div className="d2-activities-tiles-grid">
                  {/* Tile 1: Running (Blue Card) */}
                  <div className="d2-activity-tile blue-featured">
                    <div className="d2-tile-top-row">
                      <div className="d2-avatar-stack">
                        <img src="/avatar.png" alt="User 1" className="d2-avatar-tiny" />
                        <img src="/avatar.png" alt="User 2" className="d2-avatar-tiny" />
                      </div>
                      <span className="d2-arrow-up-right">↗</span>
                    </div>
                    <div className="d2-tile-bottom">
                      <div className="d2-tile-title">Running</div>
                      <div className="d2-tile-time">7:00 AM</div>
                    </div>
                  </div>

                  {/* Tile 2: Gym */}
                  <div className="d2-activity-tile">
                    <div className="d2-tile-top-row">
                      <div className="d2-avatar-stack">
                        <img src="/avatar.png" alt="User 1" className="d2-avatar-tiny" />
                        <img src="/avatar.png" alt="User 2" className="d2-avatar-tiny" />
                        <img src="/avatar.png" alt="User 3" className="d2-avatar-tiny" />
                      </div>
                      <span className="d2-arrow-up-right">↗</span>
                    </div>
                    <div className="d2-tile-bottom">
                      <div className="d2-tile-title">Gym</div>
                      <div className="d2-tile-time">8:00 PM</div>
                    </div>
                  </div>

                  {/* Tile 3: Meditation */}
                  <div className="d2-activity-tile">
                    <div className="d2-tile-top-row">
                      <div className="d2-avatar-stack">
                        <img src="/avatar.png" alt="User 1" className="d2-avatar-tiny" />
                      </div>
                      <span className="d2-arrow-up-right">↗</span>
                    </div>
                    <div className="d2-tile-bottom">
                      <div className="d2-tile-title">Meditation</div>
                      <div className="d2-tile-time">10:30 PM</div>
                    </div>
                  </div>

                  {/* Tile 4: Add Activity */}
                  <div className="d2-activity-tile dashed-add">
                    <span className="d2-add-plus-icon">+</span>
                    <span className="d2-add-txt">Add Activity</span>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
