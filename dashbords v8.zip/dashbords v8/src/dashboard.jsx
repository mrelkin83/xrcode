import React, { useState, useRef, useEffect } from 'react';
import './dashboard.css';

// --- Inline Clean Vector Icons ---
const HomeIcon = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 10.5L12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-4v6H4a1 1 0 0 1-1-1z" />
  </svg>
);

const SearchIcon = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="7" />
    <line x1="16.5" y1="16.5" x2="21" y2="21" />
  </svg>
);

const ShieldIcon = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
  </svg>
);

const MapPinIcon = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
    <circle cx="12" cy="10" r="3" />
  </svg>
);

const SettingsIcon = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </svg>
);

const UserIcon = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </svg>
);

const CameraIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
    <circle cx="12" cy="13" r="4" />
  </svg>
);

const BellIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </svg>
);

const ChevronLeft = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M15 18l-6-6 6-6" />
  </svg>
);

const ChevronRight = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 18l6-6-6-6" />
  </svg>
);

const SunCloudIcon = () => (
  <svg width="26" height="26" viewBox="0 0 32 32" fill="none">
    <circle cx="14" cy="13" r="7" fill="#fbbf24" />
    <path d="M14 3v3M14 20v3M4 13h3M21 13h3M6.9 5.9l2.1 2.1M19 18l2.1 2.1M6.9 20.1l2.1-2.1" stroke="#f59e0b" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M13 24h11a5 5 0 0 0 0-10 6.5 6.5 0 0 0-12.7-1.8A5 5 0 0 0 13 24z" fill="#f8fafc" fillOpacity="0.95" />
  </svg>
);

const SkipBackIcon = () => (
  <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor">
    <polygon points="19 20 9 12 19 4 19 20" />
    <line x1="5" y1="19" x2="5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
  </svg>
);

const SkipForwardIcon = () => (
  <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor">
    <polygon points="5 4 15 12 5 20 5 4" />
    <line x1="19" y1="5" x2="19" y2="19" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
  </svg>
);

const PlayIcon = () => (
  <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor">
    <polygon points="6 3 20 12 6 21 6 3" />
  </svg>
);

const PauseIcon = () => (
  <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor">
    <rect x="6" y="4" width="4" height="16" rx="1" />
    <rect x="14" y="4" width="4" height="16" rx="1" />
  </svg>
);

const AlertTriangleIcon = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
    <line x1="12" y1="9" x2="12" y2="13" />
    <line x1="12" y1="17" x2="12.01" y2="17" />
  </svg>
);

export default function Dashboard() {
  // Navigation active tab
  const [activeTab, setActiveTab] = useState('home');

  // macOS Dock Magnification physics state powered by requestAnimationFrame
  const dockRef = useRef(null);
  const btnRefs = useRef([]);
  const currentScalesRef = useRef([1, 1, 1, 1, 1, 1]);
  const targetScalesRef = useRef([1, 1, 1, 1, 1, 1]);
  const rafIdRef = useRef(null);
  const isHoveringDockRef = useRef(false);

  // Lighting controls
  const [livingRoomLight, setLivingRoomLight] = useState(true);
  const [bedroomLight, setBedroomLight] = useState(true);

  // Climate control & Animated Graph
  const [targetTemp, setTargetTemp] = useState(24);
  const [isAutoClimate, setIsAutoClimate] = useState(true);

  // CCTV active room
  const rooms = ['Living room', 'Kitchen', 'Backyard', 'Entrance'];
  const [roomIndex, setRoomIndex] = useState(0);

  // Music Player
  const [isPlaying, setIsPlaying] = useState(true);

  // Robot vacuum
  const [vacuumCleaning, setVacuumCleaning] = useState(true);

  // Search view state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchFilter, setSearchFilter] = useState('All');

  // Security mode state
  const [securityMode, setSecurityMode] = useState('Armed Home');

  // Navigation tabs metadata
  const dockItems = [
    { id: 'home', title: 'Home', icon: HomeIcon },
    { id: 'search', title: 'Search & Devices', icon: SearchIcon },
    { id: 'security', title: 'Security Center', icon: ShieldIcon },
    { id: 'location', title: 'Rooms & Zones', icon: MapPinIcon },
    { id: 'settings', title: 'Automations & Hub', icon: SettingsIcon },
    { id: 'user', title: 'Profile & Family', icon: UserIcon },
  ];

  // --- Real Apple Mac Dock Magnification (requestAnimationFrame Spring Physics) ---
  const animateDockPhysics = () => {
    let isMoving = false;
    const lerpSpeed = 0.24; // Ultra smooth physical spring response

    btnRefs.current.forEach((btn, idx) => {
      if (!btn) return;
      const current = currentScalesRef.current[idx];
      const target = targetScalesRef.current[idx];
      const diff = target - current;

      if (Math.abs(diff) > 0.001) {
        currentScalesRef.current[idx] = current + diff * lerpSpeed;
        isMoving = true;
      } else {
        currentScalesRef.current[idx] = target;
      }

      const scale = currentScalesRef.current[idx];
      // Direct DOM update via requestAnimationFrame for zero-lag 120fps smoothness!
      btn.style.transform = `scale(${scale.toFixed(3)})`;
      if (scale > 1.05) {
        // Higher scale icons sit visually on top of adjacent neighbors
        btn.style.zIndex = `${Math.round(scale * 30)}`;
        btn.style.filter = `drop-shadow(0 ${Math.round(3 * scale)}px ${Math.round(8 * scale)}px rgba(0, 0, 0, 0.32))`;
      } else {
        btn.style.zIndex = '1';
        btn.style.filter = 'none';
      }
    });

    if (isMoving || isHoveringDockRef.current) {
      rafIdRef.current = requestAnimationFrame(animateDockPhysics);
    } else {
      rafIdRef.current = null;
    }
  };

  const handleDockMouseMove = (e) => {
    isHoveringDockRef.current = true;
    const mouseY = e.clientY;
    const maxScale = 1.65; // Noticeable popout magnification
    const radius = 88; // Wider radius so neighbor icon magnifies smoothly as well!

    btnRefs.current.forEach((btn, idx) => {
      if (!btn) return;
      const rect = btn.getBoundingClientRect();
      const centerY = rect.top + rect.height / 2;
      const dist = Math.abs(mouseY - centerY);

      if (dist >= radius) {
        targetScalesRef.current[idx] = 1.0;
      } else {
        // True macOS dock cosine wave magnification curve
        const factor = Math.cos((dist / radius) * (Math.PI / 2));
        targetScalesRef.current[idx] = 1 + (maxScale - 1) * factor;
      }
    });

    if (!rafIdRef.current) {
      rafIdRef.current = requestAnimationFrame(animateDockPhysics);
    }
  };

  const handleDockMouseLeave = () => {
    isHoveringDockRef.current = false;
    targetScalesRef.current = [1, 1, 1, 1, 1, 1];
    if (!rafIdRef.current) {
      rafIdRef.current = requestAnimationFrame(animateDockPhysics);
    }
  };

  useEffect(() => {
    return () => {
      if (rafIdRef.current) cancelAnimationFrame(rafIdRef.current);
    };
  }, []);

  const prevRoom = () => {
    setRoomIndex((prev) => (prev === 0 ? rooms.length - 1 : prev - 1));
  };

  const nextRoom = () => {
    setRoomIndex((prev) => (prev === rooms.length - 1 ? 0 : prev + 1));
  };

  // Temperature graph dynamic points calculation
  const graphWidth = 190;
  const graphHeight = 36;
  const tempOffset = (targetTemp - 24) * 2.5;
  const p1 = { x: 5, y: 26 };
  const p2 = { x: 45, y: 22 };
  const p3 = { x: 88, y: 16 };
  const p4 = { x: 132, y: Math.max(5, Math.min(30, 10 - tempOffset)) }; // Dynamic Target Point
  const p5 = { x: 185, y: 15 };

  // Smooth SVG cubic Bezier spline
  const curvePath = `M ${p1.x} ${p1.y} C 25 ${p1.y + 2}, 30 ${p2.y}, ${p2.x} ${p2.y} C 65 ${p2.y - 4}, 70 ${p3.y}, ${p3.x} ${p3.y} C 105 ${p3.y - 3}, 115 ${p4.y}, ${p4.x} ${p4.y} C 150 ${p4.y}, 165 ${p5.y}, ${p5.x} ${p5.y}`;
  const areaPath = `${curvePath} L ${p5.x} ${graphHeight} L ${p1.x} ${graphHeight} Z`;

  // Sample Devices for Search View
  const devicesList = [
    { name: 'Living Room Chandelier', room: 'Living Room', type: 'Lights', active: livingRoomLight },
    { name: 'Master Bed Ambient Lamp', room: 'Master Bedroom', type: 'Lights', active: bedroomLight },
    { name: 'Smart Inverter AC', room: 'Living Room', type: 'Climate', active: true, val: `${targetTemp}°C` },
    { name: 'Dyson Pure Cool', room: 'Living Room', type: 'Appliances', active: true, val: 'AQI Good' },
    { name: 'Sony Bravia 4K OLED', room: 'Living Room', type: 'Media', active: true, val: 'HDMI 2' },
    { name: 'Front Entrance Deadbolt', room: 'Entrance', type: 'Security', active: true, val: 'Locked' },
  ];

  const filteredDevices = devicesList.filter((d) => {
    const matchesCategory = searchFilter === 'All' || d.type === searchFilter;
    const matchesSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase()) || d.room.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="dashboard-viewport">
      {/* Centered Master Glass Dashboard */}
      <main className="glass-dashboard-panel">
        {/* Top Header Bar */}
        <header className="dashboard-header">
          <h1 className="greeting-text">Good Morning, Alex</h1>

          <div className="header-actions-group">
            <span className="date-text">Thursday, April 10th, 2025</span>
            <button className="header-icon-btn" title="Camera" aria-label="Camera">
              <CameraIcon />
            </button>
            <button className="header-icon-btn" title="Notifications" aria-label="Notifications">
              <BellIcon />
            </button>
            <div className="avatar-wrapper" title="Alex" onClick={() => setActiveTab('user')}>
              <img src="/avatar.png" alt="Alex" className="avatar-img" />
            </div>
          </div>
        </header>

        {/* Dashboard Workspace Body */}
        <div className="dashboard-body">
          {/* Left Vertical Navigation Pill (macOS Dock with Real Magnification) */}
          <aside
            className="nav-pill-bar"
            ref={dockRef}
            onMouseMove={handleDockMouseMove}
            onMouseLeave={handleDockMouseLeave}
          >
            {dockItems.map((item, index) => {
              const IconComp = item.icon;
              return (
                <button
                  key={item.id}
                  ref={(el) => (btnRefs.current[index] = el)}
                  className={`nav-pill-btn ${activeTab === item.id ? 'active' : ''}`}
                  onClick={() => setActiveTab(item.id)}
                  title={item.title}
                  aria-label={item.title}
                >
                  <IconComp />
                  {/* macOS Floating Glass Tooltip */}
                  <span className="dock-tooltip">{item.title}</span>
                </button>
              );
            })}
          </aside>

          {/* MAIN VIEWPORT CONTENT (Dynamically switches per dock icon) */}

          {/* 1. HOME TAB */}
          {activeTab === 'home' && (
            <div className="cards-main-layout">
              {/* LEFT COLUMN */}
              <div className="column-left">
                {/* Row 1: CCTV Camera Card */}
                <section className="glass-card cctv-card">
                  <div className="card-title-row">
                    <span className="card-title">CCTV Camera</span>
                    <button className="dots-menu-btn" title="Options" aria-label="Options">
                      •••
                    </button>
                  </div>
                  <div className="cctv-preview-box">
                    <img src="/image.png" alt="CCTV Stream" className="cctv-img" />
                    <div className="cctv-live-tag">
                      <span className="live-indicator-dot"></span>
                      <span>Live</span>
                    </div>
                    <button
                      className="cctv-arrow-btn left"
                      onClick={prevRoom}
                      title="Previous Camera"
                      aria-label="Previous Camera"
                    >
                      <ChevronLeft />
                    </button>
                    <button
                      className="cctv-arrow-btn right"
                      onClick={nextRoom}
                      title="Next Camera"
                      aria-label="Next Camera"
                    >
                      <ChevronRight />
                    </button>
                    <button className="cctv-room-badge" onClick={nextRoom} title="Switch camera">
                      {rooms[roomIndex]}
                    </button>
                  </div>
                </section>

                {/* Row 2: Lighting Control & Climate (With Animated Graph) */}
                <div className="subgrid-dual">
                  {/* Lighting Control Card */}
                  <section className="glass-card">
                    <div className="card-title-row">
                      <span className="card-title">Lighting Control</span>
                    </div>
                    <div className="lighting-row">
                      <span className="lighting-label">Living Room</span>
                      <button
                        className={`toggle-switch-pill ${livingRoomLight ? 'active' : ''}`}
                        onClick={() => setLivingRoomLight(!livingRoomLight)}
                        aria-label="Toggle Living Room Light"
                      >
                        <div className="toggle-knob"></div>
                      </button>
                    </div>
                    <div className="lighting-row">
                      <span className="lighting-label">Bedroom</span>
                      <button
                        className={`toggle-switch-pill ${bedroomLight ? 'active' : ''}`}
                        onClick={() => setBedroomLight(!bedroomLight)}
                        aria-label="Toggle Bedroom Light"
                      >
                        <div className="toggle-knob"></div>
                      </button>
                    </div>
                  </section>

                  {/* Climate Card with Animated Temperature Trend Graph */}
                  <section className="glass-card climate-card">
                    <div className="card-title-row">
                      <span className="card-title">Climate</span>
                    </div>
                    <div className="climate-stats-split">
                      <div className="climate-left">
                        <span
                          className="climate-temp-big"
                          onClick={() => setTargetTemp((t) => (t >= 28 ? 18 : t + 1))}
                          style={{ cursor: 'pointer' }}
                          title="Click to raise target temp"
                        >
                          {targetTemp}°C
                        </span>
                        <span className="climate-subtext">Target</span>
                      </div>
                      <div className="climate-right">
                        <span className="climate-temp-small">22°C</span>
                        <span
                          className="climate-subtext"
                          onClick={() => setIsAutoClimate(!isAutoClimate)}
                          style={{ cursor: 'pointer', color: isAutoClimate ? 'var(--text-white-muted)' : 'var(--text-white-dim)' }}
                        >
                          {isAutoClimate ? 'Auto' : 'Manual'}
                        </span>
                      </div>
                    </div>

                    {/* Animated SVG Climate Graph */}
                    <div className="climate-graph-wrap">
                      <svg className="climate-graph-svg" viewBox={`0 0 ${graphWidth} ${graphHeight}`}>
                        <defs>
                          <linearGradient id="climateAreaGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#b8865e" stopOpacity="0.45" />
                            <stop offset="100%" stopColor="#b8865e" stopOpacity="0.0" />
                          </linearGradient>
                        </defs>
                        {/* Shaded Area Fill */}
                        <path d={areaPath} fill="url(#climateAreaGrad)" className="climate-area-fill" />
                        {/* Animated Curve Stroke */}
                        <path d={curvePath} className="climate-graph-path" />
                        {/* Glowing Target Beacon Ring */}
                        <circle cx={p4.x} cy={p4.y} r="8" fill="none" stroke="#b8865e" strokeWidth="1.5" className="climate-pulse-ring" />
                        {/* Target Temp Indicator Dot */}
                        <circle cx={p4.x} cy={p4.y} r="3.2" fill="#ffffff" filter="drop-shadow(0 0 3px #b8865e)" />
                      </svg>
                      <div className="climate-timeline-labels">
                        <span className="climate-time-txt">6 AM</span>
                        <span className="climate-time-txt">12 PM</span>
                        <span className="climate-time-txt">6 PM</span>
                        <span className="climate-time-txt" style={{ color: 'var(--accent-caramel)', fontWeight: 600 }}>Now</span>
                      </div>
                    </div>
                  </section>
                </div>

                {/* Row 3: Automation Summary & Power Usage */}
                <div className="subgrid-dual">
                  {/* Automation Summary Card */}
                  <section className="glass-card">
                    <div className="card-title-row">
                      <span className="card-title">Automation Summary</span>
                    </div>
                    <div className="automation-capsule">
                      <span className="bullet-dot-caramel"></span>
                      <span className="automation-text">Lights auto-turned off: 6 times</span>
                    </div>
                    <div className="automation-capsule">
                      <span className="bullet-dot-caramel"></span>
                      <span className="automation-text">AC auto-adjusted: 12 times</span>
                    </div>
                  </section>

                  {/* Today's Power Usage Card */}
                  <section className="glass-card">
                    <div className="card-title-row">
                      <span className="card-title">Today's Power Usage</span>
                    </div>
                    <div className="power-value-big">7.8 kWh</div>
                  </section>
                </div>
              </div>

              {/* RIGHT COLUMN */}
              <div className="column-right">
                {/* Row 1: Weather Cards */}
                <div className="subgrid-dual">
                  {/* Weather Card 1: Temp */}
                  <section className="glass-card weather-card">
                    <span className="weather-header-city">Jakarta, Indonesia</span>
                    <div className="weather-icon-temp-row">
                      <SunCloudIcon />
                      <span className="weather-temp-num">28°C</span>
                    </div>
                    <span className="weather-condition-sub">Partly Cloudy</span>
                  </section>

                  {/* Weather Card 2: AQI */}
                  <section className="glass-card weather-card">
                    <span className="weather-header-city">Jakarta, Indonesia</span>
                    <span className="weather-condition-sub">Partly Cloudy</span>
                    <div className="aqi-pill-badge">AQI 75 - Moderate</div>
                  </section>
                </div>

                {/* Row 2: Robot Vacuum & Now Playing */}
                <div className="subgrid-dual">
                  {/* Robot Vacuum Card */}
                  <section className="glass-card vacuum-card">
                    <div className="card-title-row">
                      <span className="card-title">Robot Vacuum</span>
                    </div>
                    <div className="vacuum-specs-list">
                      <div className="spec-line">
                        <span>Battery</span>
                        <span className="spec-val">: 78%</span>
                      </div>
                      <div className="spec-line">
                        <span>Time Remaining</span>
                        <span className="spec-val">: 12 min</span>
                      </div>
                    </div>
                    <div
                      className="vacuum-white-box"
                      onClick={() => setVacuumCleaning(!vacuumCleaning)}
                      style={{ cursor: 'pointer' }}
                      title="Click to toggle cleaning state"
                    >
                      <div className="vacuum-status-title">
                        {vacuumCleaning ? 'Cleaning' : 'Paused'}
                      </div>
                      <div className="vacuum-progress-track">
                        <div
                          className="vacuum-progress-fill"
                          style={{ width: vacuumCleaning ? '38%' : '38%', opacity: vacuumCleaning ? 1 : 0.6 }}
                        ></div>
                      </div>
                      <div className="vacuum-time-sub">25 to complete</div>
                    </div>
                  </section>

                  {/* Now Playing Card */}
                  <section className="glass-card now-playing-card">
                    <div className="card-title-row">
                      <span className="card-title">Now Playing</span>
                    </div>
                    <div className="now-playing-album-art">
                      <img src="/jennie.png" alt="like JENNIE" className="album-img" />
                    </div>
                    <div className="song-title-text">like JENNIE</div>
                    <div className="player-scrubber-row">
                      <span className="player-timestamp">1:34</span>
                      <div className="player-scrubber-track">
                        <div className="player-scrubber-fill"></div>
                      </div>
                      <span className="player-timestamp">3:10</span>
                    </div>
                    <div className="player-controls-row">
                      <button className="player-btn" title="Previous Track" aria-label="Previous Track">
                        <SkipBackIcon />
                      </button>
                      <button
                        className="play-pause-circle-btn"
                        onClick={() => setIsPlaying(!isPlaying)}
                        title={isPlaying ? 'Pause' : 'Play'}
                        aria-label={isPlaying ? 'Pause' : 'Play'}
                      >
                        {isPlaying ? <PauseIcon /> : <PlayIcon />}
                      </button>
                      <button className="player-btn" title="Next Track" aria-label="Next Track">
                        <SkipForwardIcon />
                      </button>
                    </div>
                  </section>
                </div>

                {/* Row 3: Notification Center */}
                <section className="glass-card notification-center-card">
                  <div className="card-title-row">
                    <span className="card-title">Notification Center</span>
                    <button className="dots-menu-btn" title="Options" aria-label="Options">
                      •••
                    </button>
                  </div>
                  <div className="notification-pill-item">
                    <div className="notification-icon-bubble" style={{ background: 'var(--accent-caramel)' }}>
                      <ShieldIcon />
                    </div>
                    <span className="notification-msg-text">Security camera update available</span>
                  </div>
                  <div className="notification-pill-item">
                    <div className="notification-icon-bubble" style={{ background: 'var(--accent-caramel)' }}>
                      <AlertTriangleIcon />
                    </div>
                    <span className="notification-msg-text">Motion detected in backyard</span>
                  </div>
                </section>
              </div>
            </div>
          )}

          {/* 2. SEARCH & DEVICES TAB */}
          {activeTab === 'search' && (
            <div className="tab-view-container">
              <div className="tab-view-header">
                <h2 className="tab-view-title">Smart Devices Hub</h2>
                <span className="tab-badge-pill">{filteredDevices.length} Connected Devices</span>
              </div>
              <div className="search-input-box">
                <SearchIcon />
                <input
                  type="text"
                  placeholder="Search devices, rooms, automations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="search-text-field"
                />
              </div>
              <div className="filter-chips-row">
                {['All', 'Lights', 'Climate', 'Security', 'Appliances', 'Media'].map((cat) => (
                  <button
                    key={cat}
                    className={`filter-chip ${searchFilter === cat ? 'active' : ''}`}
                    onClick={() => setSearchFilter(cat)}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <div className="device-cards-grid">
                {filteredDevices.map((dev, i) => (
                  <div key={i} className="device-item-card">
                    <div className="device-top-line">
                      <div className={`device-icon-wrap ${dev.active ? 'active' : ''}`}>
                        <HomeIcon />
                      </div>
                      <button className={`toggle-switch-pill ${dev.active ? 'active' : ''}`}>
                        <div className="toggle-knob"></div>
                      </button>
                    </div>
                    <div>
                      <div className="device-name">{dev.name}</div>
                      <div className="device-room">{dev.room} • {dev.val || (dev.active ? 'Active' : 'Off')}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. SECURITY CENTER TAB */}
          {activeTab === 'security' && (
            <div className="tab-view-container">
              <div className="security-status-banner">
                <div>
                  <h2 className="tab-view-title">Surveillance & Perimeter Security</h2>
                  <span style={{ fontSize: '11px', color: 'var(--text-white-muted)' }}>Status: All 18 sensors online & armed</span>
                </div>
                <div className="security-mode-pills">
                  {['Armed Away', 'Armed Home', 'Disarmed'].map((m) => (
                    <button
                      key={m}
                      className={`security-mode-btn ${securityMode === m ? 'active' : ''}`}
                      onClick={() => setSecurityMode(m)}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
              <div className="security-quad-grid">
                <div className="camera-tile">
                  <img src="/image.png" alt="Living Room" />
                  <div className="camera-tile-overlay">
                    <div className="cctv-live-tag" style={{ position: 'static' }}>
                      <span className="live-indicator-dot"></span> Live
                    </div>
                    <span className="camera-tile-title">Cam 1: Living Room Stream</span>
                  </div>
                </div>
                <div className="camera-tile">
                  <img src="/image.png" alt="Front Porch" style={{ filter: 'brightness(0.9) contrast(1.1)' }} />
                  <div className="camera-tile-overlay">
                    <div className="cctv-live-tag" style={{ position: 'static' }}>
                      <span className="live-indicator-dot"></span> Live
                    </div>
                    <span className="camera-tile-title">Cam 2: Front Entrance Door</span>
                  </div>
                </div>
                <div className="camera-tile">
                  <img src="/image.png" alt="Backyard" style={{ filter: 'hue-rotate(20deg) brightness(0.85)' }} />
                  <div className="camera-tile-overlay">
                    <div className="cctv-live-tag" style={{ position: 'static', background: 'rgba(230, 57, 70, 0.9)', color: '#fff' }}>
                      <span className="live-indicator-dot" style={{ background: '#fff' }}></span> Motion Alert
                    </div>
                    <span className="camera-tile-title">Cam 3: Backyard Patio</span>
                  </div>
                </div>
                <div className="camera-tile">
                  <img src="/image.png" alt="Garage" style={{ filter: 'grayscale(0.3) brightness(0.9)' }} />
                  <div className="camera-tile-overlay">
                    <div className="cctv-live-tag" style={{ position: 'static' }}>
                      <span className="live-indicator-dot"></span> Live
                    </div>
                    <span className="camera-tile-title">Cam 4: Driveway & Garage</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4. ROOMS & LOCATION TAB */}
          {activeTab === 'location' && (
            <div className="tab-view-container">
              <div className="tab-view-header">
                <h2 className="tab-view-title">Floor Plan & Room Controls</h2>
                <span className="tab-badge-pill">5 Active Zones</span>
              </div>
              <div className="rooms-grid">
                {[
                  { name: 'Living Room', temp: '24°C', hum: '48%', dev: 4, preset: 'Relax Mode' },
                  { name: 'Master Bedroom', temp: '22°C', hum: '50%', dev: 2, preset: 'Sleep Mode' },
                  { name: 'Kitchen & Dining', temp: '23°C', hum: '52%', dev: 3, preset: 'Dinner Mode' },
                  { name: 'Backyard Garden', temp: '26°C', hum: '60%', dev: 2, preset: 'Path Lights' },
                  { name: 'Home Office', temp: '23.5°C', hum: '45%', dev: 3, preset: 'Focus Mode' },
                  { name: 'Balcony Lounge', temp: '27°C', hum: '58%', dev: 1, preset: 'Night Dim' },
                ].map((room, idx) => (
                  <div key={idx} className="room-glass-card">
                    <div className="room-card-head">
                      <span className="room-card-title">{room.name}</span>
                      <button className="dots-menu-btn" style={{ width: 18, height: 18 }}>•••</button>
                    </div>
                    <div className="room-stat-pills">
                      <span className="room-stat-badge">{room.temp}</span>
                      <span className="room-stat-badge">{room.hum}</span>
                      <span className="room-stat-badge">{room.dev} Dev</span>
                    </div>
                    <button className="room-preset-btn">⚡ {room.preset}</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. SETTINGS & AUTOMATIONS TAB */}
          {activeTab === 'settings' && (
            <div className="tab-view-container">
              <div className="tab-view-header">
                <h2 className="tab-view-title">Automations & Hub Configuration</h2>
                <span className="tab-badge-pill">System Health: 99.8%</span>
              </div>
              <div className="settings-dual-cols">
                <div className="glass-card" style={{ justifyContent: 'flex-start' }}>
                  <span className="card-title">Scheduled Automations</span>
                  {[
                    { title: 'Good Morning Routine', time: '07:00 AM • Blinds & Coffee Maker', active: true },
                    { title: 'Away Tariff Mode', time: 'Geo-fence • Eco Climate 27°C', active: true },
                    { title: 'Bedtime Security Sweep', time: '11:30 PM • Lock all doors & dim', active: true },
                    { title: 'Cinema Night Preset', time: 'Custom • Living Room 20% Dim', active: false },
                  ].map((routine, idx) => (
                    <div key={idx} className="setting-routine-row">
                      <div>
                        <div className="routine-title">{routine.title}</div>
                        <div className="routine-sub">{routine.time}</div>
                      </div>
                      <button className={`toggle-switch-pill ${routine.active ? 'active' : ''}`}>
                        <div className="toggle-knob"></div>
                      </button>
                    </div>
                  ))}
                </div>

                <div className="glass-card" style={{ justifyContent: 'flex-start' }}>
                  <span className="card-title">Mesh & Network Bridges</span>
                  <div className="hub-status-box">
                    <div>
                      <div className="hub-txt-main">Zigbee 3.0 Mesh</div>
                      <div className="hub-txt-sub">28 nodes connected • Excellent Signal</div>
                    </div>
                    <span style={{ fontSize: 11, color: '#4ade80' }}>● Online</span>
                  </div>
                  <div className="hub-status-box">
                    <div>
                      <div className="hub-txt-main">Matter Protocol Bridge</div>
                      <div className="hub-txt-sub">Firmware v4.2.1 • Thread Border Router</div>
                    </div>
                    <span style={{ fontSize: 11, color: '#4ade80' }}>● Synced</span>
                  </div>
                  <div className="hub-status-box">
                    <div>
                      <div className="hub-txt-main">Wi-Fi 6 Smart Gateway</div>
                      <div className="hub-txt-sub">5.2 GHz • 860 Mbps • 42 Clients</div>
                    </div>
                    <span style={{ fontSize: 11, color: '#4ade80' }}>● Optimal</span>
                  </div>
                  <div className="automation-capsule" style={{ marginTop: 'auto' }}>
                    <span className="bullet-dot-caramel"></span>
                    <span className="automation-text">Energy saver saved 18.4 kWh this week</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 6. USER PROFILE TAB */}
          {activeTab === 'user' && (
            <div className="tab-view-container">
              <div className="tab-view-header">
                <h2 className="tab-view-title">User Account & Family Access</h2>
                <span className="tab-badge-pill">Role: Master Administrator</span>
              </div>
              <div className="user-cards-split">
                <div className="glass-card" style={{ justifyContent: 'flex-start' }}>
                  <div className="profile-summary-box">
                    <img src="/avatar.png" alt="Alex Mercer" className="profile-avatar-large" />
                    <div>
                      <div className="profile-info-title">Alex Mercer</div>
                      <div className="profile-info-sub">alex.mercer@smarthome.io</div>
                      <div style={{ fontSize: 10, color: 'var(--accent-caramel)', marginTop: 2, fontWeight: 600 }}>NFC Digital Pass Synced</div>
                    </div>
                  </div>
                  <span className="card-title" style={{ marginTop: 12 }}>Connected Ecosystems</span>
                  <div className="setting-routine-row">
                    <div>
                      <div className="routine-title">Apple HomeKit</div>
                      <div className="routine-sub">Siri & Home App Synced</div>
                    </div>
                    <span style={{ fontSize: 11, color: 'var(--accent-caramel)', fontWeight: 600 }}>Linked</span>
                  </div>
                  <div className="setting-routine-row">
                    <div>
                      <div className="routine-title">Google Assistant</div>
                      <div className="routine-sub">Nest Hub Connected</div>
                    </div>
                    <span style={{ fontSize: 11, color: 'var(--accent-caramel)', fontWeight: 600 }}>Linked</span>
                  </div>
                </div>

                <div className="glass-card" style={{ justifyContent: 'flex-start' }}>
                  <span className="card-title">Household Members</span>
                  {[
                    { name: 'Sarah Mercer', role: 'Family Co-Admin • Full Access', pass: 'Active' },
                    { name: 'Liam Mercer', role: 'Kids Profile • Bedroom & TV Only', pass: 'Restricted' },
                    { name: 'Elena (Housekeeper)', role: 'Guest Pin • Mon-Fri 10:00 - 14:00', pass: 'Scheduled' },
                  ].map((mem, idx) => (
                    <div key={idx} className="family-member-row">
                      <div>
                        <div className="member-name">{mem.name}</div>
                        <div className="member-role">{mem.role}</div>
                      </div>
                      <span style={{ fontSize: 10.5, color: 'var(--accent-caramel)', fontWeight: 600 }}>{mem.pass}</span>
                    </div>
                  ))}
                  <div className="automation-capsule" style={{ marginTop: 'auto' }}>
                    <span className="bullet-dot-caramel"></span>
                    <span className="automation-text">Last login: Today at 08:14 AM from iPhone 16 Pro</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
