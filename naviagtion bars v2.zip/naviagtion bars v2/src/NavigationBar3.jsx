import React, { useState } from 'react'
import { Home, Heart, PlusCircle, User, Bell } from 'lucide-react'
import { motion, useAnimation } from 'framer-motion'
import './NavigationBar3.css'

const icons = [
  { id: 'home', name: 'Home', Icon: Home, color: '#fcd5f8' },
  { id: 'heart', name: 'Likes', Icon: Heart, color: '#ffd6e8' },
  { id: 'plus', name: 'Add', Icon: PlusCircle, color: '#e8d6ff' },
  { id: 'user', name: 'Profile', Icon: User, color: '#d6f0ff' },
  { id: 'bell', name: 'Alerts', Icon: Bell, color: '#fef0b8' },
]

export default function NavigationBar3() {
  const [activeIndex, setActiveIndex] = useState(null)
  const [clickCounts, setClickCounts] = useState({ 0: 0, 1: 0, 2: 0, 3: 0, 4: 0 })
  const controls = useAnimation()

  const activeColor = activeIndex !== null ? icons[activeIndex].color : '#ffffff'

  const handleTabClick = (index) => {
    setActiveIndex(index)
    setClickCounts((prev) => ({ ...prev, [index]: prev[index] + 1 }))
    controls.start({
      maxWidth: ['460px', '390px', '480px', '450px', '460px'],
      transition: {
        duration: 0.95,
        times: [0, 0.28, 0.65, 0.85, 1],
        ease: ['circOut', 'easeIn', 'easeOut', 'easeInOut'],
      },
    })
  }

  return (
    <div className="nav3-container">
      <motion.div className="nav3-dock-wrapper" animate={controls}>
        {/* Gooey Filter for Liquid Physics */}
        <svg style={{ width: 0, height: 0, position: 'absolute' }}>
          <filter id="goo-nav3">
            <feGaussianBlur in="SourceGraphic" stdDeviation="15" result="blur" />
            <feColorMatrix
              in="blur"
              mode="matrix"
              values="1 0 0 0 0  
                      0 1 0 0 0  
                      0 0 1 0 0  
                      0 0 0 30 -12"
              result="goo"
            />
            <feBlend in="SourceGraphic" in2="goo" />
          </filter>
        </svg>

        {/* The Liquid Layer */}
        <div className="nav3-gooey-container">
          <motion.div
            className="nav3-dock-base"
            initial={false}
            animate={{ backgroundColor: activeColor }}
            transition={{ duration: 0.65, ease: 'easeInOut' }}
          />

          {icons.map((item, index) => {
            const isActive = activeIndex === index

            return (
              <React.Fragment key={`bubble-group-${item.id}`}>
                <motion.div
                  key={`wave-${item.id}-${clickCounts[index]}`}
                  className="nav3-wave-base"
                  initial={false}
                  animate={
                    isActive
                      ? {
                          y: [0, -55, 0, 30, -5, 0],
                          scaleY: [1, 2.5, 1, 0.6, 1.1, 1],
                          scaleX: [1, 0.55, 1, 1.3, 0.9, 1],
                          backgroundColor: activeColor,
                        }
                      : {
                          y: 0,
                          scaleY: 1,
                          scaleX: 1,
                          backgroundColor: activeColor,
                        }
                  }
                  transition={{
                    y: {
                      duration: 0.95,
                      times: [0, 0.15, 0.28, 0.65, 0.85, 1],
                      ease: ['circOut', 'easeIn', 'easeOut', 'easeOut', 'easeInOut'],
                    },
                    scaleY: {
                      duration: 0.95,
                      times: [0, 0.15, 0.28, 0.65, 0.85, 1],
                      ease: ['circOut', 'easeIn', 'easeOut', 'easeOut', 'easeInOut'],
                    },
                    scaleX: {
                      duration: 0.95,
                      times: [0, 0.15, 0.28, 0.65, 0.85, 1],
                      ease: ['circOut', 'easeIn', 'easeOut', 'easeOut', 'easeInOut'],
                    },
                    backgroundColor: { duration: 0.65, ease: 'easeInOut' },
                  }}
                  style={{
                    left: `calc(${10 + index * 20}% - 30px)`,
                  }}
                />
                <motion.div
                  key={`bubble-${item.id}-${clickCounts[index]}`}
                  className="nav3-liquid-bubble"
                  initial={false}
                  animate={
                    isActive
                      ? {
                          y: [0, -135, 15, -15, 0],
                          backgroundColor: activeColor,
                        }
                      : {
                          y: 0,
                          backgroundColor: activeColor,
                        }
                  }
                  transition={{
                    duration: 0.95,
                    times: [0, 0.28, 0.65, 0.85, 1],
                    ease: ['circOut', 'easeIn', 'easeOut', 'easeInOut'],
                    backgroundColor: { duration: 0.65, ease: 'easeInOut' },
                  }}
                  style={{
                    left: `calc(${10 + index * 20}% - 30px)`,
                  }}
                />
              </React.Fragment>
            )
          })}
        </div>

        {/* The Icons Layer */}
        <div className="nav3-icons-layer">
          {icons.map((item, index) => {
            const IconComponent = item.Icon
            const isActive = activeIndex === index

            return (
              <div
                key={item.id}
                className="nav3-dock-icon"
                onClick={() => handleTabClick(index)}
                style={{ left: `calc(${10 + index * 20}% - 30px)` }}
              >
                <motion.div
                  key={`icon-${item.id}-${clickCounts[index]}`}
                  initial={false}
                  animate={
                    isActive
                      ? {
                          y: [0, -135, 15, -15, 0],
                          scale: [1, 1.15, 0.8, 1.1, 1],
                          color: [
                            'var(--icon-inactive)',
                            'var(--icon-active)',
                            'var(--icon-active)',
                            'var(--icon-active)',
                            'var(--icon-active)',
                          ],
                        }
                      : {
                          y: 0,
                          scale: 1,
                          color: 'var(--icon-inactive)',
                        }
                  }
                  transition={{
                    duration: 0.95,
                    times: [0, 0.28, 0.65, 0.85, 1],
                    ease: ['circOut', 'easeIn', 'easeOut', 'easeInOut'],
                  }}
                  className="nav3-icon-inner"
                >
                  <IconComponent
                    size={22}
                    strokeWidth={isActive ? 2.5 : 2}
                    color={isActive ? 'var(--icon-active)' : 'var(--icon-inactive)'}
                  />
                </motion.div>

                <motion.span
                  className="nav3-icon-label"
                  animate={{ color: isActive ? 'var(--icon-active)' : 'var(--icon-inactive)' }}
                  transition={{ duration: 0.3 }}
                >
                  {item.name}
                </motion.span>

                {/* Subtle active dot */}
                <motion.div
                  initial={false}
                  animate={{
                    scale: isActive ? 1 : 0,
                    opacity: isActive ? 1 : 0,
                  }}
                  transition={{ delay: 0.1 }}
                  className="nav3-active-dot"
                />
              </div>
            )
          })}
        </div>
      </motion.div>
    </div>
  )
}
