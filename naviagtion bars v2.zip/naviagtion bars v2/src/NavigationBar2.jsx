import { useState } from 'react'
import { Home, Heart, PlusCircle, User, Bell } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import './NavigationBar2.css'

const tabs = [
  { id: 0, icon: Home, label: 'Home' },
  { id: 1, icon: Heart, label: 'Favorites' },
  { id: 2, icon: PlusCircle, label: 'Add' },
  { id: 3, icon: User, label: 'Profile' },
  { id: 4, icon: Bell, label: 'Notifications' },
]

export default function NavigationBar2() {
  const [activeTab, setActiveTab] = useState(0)
  const ActiveIcon = tabs[activeTab].icon

  return (
    <div className="nav2-container">
      {/* Curved White Navigation Bar */}
      <nav className="nav2-bar" aria-label="Curved Navigation Bar">
        {/* Animated Slider carrying the organic Notch and Floating Gradient Bubble */}
        <motion.div
          className="nav2-slider"
          animate={{ left: `${activeTab * 20}%` }}
          transition={{
            type: 'spring',
            stiffness: 360,
            damping: 22,
            mass: 0.8,
          }}
        >
          {/* SVG Notch cutting cleanly into the white navbar */}
          <svg
            className="nav2-notch-svg"
            viewBox="0 0 92 34"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            <path
              className="nav2-notch-fill"
              d="M 0 0 C 22 0, 24 34, 46 34 C 68 34, 70 0, 92 0 Z"
              fill="var(--bg-color)"
            />
            <path
              d="M 0 0 C 22 0, 24 34, 46 34 C 68 34, 70 0, 92 0"
              fill="none"
              stroke="rgba(0, 0, 0, 0.05)"
              strokeWidth="1.2"
            />
          </svg>

          {/* Elevated Gradient Circular Bubble */}
          <div className="nav2-bubble">
            <AnimatePresence mode="popLayout">
              <motion.div
                key={activeTab}
                initial={{ scale: 0.4, y: 6, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.4, y: -4, opacity: 0, transition: { duration: 0.08 } }}
                transition={{
                  type: 'spring',
                  stiffness: 420,
                  damping: 18,
                  delay: 0.08,
                }}
                className="nav2-bubble-icon"
              >
                <ActiveIcon size={24} color="#ffffff" strokeWidth={2.4} />
              </motion.div>
            </AnimatePresence>
          </div>
        </motion.div>

        {/* Tab buttons */}
        <div className="nav2-tabs-row">
          {tabs.map((tab) => {
            const Icon = tab.icon
            const isActive = activeTab === tab.id

            return (
              <button
                key={tab.id}
                type="button"
                className={`nav2-tab-btn ${isActive ? 'active' : ''}`}
                onClick={() => setActiveTab(tab.id)}
                aria-label={tab.label}
              >
                <Icon
                  className="nav2-tab-icon"
                  size={24}
                  strokeWidth={2}
                />
              </button>
            )
          })}
        </div>

        {/* iOS Home Indicator Pill */}
        <div className="nav2-home-indicator"></div>
      </nav>
    </div>
  )
}
