import { useState } from 'react'
import { Home, Heart, PlusCircle, User, Bell } from 'lucide-react'
import { motion } from 'framer-motion'
import NavigationBar2 from './NavigationBar2'
import NavigationBar3 from './NavigationBar3'
import './App.css'

const bgThemes = [
  { name: 'Periwinkle', color: '#a8c0ea' },
  { name: 'Sage Mint', color: '#a2dad0' },
  { name: 'Lavender', color: '#c5bce8' },
  { name: 'Sky Blue', color: '#96d3ea' },
  { name: 'Warm Sand', color: '#e8d5b5' },
]

function App() {
  const [activeTab, setActiveTab] = useState(1)
  const [currentBg, setCurrentBg] = useState(bgThemes[0].color)

  const handleThemeChange = (color) => {
    setCurrentBg(color)
    document.documentElement.style.setProperty('--bg-color', color)
  }

  const tabs = [
    { id: 0, icon: Home },
    { id: 1, icon: Heart },
    { id: 2, icon: PlusCircle },
    { id: 3, icon: User },
    { id: 4, icon: Bell },
  ]

  return (
    <>
      {/* Floating Theme Switcher at Top */}
      <div className="theme-picker">
        <span className="theme-picker-label">🎨 BG Color:</span>
        {bgThemes.map((theme) => (
          <button
            key={theme.name}
            type="button"
            className={`theme-btn ${currentBg === theme.color ? 'active' : ''}`}
            onClick={() => handleThemeChange(theme.color)}
          >
            <span
              className="theme-color-dot"
              style={{ backgroundColor: theme.color }}
            />
            {theme.name}
          </button>
        ))}
      </div>

      <div className="container">
      {/* First Navigation Bar - Dark Pill with Red Spotlight */}
      <nav className="navbar">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id
          
          return (
            <div 
              key={tab.id} 
              className={`nav-item ${isActive ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {isActive && (
                <>
                  <motion.div 
                    layoutId="active-indicator"
                    className="active-indicator"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                  <motion.div 
                    layoutId="spotlight"
                    className="spotlight"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                </>
              )}
              <Icon 
                className={`icon ${isActive ? 'active-icon' : ''}`} 
                size={26} 
                strokeWidth={2}
              />
            </div>
          )
        })}
      </nav>

      {/* Second Navigation Bar - Standalone Curved Notch with Gradient Bubble */}
      <NavigationBar2 />

      {/* Third Navigation Bar - Liquid Gooey Mobile Dock */}
      <NavigationBar3 />
    </div>
    </>
  )
}

export default App
