import React from 'react';
import BasketballUpload from './upload.jsx';

function App() {
  return (
    <main style={{ minHeight: '100vh', width: '100%', margin: 0, padding: 0 }}>
      <BasketballUpload />
    </main>
  );
}

export default App;
