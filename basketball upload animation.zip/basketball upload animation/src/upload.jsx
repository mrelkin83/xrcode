import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './upload.css';

// Sound synthesizer using Web Audio API (Zero external assets required)
class SoundFX {
  constructor() {
    this.ctx = null;
    this.enabled = true;
  }

  init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playWhoosh() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(120, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(380, this.ctx.currentTime + 0.22);
      osc.frequency.exponentialRampToValueAtTime(160, this.ctx.currentTime + 0.48);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(550, this.ctx.currentTime);

      gain.gain.setValueAtTime(0.01, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.18, this.ctx.currentTime + 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.48);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.48);
    } catch {
      // Audio fallback silent
    }
  }

  playSwish() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    try {
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.32);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1600, this.ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(800, this.ctx.currentTime + 0.28);
      filter.Q.setValueAtTime(4.0, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.28, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.32);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start();
    } catch {
      // Audio fallback silent
    }
  }

  playSuccess() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.07);

        gain.gain.setValueAtTime(0, now + idx * 0.07);
        gain.gain.linearRampToValueAtTime(0.12, now + idx * 0.07 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.32);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now + idx * 0.07);
        osc.stop(now + idx * 0.07 + 0.35);
      });
    } catch {
      // Audio fallback silent
    }
  }
}

const sfx = new SoundFX();

export default function BasketballUpload({
  uploadEndpoint = null,
  onUpload = null,
  onUploadComplete = null,
}) {
  const containerRef = useRef(null);
  const fileInputRef = useRef(null);
  const rimRef = useRef(null);

  // Stats
  const [uploadedCount, setUploadedCount] = useState(0);
  const [isBadgeBouncing, setIsBadgeBouncing] = useState(false);
  const [soundMuted, setSoundMuted] = useState(false);
  const [isDragOverWindow, setIsDragOverWindow] = useState(false);

  // Active file metadata (default: document.pdf)
  const [currentFile, setCurrentFile] = useState({
    name: 'document.pdf',
    size: '2.4 MB',
    type: 'pdf',
    rawFile: null,
  });
  const [isCustomFileLoaded, setIsCustomFileLoaded] = useState(false);

  // Default launch position (56x74 card at bottom-left)
  const defaultPos = { x: 80, y: 550 };
  const [filePos, setFilePos] = useState(defaultPos);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  // Flight animation state
  const [isFlying, setIsFlying] = useState(false);
  const [flightTransform, setFlightTransform] = useState({
    x: 80,
    y: 550,
    scale: 1,
    rotation: 0,
    opacity: 1,
    inHoop: false,
  });

  // Basketball Hoop dynamic coordinate
  const [hoopTarget, setHoopTarget] = useState({ x: 290, y: 325 });

  // Net animation state ('idle' | 'swish')
  const [netState, setNetState] = useState('idle');

  // Upload progress: 'idle' | 'uploading' | 'completed'
  const [uploadStatus, setUploadStatus] = useState('idle');
  const [uploadProgress, setUploadProgress] = useState(0);

  // Drag tracking refs
  const dragStartPosRef = useRef({ x: 0, y: 0 });
  const mouseStartPosRef = useRef({ x: 0, y: 0 });
  const hasMovedRef = useRef(false);
  const animFrameRef = useRef(null);

  // Sync mute setting
  useEffect(() => {
    sfx.enabled = !soundMuted;
  }, [soundMuted]);

  // Dynamically calculate exact center of the rim relative to container
  const updateHoopCoordinates = useCallback(() => {
    if (rimRef.current && containerRef.current) {
      const rimRect = rimRef.current.getBoundingClientRect();
      const containerRect = containerRef.current.getBoundingClientRect();
      setHoopTarget({
        x: rimRect.left - containerRect.left + rimRect.width / 2,
        y: rimRect.top - containerRect.top + rimRect.height / 2,
      });
    }
  }, []);

  useEffect(() => {
    updateHoopCoordinates();
    window.addEventListener('resize', updateHoopCoordinates);
    return () => window.removeEventListener('resize', updateHoopCoordinates);
  }, [updateHoopCoordinates]);

  // Parabolic trajectory formula with exact apex height
  const calculateParabolaControlPoint = useCallback(
    (startX, startY, targetX, targetY) => {
      const apexY = Math.min(startY, targetY) - 155;
      const apexX = startX + (targetX - startX) * 0.52;

      const ctlX = 2 * apexX - 0.5 * (startX + targetX);
      const ctlY = 2 * apexY - 0.5 * (startY + targetY);

      return { x: ctlX, y: ctlY };
    },
    []
  );

  // Generate thinner trajectory preview dots
  const getTrajectoryPoints = useCallback(() => {
    const startX = filePos.x + 28;
    const startY = filePos.y + 8;
    const targetX = hoopTarget.x;
    const targetY = hoopTarget.y - 12;

    const ctl = calculateParabolaControlPoint(startX, startY, targetX, targetY);

    const points = [];
    const count = 10;
    for (let i = 1; i < count; i++) {
      const t = i / count;
      const x = (1 - t) * (1 - t) * startX + 2 * (1 - t) * t * ctl.x + t * t * targetX;
      const y = (1 - t) * (1 - t) * startY + 2 * (1 - t) * t * ctl.y + t * t * targetY;
      points.push({ x, y, t });
    }
    return points;
  }, [filePos, hoopTarget, calculateParabolaControlPoint]);

  // Execute realistic basketball throw physics
  const shootFile = useCallback(() => {
    if (isFlying || uploadStatus === 'uploading') return;

    const fileCardWidth = 56;
    const startX = filePos.x;
    const startY = filePos.y;

    // Target scale when entering the rim in 3D perspective
    const targetScale = 0.44;
    const targetCenterOffset = (fileCardWidth * targetScale) / 2;
    const targetX = hoopTarget.x - targetCenterOffset;
    const targetY = hoopTarget.y - 18;

    const ctl = calculateParabolaControlPoint(
      startX + 28,
      startY + 8,
      hoopTarget.x,
      targetY
    );
    const ctlTopLeftX = ctl.x - 28;
    const ctlTopLeftY = ctl.y - 8;

    setIsFlying(true);
    setIsDragging(false);
    sfx.playWhoosh();

    const startTime = performance.now();
    const flightDuration = 820; // ms

    const animateFlight = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / flightDuration, 1);

      const t = progress;

      // Position on parabolic curve
      const currentX =
        (1 - t) * (1 - t) * startX + 2 * (1 - t) * t * ctlTopLeftX + t * t * targetX;
      const currentY =
        (1 - t) * (1 - t) * startY + 2 * (1 - t) * t * ctlTopLeftY + t * t * targetY;

      // 3D perspective scaling
      const scale = 1.0 - (1.0 - targetScale) * t;

      // Natural basketball flight rotation
      let rotation = 0;
      if (t < 0.5) {
        rotation = -12 * (t / 0.5);
      } else {
        rotation = -12 + 18 * ((t - 0.5) / 0.5);
      }

      // Entering inside rim opening
      const entersRim = t >= 0.86;

      if (progress < 1) {
        setFlightTransform({
          x: currentX,
          y: currentY,
          scale,
          rotation,
          opacity: 1,
          inHoop: entersRim,
        });

        // Trigger net ripple & swish right as file enters rim
        if (entersRim && netState === 'idle') {
          setNetState('swish');
          sfx.playSwish();
        }

        animFrameRef.current = requestAnimationFrame(animateFlight);
      } else {
        // Swish through net!
        setNetState('swish');
        sfx.playSwish();

        // Gravity drop down through the bottom of the net
        setFlightTransform({
          x: targetX,
          y: targetY + 68,
          scale: targetScale * 0.85,
          rotation: 4,
          opacity: 0,
          inHoop: true,
        });

        // Reset net ripple
        setTimeout(() => {
          setNetState('idle');
        }, 550);

        // Reset flight state & trigger upload progress in dashed box
        setTimeout(() => {
          setIsFlying(false);
          setFilePos(defaultPos);
          startUploadProcess();
        }, 350);
      }
    };

    animFrameRef.current = requestAnimationFrame(animateFlight);
  }, [filePos, hoopTarget, isFlying, uploadStatus, calculateParabolaControlPoint, netState, defaultPos]);

  const handleUploadSuccess = useCallback(
    (resData = null) => {
      setUploadProgress(100);
      setUploadStatus('completed');
      sfx.playSuccess();

      // Increment top-right badge
      setUploadedCount((prev) => prev + 1);
      setIsBadgeBouncing(true);
      setTimeout(() => setIsBadgeBouncing(false), 800);

      if (typeof onUploadComplete === 'function') {
        onUploadComplete(currentFile.rawFile || currentFile, resData);
      }

      // Reset back to idle after delay
      setTimeout(() => {
        setUploadStatus('idle');
        setUploadProgress(0);
        setIsCustomFileLoaded(false);
      }, 2200);
    },
    [currentFile, onUploadComplete]
  );

  // Upload Progress: Supports real backend API, custom onUpload callback, or smooth demo simulation
  const startUploadProcess = useCallback(() => {
    setUploadStatus('uploading');
    setUploadProgress(0);

    // 1. Custom onUpload handler (e.g. Firebase, Supabase, Cloudinary, Axios)
    if (typeof onUpload === 'function') {
      onUpload(currentFile.rawFile, (percent) => {
        setUploadProgress(Math.min(100, Math.max(0, Math.round(percent))));
      })
        .then((res) => {
          handleUploadSuccess(res);
        })
        .catch((err) => {
          console.error('Upload failed:', err);
          setUploadStatus('idle');
        });
      return;
    }

    // 2. Real Backend Endpoint (e.g. uploadEndpoint="/api/upload") with live byte progress
    if (uploadEndpoint && currentFile.rawFile) {
      const xhr = new XMLHttpRequest();
      const formData = new FormData();
      formData.append('file', currentFile.rawFile);

      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          const percent = Math.round((e.loaded / e.total) * 100);
          setUploadProgress(percent);
        }
      };

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          let responseData = xhr.responseText;
          try {
            responseData = JSON.parse(xhr.responseText);
          } catch {}
          handleUploadSuccess(responseData);
        } else {
          console.error('Upload endpoint error:', xhr.statusText);
          setUploadStatus('idle');
        }
      };

      xhr.onerror = () => {
        console.error('Upload network error');
        setUploadStatus('idle');
      };

      xhr.open('POST', uploadEndpoint);
      xhr.send(formData);
      return;
    }

    // 3. Fallback realistic simulation for interactive demo / UI testing
    let current = 0;
    const interval = setInterval(() => {
      current += Math.floor(Math.random() * 16) + 12;
      if (current >= 100) {
        clearInterval(interval);
        handleUploadSuccess();
      } else {
        setUploadProgress(current);
      }
    }, 110);
  }, [currentFile, onUpload, uploadEndpoint, handleUploadSuccess]);

  // Pointer drag event handlers for springy aiming
  const handlePointerDown = (e) => {
    if (isFlying || uploadStatus === 'uploading') return;
    e.preventDefault();
    updateHoopCoordinates();

    mouseStartPosRef.current = { x: e.clientX, y: e.clientY };
    dragStartPosRef.current = { ...filePos };
    hasMovedRef.current = false;
    setIsDragging(true);
  };

  const handlePointerMove = useCallback(
    (e) => {
      if (!isDragging || !containerRef.current) return;
      e.preventDefault();

      const dx = e.clientX - mouseStartPosRef.current.x;
      const dy = e.clientY - mouseStartPosRef.current.y;

      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
        hasMovedRef.current = true;
      }

      const rect = containerRef.current.getBoundingClientRect();
      const rawX = dragStartPosRef.current.x + dx;
      const rawY = dragStartPosRef.current.y + dy;

      // Bound within court boundaries
      const clampedX = Math.max(16, Math.min(rawX, rect.width - 76));
      const clampedY = Math.max(160, Math.min(rawY, rect.height - 95));

      setFilePos({ x: clampedX, y: clampedY });
      setDragOffset({ x: dx, y: dy });
    },
    [isDragging]
  );

  const handlePointerUp = useCallback(() => {
    if (!isDragging) return;
    setIsDragging(false);
    setDragOffset({ x: 0, y: 0 });

    // Release to shoot!
    shootFile();
  }, [isDragging, shootFile]);

  // Window pointer listeners
  useEffect(() => {
    if (isDragging) {
      window.addEventListener('pointermove', handlePointerMove);
      window.addEventListener('pointerup', handlePointerUp);
    }
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    };
  }, [isDragging, handlePointerMove, handlePointerUp]);

  // Clean animation frame
  useEffect(() => {
    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, []);

  // Set selected file onto the launcher pad (DOES NOT auto-shoot; user will aim and shoot!)
  const loadFileOntoLauncher = (file) => {
    if (!file) return;
    const sizeStr = (file.size / (1024 * 1024)).toFixed(1) + ' MB';
    const ext = file.name.split('.').pop()?.toLowerCase() || 'pdf';

    setCurrentFile({
      name: file.name,
      size: sizeStr,
      type: ext,
      rawFile: file,
    });
    setIsCustomFileLoaded(true);
    setFilePos(defaultPos); // place ready at launcher
  };

  // Native File Drop Handler (From OS folder) -> loads onto launcher!
  const handleNativeDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOverWindow(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      loadFileOntoLauncher(e.dataTransfer.files[0]);
    }
  };

  const handleNativeDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragOverWindow) setIsDragOverWindow(true);
  };

  const handleNativeDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOverWindow(false);
  };

  // Native file input selection -> loads onto launcher!
  const handleFileInputChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      loadFileOntoLauncher(e.target.files[0]);
    }
  };

  const trajectoryPoints = getTrajectoryPoints();

  return (
    <div className="upload-page-wrapper">
      <div
        className={`basketball-upload-card ${isDragOverWindow ? 'court-drag-over' : ''}`}
        ref={containerRef}
        onDragOver={handleNativeDragOver}
        onDragLeave={handleNativeDragLeave}
        onDrop={handleNativeDrop}
      >
        {/* Top Header */}
        <header className="upload-header">
          <div className="header-titles">
            <h1 className="main-title">Upload files</h1>
            <p className="sub-title">Drag and drop, or take the shot.</p>
          </div>
          <div className="header-actions">
            <button
              type="button"
              className="sound-toggle-btn"
              onClick={() => setSoundMuted(!soundMuted)}
              title={soundMuted ? 'Unmute sound effects' : 'Mute sound effects'}
              aria-label="Toggle Sound"
            >
              {soundMuted ? (
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M11 5L6 9H2v6h4l5 4V5z" />
                  <line x1="23" y1="9" x2="17" y2="15" />
                  <line x1="17" y1="9" x2="23" y2="15" />
                </svg>
              ) : (
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                  <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
                </svg>
              )}
            </button>
            <motion.div
              className={`uploaded-badge ${isBadgeBouncing ? 'badge-bounce' : ''}`}
              animate={isBadgeBouncing ? { scale: [1, 1.24, 1], rotate: [0, -4, 4, 0] } : { scale: 1 }}
              transition={{ type: 'spring', stiffness: 450, damping: 14 }}
            >
              Uploaded <span className="badge-count">{uploadedCount}</span>
            </motion.div>
          </div>
        </header>

        {/* Center Dashed Drop Area */}
        <div className="drop-zone-container">
          <div
            className={`dashed-box ${uploadStatus === 'uploading' ? 'box-uploading' : ''}`}
            onClick={() => {
              if (uploadStatus === 'idle') fileInputRef.current?.click();
            }}
          >
            <input
              type="file"
              ref={fileInputRef}
              style={{ display: 'none' }}
              onChange={handleFileInputChange}
            />

            {/* Default Box Content */}
            {uploadStatus === 'idle' && (
              <div className="box-center-content">
                <div className="upload-icon-wrapper">
                  <svg
                    className="upload-tray-icon"
                    width="26"
                    height="26"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M4 16.5v2.25A2.25 2.25 0 006.25 21h11.5A2.25 2.25 0 0020 18.75V16.5" />
                    <polyline points="16 9 12 5 8 9" />
                    <line x1="12" y1="5" x2="12" y2="16" />
                  </svg>
                </div>
                <h3 className="drop-title">
                  {isCustomFileLoaded ? currentFile.name : 'Drop files here'}
                </h3>
                <p className="drop-subtitle">
                  {isCustomFileLoaded ? 'Ready to shoot! Aim below or take the shot' : 'or take the shot'}
                </p>
              </div>
            )}

            {/* Upload Progress Bar */}
            <AnimatePresence>
              {uploadStatus !== 'idle' && (
                <motion.div
                  className="upload-progress-wrapper"
                  initial={{ opacity: 0, y: 14, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -8, scale: 0.95 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 26 }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="upload-file-header">
                    <div className="upload-file-info">
                      <span className="file-badge-tag">{currentFile.type.toUpperCase()}</span>
                      <span className="upload-filename">{currentFile.name}</span>
                    </div>
                    <span className="upload-filesize">
                      {uploadStatus === 'completed' ? 'Done' : `${uploadProgress}%`}
                    </span>
                  </div>
                  <div className="progress-track">
                    <motion.div
                      className={`progress-fill ${uploadStatus === 'completed' ? 'fill-completed' : ''}`}
                      style={{ width: `${uploadProgress}%` }}
                      transition={{ ease: 'easeOut', duration: 0.14 }}
                    />
                  </div>
                  <div className="progress-status-footer">
                    {uploadStatus === 'completed' ? (
                      <span className="success-tag">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <polyline points="20 6 9 17 4 12" />
                        </svg>
                        File uploaded successfully
                      </span>
                    ) : (
                      <span className="uploading-tag">Uploading file...</span>
                    )}
                    <span className="file-bytes">{currentFile.size}</span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Basketball Hoop & Backboard Assembly */}
            <div className="basketball-hoop-assembly">
              {/* Backboard */}
              <div className="hoop-backboard">
                <div className="backboard-inner-rect" />
              </div>

              {/* Mount Bracket */}
              <div className="hoop-mount-bracket" />

              {/* Back Rim Arc */}
              <svg className="hoop-svg-back" viewBox="0 0 94 28">
                <path
                  d="M 5,14 A 42,12 0 0,1 89,14"
                  fill="none"
                  stroke="#4338ca"
                  strokeWidth="5"
                  strokeLinecap="round"
                />
              </svg>

              {/* Basketball Net with Spring Swish */}
              <motion.div
                className="hoop-net-container"
                animate={
                  netState === 'swish'
                    ? {
                        scaleX: [1, 1.25, 0.93, 1.06, 1],
                        scaleY: [1, 1.28, 0.91, 1.05, 1],
                        rotate: [0, 2.5, -2, 1, 0],
                      }
                    : { scaleX: 1, scaleY: 1, rotate: 0 }
                }
                transition={{
                  duration: 0.58,
                  times: [0, 0.25, 0.5, 0.75, 1],
                  ease: 'easeInOut',
                }}
              >
                <svg className="hoop-net-svg" viewBox="0 0 94 88" fill="none">
                  <g stroke="#94a3b8" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M 10,2 L 20,24 L 28,48 L 34,72 L 35,84" />
                    <path d="M 23,2 L 32,24 L 38,48 L 42,72 L 43,84" />
                    <path d="M 36,2 L 44,24 L 48,48 L 50,72 L 50,84" />
                    <path d="M 50,2 L 54,24 L 56,48 L 56,72 L 56,84" />
                    <path d="M 63,2 L 64,24 L 62,48 L 60,72 L 59,84" />
                    <path d="M 76,2 L 72,24 L 68,48 L 64,72 L 63,84" />
                    <path d="M 86,2 L 78,24 L 72,48 L 67,72 L 66,84" />

                    <path d="M 84,2 L 74,24 L 66,48 L 60,72 L 59,84" />
                    <path d="M 71,2 L 62,24 L 56,48 L 52,72 L 51,84" />
                    <path d="M 58,2 L 50,24 L 46,48 L 44,72 L 44,84" />
                    <path d="M 44,2 L 40,24 L 38,48 L 38,72 L 38,84" />
                    <path d="M 31,2 L 30,24 L 32,48 L 34,72 L 35,84" />
                    <path d="M 18,2 L 22,24 L 26,48 L 30,72 L 31,84" />
                    <path d="M 8,2 L 16,24 L 22,48 L 27,72 L 28,84" />

                    <path d="M 14,24 Q 47,30 80,24" fill="none" strokeWidth="1.6" />
                    <path d="M 24,48 Q 47,52 70,48" fill="none" strokeWidth="1.5" />
                    <path d="M 32,70 Q 47,73 62,70" fill="none" strokeWidth="1.4" />
                    <path d="M 35,84 Q 41,88 47,84 Q 53,88 59,84" fill="none" strokeWidth="1.6" />
                  </g>
                </svg>
              </motion.div>

              {/* Front Rim Arc */}
              <div ref={rimRef} className="rim-ref-anchor">
                <svg className="hoop-svg-front" viewBox="0 0 94 28">
                  <path
                    d="M 5,14 A 42,12 0 0,0 89,14"
                    fill="none"
                    stroke="#6366f1"
                    strokeWidth="5.5"
                    strokeLinecap="round"
                  />
                  <path
                    d="M 12,16 A 38,9 0 0,0 82,16"
                    fill="none"
                    stroke="#a5b4fc"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Trajectory Arc Dots */}
        {(isDragging || (!isFlying && uploadStatus === 'idle')) && (
          <svg className="trajectory-overlay-svg">
            {trajectoryPoints.map((pt, index) => {
              const radius = 1.8 + pt.t * 0.85;
              const opacity = 0.5 + pt.t * 0.5;
              return (
                <circle
                  key={index}
                  cx={pt.x}
                  cy={pt.y}
                  r={radius}
                  fill="#6366f1"
                  opacity={opacity}
                  className="trajectory-dot"
                />
              );
            })}
          </svg>
        )}

        {/* The Flying File along physics path */}
        {isFlying && (
          <div
            className={`flying-file-card ${flightTransform.inHoop ? 'in-hoop-layer' : ''}`}
            style={{
              transform: `translate(${flightTransform.x}px, ${flightTransform.y}px) scale(${flightTransform.scale}) rotate(${flightTransform.rotation}deg)`,
              opacity: flightTransform.opacity,
            }}
          >
            <FileCardItem
              fileName={currentFile.name}
              fileType={currentFile.type}
              isHeld={false}
            />
          </div>
        )}

        {/* The Draggable File Card with Framer Motion Springy Aiming */}
        <AnimatePresence>
          {!isFlying && (
            <motion.div
              key={currentFile.name}
              className={`court-file-card ${isDragging ? 'is-dragging' : ''}`}
              style={{
                left: `${filePos.x}px`,
                top: `${filePos.y}px`,
              }}
              initial={{ scale: 0.2, opacity: 0, y: 35 }}
              animate={{
                scale: isDragging ? 1.07 : 1,
                rotate: isDragging ? Math.max(-12, Math.min(12, dragOffset.x * 0.12)) : 0,
                opacity: 1,
                y: 0,
              }}
              exit={{ opacity: 0, scale: 0.8 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 1.08 }}
              transition={{
                type: 'spring',
                stiffness: isDragging ? 600 : 380,
                damping: isDragging ? 35 : 24,
              }}
              onPointerDown={handlePointerDown}
              onClick={() => {
                if (!hasMovedRef.current) shootFile();
              }}
            >
              <FileCardItem
                fileName={currentFile.name}
                fileType={currentFile.type}
                isHeld={isDragging}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom Tip / Cue */}
        <div className="court-footer-tip">
          <span>
            {isDragging
              ? 'Release to shoot!'
              : isCustomFileLoaded
              ? `Ready: "${currentFile.name}" — Aim & release to shoot!`
              : 'Aim the file & release to shoot into the basket'}
          </span>
        </div>
      </div>
    </div>
  );
}

// PDF Document Card (With Blue Badge matching request)
function FileCardItem({ fileName = 'document.pdf', fileType = 'pdf', isHeld = false }) {
  const badgeLabel = (fileType || 'pdf').slice(0, 4).toUpperCase();

  return (
    <div className="file-paper-card">
      {/* Dog-ear corner fold */}
      <div className="dog-ear-corner" />

      {/* Document skeleton lines */}
      <div className="doc-skeleton-lines">
        <div className="doc-line line-1" />
        <div className="doc-line line-2" />
        <div className="doc-line line-3" />
      </div>

      {/* Blue Tag Badge (Blue color as requested!) */}
      <div className="pdf-tag-badge">
        <span>{badgeLabel}</span>
      </div>

      {/* Hand Fist Icon when held */}
      {isHeld && (
        <div className="drag-hand-fist">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="#111827">
            <path d="M18.5 7.5c-.83 0-1.5.67-1.5 1.5v.5h-1V7.5c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v2h-1V5.5c0-.83-.67-1.5-1.5-1.5S9 4.67 9 5.5v5h-1V7c0-.83-.67-1.5-1.5-1.5S5 6.17 5 7v7.5c0 3.59 2.91 6.5 6.5 6.5h3.5c3.31 0 6-2.69 6-6V9c0-.83-.67-1.5-1.5-1.5h-1z" />
          </svg>
        </div>
      )}
    </div>
  );
}
