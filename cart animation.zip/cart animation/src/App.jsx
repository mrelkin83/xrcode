import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './index.css';

// SVG Fallback graphics
const SipzyGraphic = ({ id }) => {
  switch (id) {
    case 'lemon-dragon':
      return (
        <svg viewBox="0 0 120 160" className="product-image" xmlns="http://www.w3.org/2000/svg">
          <defs><linearGradient id="can1" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#4d7c0f" /><stop offset="50%" stopColor="#84cc16" /><stop offset="100%" stopColor="#365314" /></linearGradient></defs>
          <rect x="32" y="16" width="56" height="128" rx="8" fill="url(#can1)" stroke="#1a2e05" strokeWidth="1" />
          <path d="M32 22 Q60 26 88 22 L88 18 Q60 14 32 18 Z" fill="#94a3b8" />
          <path d="M32 138 Q60 142 88 138 L88 142 Q60 146 32 142 Z" fill="#94a3b8" />
          <rect x="34" y="38" width="52" height="30" rx="3" fill="#ffffff" />
          <text x="60" y="52" textAnchor="middle" fill="#dc2626" fontSize="11" fontWeight="800">Sipzy</text>
          <text x="60" y="63" textAnchor="middle" fill="#15803d" fontSize="7.5" fontWeight="700">DRINK 1</text>
          <circle cx="60" cy="95" r="16" fill="#facc15" stroke="#ca8a04" strokeWidth="1.5" />
        </svg>
      );
    case 'pubg-king':
      return (
        <svg viewBox="0 0 120 160" className="product-image" xmlns="http://www.w3.org/2000/svg">
          <defs><linearGradient id="can2" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stopColor="#1e1b18" /><stop offset="50%" stopColor="#4a3e26" /><stop offset="100%" stopColor="#1a1612" /></linearGradient></defs>
          <rect x="32" y="16" width="56" height="128" rx="8" fill="url(#can2)" stroke="#0f0e0d" strokeWidth="1" />
          <path d="M32 22 Q60 26 88 22 L88 18 Q60 14 32 18 Z" fill="#f59e0b" />
          <path d="M32 138 Q60 142 88 138 L88 142 Q60 146 32 142 Z" fill="#f59e0b" />
          <text x="60" y="45" textAnchor="middle" fill="#f59e0b" fontSize="12" fontWeight="800">Sipzy</text>
          <text x="60" y="58" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="800">DRINK 2</text>
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 120 160" className="product-image" xmlns="http://www.w3.org/2000/svg">
          <rect x="32" y="16" width="56" height="128" rx="8" fill="#cbd5e1" />
          <text x="60" y="80" textAnchor="middle" fill="#475569" fontSize="12" fontWeight="bold">Sipzy</text>
        </svg>
      );
  }
};

const productsData = [
  {
    id: 'lemon-dragon', title: 'Drink 1', category: 'DRINK', rating: '4.5', reviews: '52', price: '3.99',
    imageUrl: '/lemon_dragon.png',
    fallbackUrl: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'pubg-king', title: 'Drink 2', category: 'DRINK', rating: '4.5', reviews: '159', price: '12.99',
    imageUrl: '/pubg_king.png',
    fallbackUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600&auto=format&fit=crop&q=80'
  }
];

// ─── Product Card ───
const ProductCard = ({ product, onAdd, isFlying }) => {
  const [added, setAdded] = useState(false);
  const [imgSrc, setImgSrc] = useState(product.imageUrl);
  const [imgFailed, setImgFailed] = useState(false);
  const imageRef = useRef(null);

  const handleAddClick = () => {
    setAdded(true);
    if (onAdd) onAdd(product, imageRef.current);
    setTimeout(() => setAdded(false), 1500);
  };

  const handleImageError = () => {
    if (imgSrc !== product.fallbackUrl) setImgSrc(product.fallbackUrl);
    else setImgFailed(true);
  };

  return (
    <div className="product-card">
      <div className="card-image-wrapper">
        {!imgFailed ? (
          <img ref={imageRef} src={imgSrc} alt={product.title} className="product-image" onError={handleImageError} loading="lazy"
            style={{ opacity: isFlying ? 0 : 1, transition: isFlying ? 'opacity 0.08s ease-out' : 'opacity 0.4s ease-in 0.15s' }}
          />
        ) : (
          <div ref={imageRef} style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <SipzyGraphic id={product.id} />
          </div>
        )}
      </div>
      <div className="card-content">
        <div className="product-category">{product.category}</div>
        <h3 className="product-title" title={product.title}>{product.title}</h3>
        <div className="product-rating">
          <div className="stars-row">
            {[...Array(5)].map((_, i) => (
              <svg key={i} xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
            ))}
          </div>
          <span className="rating-number">{product.rating} ({product.reviews})</span>
        </div>
        <div className="card-footer">
          <div className="product-price">${product.price}</div>
          <button type="button" onClick={handleAddClick} className={`add-button ${added ? 'added' : ''}`}>
            {added ? (
              <><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>Added</>
            ) : (
              <><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>Add</>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Delivery Truck Banner with Wind Effect & Green Text (No Background) ───
const DeliveryTruckEffect = ({ isExpanded }) => {
  const [stage, setStage] = useState('driving'); // 'driving' | 'arrived'

  useEffect(() => {
    if (isExpanded) {
      setStage('driving');
      const timer = setTimeout(() => {
        setStage('arrived');
      }, 1250);
      return () => clearTimeout(timer);
    }
  }, [isExpanded]);

  return (
    <div className="delivery-truck-banner">
      {/* Truck driving ALL THE WAY across the entire bar width in one completely continuous straight line with zero middle stopping (`beechmai ni rukti`) and zero up-down (`upar nechai ni hoti`) */}
      <motion.div
        className="truck-svg-wrapper"
        initial={{ x: -40, y: 0 }}
        animate={
          stage === 'driving'
            ? {
              x: [-40, 360], // Exactly 2 values so it never slows/stops in the middle!
              y: 0,          // Zero up and down (`upar nechai ni hoti`)!
              rotate: 0,     // Zero rotation/tilt!
              transition: {
                x: { duration: 1.25, ease: [0.3, 0.0, 0.7, 1.0] }
              }
            }
            : { x: 390, y: 0, rotate: 0, opacity: 0, transition: { duration: 0.3, ease: "easeOut" } }
        }
      >
        {/* Wind lines streaming fast right around the truck during the full-length drive */}
        <AnimatePresence>
          {stage === 'driving' && (
            <motion.div
              className="truck-wind-effect"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.span
                className="wind-line line-1"
                animate={{ x: [-10, -70], opacity: [0, 1, 0], scaleX: [0.6, 2.0, 0.2] }}
                transition={{ duration: 0.24, repeat: Infinity, ease: "linear", delay: 0 }}
              />
              <motion.span
                className="wind-line line-2"
                animate={{ x: [-15, -85], opacity: [0, 0.95, 0], scaleX: [0.5, 2.2, 0.3] }}
                transition={{ duration: 0.28, repeat: Infinity, ease: "linear", delay: 0.08 }}
              />
              <motion.span
                className="wind-line line-3"
                animate={{ x: [-8, -65], opacity: [0, 0.9, 0], scaleX: [0.7, 1.8, 0.3] }}
                transition={{ duration: 0.22, repeat: Infinity, ease: "linear", delay: 0.16 }}
              />
              <motion.span
                className="wind-line line-4"
                animate={{ x: [-12, -80], opacity: [0, 1, 0], scaleX: [0.4, 2.1, 0.2] }}
                transition={{ duration: 0.26, repeat: Infinity, ease: "linear", delay: 0.12 }}
              />
              <motion.span
                className="wind-line line-5"
                animate={{ x: [-6, -58], opacity: [0, 0.85, 0], scaleX: [0.6, 1.7, 0.4] }}
                transition={{ duration: 0.3, repeat: Infinity, ease: "linear", delay: 0.2 }}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* User's exact requested Truck SVG in pure white color */}
        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="icon icon-tabler icons-tabler-outline icon-tabler-truck-delivery truck-icon-white">
          <path stroke="none" d="M0 0h24v24H0z" fill="none" />
          <path d="M5 17a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" />
          <path d="M15 17a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" />
          <path d="M5 17h-2v-4m-1 -8h11v12m-4 0h6m4 0h2v-6h-8m0 -5h5l3 5" />
          <path d="M3 9l4 0" />
        </svg>
      </motion.div>

      {/* Text after drive completes (`us kah baad text aaye`), with ZERO background (`bakcground nahi hona chayia wo khali text hona chayai`) */}
      <div className="truck-banner-text-area">
        <AnimatePresence mode="wait">
          {stage === 'driving' ? (
            <motion.span
              key="driving-msg"
              className="driving-status-text"
              initial={{ opacity: 0, x: 5 }}
              animate={{ opacity: 0.85, x: 0 }}
              exit={{ opacity: 0, x: -5 }}
              transition={{ duration: 0.18 }}
            >
              Checking free delivery eligibility...
            </motion.span>
          ) : stage === 'arrived' ? (
            <motion.div
              key="arrived-msg"
              className="eligible-green-wrapper-nobg"
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ type: "spring", stiffness: 450, damping: 24 }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="green-check-icon">
                <polyline points="20 6 9 17 4 12" />
              </svg>
              {/* `eligile for free delivery green text mai wo khali text hona chayai` */}
              <span className="eligible-green-text-nobg">Eligible for FREE Delivery</span>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>
    </div>
  );
};

// ─── CartDock: ONE component that morphs between collapsed capsule ↔ expanded card ───
const CartDock = ({ items, isWiggling, dockRef, avatarsTargetRef, isExpanded, setIsExpanded }) => {
  if (!items || items.length === 0) return null;

  const displayItems = items.slice(-3).reverse();
  const total = items.reduce((acc, item) => acc + parseFloat(item.price || 0), 0).toFixed(2);

  // Smooth, continuous cubic-bezier curve that never pauses or stalls midway when extending left/right
  const smoothTransition = { duration: 0.38, ease: [0.25, 0.8, 0.25, 1] };

  return (
    <motion.div
      ref={dockRef}
      onClick={() => { if (!isExpanded) setIsExpanded(true); }}
      className="cart-dock-unified"
      style={{ cursor: isExpanded ? 'default' : 'pointer' }}
      initial={{ x: "-50%", bottom: "64px", width: "56px", height: "56px", borderRadius: "28px", opacity: 0, scale: 0.85 }}
      animate={
        isExpanded
          ? {
            x: "-50%",
            bottom: "32px",
            width: "435px",
            height: "445px",
            borderRadius: "28px",
            opacity: 1,
            scale: 1,
            transition: smoothTransition
          }
          : isWiggling
            ? {
              x: "-50%",
              bottom: "64px",
              width: "280px",
              height: "56px",
              borderRadius: "28px",
              opacity: 1,
              scale: [1, 1.06, 0.96, 1.03, 1],
              transition: {
                ...smoothTransition,
                scale: { duration: 0.38, ease: "easeInOut" }
              }
            }
            : {
              x: "-50%",
              bottom: "64px",
              width: "280px",
              height: "56px",
              borderRadius: "28px",
              opacity: 1,
              scale: 1,
              transition: smoothTransition
            }
      }
      exit={{ width: "56px", opacity: 0, scale: 0.85, transition: { duration: 0.25, ease: [0.25, 0.8, 0.25, 1] } }}
      whileHover={
        !isExpanded
          ? { scale: 1.02, transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] } }
          : { scale: 1.006, transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] } }
      }
    >
      <AnimatePresence mode="popLayout">
        {!isExpanded ? (
          /* ─── COLLAPSED CAPSULE CONTENT ─── */
          <motion.div
            key="capsule-content"
            className="capsule-content-relative"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1, transition: { duration: 0.2 } }}
            exit={{ opacity: 0, transition: { duration: 0.15 } }}
          >
            <div ref={avatarsTargetRef} className="dock-avatars-group">
              {displayItems.map((item, idx) => (
                <motion.div
                  key={`${item.id}-${idx}-${items.length}`}
                  initial={{ scale: 0, opacity: 0, rotate: -20 }}
                  animate={{ scale: 1, opacity: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 500, damping: 24, delay: idx === 0 ? 0.05 : 0 }}
                  className="dock-avatar"
                >
                  <img src={item.imageUrl} alt={item.title} />
                </motion.div>
              ))}
            </div>
            <div className="dock-content">
              <span className="dock-title">View cart</span>
              <span className="dock-subtitle">{items.length} {items.length === 1 ? 'Item' : 'Items'}</span>
            </div>
            <div className="dock-arrow-btn">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </div>
          </motion.div>
        ) : (
          /* ─── EXPANDED CARD CONTENT ─── */
          <motion.div
            key="card-content"
            className="card-content-relative"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1, transition: { duration: 0.25, delay: 0.08 } }}
            exit={{ opacity: 0, transition: { duration: 0.15 } }}
          >
            {/* Header */}
            <div className="expanded-header">
              <div className="expanded-header-left">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#e11d48" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" /><path d="M3 6h18" /><path d="M16 10a4 4 0 0 1-8 0" />
                </svg>
                <span className="expanded-header-title">Your Cart</span>
                <span className="expanded-header-badge">{items.length}</span>
              </div>
              <button type="button" className="close-expanded-btn" onClick={(e) => { e.stopPropagation(); setIsExpanded(false); }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            {/* Items */}
            <div className="expanded-items-list">
              {items.map((item, idx) => (
                <motion.div
                  key={`${item.id}-ex-${idx}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.12 + idx * 0.05, duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                  className="expanded-item-row"
                >
                  <div className="expanded-item-img-box">
                    <img src={item.imageUrl} alt={item.title} />
                  </div>
                  <div className="expanded-item-info">
                    <span className="expanded-item-category">{item.category}</span>
                    <span className="expanded-item-name">{item.title}</span>
                  </div>
                  <span className="expanded-item-price">${item.price}</span>
                </motion.div>
              ))}
            </div>

            {/* Delivery Truck Banner right below products (`products kah necha`) */}
            <DeliveryTruckEffect isExpanded={isExpanded} />

            {/* Footer */}
            <div className="expanded-footer">
              <div className="expanded-subtotal">
                <span>Subtotal</span>
                <span className="expanded-subtotal-val">${total}</span>
              </div>
              <button type="button" className="expanded-checkout-btn" onClick={(e) => { e.stopPropagation(); alert(`Checkout — ${items.length} items ($${total})`); }}>
                <span>Proceed to Checkout</span>
                <div className="checkout-btn-right">
                  <span>${total}</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="9 18 15 12 9 6" />
                  </svg>
                </div>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// ─── Main App ───
export default function App() {
  const [cartItems, setCartItems] = useState([]);
  const [isWiggling, setIsWiggling] = useState(false);
  const [flyingItem, setFlyingItem] = useState(null);
  const [isDockVisible, setIsDockVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [flyingProductId, setFlyingProductId] = useState(null);

  const dockRef = useRef(null);
  const avatarsTargetRef = useRef(null);

  const handleAddToCart = useCallback((product, imgElement) => {
    if (flyingItem) return;
    setIsDockVisible(true);
    setFlyingProductId(product.id);
    setIsExpanded(false);

    if (imgElement) {
      const imageRect = imgElement.getBoundingClientRect();
      const startX = imageRect.left;
      const startY = imageRect.top;
      const startW = imageRect.width;
      const startH = imageRect.height;
      const targetRect = avatarsTargetRef.current?.getBoundingClientRect();
      const targetX = targetRect ? targetRect.left + 8 : window.innerWidth / 2 - 130;
      const targetY = targetRect ? targetRect.top + (targetRect.height / 2) - 19 : window.innerHeight - 105;

      setFlyingItem({ imageUrl: product.imageUrl, startX, startY, startW, startH, endX: targetX, endY: targetY });

      setTimeout(() => {
        setFlyingItem(null);
        setFlyingProductId(null);
        setCartItems((prev) => {
          const next = [...prev, product];
          if (prev.length > 0) {
            setIsWiggling(true);
            setTimeout(() => setIsWiggling(false), 450);
          }
          return next;
        });
      }, 900);
    } else {
      setFlyingProductId(null);
      setCartItems((prev) => {
        const next = [...prev, product];
        if (prev.length > 0) {
          setIsWiggling(true);
          setTimeout(() => setIsWiggling(false), 450);
        }
        return next;
      });
    }
  }, [flyingItem]);

  return (
    <div className="app-container">
      <div className="section-header">
        <h2 className="section-title">Popular Products</h2>
      </div>

      <div className="product-grid">
        {productsData.map((product) => (
          <ProductCard key={product.id} product={product} onAdd={handleAddToCart} isFlying={flyingProductId === product.id} />
        ))}
      </div>

      {/* ONE dock element that morphs between capsule ↔ expanded */}
      <AnimatePresence>
        {(isDockVisible || cartItems.length > 0) && (
          <CartDock
            items={cartItems}
            isWiggling={isWiggling}
            dockRef={dockRef}
            avatarsTargetRef={avatarsTargetRef}
            isExpanded={isExpanded}
            setIsExpanded={setIsExpanded}
          />
        )}
      </AnimatePresence>

      {/* Fly to Cart Animation */}
      <AnimatePresence>
        {flyingItem && (
          <motion.img
            src={flyingItem.imageUrl}
            className="flying-product-clone"
            initial={{ x: flyingItem.startX, y: flyingItem.startY, width: flyingItem.startW, height: flyingItem.startH, opacity: 1, scale: 1 }}
            animate={{
              x: flyingItem.endX,
              y: [flyingItem.startY, flyingItem.startY - 80, flyingItem.endY],
              width: 38, height: 38,
              opacity: [1, 1, 0.9, 0],
              scale: [1, 0.7, 0.35],
            }}
            exit={{ opacity: 0 }}
            transition={{
              duration: 0.9,
              x: { duration: 0.9, ease: [0.22, 1, 0.36, 1] },
              y: { duration: 0.9, ease: "easeInOut", times: [0, 0.4, 1] },
              width: { duration: 0.9, ease: "easeInOut" },
              height: { duration: 0.9, ease: "easeInOut" },
              opacity: { duration: 0.9, times: [0, 0.3, 0.7, 1] },
              scale: { duration: 0.9, ease: "easeInOut", times: [0, 0.4, 1] },
            }}
            style={{ top: 0, left: 0 }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
