import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import StatisticCard from './components/StatisticCard';
import GoalsAndSavings from './components/GoalsAndSavings';
import CardsView from './components/CardsView';
import WalletView from './components/WalletView';
import DocumentsView from './components/DocumentsView';
import SettingsView from './components/SettingsView';
import RightSidebar from './components/RightSidebar';
import bgImage from './assets/image.png';
import './App.css';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="dashboard-app-container">
      {/* Background Image Layer */}
      <div 
        className="dashboard-background-image" 
        style={{ backgroundImage: `url(${bgImage})` }} 
      />

      {/* Main Floating Dashboard Workspace with spacing around it */}
      <div className="dashboard-wrapper">
        {/* Floating Left Navigation Capsule */}
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Floating Main Glassmorphic Dashboard Panel */}
        <main className="dashboard-main-glass-panel">
          {/* Ambient Warm Backlight Glow inside Glass */}
          <div className="ambient-backlight-glow" />

          {/* Left / Center Dynamic Content Column based on Active Sidebar Tab */}
          <div className="panel-left-content">
            {activeTab === 'dashboard' && (
              <>
                <Header />
                <StatisticCard />
                <GoalsAndSavings />
              </>
            )}

            {activeTab === 'cards' && <CardsView />}
            {activeTab === 'wallet' && <WalletView />}
            {activeTab === 'documents' && <DocumentsView />}
            {activeTab === 'settings' && <SettingsView />}
          </div>

          {/* Right Content Column */}
          <RightSidebar />
        </main>
      </div>
    </div>
  );
}

export default App;
