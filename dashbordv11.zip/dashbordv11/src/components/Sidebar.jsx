import React from 'react';
import { 
  GridIcon, 
  CreditCardIcon, 
  WalletIcon, 
  DocumentIcon, 
  SettingsIcon, 
  LogoutIcon 
} from './Icons';

export default function Sidebar({ activeTab, setActiveTab }) {
  const navItems = [
    { id: 'dashboard', icon: GridIcon, label: 'Dashboard' },
    { id: 'cards', icon: CreditCardIcon, label: 'Cards' },
    { id: 'wallet', icon: WalletIcon, label: 'Wallet' },
    { id: 'documents', icon: DocumentIcon, label: 'Documents' },
    { id: 'settings', icon: SettingsIcon, label: 'Settings' },
  ];

  return (
    <aside className="floating-sidebar" aria-label="Main Navigation">
      <div className="nav-top-group">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`nav-button ${isActive ? 'active' : ''}`}
              title={item.label}
              aria-label={item.label}
            >
              <Icon size={20} color={isActive ? '#ffffff' : 'rgba(255, 255, 255, 0.65)'} />
            </button>
          );
        })}
      </div>

      <div className="nav-bottom-group">
        <button 
          className="nav-button logout-btn" 
          title="Logout" 
          aria-label="Logout"
          onClick={() => setActiveTab('dashboard')}
        >
          <LogoutIcon size={19} color="rgba(255, 255, 255, 0.55)" />
        </button>
      </div>
    </aside>
  );
}
