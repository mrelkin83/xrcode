import React, { useState } from 'react';

export default function CardsView() {
  const [selectedCard, setSelectedCard] = useState(0);
  const [isFrozen, setIsFrozen] = useState(false);
  const [spendingLimit, setSpendingLimit] = useState(12000);
  const [onlineEnabled, setOnlineEnabled] = useState(true);

  const cardsList = [
    {
      id: 'black-obsidian',
      name: 'Black Obsidian Metal',
      tier: 'World Elite Mastercard',
      number: '•••• •••• •••• 8824',
      balance: '$84,250.00',
      limit: '$150,000',
      expiry: '09/28',
      type: 'mastercard',
      gradient: 'linear-gradient(135deg, rgba(20,22,28,0.95) 0%, rgba(35,39,48,0.85) 100%)',
      glow: 'rgba(255, 255, 255, 0.15)',
    },
    {
      id: 'emerald-platinum',
      name: 'Emerald Corporate',
      tier: 'Platinum Visa Business',
      number: '•••• •••• •••• 4190',
      balance: '$42,800.50',
      limit: '$80,000',
      expiry: '11/27',
      type: 'visa',
      gradient: 'linear-gradient(135deg, rgba(16, 75, 58, 0.9) 0%, rgba(9, 38, 30, 0.95) 100%)',
      glow: 'rgba(38, 194, 129, 0.35)',
    },
    {
      id: 'neon-virtual',
      name: 'Virtual Cyber Card',
      tier: 'Instant Digital Card',
      number: '•••• •••• •••• 9032',
      balance: '$6,450.00',
      limit: '$15,000',
      expiry: '04/29',
      type: 'visa',
      gradient: 'linear-gradient(135deg, rgba(88, 28, 135, 0.88) 0%, rgba(30, 27, 75, 0.95) 100%)',
      glow: 'rgba(168, 85, 247, 0.35)',
    },
  ];

  const currentCard = cardsList[selectedCard];

  const categories = [
    { name: 'Luxury Shopping', amount: '$6,420', percent: 42, color: '#ff7a22' },
    { name: 'Travel & Flights', amount: '$3,850', percent: 25, color: '#2cd5c4' },
    { name: 'Dining & Club', amount: '$2,640', percent: 18, color: '#a855f7' },
    { name: 'Tech & Software', amount: '$2,340', percent: 15, color: '#26c281' },
  ];

  const transactions = [
    { title: 'Apple Store Regent St', cat: 'Electronics', date: 'Today, 2:45 PM', amount: '-$1,299.00', icon: '💻' },
    { title: 'Emirates First Class', cat: 'Travel', date: 'Yesterday, 8:12 PM', amount: '-$4,850.00', icon: '✈️' },
    { title: 'Nobu Restaurant', cat: 'Fine Dining', date: '04 Oct 2026', amount: '-$640.20', icon: '🍸' },
  ];

  return (
    <div className="tab-view-container">
      {/* Header */}
      <div className="dashboard-header">
        <div className="dashboard-title-wrap">
          <h1 className="dashboard-title">
            Cards & Accounts <span className="title-card-icon">💳</span>
          </h1>
        </div>

        <div className="header-metrics-pill">
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Credit Available</span>
              <span className="metric-value">$150,000.00</span>
            </div>
          </div>
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Active Cards</span>
              <span className="metric-value">3 Virtual & Metal</span>
            </div>
          </div>
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Monthly Spent</span>
              <span className="metric-value">$15,250.20</span>
            </div>
          </div>
        </div>
      </div>

      {/* Cards Selection Row */}
      <div className="cards-display-row">
        {cardsList.map((card, idx) => (
          <div
            key={card.id}
            className={`showcase-card ${selectedCard === idx ? 'active-showcase' : ''}`}
            style={{ background: card.gradient, boxShadow: `0 14px 30px ${card.glow}` }}
            onClick={() => setSelectedCard(idx)}
          >
            <div className="showcase-card-top">
              <span className="card-brand-tag">{card.tier}</span>
              <span className="card-logo-tag">{card.type.toUpperCase()}</span>
            </div>
            <div className="showcase-card-mid">
              <span className="showcase-card-num">{card.number}</span>
              <span className="showcase-card-val">{card.balance}</span>
            </div>
            <div className="showcase-card-bot">
              <span className="showcase-card-name">{card.name}</span>
              <span className="showcase-card-exp">{card.expiry}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Card Controls & Analytics Grid */}
      <div className="bottom-sections-grid">
        {/* Left: Card Controls & Security */}
        <div className="statistic-card" style={{ flex: 1 }}>
          <div className="stat-card-top">
            <div>
              <h3 className="stat-card-title">Card Security & Limits</h3>
              <p className="stat-card-subtitle">{currentCard.name} ({currentCard.number.slice(-4)})</p>
            </div>
            <button
              className={`toggle-pill-btn ${isFrozen ? 'frozen' : ''}`}
              onClick={() => setIsFrozen(!isFrozen)}
            >
              {isFrozen ? '❄️ Frozen' : '🛡️ Active'}
            </button>
          </div>

          <div className="control-slider-wrap">
            <div className="slider-label-row">
              <span className="metric-label">Monthly Spending Limit</span>
              <span className="metric-value">${spendingLimit.toLocaleString()}</span>
            </div>
            <input
              type="range"
              min="2000"
              max="50000"
              step="1000"
              value={spendingLimit}
              onChange={(e) => setSpendingLimit(Number(e.target.value))}
              className="glass-range-slider"
            />
          </div>

          <div className="toggle-switches-grid">
            <div className="toggle-switch-item" onClick={() => setOnlineEnabled(!onlineEnabled)}>
              <div>
                <span className="toggle-title">Online Purchases</span>
                <span className="toggle-sub">E-commerce & subscriptions</span>
              </div>
              <span className={`switch-indicator ${onlineEnabled ? 'on' : 'off'}`} />
            </div>

            <div className="toggle-switch-item">
              <div>
                <span className="toggle-title">International Payments</span>
                <span className="toggle-sub">Zero FX conversion fees</span>
              </div>
              <span className="switch-indicator on" />
            </div>
          </div>
        </div>

        {/* Right: Category Spending Analytics */}
        <div className="statistic-card" style={{ flex: 1 }}>
          <div className="stat-card-top">
            <div>
              <h3 className="stat-card-title">Spending by Category</h3>
              <p className="stat-card-subtitle">Current Billing Cycle</p>
            </div>
            <span className="savings-growth-badge">↑ 12.4% vs last mo</span>
          </div>

          <div className="categories-breakdown-list">
            {categories.map((cat) => (
              <div key={cat.name} className="cat-breakdown-item">
                <div className="cat-info-row">
                  <span className="cat-name">{cat.name}</span>
                  <span className="cat-amount">{cat.amount}</span>
                </div>
                <div className="goal-progress-bar">
                  <div
                    className="goal-progress-fill"
                    style={{ width: `${cat.percent}%`, background: cat.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Card Transactions */}
      <div className="recent-card-tx-section">
        <h3 className="section-title">Recent Card Activity</h3>
        <div className="tx-list-horizontal">
          {transactions.map((tx, idx) => (
            <div key={idx} className="transaction-item-card" style={{ flex: 1 }}>
              <div className="tx-emoji-icon">{tx.icon}</div>
              <div className="transaction-details">
                <span className="sender-name">{tx.title}</span>
                <span className="transaction-timestamp">{tx.cat} • {tx.date}</span>
              </div>
              <div className="transaction-amount-wrap">
                <span className="amount-badge" style={{ color: '#ff6262', background: 'rgba(255, 98, 98, 0.15)' }}>
                  {tx.amount}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

