import React from 'react';

export default function GoalsAndSavings() {
  const goals = [
    {
      id: 'house',
      percent: '78%',
      progress: 78,
      title: 'Build a House',
      watermarkIcon: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
          <polyline points="9 22 9 12 15 12 15 22" />
        </svg>
      )
    },
    {
      id: 'wedding',
      percent: '97%',
      progress: 97,
      title: 'Wedding savings',
      watermarkIcon: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <circle cx="9" cy="12" r="6" />
          <circle cx="15" cy="12" r="6" />
        </svg>
      )
    }
  ];

  const bars = [
    { month: 'Feb', height: '38%' },
    { month: 'Mar', height: '68%' },
    { month: 'Apr', height: '94%' },
  ];

  return (
    <div className="bottom-sections-grid">
      {/* Goals Column */}
      <div className="goals-section">
        <div className="goals-header">
          <h2 className="section-title">Goals</h2>
          <button className="add-goals-btn" title="Add Goal">
            Add Goals +
          </button>
        </div>

        <div className="goals-cards-row">
          {goals.map((goal) => (
            <div key={goal.id} className="goal-card">
              <div className="goal-watermark">{goal.watermarkIcon}</div>
              <div className="goal-percentage">{goal.percent}</div>
              
              <div className="goal-progress-bar">
                <div 
                  className="goal-progress-fill" 
                  style={{ width: `${goal.progress}%` }} 
                />
              </div>

              <div className="goal-title">{goal.title}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Other Savings Column */}
      <div className="other-savings-section">
        <div className="other-savings-header">
          <h2 className="section-title">Other Savings</h2>
        </div>

        <div className="savings-card">
          <div className="savings-info">
            <span className="savings-label">Bussiness Savings</span>
            <div className="savings-amount">
              <span className="currency-symbol">$</span>
              <span className="amount-number">439,283.0</span>
            </div>
            <div className="savings-growth-badge">
              <span className="arrow-up">↑</span>
              <span>49.3%</span>
            </div>
          </div>

          <div className="savings-bar-chart">
            <div className="bars-wrap">
              {bars.map((bar) => (
                <div key={bar.month} className="bar-column">
                  <div className="bar-track">
                    <div 
                      className="bar-fill" 
                      style={{ height: bar.height }} 
                    />
                  </div>
                  <span className="bar-label">{bar.month}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

