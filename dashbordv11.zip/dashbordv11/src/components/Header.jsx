import React from 'react';
import { CoinIcon, BriefcaseIcon, CashIcon } from './Icons';

export default function Header() {
  const metrics = [
    {
      id: 'balance',
      icon: CoinIcon,
      label: 'Total Balance',
      value: '$678,993.98',
    },
    {
      id: 'earnings',
      icon: BriefcaseIcon,
      label: 'Earnings',
      value: '$998,993.98',
    },
    {
      id: 'expenses',
      icon: CashIcon,
      label: 'Expenses',
      value: '$28,993.98',
    },
  ];

  return (
    <header className="dashboard-header">
      <div className="dashboard-title-wrap">
        <h1 className="dashboard-title">
          My Dashboard <span className="title-card-icon" role="img" aria-label="card">💳</span>
        </h1>
      </div>

      <div className="header-metrics-pill">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <div key={metric.id} className="header-metric-item">
              <div className="metric-icon-circle">
                <Icon size={13} color="rgba(255, 255, 255, 0.75)" />
              </div>
              <div className="metric-info">
                <span className="metric-label">{metric.label}</span>
                <span className="metric-value">{metric.value}</span>
              </div>
            </div>
          );
        })}
      </div>
    </header>
  );
}

