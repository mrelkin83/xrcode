import React, { useState } from 'react';
import { ChevronDownIcon } from './Icons';

export default function StatisticCard() {
  const [selectedFilter, setSelectedFilter] = useState('All Transaction');
  const [showDropdown, setShowDropdown] = useState(false);
  const [activeLegend, setActiveLegend] = useState('all');

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];

  return (
    <div className="statistic-section">
      <div className="statistic-header">
        <h2 className="section-title">Statistic</h2>
        <div className="dropdown-container">
          <button 
            className="filter-pill-btn" 
            onClick={() => setShowDropdown(!showDropdown)}
            aria-label="Filter transactions"
          >
            <span>{selectedFilter}</span>
            <ChevronDownIcon size={12} color="#9498a5" />
          </button>
          {showDropdown && (
            <div className="dropdown-menu">
              {['All Transaction', 'Monthly', 'Weekly', 'Yearly'].map((option) => (
                <div
                  key={option}
                  className={`dropdown-item ${selectedFilter === option ? 'selected' : ''}`}
                  onClick={() => {
                    setSelectedFilter(option);
                    setShowDropdown(false);
                  }}
                >
                  {option}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="statistic-card">
        {/* Ambient background glow inside the card */}
        <div className="statistic-card-glow" />

        <div className="stat-card-top">
          <div className="stat-card-headings">
            <h3 className="stat-card-title">Top Contributor</h3>
            <p className="stat-card-subtitle">Top half-year Earning and Expenses source</p>
          </div>

          <div className="stat-card-legend">
            <button 
              className={`legend-item ${activeLegend === 'groceries' ? 'active' : ''}`}
              onClick={() => setActiveLegend(activeLegend === 'groceries' ? 'all' : 'groceries')}
            >
              <span className="legend-dot cyan" />
              <span>Groceries</span>
            </button>
            <button 
              className={`legend-item ${activeLegend === 'corporate' ? 'active' : ''}`}
              onClick={() => setActiveLegend(activeLegend === 'corporate' ? 'all' : 'corporate')}
            >
              <span className="legend-dot green" />
              <span>Invest Corporate</span>
            </button>
            <button 
              className={`legend-item ${activeLegend === 'hobbies' ? 'active' : ''}`}
              onClick={() => setActiveLegend(activeLegend === 'hobbies' ? 'all' : 'hobbies')}
            >
              <span className="legend-dot orange" />
              <span>Hobbies</span>
            </button>
          </div>
        </div>

        {/* SVG Curve Chart */}
        <div className="chart-container">
          {/* Tooltip Card over March point */}
          <div className="chart-tooltip-pin">
            <div className="tooltip-bubble">
              <div className="tooltip-badge">GC</div>
              <div className="tooltip-text">
                <span className="tooltip-label">Groceries</span>
                <span className="tooltip-amount">$45,89</span>
              </div>
            </div>
            {/* Guide line down to the point */}
            <div className="tooltip-line" />
            <div className="tooltip-dot" />
          </div>

          <svg 
            className="chart-svg" 
            viewBox="0 0 620 160" 
            preserveAspectRatio="none"
          >
            <defs>
              <linearGradient id="orangeGlowLine" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ff7a22" />
                <stop offset="50%" stopColor="#ff6219" />
                <stop offset="100%" stopColor="#ff8a38" />
              </linearGradient>

              <filter id="orangeShadow" x="-10%" y="-20%" width="120%" height="150%">
                <feDropShadow dx="0" dy="5" stdDeviation="6" floodColor="#ff7322" floodOpacity="0.45" />
              </filter>
            </defs>

            {/* Dotted vertical reference line at March (x = 248) */}
            <line 
              x1="248" 
              y1="40" 
              x2="248" 
              y2="155" 
              stroke="rgba(255, 255, 255, 0.2)" 
              strokeDasharray="4 4" 
              strokeWidth="1.2"
            />

            {/* Secondary line (Light silver / translucent white curve) */}
            <path
              d="M 20 115 C 65 110, 85 130, 134 125 C 180 120, 205 85, 248 102 C 295 120, 320 85, 362 72 C 405 60, 440 100, 476 112 C 520 125, 560 95, 600 112"
              fill="none"
              stroke="rgba(255, 255, 255, 0.48)"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Main Primary Glowing Orange Line */}
            <path
              d="M 20 110 C 65 115, 80 135, 134 135 C 185 135, 210 75, 248 76 C 290 77, 315 132, 362 130 C 410 128, 440 68, 476 68 C 515 68, 555 105, 600 95"
              fill="none"
              stroke="url(#orangeGlowLine)"
              strokeWidth="2.8"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#orangeShadow)"
            />

            {/* Active marker dot on orange curve at March (248, 76) */}
            <circle cx="248" cy="76" r="4.5" fill="#ffffff" stroke="#ff7322" strokeWidth="2.5" />
          </svg>

          {/* X-Axis Month Labels */}
          <div className="chart-x-axis">
            {months.map((month) => (
              <span key={month} className={`x-label ${month === 'Mar' ? 'highlight' : ''}`}>
                {month}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

