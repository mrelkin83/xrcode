import React, { useState } from 'react';

export default function SettingsView() {
  const [twoFactor, setTwoFactor] = useState(true);
  const [biometrics, setBiometrics] = useState(true);
  const [smsAlerts, setSmsAlerts] = useState(true);
  const [currency, setCurrency] = useState('USD');
  const [glassIntensity, setGlassIntensity] = useState(85);

  return (
    <div className="tab-view-container">
      {/* Header */}
      <div className="dashboard-header">
        <div className="dashboard-title-wrap">
          <h1 className="dashboard-title">
            Account Settings <span className="title-card-icon">⚙️</span>
          </h1>
        </div>

        <div className="header-metrics-pill">
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Security Health</span>
              <span className="metric-value" style={{ color: '#26c281' }}>98/100 Excellent</span>
            </div>
          </div>
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">KYC Verification</span>
              <span className="metric-value">Tier 3 Unlimited</span>
            </div>
          </div>
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Connected Devices</span>
              <span className="metric-value">MacBook Pro & iPhone</span>
            </div>
          </div>
        </div>
      </div>

      {/* Settings Grid */}
      <div className="bottom-sections-grid">
        {/* Security & Authentication */}
        <div className="statistic-card" style={{ flex: 1 }}>
          <div className="stat-card-top">
            <div>
              <h3 className="stat-card-title">Security & Access Control</h3>
              <p className="stat-card-subtitle">Manage multi-factor keys and biometric authentication</p>
            </div>
          </div>

          <div className="toggle-switches-grid">
            <div className="toggle-switch-item" onClick={() => setTwoFactor(!twoFactor)}>
              <div>
                <span className="toggle-title">Two-Factor Authentication (2FA)</span>
                <span className="toggle-sub">Authenticator App / Hardware YubiKey</span>
              </div>
              <span className={`switch-indicator ${twoFactor ? 'on' : 'off'}`} />
            </div>

            <div className="toggle-switch-item" onClick={() => setBiometrics(!biometrics)}>
              <div>
                <span className="toggle-title">Biometric TouchID / FaceID</span>
                <span className="toggle-sub">Instant zero-friction authorization</span>
              </div>
              <span className={`switch-indicator ${biometrics ? 'on' : 'off'}`} />
            </div>

            <div className="toggle-switch-item" onClick={() => setSmsAlerts(!smsAlerts)}>
              <div>
                <span className="toggle-title">Instant Transaction Alerts</span>
                <span className="toggle-sub">Real-time alerts on wire transfers &gt; $500</span>
              </div>
              <span className={`switch-indicator ${smsAlerts ? 'on' : 'off'}`} />
            </div>
          </div>
        </div>

        {/* Preferences & System Display */}
        <div className="statistic-card" style={{ flex: 1 }}>
          <div className="stat-card-top">
            <div>
              <h3 className="stat-card-title">Preferences & Regional</h3>
              <p className="stat-card-subtitle">Custom currency and interface display settings</p>
            </div>
          </div>

          <div className="control-slider-wrap">
            <div className="slider-label-row">
              <span className="metric-label">Glassmorphic Blur Intensity</span>
              <span className="metric-value">{glassIntensity}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="100"
              value={glassIntensity}
              onChange={(e) => setGlassIntensity(Number(e.target.value))}
              className="glass-range-slider"
            />
          </div>

          <div className="settings-field-group">
            <span className="metric-label">Default Base Currency</span>
            <div className="currency-selector-row">
              {['USD ($)', 'EUR (€)', 'GBP (£)', 'AED (د.إ)'].map((curr) => (
                <button
                  key={curr}
                  className={`filter-pill-btn ${currency === curr.slice(0, 3) ? 'active' : ''}`}
                  onClick={() => setCurrency(curr.slice(0, 3))}
                  style={{
                    background: currency === curr.slice(0, 3) ? 'linear-gradient(135deg, #ff7a22, #ee5300)' : 'rgba(255,255,255,0.08)',
                    color: '#fff',
                  }}
                >
                  {curr}
                </button>
              ))}
            </div>
          </div>

          <button className="nav-button active" style={{ width: '100%', borderRadius: '14px', marginTop: '16px' }}>
            Save Preferences
          </button>
        </div>
      </div>
    </div>
  );
}

