import React, { useState } from 'react';
import { 
  BellIcon, 
  MoreVerticalIcon, 
  TransferIcon, 
  ReceiveIcon, 
  BillIcon, 
  TopUpIcon, 
  ArrowRightIcon,
  ContactlessIcon 
} from './Icons';
import userAvatar from '../assets/avatar_user.png';
import gojoAvatar from '../assets/avatar_gojo.png';
import visaCardImg from '../assets/visa_card.png';

export default function RightSidebar() {
  const [activeAction, setActiveAction] = useState(null);

  const actionButtons = [
    { id: 'transfer', label: 'Transfer', icon: TransferIcon },
    { id: 'receive', label: 'Receive', icon: ReceiveIcon },
    { id: 'bill', label: 'Bill', icon: BillIcon },
    { id: 'topup', label: 'Top Up', icon: TopUpIcon },
  ];

  return (
    <aside className="right-panel" aria-label="Account Overview">
      {/* Top Header Icons */}
      <div className="right-panel-header">
        <button className="glass-icon-btn notif-btn" aria-label="Notifications">
          <BellIcon size={17} color="rgba(255, 255, 255, 0.85)" />
          <span className="red-notification-dot" />
        </button>

        <button className="glass-icon-btn more-btn" aria-label="More options">
          <MoreVerticalIcon size={17} color="rgba(255, 255, 255, 0.7)" />
        </button>
      </div>

      {/* User Profile */}
      <div className="user-profile-section">
        <div className="avatar-wrapper">
          <img 
            src={userAvatar} 
            alt="Rizasyah Somadudin" 
            className="user-avatar-img"
          />
        </div>
        <span className="user-tier-tag">Exlusive Card</span>
        <h3 className="user-full-name">Rizasyah Somadudin</h3>
      </div>

      {/* Quick Action Buttons */}
      <div className="action-buttons-grid">
        {actionButtons.map((btn) => {
          const Icon = btn.icon;
          const isCurrent = activeAction === btn.id;
          return (
            <div 
              key={btn.id} 
              className={`action-btn-item ${isCurrent ? 'active' : ''}`}
              onClick={() => setActiveAction(btn.id)}
            >
              <button className="action-circle-btn" aria-label={btn.label}>
                <Icon size={19} color="#ffffff" />
              </button>
              <span className="action-btn-label">{btn.label}</span>
            </div>
          );
        })}
      </div>

      {/* VISA Card Section */}
      <div className="credit-card-container">
        {/* Underlay card layer */}
        <div className="card-underlay-layer" />

        {/* Primary Glassy/Fiery VISA Card */}
        <div className="premium-visa-card">
          {/* Card background texture */}
          <div 
            className="visa-card-bg-img" 
            style={{ backgroundImage: `url(${visaCardImg})` }}
          />

          {/* Top Row: VISA wordmark & EMV chip + contactless */}
          <div className="card-top-row">
            <span className="visa-logo">VISA</span>
            <div className="card-chip-wrap">
              <div className="emv-gold-chip">
                <div className="chip-line horizontal" />
                <div className="chip-line vertical" />
                <div className="chip-core" />
              </div>
              <ContactlessIcon size={17} color="rgba(255, 255, 255, 0.85)" />
            </div>
          </div>

          {/* Card Details: Balance & Expiry */}
          <div className="card-bottom-row">
            <div className="card-balance-info">
              <span className="card-balance-title">Total Balance</span>
              <div className="card-balance-value">$675,989.0</div>
            </div>

            <div className="card-expiry-info">
              <span className="card-expiry-title">Expired</span>
              <span className="card-expiry-value">07/23</span>
            </div>
          </div>
        </div>
      </div>

      {/* Last Transaction Section */}
      <div className="last-transaction-section">
        <h4 className="transaction-section-title">Last Transaction</h4>

        <div className="transaction-item-card">
          <div className="transaction-avatar-wrap">
            <img 
              src={gojoAvatar} 
              alt="Gojo Ackerman" 
              className="transaction-avatar-img"
            />
          </div>

          <div className="transaction-details">
            <span className="sender-name">Gojo Ackerman</span>
            <span className="transaction-timestamp">02.03.2022 12:02 AM</span>
          </div>

          <div className="transaction-amount-wrap">
            <div className="amount-badge">+ $900</div>
            <span className="transaction-category">
              Bonus salary <span className="clock-symbol">⏱</span>
            </span>
          </div>
        </div>

        <button className="see-all-transactions-btn">
          <span>See all transactions</span>
          <ArrowRightIcon size={15} color="#b4b6c2" />
        </button>
      </div>
    </aside>
  );
}

