import React, { useState } from 'react';

export default function WalletView() {
  const [swapAmount, setSwapAmount] = useState('5000');
  const [fromAsset, setFromAsset] = useState('USD');
  const [toAsset, setToAsset] = useState('BTC');

  const assets = [
    { name: 'Bitcoin', symbol: 'BTC', balance: '4.65 BTC', val: '$420,000.00', change: '+5.8%', icon: '₿', color: '#ff7a22' },
    { name: 'Ethereum', symbol: 'ETH', balance: '52.1 ETH', val: '$185,000.00', change: '+3.2%', icon: 'Ξ', color: '#627eea' },
    { name: 'Solana', symbol: 'SOL', balance: '410.0 SOL', val: '$68,400.00', change: '+8.7%', icon: '◎', color: '#14f195' },
    { name: 'USD Treasury', symbol: 'USD', balance: '$755,590', val: '$755,590.00', change: '+0.1%', icon: '$', color: '#2cd5c4' },
  ];

  return (
    <div className="tab-view-container">
      {/* Header */}
      <div className="dashboard-header">
        <div className="dashboard-title-wrap">
          <h1 className="dashboard-title">
            Wallets & Portfolio <span className="title-card-icon">🪙</span>
          </h1>
        </div>

        <div className="header-metrics-pill">
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Total Portfolio</span>
              <span className="metric-value">$1,428,990.00</span>
            </div>
          </div>
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">24h Gain</span>
              <span className="metric-value" style={{ color: '#26c281' }}>+$14,280 (+3.2%)</span>
            </div>
          </div>
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Staking APY</span>
              <span className="metric-value">8.4% Fixed</span>
            </div>
          </div>
        </div>
      </div>

      {/* Asset Cards Grid */}
      <div className="asset-cards-grid">
        {assets.map((asset) => (
          <div key={asset.symbol} className="goal-card asset-pill-card">
            <div className="asset-top-row">
              <div className="asset-icon-circle" style={{ color: asset.color, borderColor: asset.color }}>
                {asset.icon}
              </div>
              <span className="savings-growth-badge" style={{ color: '#26c281', background: 'rgba(38,194,129,0.15)' }}>
                {asset.change}
              </span>
            </div>
            <div className="asset-mid-info">
              <span className="asset-name-tag">{asset.name}</span>
              <span className="asset-val-big">{asset.val}</span>
              <span className="asset-holding-sub">{asset.balance}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Chart & Quick Swap Row */}
      <div className="bottom-sections-grid">
        {/* Left: Portfolio Growth Chart */}
        <div className="statistic-card" style={{ flex: 1.2 }}>
          <div className="stat-card-top">
            <div>
              <h3 className="stat-card-title">Portfolio Capital Growth</h3>
              <p className="stat-card-subtitle">Cumulative Return (Last 6 Months)</p>
            </div>
            <div className="savings-growth-badge">↑ 34.8% YTD</div>
          </div>

          <div className="chart-container">
            <svg className="chart-svg" viewBox="0 0 620 150" preserveAspectRatio="none">
              <defs>
                <linearGradient id="walletAreaGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2cd5c4" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#2cd5c4" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              <path
                d="M 10 120 C 80 110, 140 85, 210 90 C 280 95, 340 50, 420 55 C 490 60, 540 25, 610 20 L 610 150 L 10 150 Z"
                fill="url(#walletAreaGlow)"
              />
              <path
                d="M 10 120 C 80 110, 140 85, 210 90 C 280 95, 340 50, 420 55 C 490 60, 540 25, 610 20"
                fill="none"
                stroke="#2cd5c4"
                strokeWidth="3"
                strokeLinecap="round"
              />
              <circle cx="610" cy="20" r="5" fill="#ffffff" stroke="#2cd5c4" strokeWidth="3" />
            </svg>
            <div className="chart-x-axis">
              {['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'].map((m) => (
                <span key={m} className="x-label">{m}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Instant Crypto / Fiat Swap */}
        <div className="statistic-card" style={{ flex: 0.8 }}>
          <div className="stat-card-top">
            <div>
              <h3 className="stat-card-title">Instant Swap</h3>
              <p className="stat-card-subtitle">Zero Slippage Guarantee</p>
            </div>
            <span className="legend-dot cyan" />
          </div>

          <div className="swap-input-group">
            <div className="swap-box">
              <span className="metric-label">You Pay</span>
              <div className="swap-input-row">
                <input
                  type="text"
                  value={swapAmount}
                  onChange={(e) => setSwapAmount(e.target.value)}
                  className="swap-numeric-input"
                />
                <select value={fromAsset} onChange={(e) => setFromAsset(e.target.value)} className="swap-select">
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                  <option value="BTC">BTC</option>
                </select>
              </div>
            </div>

            <div className="swap-divider-icon">⇅</div>

            <div className="swap-box">
              <span className="metric-label">You Receive (Est.)</span>
              <div className="swap-input-row">
                <span className="swap-numeric-output">
                  {(Number(swapAmount || 0) / 92000).toFixed(4)}
                </span>
                <select value={toAsset} onChange={(e) => setToAsset(e.target.value)} className="swap-select">
                  <option value="BTC">BTC</option>
                  <option value="ETH">ETH</option>
                  <option value="SOL">SOL</option>
                </select>
              </div>
            </div>

            <button className="nav-button active" style={{ width: '100%', borderRadius: '14px', marginTop: '12px' }}>
              Confirm Instant Exchange
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

