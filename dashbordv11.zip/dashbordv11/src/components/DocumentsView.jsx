import React, { useState } from 'react';

export default function DocumentsView() {
  const [filter, setFilter] = useState('all');

  const docs = [
    { id: 1, title: 'Q3 Corporate Tax Return 2026', type: 'tax', date: '04 Oct 2026', size: '4.8 MB', status: 'Approved', amount: '$32,400' },
    { id: 2, title: 'Monthly Statement - Sep 2026', type: 'statement', date: '01 Oct 2026', size: '2.1 MB', status: 'Verified', amount: '$168,900' },
    { id: 3, title: 'AWS Cloud Architecture Invoice', type: 'invoice', date: '28 Sep 2026', size: '840 KB', status: 'Paid', amount: '$4,850' },
    { id: 4, title: 'Stripe Merchant Payout Receipt', type: 'statement', date: '25 Sep 2026', size: '1.2 MB', status: 'Cleared', amount: '$54,200' },
    { id: 5, title: 'Commercial Office Lease London', type: 'invoice', date: '15 Sep 2026', size: '3.4 MB', status: 'Paid', amount: '$8,500' },
  ];

  const filteredDocs = filter === 'all' ? docs : docs.filter((d) => d.type === filter);

  return (
    <div className="tab-view-container">
      {/* Header */}
      <div className="dashboard-header">
        <div className="dashboard-title-wrap">
          <h1 className="dashboard-title">
            Documents & Statements <span className="title-card-icon">📑</span>
          </h1>
        </div>

        <div className="header-metrics-pill">
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Invoices Cleared</span>
              <span className="metric-value">$268,850.00</span>
            </div>
          </div>
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Tax Deductible</span>
              <span className="metric-value">$42,300.00</span>
            </div>
          </div>
          <div className="header-metric-item">
            <div className="metric-info">
              <span className="metric-label">Audited Records</span>
              <span className="metric-value">100% Verified</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs Row */}
      <div className="doc-filter-tabs">
        {[
          { id: 'all', label: 'All Documents' },
          { id: 'tax', label: 'Tax Filings' },
          { id: 'statement', label: 'Bank Statements' },
          { id: 'invoice', label: 'Expense Invoices' },
        ].map((tab) => (
          <button
            key={tab.id}
            className={`filter-pill-btn ${filter === tab.id ? 'active' : ''}`}
            onClick={() => setFilter(tab.id)}
            style={{
              background: filter === tab.id ? 'linear-gradient(135deg, #ff7a22, #ee5300)' : 'rgba(255,255,255,0.08)',
              color: '#ffffff',
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Documents List Card */}
      <div className="statistic-card" style={{ flex: 1 }}>
        <div className="stat-card-top">
          <div>
            <h3 className="stat-card-title">Audit Trail & Digital Records</h3>
            <p className="stat-card-subtitle">Encrypted PDF & CSV Exports with cryptographic signatures</p>
          </div>
          <button className="add-goals-btn" style={{ color: '#2cd5c4' }}>
            + Upload New Document
          </button>
        </div>

        <div className="docs-table-list">
          {filteredDocs.map((doc) => (
            <div key={doc.id} className="doc-row-item">
              <div className="doc-icon-badge">📄</div>

              <div className="doc-name-col">
                <span className="sender-name">{doc.title}</span>
                <span className="transaction-timestamp">{doc.date} • {doc.size}</span>
              </div>

              <span className="savings-growth-badge" style={{ color: '#26c281', background: 'rgba(38, 194, 129, 0.15)' }}>
                {doc.status}
              </span>

              <span className="amount-number" style={{ fontSize: '15px' }}>{doc.amount}</span>

              <button className="glass-icon-btn" title="Download Document">
                📥
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

