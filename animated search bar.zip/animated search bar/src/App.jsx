import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Loader2 } from 'lucide-react';
import './index.css';

const MOCK_PRODUCTS = [
  { id: 1, name: 'Minimalist Hoodie', price: '$89', category: 'Apparel', img: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=400&h=500' },
  { id: 2, name: 'Classic White Tee', price: '$35', category: 'Apparel', img: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&q=80&w=400&h=500' },
  { id: 3, name: 'Canvas Sneakers', price: '$120', category: 'Footwear', img: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&q=80&w=400&h=500' },
  { id: 4, name: 'Wool Beanie', price: '$45', category: 'Accessories', img: 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?auto=format&fit=crop&q=80&w=400&h=500' },
  { id: 5, name: 'Leather Tote', price: '$195', category: 'Accessories', img: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&q=80&w=400&h=500' },
  { id: 6, name: 'Denim Jacket', price: '$150', category: 'Apparel', img: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?auto=format&fit=crop&q=80&w=400&h=500' }
];

export default function App() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [portalCenter, setPortalCenter] = useState({ x: 0, y: 0 });
  const inputRef = useRef(null);
  const searchBarRef = useRef(null);
  const gridRef = useRef(null);
  const [cardTargets, setCardTargets] = useState([]);
  const [animateCards, setAnimateCards] = useState(false);

  useEffect(() => {
    if (isExpanded && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isExpanded]);

  // Calculate where each card needs to fly to
  const calculateTargets = useCallback(() => {
    if (!gridRef.current || !searchBarRef.current) return;

    const searchRect = searchBarRef.current.getBoundingClientRect();
    const centerX = searchRect.left + searchRect.width / 2;
    const centerY = searchRect.top + searchRect.height / 2;

    setPortalCenter({ x: centerX, y: centerY });

    const cardEls = gridRef.current.querySelectorAll('[data-card]');
    const targets = [];
    cardEls.forEach((el) => {
      const rect = el.getBoundingClientRect();
      targets.push({
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
        w: rect.width,
        h: rect.height,
      });
    });
    setCardTargets(targets);
  }, []);

  const handleExpand = () => {
    if (!isExpanded) {
      setIsExpanded(true);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && query.trim() !== '') {
      setIsSearching(true);
      setShowResults(false);
      setAnimateCards(false);

      setTimeout(() => {
        setIsSearching(false);
        setShowResults(true);

        // Wait for grid to render so we can measure positions
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            calculateTargets();
            setAnimateCards(true);
          });
        });
      }, 1500);
    }
  };

  const handleBlur = () => {
    if (query === '' && !showResults) {
      setIsExpanded(false);
    }
  };

  return (
    <div style={{ position: 'relative', width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 120 }}>

      {/* Search Bar Container */}
      <motion.div
        ref={searchBarRef}
        layout
        style={{
          position: 'relative',
          zIndex: 50,
          borderRadius: 32,
          boxShadow: isSearching
            ? '0 20px 40px rgba(255, 127, 80, 0.15), 0 0 40px rgba(255, 127, 80, 0.1)'
            : '0 0 0 1px rgba(0,0,0,0.04), 0 12px 30px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,1)',
          display: 'flex',
          alignItems: 'center',
          overflow: 'hidden',
          transition: 'box-shadow 0.4s ease'
        }}
        initial={{ width: 64, height: 64 }}
        animate={{
          width: isExpanded ? 500 : 64,
          height: 64
        }}
        transition={
          isExpanded
            ? { type: 'spring', stiffness: 150, damping: 10, mass: 1 }
            : { type: 'tween', duration: 0.3, ease: 'easeOut' }
        }
        onClick={handleExpand}
      >
        {/* Rotating Premium Glow Background */}
        <AnimatePresence>
          {isSearching && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              style={{
                position: 'absolute',
                top: '-50%',
                left: '-50%',
                right: '-50%',
                bottom: '-50%',
                background: 'conic-gradient(from 0deg, #FF7F50, #FF3366, #9933FF, #00C9FF, #FF7F50)',
                animation: 'spin 2s linear infinite',
                filter: 'blur(12px)',
                zIndex: 0
              }}
            />
          )}
        </AnimatePresence>

        {/* Inner Search Background */}
        <div
          style={{
            position: 'absolute',
            inset: isSearching ? 2 : 0,
            background: 'rgba(255, 255, 255, 0.95)',
            backdropFilter: 'blur(24px)',
            WebkitBackdropFilter: 'blur(24px)',
            borderRadius: isSearching ? 30 : 32,
            zIndex: 1,
            transition: 'inset 0.3s ease, border-radius 0.3s ease',
          }}
        />

        {/* Content Container */}
        <div style={{ position: 'relative', zIndex: 2, display: 'flex', width: 500, height: '100%', alignItems: 'center' }}>
          <div style={{ width: 64, height: 64, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: '#86868b' }}>
            <AnimatePresence mode="wait">
              {isSearching ? (
                <motion.div
                  key="loader"
                  initial={{ opacity: 0, scale: 0.5, rotate: -90 }}
                  animate={{ opacity: 1, scale: 1, rotate: 0 }}
                  exit={{ opacity: 0, scale: 0.5, rotate: 90 }}
                  transition={{ duration: 0.2 }}
                >
                  <Loader2 size={24} style={{ animation: 'spin 1s linear infinite' }} />
                </motion.div>
              ) : (
                <motion.div
                  key="search"
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.5 }}
                  transition={{ duration: 0.2 }}
                >
                  <Search size={24} color={isExpanded ? '#1d1d1f' : '#86868b'} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <AnimatePresence>
            {isExpanded && (
              <motion.input
                ref={inputRef}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10, transition: { duration: 0.1 } }}
                transition={{ delay: 0.1, duration: 0.3 }}
                style={{
                  border: 'none',
                  background: 'transparent',
                  height: '100%',
                  width: '100%',
                  fontSize: 20,
                  color: '#1d1d1f',
                  paddingRight: 24,
                  fontWeight: 400,
                  fontFamily: 'inherit'
                }}
                placeholder="Search products..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                onBlur={handleBlur}
                disabled={isSearching}
              />
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>

      {/* Hidden measurement grid — renders invisibly to measure final card positions */}
      {showResults && (
        <div
          ref={gridRef}
          style={{
            position: 'absolute',
            top: 32,
            width: '100%',
            maxWidth: 860,
            paddingTop: 80,
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
            gap: 24,
            visibility: 'hidden',
            pointerEvents: 'none',
            zIndex: -1,
          }}
        >
          {MOCK_PRODUCTS.map((p) => (
            <div key={p.id} data-card style={{ height: 320, borderRadius: 20 }} />
          ))}
        </div>
      )}

      {/* Animated flying cards — positioned via fixed overlay, fly from search bar center */}
      <AnimatePresence>
        {showResults && animateCards && cardTargets.length > 0 && (
          <>
            {MOCK_PRODUCTS.map((product, i) => {
              const target = cardTargets[i];
              if (!target) return null;
              return (
                <FlyingCard
                  key={product.id}
                  product={product}
                  index={i}
                  portalCenter={portalCenter}
                  target={target}
                />
              );
            })}
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function FlyingCard({ product, index, portalCenter, target }) {
  const cardW = target.w;
  const cardH = target.h;

  return (
    <motion.div
      initial={{
        position: 'fixed',
        left: portalCenter.x - cardW / 2,
        top: portalCenter.y - cardH / 2,
        width: cardW,
        height: cardH,
        opacity: 0,
        scale: 0,
        rotateZ: index % 2 === 0 ? -12 : 12,
        rotateX: 45,
        filter: 'blur(12px)',
        zIndex: 100 - index, // IN FRONT of the search bar
      }}
      animate={{
        left: target.x - cardW / 2,
        top: [
          portalCenter.y - cardH / 2,
          portalCenter.y - cardH / 2 - 180, // pop UP 180px
          target.y - cardH / 2
        ],
        opacity: [0, 1, 1],
        scale: [0, 0.25, 1], // Burst to 25% size quickly, then grow to 100%
        rotateZ: 0,
        rotateX: 0,
        filter: 'blur(0px)',
      }}
      exit={{
        left: portalCenter.x - cardW / 2,
        top: portalCenter.y - cardH / 2,
        opacity: 0,
        scale: 0,
        rotateZ: index % 2 === 0 ? -12 : 12,
        rotateX: 45,
        filter: 'blur(12px)',
        transition: { duration: 0.35, ease: [0.4, 0, 1, 1] }
      }}
      transition={{
        default: {
          type: 'spring',
          stiffness: 160,
          damping: 16,
          mass: 1.2,
          delay: index * 0.12,
        },
        top: {
          duration: 0.9,
          ease: ["easeOut", "easeIn"],
          times: [0, 0.45, 1],
          delay: index * 0.12,
        },
        scale: {
          duration: 0.9,
          ease: ["easeOut", "easeInOut"],
          times: [0, 0.3, 1], // Reaches 20% size at 30% of the animation, then grows
          delay: index * 0.12,
        },
        opacity: {
          duration: 0.2,
          delay: index * 0.12,
        }
      }}
      style={{
        position: 'fixed',
        transformOrigin: 'center center',
        willChange: 'transform, opacity, left, top',
      }}
    >
      <motion.div
        style={{
          width: '100%',
          height: '100%',
          background: '#ffffff',
          borderRadius: 20,
          overflow: 'hidden',
          boxShadow: '0 4px 20px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.03)',
          cursor: 'pointer',
          transformOrigin: 'center center',
          display: 'flex',
          flexDirection: 'column'
        }}
        whileHover={{
          scale: 1.03,
          boxShadow: '0 20px 40px rgba(0,0,0,0.12), 0 0 0 1px rgba(0,0,0,0.02)',
          transition: { duration: 0.25, ease: [0.25, 0.1, 0.25, 1] }
        }}
      >
        <div style={{ width: '100%', height: 230, overflow: 'hidden', backgroundColor: '#f5f5f7', flexShrink: 0 }}>
          <motion.img
            src={product.img}
            alt={product.name}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          />
        </div>
        <div style={{ padding: '16px 20px' }}>
          <div style={{ fontSize: 12, fontWeight: 500, color: '#86868b', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            {product.category}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: 15, fontWeight: 600, color: '#1d1d1f', margin: 0 }}>{product.name}</h3>
            <span style={{ fontSize: 15, fontWeight: 500, color: '#1d1d1f' }}>{product.price}</span>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
