import { motion, useScroll, useTransform, useSpring } from 'framer-motion';
import MacbookBase from './components/MacbookBase';
import MacbookLid from './components/MacbookLid';
import MacOSDashboard from './components/MacOSDashboard';

export default function Macbook({ scrollContainerRef }) {
    // Attach scroll progress to the outer scroll container
    const { scrollYProgress } = useScroll({
        target: scrollContainerRef,
        offset: ["start start", "end end"],
    });

    // Apply balanced spring physics for smooth, natural 60fps Apple feel
    const smoothProgress = useSpring(scrollYProgress, {
        stiffness: 110,
        damping: 26,
        restDelta: 0.001,
    });

    // Phase 1 (0.0 - 0.55): Realistic Lid Opening
    // When closed (-165deg), the lid presses firmly flat on top of the keyboard.
    // As user scrolls down, it opens smoothly and stops at -10deg (standing upright without touching the top navbar).
    const lidAngle = useTransform(smoothProgress, [0, 0.55], [-165, -10]);

    // Phase 1.5A (0.0 - 0.12): Front Trackpad Glow
    // Starts fine at 0.6 when closed, INTENSIFIES to 1.0 as lid lifts slightly (0.05), then DISAPPEARS as lid goes higher (0.12)!
    const trackpadGlow = useTransform(smoothProgress, [0, 0.05, 0.12], [0.6, 1, 0]);

    // Phase 1.5B (0.10 - 0.35): Keyboard Well Glow
    // Turns on inside keyboard after trackpad glow fades (0.20), then fades out as screen powers on and opens fully (0.35)!
    const keyboardGlow = useTransform(smoothProgress, [0.10, 0.20, 0.35], [0, 1, 0]);

    // Phase 2 (0.14 - 0.35): Screen Power On
    // Lid first lifts up noticeably off the keyboard [0.0 - 0.14], THEN the screen powers on!
    const screenPower = useTransform(smoothProgress, [0.14, 0.35], [0, 1]);

    // Phase 0: Apple Intelligence Headline (Stays visible while lid opens, rising screen (z-10) hides text (z-0) behind it!)
    const headlineOpacity = useTransform(smoothProgress, [0.40, 0.55], [1, 0]);
    const headlineTranslateY = useTransform(smoothProgress, [0.40, 0.55], [0, -30]);

    // Phase 3 (0.18 - 0.48): UI Content Reveal
    // Content appears smoothly right after the screen powers up and is rising into position!
    const uiOpacity = useTransform(smoothProgress, [0.18, 0.48], [0, 1]);
    const uiTranslateY = useTransform(smoothProgress, [0.18, 0.48], [20, 0]);

    return (
        <div className="fixed inset-0 w-full h-screen flex flex-col items-center justify-center pt-80 md:pt-[440px] overflow-hidden perspective-2000 pointer-events-auto z-10">

            {/* Above MacBook: Glowing Apple Intelligence Headline (z-0 so rising lid z-10 covers and hides it behind the screen!) */}
            <motion.div
                style={{
                    opacity: headlineOpacity,
                    y: headlineTranslateY,
                }}
                className="absolute top-20 sm:top-24 md:top-28 inset-x-0 flex flex-col items-center justify-center text-center px-4 z-0 pointer-events-none select-none"
            >
                <span className="text-base sm:text-lg md:text-2xl font-medium tracking-tight text-white mb-1 sm:mb-2 drop-shadow-md">
                    MacBook Pro
                </span>
                <div className="relative inline-block">
                    {/* Glowing blur background text for intense neon bloom */}
                    <h1 className="absolute inset-0 z-0 font-semibold text-3xl sm:text-5xl md:text-6xl lg:text-7xl tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-[#00d2ff] via-[#b066ff] via-50%-[#ff4d88] to-[#ff9900] blur-xl opacity-90 scale-105">
                        Built for Apple Intelligence.
                    </h1>
                    {/* Secondary soft glow */}
                    <h1 className="absolute inset-0 z-0 font-semibold text-3xl sm:text-5xl md:text-6xl lg:text-7xl tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-[#00d2ff] via-[#b066ff] via-50%-[#ff4d88] to-[#ff9900] blur-md opacity-100">
                        Built for Apple Intelligence.
                    </h1>
                    {/* Crisp foreground text */}
                    <h1 className="relative z-10 font-semibold text-3xl sm:text-5xl md:text-6xl lg:text-7xl tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-[#20e0ff] via-[#c484ff] via-50%-[#ff6699] to-[#ffad1f] drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
                        Built for Apple Intelligence.
                    </h1>
                </div>
            </motion.div>

            {/* Ambient background lighting glow that expands as screen powers on */}
            <motion.div
                style={{ opacity: screenPower }}
                className="absolute w-[600px] h-[350px] rounded-full bg-gradient-to-tr from-purple-500/15 via-indigo-500/10 to-blue-500/10 blur-[100px] pointer-events-none -z-10"
            />

            {/* 3D MacBook Assembly (100% FIXED in exact center of screen, NEVER moves, tilts, or zooms!) */}
            <div
                style={{
                    transform: 'rotateX(14deg) scale(0.82)',
                }}
                className="preserve-3d relative w-[760px] max-w-[92vw] aspect-[16/10] z-10 transition-shadow"
            >
                {/* Lid Hinge & Screen Assembly (Attached at bottom center above keyboard base) */}
                <MacbookLid
                    lidAngle={lidAngle}
                    screenPower={screenPower}
                    uiOpacity={uiOpacity}
                    uiTranslateY={uiTranslateY}
                >
                    {/* Interactive macOS Desktop & Dashboard UI */}
                    <MacOSDashboard />
                </MacbookLid>

                {/* Bottom Aluminum Keyboard Chassis */}
                <MacbookBase trackpadGlow={trackpadGlow} keyboardGlow={keyboardGlow} />
            </div>

            {/* Realistic Ambient Drop Shadow on Floor */}
            <div
                style={{
                    transform: 'scale(1)',
                    opacity: 0.25,
                }}
                className="w-[680px] max-w-[85vw] h-12 rounded-[50%] bg-black blur-2xl mt-8 -z-10 pointer-events-none transition-all"
            />
        </div>
    );
}
