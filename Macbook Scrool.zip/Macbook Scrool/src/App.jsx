import { useRef } from 'react';
import Macbook from './Macbook';

export default function App() {
  const containerRef = useRef(null);

  return (
    <div className="min-h-screen bg-[#000000] text-white selection:bg-purple-600 selection:text-white font-sans overflow-x-hidden">

      {/* Top Apple Global Navigation Bar (No border, simple clean centered tags) */}
      <header className="fixed top-0 inset-x-0 h-12 bg-black/80 backdrop-blur-md z-50 px-4 flex items-center justify-center">
        <nav className="flex items-center justify-center gap-4 sm:gap-6 md:gap-7 lg:gap-8 text-xs sm:text-[13px] font-normal text-white/80 tracking-tight whitespace-nowrap overflow-x-auto no-scrollbar py-2">
          <a href="#apple" className="text-base sm:text-lg hover:text-white transition-colors"></a>
          <a href="#store" className="hover:text-white transition-colors">Store</a>
          <a href="#mac" className="hover:text-white transition-colors">Mac</a>
          <a href="#ipad" className="hover:text-white transition-colors">iPad</a>
          <a href="#iphone" className="hover:text-white transition-colors">iPhone</a>
          <a href="#watch" className="hover:text-white transition-colors">Watch</a>
          <a href="#vision" className="hover:text-white transition-colors">Vision</a>
          <a href="#airpods" className="hover:text-white transition-colors">AirPods</a>
          <a href="#tv-home" className="hover:text-white transition-colors">TV & Home</a>
          <a href="#entertainment" className="hover:text-white transition-colors">Entertainment</a>
          <a href="#accessories" className="hover:text-white transition-colors">Accessories</a>
          <a href="#support" className="hover:text-white transition-colors">Support</a>
          <button aria-label="Search" className="hover:text-white transition-colors">
            <svg className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-current" viewBox="0 0 24 24">
              <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
            </svg>
          </button>
          <button aria-label="Shopping Bag" className="hover:text-white transition-colors">
            <svg className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-current" viewBox="0 0 24 24">
              <path d="M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z" />
            </svg>
          </button>
        </nav>
      </header>

      {/* Main Scroll Container (400vh for smooth scrolling while MacBook stays fixed in center) */}
      <section ref={containerRef} className="relative w-full h-[400vh]">
        <Macbook scrollContainerRef={containerRef} />
      </section>
    </div>
  );
}
