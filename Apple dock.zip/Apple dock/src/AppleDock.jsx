import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useMotionValueEvent, AnimatePresence } from 'framer-motion';
import {
  RiHome5Line, RiHome5Fill,
  RiSearchLine, RiSearchFill,
  RiHeartLine, RiHeartFill,
  RiShoppingCartLine, RiShoppingCartFill,
  RiCloseLine
} from '@remixicon/react';

export default function AppleDock() {
  const { scrollY } = useScroll();
  const [isShrunk, setIsShrunk] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('home');
  const [cartCount] = useState(3); // Demo cart count
  const [heartParticles, setHeartParticles] = useState([]);

  const triggerHeartBurst = () => {
    setActiveTab('likes');
    setIsSearchOpen(false);
    const idBase = Date.now() + Math.random();
    const newHearts = [
      { id: idBase + 1, x: -16, delay: 0, scale: 0.85, type: 'pinkPurple1' },
      { id: idBase + 2, x: 1, delay: 0.08, scale: 1.15, type: 'pinkPurple2' },
      { id: idBase + 3, x: 18, delay: 0.16, scale: 0.95, type: 'pinkPurple3' }
    ];
    setHeartParticles(prev => [...prev, ...newHearts]);
    setTimeout(() => {
      setHeartParticles(prev => prev.filter(h => !newHearts.some(nh => nh.id === h.id)));
    }, 1300);
  };

  useEffect(() => {
    setMounted(true);
  }, []);

  const lastScrollY = useRef(0);

  useMotionValueEvent(scrollY, "change", (latest) => {
    if (latest < 50) {
      setIsShrunk(false);
      lastScrollY.current = latest;
      return;
    }

    const diff = latest - lastScrollY.current;

    if (diff > 15) {
      setIsShrunk(true);
      if (isSearchOpen) setIsSearchOpen(false);
      lastScrollY.current = latest;
    } else if (diff < -15) {
      setIsShrunk(false);
      lastScrollY.current = latest;
    }
  });

  if (!mounted) return null;

  const isActive = (tab) => activeTab === tab;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center pointer-events-none px-4"
      dir="ltr"
    >
      <motion.div
        layout
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="pointer-events-auto flex items-center overflow-visible"
        style={{
          background: 'rgba(15, 23, 42, 0.78)',
          backdropFilter: 'blur(32px) saturate(180%)',
          WebkitBackdropFilter: 'blur(32px) saturate(180%)',
          border: '1px solid rgba(255, 255, 255, 0.22)',
          boxShadow: '0 24px 50px rgba(0, 0, 0, 0.4), inset 0 1px 1px rgba(255, 255, 255, 0.35)',
          borderRadius: 36,
          padding: isShrunk ? '10px 24px' : '16px 32px',
          width: isSearchOpen ? '90vw' : 'auto',
          maxWidth: isSearchOpen ? '500px' : 'none',
          justifyContent: 'space-between',
          gap: isSearchOpen ? '16px' : isShrunk ? '24px' : '40px',
          transition:
            'padding 0.4s cubic-bezier(0.16, 1, 0.3, 1), gap 0.4s cubic-bezier(0.16, 1, 0.3, 1), width 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {/* Home */}
        <button
          onClick={() => { setActiveTab('home'); setIsSearchOpen(false); }}
          className="relative group flex items-center justify-center cursor-pointer"
          style={{ flexShrink: 0, background: 'none', border: 'none', padding: 0 }}
        >
          <motion.div
            layout
            whileHover={{ scale: 1.15 }}
            whileTap={{ scale: 0.95 }}
            animate={{ scale: isShrunk ? 0.85 : 1 }}
            transition={{ type: 'spring', bounce: 0.4 }}
            className="relative"
            style={{
              color: isActive('home') ? '#22d3ee' : '#64748b',
              transition: 'color 0.3s',
            }}
          >
            {isActive('home') && (
              <motion.div
                layoutId="dock-indicator"
                className="absolute rounded-2xl"
                transition={{ type: 'spring', stiffness: 400, damping: 28 }}
                style={{
                  inset: '-10px -12px',
                  background: 'linear-gradient(135deg, rgba(255,255,255,0.25) 0%, rgba(255,255,255,0.08) 100%)',
                  backdropFilter: 'blur(16px)',
                  WebkitBackdropFilter: 'blur(16px)',
                  border: '1px solid rgba(255, 255, 255, 0.35)',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.25), inset 0 1px 1px rgba(255, 255, 255, 0.6)',
                  zIndex: -1,
                }}
              />
            )}
            {isActive('home') && !isShrunk && (
              <motion.div
                className="absolute rounded-full"
                style={{
                  bottom: '-8px',
                  width: '4px',
                  height: '4px',
                  background: '#22d3ee',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  boxShadow: '0 0 8px rgba(34,211,238,0.8)',
                }}
              />
            )}
            {isActive('home') ? <RiHome5Fill size={24} /> : <RiHome5Line size={24} />}
          </motion.div>
        </button>

        {/* Dynamic Center Content */}
        {isSearchOpen ? (
          <motion.form
            initial={{ opacity: 0, width: 0, scale: 0.95 }}
            animate={{ opacity: 1, width: '100%', scale: 1 }}
            exit={{ opacity: 0, width: 0, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 400, damping: 28 }}
            className="flex items-center overflow-hidden"
            style={{
              flex: 1,
              background: 'linear-gradient(135deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.08) 100%)',
              backdropFilter: 'blur(24px)',
              WebkitBackdropFilter: 'blur(24px)',
              borderRadius: '9999px',
              padding: '6px 16px',
              border: '1px solid rgba(255, 255, 255, 0.4)',
              boxShadow: '0 12px 32px rgba(0,0,0,0.3), inset 0 1px 2px rgba(255, 255, 255, 0.5)',
            }}
            onSubmit={(e) => e.preventDefault()}
          >
            <input
              autoFocus
              dir="ltr"
              placeholder="Search..."
              className="dock-search-input"
              style={{
                width: '100%',
                background: 'transparent',
                fontSize: '14px',
                color: '#fff',
                outline: 'none',
                padding: '0 8px',
                border: 'none',
              }}
            />
            <button
              type="button"
              onClick={() => setIsSearchOpen(false)}
              style={{
                background: 'none',
                border: 'none',
                color: '#94a3b8',
                padding: '4px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
              }}
            >
              <RiCloseLine size={20} />
            </button>
          </motion.form>
        ) : (
          <>
            {/* Search */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="relative group flex items-center justify-center cursor-pointer"
              style={{ flexShrink: 0, background: 'none', border: 'none', padding: 0 }}
            >
              <motion.div
                layout
                whileHover={{ scale: 1.15 }}
                whileTap={{ scale: 0.95 }}
                animate={{ scale: isShrunk ? 0.85 : 1 }}
                transition={{ type: 'spring', bounce: 0.4 }}
                className="relative flex items-center justify-center"
              >
                <motion.div
                  className="absolute rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                  style={{
                    inset: '-10px -12px',
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.25) 0%, rgba(255,255,255,0.08) 100%)',
                    backdropFilter: 'blur(16px)',
                    WebkitBackdropFilter: 'blur(16px)',
                    border: '1px solid rgba(255, 255, 255, 0.35)',
                    boxShadow: '0 8px 24px rgba(0,0,0,0.2), inset 0 1px 1px rgba(255, 255, 255, 0.6)',
                    zIndex: -1,
                  }}
                />
                <div style={{ color: '#94a3b8' }} className="group-hover:text-cyan-400 transition-colors">
                  <RiSearchLine size={24} />
                </div>
              </motion.div>
            </button>

            {/* Like Button with Instagram Floating Heart Burst */}
            <button
              onClick={triggerHeartBurst}
              className="relative group flex items-center justify-center cursor-pointer overflow-visible"
              style={{ flexShrink: 0, background: 'none', border: 'none', padding: 0 }}
            >
              {/* Floating Hearts Particles */}
              <div className="absolute left-1/2 bottom-full pointer-events-none z-50 overflow-visible">
                <AnimatePresence>
                  {heartParticles.map((h) => (
                    <motion.div
                      key={h.id}
                      initial={{ opacity: 0, y: 10, x: 0, scale: 0.2 }}
                      animate={{
                        opacity: [0, 1, 1, 0],
                        y: [-5, -30, -55, -80],
                        x: [0, h.x * 0.5, h.x * 1.1, h.x],
                        scale: [0.3, h.scale, h.scale * 1.15, h.scale * 0.7],
                      }}
                      exit={{ opacity: 0, scale: 0 }}
                      transition={{
                        duration: 1.15,
                        delay: h.delay,
                        ease: [0.22, 1, 0.36, 1],
                      }}
                      className="absolute flex items-center justify-center"
                      style={{
                        bottom: '0px',
                        left: '-10px',
                      }}
                    >
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="drop-shadow-[0_4px_10px_rgba(217,70,239,0.7)]">
                        <defs>
                          <linearGradient id={`grad-${h.id}`} x1="0%" y1="100%" x2="100%" y2="0%">
                            {h.type === 'pinkPurple1' && (
                              <>
                                <stop offset="0%" stopColor="#ff007f" />
                                <stop offset="50%" stopColor="#d946ef" />
                                <stop offset="100%" stopColor="#8b5cf6" />
                              </>
                            )}
                            {h.type === 'pinkPurple2' && (
                              <>
                                <stop offset="0%" stopColor="#f472b6" />
                                <stop offset="50%" stopColor="#ec4899" />
                                <stop offset="100%" stopColor="#a855f7" />
                              </>
                            )}
                            {h.type === 'pinkPurple3' && (
                              <>
                                <stop offset="0%" stopColor="#ff2a85" />
                                <stop offset="50%" stopColor="#c026d3" />
                                <stop offset="100%" stopColor="#6366f1" />
                              </>
                            )}
                          </linearGradient>
                        </defs>
                        <path
                          d="M12 21.35L10.55 20.03C5.4 15.36 2 12.28 2 8.5C2 5.42 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.09C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.42 22 8.5C22 12.28 18.6 15.36 13.45 20.04L12 21.35Z"
                          fill={`url(#grad-${h.id})`}
                        />
                      </svg>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              <motion.div
                layout
                whileHover={{ scale: 1.15 }}
                whileTap={{ scale: 1.35 }}
                animate={{ scale: isShrunk ? 0.85 : 1 }}
                transition={{ type: 'spring', bounce: 0.5 }}
                className="relative"
                style={{
                  color: isActive('likes') ? '#dc2743' : '#64748b',
                  transition: 'color 0.3s',
                }}
              >
                {isActive('likes') && (
                  <motion.div
                    layoutId="dock-indicator"
                    className="absolute rounded-2xl"
                    transition={{ type: 'spring', stiffness: 400, damping: 28 }}
                    style={{
                      inset: '-10px -12px',
                      background: 'linear-gradient(135deg, rgba(220,39,67,0.3) 0%, rgba(188,24,136,0.15) 100%)',
                      backdropFilter: 'blur(16px)',
                      WebkitBackdropFilter: 'blur(16px)',
                      border: '1px solid rgba(220, 39, 67, 0.5)',
                      boxShadow: '0 8px 24px rgba(220,39,67,0.35), inset 0 1px 1px rgba(255,255,255,0.45)',
                      zIndex: -1,
                    }}
                  />
                )}
                {isActive('likes') && !isShrunk && (
                  <motion.div
                    className="absolute rounded-full"
                    style={{
                      bottom: '-8px',
                      width: '4px',
                      height: '4px',
                      background: '#dc2743',
                      left: '50%',
                      transform: 'translateX(-50%)',
                      boxShadow: '0 0 8px rgba(220,39,67,0.8)',
                    }}
                  />
                )}
                {isActive('likes') ? (
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="drop-shadow-[0_0_12px_rgba(220,39,67,0.8)]">
                    <defs>
                      <linearGradient id="main-heart-insta-grad" x1="0%" y1="100%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#f09433" />
                        <stop offset="30%" stopColor="#e6683c" />
                        <stop offset="60%" stopColor="#dc2743" />
                        <stop offset="85%" stopColor="#cc2366" />
                        <stop offset="100%" stopColor="#bc1888" />
                      </linearGradient>
                    </defs>
                    <path
                      d="M12 21.35L10.55 20.03C5.4 15.36 2 12.28 2 8.5C2 5.42 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.09C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.42 22 8.5C22 12.28 18.6 15.36 13.45 20.04L12 21.35Z"
                      fill="url(#main-heart-insta-grad)"
                    />
                  </svg>
                ) : (
                  <RiHeartLine size={24} />
                )}
              </motion.div>
            </button>
          </>
        )}

        {/* Cart */}
        <button
          onClick={() => { setActiveTab('cart'); setIsSearchOpen(false); }}
          className="relative group flex items-center justify-center cursor-pointer"
          style={{ flexShrink: 0, background: 'none', border: 'none', padding: 0 }}
        >
          <motion.div
            layout
            whileHover={{ scale: 1.15 }}
            whileTap={{ scale: 0.95 }}
            animate={{ scale: isShrunk ? 0.85 : 1 }}
            transition={{ type: 'spring', bounce: 0.4 }}
            className="relative"
            style={{
              color: isActive('cart') ? '#22d3ee' : '#64748b',
              transition: 'color 0.3s',
            }}
          >
            {isActive('cart') && (
              <motion.div
                layoutId="dock-indicator"
                className="absolute rounded-2xl"
                transition={{ type: 'spring', stiffness: 400, damping: 28 }}
                style={{
                  inset: '-10px -12px',
                  background: 'linear-gradient(135deg, rgba(255,255,255,0.25) 0%, rgba(255,255,255,0.08) 100%)',
                  backdropFilter: 'blur(16px)',
                  WebkitBackdropFilter: 'blur(16px)',
                  border: '1px solid rgba(255, 255, 255, 0.35)',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.25), inset 0 1px 1px rgba(255, 255, 255, 0.6)',
                  zIndex: -1,
                }}
              />
            )}
            {isActive('cart') && !isShrunk && (
              <motion.div
                className="absolute rounded-full"
                style={{
                  bottom: '-8px',
                  width: '4px',
                  height: '4px',
                  background: '#22d3ee',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  boxShadow: '0 0 8px rgba(34,211,238,0.8)',
                }}
              />
            )}
            {isActive('cart') ? (
              <RiShoppingCartFill size={24} />
            ) : (
              <RiShoppingCartLine size={24} />
            )}

            {cartCount > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute flex items-center justify-center"
                style={{
                  top: '-6px',
                  right: '-10px',
                  background: '#f43f5e',
                  color: '#fff',
                  fontSize: '10px',
                  fontWeight: 900,
                  height: '18px',
                  minWidth: '18px',
                  padding: '0 4px',
                  borderRadius: '9999px',
                  border: '2px solid #150f30',
                  boxShadow: '0 0 10px rgba(244,63,94,0.5)',
                }}
              >
                {cartCount > 99 ? '99+' : cartCount}
              </motion.div>
            )}
          </motion.div>
        </button>
      </motion.div>
    </div>
  );
}
