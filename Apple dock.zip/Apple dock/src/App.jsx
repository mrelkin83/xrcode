import React from 'react';
import AppleDock from './AppleDock';

const App = () => {
  return (
    <div
      style={{
        minHeight: '300vh',
        background: '#ffffff',
        color: '#0f172a',
        fontFamily: "'Inter', 'Segoe UI', sans-serif",
      }}
    >
      <AppleDock />
    </div>
  );
};

export default App;
