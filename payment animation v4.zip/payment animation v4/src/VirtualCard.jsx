import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import lottie from 'lottie-web';
import successAnimData from './assets/Payment Success.json';
import './VirtualCard.css';

const Particles = () => {
  const particles = useMemo(() => {
    return Array.from({ length: 20 }).map((_, i) => {
      const angle = (Math.random() * 360) * (Math.PI / 180);
      const distance = 80 + Math.random() * 120; // shoot 80 to 200px out
      const size = 3 + Math.random() * 4; // 3 to 7px size
      const duration = 0.5 + Math.random() * 0.4;
      return { id: i, angle, distance, size, duration };
    });
  }, []);

  return (
    <div className="particles-container">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="particle"
          style={{ width: p.size, height: p.size }}
          initial={{ x: 0, y: 0, opacity: 1, scale: 0 }}
          animate={{
            x: Math.cos(p.angle) * p.distance,
            y: Math.sin(p.angle) * p.distance,
            opacity: [1, 1, 0],
            scale: [0, 1.5, 0]
          }}
          transition={{ duration: p.duration, ease: "easeOut" }}
        />
      ))}
    </div>
  );
};

const LottieSuccess = () => {
  const containerRef = useRef(null);
  useEffect(() => {
    const anim = lottie.loadAnimation({
      container: containerRef.current,
      renderer: 'svg',
      loop: true,
      autoplay: true,
      animationData: successAnimData,
    });
    return () => anim.destroy();
  }, []);
  return <div ref={containerRef} className="lottie-success-overlay" />;
};

function VirtualCard({ name, cardNumber, expiry, cvv, isVisible }) {
  const [isLanded, setIsLanded] = useState(false);

  // Reset shadow state when card is hidden
  useEffect(() => {
    if (!isVisible) {
      setIsLanded(false);
    }
  }, [isVisible]);

  const formattedCardNumber = cardNumber || 'XXXX XXXX XXXX XXXX';
  const displayName = name || 'CARDHOLDER NAME';
  const displayExpiry = expiry || '00/00';
  const displayCvv = cvv || '0000';

  const CardContent = (
    <div className={`virtual-card ${isLanded ? 'with-shadow' : ''}`}>
      {/* Top Row: Bank Name & Card Type */}
      <div className="card-top-row">
        <div className="bank-brand">
          <svg viewBox="0 0 24 24" width="20" height="20">
            <path d="M 0 24 L 24 24 L 24 0 A 24 24 0 0 0 0 24" fill="#fff" />
          </svg>
          <span>BANK NAME</span>
        </div>
        <div className="card-type">Credit Card</div>
      </div>

      {/* Second Row: Chip and NFC */}
      <div className="card-chip-row">
        <div className="chip">
          <svg viewBox="0 0 50 36" width="50" height="36">
            <rect x="0" y="0" width="50" height="36" fill="transparent" />
            <path d="M 12 0 L 12 36 M 38 0 L 38 36 M 0 12 L 50 12 M 0 24 L 50 24" stroke="rgba(0,0,0,0.15)" strokeWidth="1.5" />
            <rect x="18" y="10" width="14" height="16" rx="2" fill="none" stroke="rgba(0,0,0,0.2)" strokeWidth="1.5" />
          </svg>
        </div>
        <div className="nfc-icon">
          <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 8.24A15 15 0 0 1 12 5.5a15 15 0 0 1 8 2.74" />
            <path d="M6 12a10.94 10.94 0 0 1 12 0" />
            <path d="M8 15.5a6.83 6.83 0 0 1 8 0" />
            <path d="M10 19a2.76 2.76 0 0 1 4 0" />
          </svg>
        </div>
      </div>

      {/* Third Row: Card Number */}
      <div className="card-number-row">
        {formattedCardNumber}
      </div>

      {/* Fourth Row: Details */}
      <div className="card-details-row">
        <div className="cvv-area">{displayCvv}</div>
        <div className="expiry-area">
          <div className="expires-label">
            EXPIRES<br />END
          </div>
          <div className="expires-value">{displayExpiry}</div>
        </div>
      </div>

      {/* Bottom Row: Cardholder Name */}
      <div className="card-bottom-row">
        {displayName.toUpperCase()}
      </div>
    </div>
  );

  return (
    <div className={`virtual-card-wrapper ${isVisible ? 'show-card' : ''} ${isLanded ? 'is-landed' : ''}`}>
      {isLanded && <Particles />}
      {isLanded && <LottieSuccess />}
      <AnimatePresence>
        {isVisible && (
          <>
            <motion.div
              className="card-half card-left"
              initial={{ x: -800, y: 400, rotate: -35, scale: 0.4, opacity: 0 }}
              animate={{ x: 0, y: 0, rotate: 0, scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 55, damping: 14, delay: 0.3 }}
              onAnimationComplete={() => setIsLanded(true)}
            >
              {CardContent}
            </motion.div>

            <motion.div
              className="card-half card-right"
              initial={{ x: 800, y: 400, rotate: 35, scale: 0.4, opacity: 0 }}
              animate={{ x: 0, y: 0, rotate: 0, scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 55, damping: 14, delay: 0.3 }}
            >
              {CardContent}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

export default VirtualCard;
