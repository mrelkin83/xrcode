import React, { useEffect, useRef } from 'react';
import lottie from 'lottie-web';
import walletAnimationData from './assets/Wallet animation.json';
import './PaymentAnimation.css';

function PaymentAnimation() {
  const containerRef = useRef(null);

  useEffect(() => {
    const anim = lottie.loadAnimation({
      container: containerRef.current,
      renderer: 'svg',
      loop: true,
      autoplay: true,
      animationData: walletAnimationData,
    });

    return () => anim.destroy();
  }, []);

  return (
    <div className="payment-anim-container">
      <div ref={containerRef} style={{ width: 140, height: 140 }}></div>
    </div>
  );
}

export default PaymentAnimation;
