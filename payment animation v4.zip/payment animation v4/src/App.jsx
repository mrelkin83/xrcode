import React, { useState, useEffect, useRef } from 'react';
import { X, ChevronRight, ArrowLeft } from 'lucide-react';
import lottie from 'lottie-web';
import cardSwipingData from './assets/Card swiping.json';
import PaymentAnimation from './PaymentAnimation';
import VirtualCard from './VirtualCard';
import './App.css';

function App() {
  const [name, setName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cvv, setCvv] = useState('');
  const [expiry, setExpiry] = useState('');
  const [email, setEmail] = useState('');
  // 'idle' | 'processing' | 'success'
  const [paymentState, setPaymentState] = useState('idle');
  const cardAnimRef = useRef(null);

  const handlePayment = (e) => {
    e.preventDefault();
    setPaymentState('processing'); // starts form exit and shows loader
    
    // Wait for form to fade out, then keep loader briefly (total 1.2s)
    setTimeout(() => {
      setPaymentState('success'); // hides loader, shows card
    }, 1200);
  };

  const handleCardNumberChange = (e) => {
    // Only allow numbers, then format with spaces every 4 digits
    let val = e.target.value.replace(/\D/g, '');
    if (val.length > 16) val = val.slice(0, 16);
    const formatted = val.replace(/(\d{4})/g, '$1 ').trim();
    setCardNumber(formatted);
  };

  const handleExpiryChange = (e) => {
    // Only allow numbers, format as MM/YY
    let val = e.target.value.replace(/\D/g, '');
    if (val.length > 4) val = val.slice(0, 4);
    if (val.length > 2) {
      val = val.slice(0, 2) + '/' + val.slice(2);
    }
    setExpiry(val);
  };

  const handleCvvChange = (e) => {
    // Only allow up to 3 numbers
    let val = e.target.value.replace(/\D/g, '');
    if (val.length > 3) val = val.slice(0, 3);
    setCvv(val);
  };

  useEffect(() => {
    const anim = lottie.loadAnimation({
      container: cardAnimRef.current,
      renderer: 'svg',
      loop: true,
      autoplay: true,
      animationData: cardSwipingData,
    });
    return () => anim.destroy();
  }, []);
  return (
    <div className="checkout-container">
      <VirtualCard 
        name={name} 
        cardNumber={cardNumber} 
        expiry={expiry} 
        cvv={cvv} 
        isVisible={paymentState === 'success'} 
      />

      {/* Success Message */}
      {paymentState === 'success' && (
        <div className="success-message">
          <div className="check-circle">
            <svg viewBox="0 0 52 52">
              <circle className="check-circle-path" cx="26" cy="26" r="24" fill="none" />
              <path className="check-path" fill="none" d="M16 26 l6 6 l14 -14" />
            </svg>
          </div>
          <p>Payment Successful</p>
        </div>
      )}

      {/* Processing Loader */}
      {paymentState === 'processing' && (
        <div className="processing-loader">
          <div className="spinner"></div>
          <p>Processing payment...</p>
        </div>
      )}

      <button className="close-btn" aria-label="Close">
        <X size={16} />
      </button>

      {/* Left Info Section */}
      <div className={`info-section ${paymentState !== 'idle' ? 'slide-out-left' : ''}`}>
        <PaymentAnimation />

        <div className="header">
          <h1>Checkout</h1>
          <p className="subtitle">You've one more step to go...</p>
        </div>

        <div className="info-box">
          <div className="info-item">
            1. Please fill the fields with correct details to continue your payment
          </div>

          <div className="info-item">
            2. We accept following cards
            <div className="cards-accepted">
              {/* Visa */}
              <div className="card-logo-box">
                <svg viewBox="0 0 48 32" width="55" height="36">
                  <rect width="48" height="32" rx="4" fill="#1A1F71" />
                  <text x="24" y="20" fill="#fff" fontSize="12" fontWeight="bold" fontStyle="italic" textAnchor="middle" fontFamily="Arial">VISA</text>
                </svg>
              </div>
              {/* MasterCard */}
              <div className="card-logo-box">
                <svg viewBox="0 0 48 32" width="55" height="36">
                  <rect width="48" height="32" rx="4" fill="#252525" />
                  <circle cx="19" cy="16" r="9" fill="#EB001B" />
                  <circle cx="29" cy="16" r="9" fill="#F79E1B" />
                  <path d="M24 9.17a9 9 0 0 1 0 13.66 9 9 0 0 1 0-13.66z" fill="#FF5F00" />
                  <text x="24" y="28" fill="#fff" fontSize="4" textAnchor="middle" fontFamily="Arial" fontWeight="bold">mastercard</text>
                </svg>
              </div>
              {/* American Express */}
              <div className="card-logo-box">
                <svg viewBox="0 0 48 32" width="55" height="36">
                  <rect width="48" height="32" rx="4" fill="#006FCF" />
                  <text x="24" y="13" fill="#fff" fontSize="5.5" fontWeight="bold" textAnchor="middle" fontFamily="Arial">AMERICAN</text>
                  <text x="24" y="21" fill="#fff" fontSize="5.5" fontWeight="bold" textAnchor="middle" fontFamily="Arial">EXPRESS</text>
                </svg>
              </div>
              {/* Discover */}
              <div className="card-logo-box">
                <svg viewBox="0 0 48 32" width="55" height="36">
                  <rect width="48" height="32" rx="4" fill="#fff" stroke="#e0e0e0" />
                  <text x="24" y="15" fill="#231f20" fontSize="6" fontWeight="bold" textAnchor="middle" fontFamily="Arial">DISC<tspan fill="#FF6000">O</tspan>VER</text>
                  <text x="24" y="23" fill="#555" fontSize="3.5" textAnchor="middle" fontFamily="Arial">NETWORK</text>
                </svg>
              </div>
            </div>
          </div>

          <div className="info-item">
            3. We won't share any details with third-party for more info Read our <span className="privacy-link">Privacy Policy</span>
          </div>

          <div className="support-section">
            <p>Need Support?</p>
            <span className="support-link">Contact Us</span>
          </div>
        </div>
      </div>

      {/* Right Form Section */}
      <div className={`form-section ${paymentState !== 'idle' ? 'slide-out-right' : ''}`}>
        <form autoComplete="off" onSubmit={handlePayment}>
          <div className="form-group">
            <label>Name on card</label>
            <input
              type="text"
              name="dummy_name_123"
              autoComplete="new-password"
              placeholder="Enter card holders' Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Card Number</label>
            <div className="input-with-icon">
              <input
                type="text"
                name="dummy_cc_123"
                autoComplete="new-password"
                placeholder="0000 0000 0000 0000"
                value={cardNumber}
                onChange={handleCardNumberChange}
                maxLength={19}
              />
              <div className="input-icon">
                <svg viewBox="0 0 48 32" width="30" height="20">
                  <text x="24" y="22" fill="#1A1F71" fontSize="16" fontWeight="bold" fontStyle="italic" textAnchor="middle" fontFamily="Arial">VISA</text>
                </svg>
              </div>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>CVV</label>
              <input
                type="password"
                name="dummy_cvv_123"
                autoComplete="new-password"
                placeholder="***"
                value={cvv}
                onChange={handleCvvChange}
                maxLength={3}
              />
            </div>

            <div className="form-group">
              <label>Card Expiration Date</label>
              <input
                type="text"
                name="dummy_exp_123"
                autoComplete="new-password"
                placeholder="MM/YY"
                value={expiry}
                onChange={handleExpiryChange}
                maxLength={5}
              />
            </div>
          </div>

          <div className="form-group">
            <label>Send invoice to</label>
            <input
              type="email"
              name="dummy_email_123"
              autoComplete="new-password"
              placeholder="Enter your email address here"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="form-actions">
            <div className="pay-row">
              <button className="pay-btn" type="submit">
                Continue payment <ChevronRight size={18} />
              </button>
              <div ref={cardAnimRef} className="card-swipe-anim"></div>
            </div>

            <button type="button" className="go-back">
              <ArrowLeft size={14} /> Go back
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default App;
