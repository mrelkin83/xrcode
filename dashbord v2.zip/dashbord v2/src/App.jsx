import React, { useState } from 'react';
import Dashboard1 from './dashbird1.jsx';
import Dashboard2 from './dashbord2.jsx';

function App() {
  // Show Dashboard 2 as requested by user
  const [currentDash, setCurrentDash] = useState(2);

  return (
    <>
      {currentDash === 1 ? (
        <div style={{ position: 'relative', width: '100%', height: '100%' }}>
          <Dashboard1 />
          <div className="dashboard-switcher-pill">
            <span style={{ opacity: 0.7 }}>Dashboard:</span>
            <button className="switcher-btn active">Dashboard 1</button>
            <button className="switcher-btn" onClick={() => setCurrentDash(2)}>
              Dashboard 2
            </button>
          </div>
        </div>
      ) : (
        <Dashboard2 onSwitchToDash1={() => setCurrentDash(1)} />
      )}
    </>
  );
}

export default App;
