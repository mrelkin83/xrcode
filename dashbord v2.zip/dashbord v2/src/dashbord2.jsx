import React, { useState } from 'react';
import './dashbord2.css';
import {
  LayoutGrid,
  Calendar,
  Mail,
  BarChart2,
  Users,
  Layers,
  Settings,
  ScanLine,
  HelpCircle,
  Search,
  Bell,
  Info,
  Sun,
  Moon,
  ChevronDown,
  Filter,
  Check,
  ArrowUpRight,
  TrendingUp,
  CreditCard,
  Download,
  Upload,
  Clock,
  Smile,
  Wallet,
  Compass,
  DollarSign,
  Shield,
  QrCode,
  MessageSquare,
  PieChart,
  FileText,
  Lock,
  ExternalLink,
  ArrowLeft,
  RefreshCw,
  Smartphone,
  PhoneCall,
  Copy,
  CheckCircle2,
  User,
  Building,
  AlertCircle
} from 'lucide-react';

export default function Dashboard2({ onSwitchToDash1 }) {
  const [activeNav, setActiveNav] = useState('menu');
  const [activeHeaderTab, setActiveHeaderTab] = useState('Portfolio Overview');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [selectedDay, setSelectedDay] = useState('Sun');
  const [toastMsg, setToastMsg] = useState('');

  // Settings State
  const [settingsForm, setSettingsForm] = useState({
    name: 'Thomas Anderson',
    email: 'thomas.invest@wealth.ca',
    taxId: '***-**-8492',
    currency: 'USD ($)',
    twoFactor: true,
    autoRebalance: true,
    dividendReinvest: true,
    biometrics: true,
    tradingLimit: '$50,000'
  });
  const [settingsTab, setSettingsTab] = useState('general');

  // Transactions State
  const [transactions, setTransactions] = useState([
    {
      id: 1,
      name: 'App Store Transaction',
      type: 'apple',
      iconText: 'A',
      price: '$24.99',
      date: '12 Apr 2026',
      time: '10:45 AM',
      note: '---',
      status: 'Failed',
      checked: false,
    },
    {
      id: 2,
      name: 'Live Concert',
      type: 'concert',
      iconText: '♫',
      price: '$320.00',
      date: '10 Apr 2026',
      time: '08:30 PM',
      note: 'Tickets for live concert',
      status: 'Successful',
      checked: true,
    },
    {
      id: 3,
      name: 'Grocery Purchase',
      type: 'grocery',
      iconText: '🌱',
      price: '$76.20',
      date: '14 Apr 2026',
      time: '07:10 PM',
      note: 'Booked tickets for plann...',
      status: 'Pending',
      checked: false,
    },
    {
      id: 4,
      name: 'Software License',
      type: 'software',
      iconText: '■',
      price: '$149.30',
      date: '11 Apr 2026',
      time: '04:15 PM',
      note: 'Tools needed for project',
      status: 'Successful',
      checked: false,
    },
  ]);

  const toggleCheck = (id) => {
    setTransactions((prev) =>
      prev.map((t) => (t.id === id ? { ...t, checked: !t.checked } : t))
    );
  };

  const showToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 2200);
  };

  // Stepped chart points corresponding to each day
  const chartPoints = [
    { day: 'Wed', value: '$65.4', x: 20, y: 88 },
    { day: 'Thu', value: '$72.1', x: 70, y: 78 },
    { day: 'Fri', value: '$84.0', x: 120, y: 55 },
    { day: 'Sat', value: '$79.2', x: 170, y: 62 },
    { day: 'Sun', value: '$126.3', x: 220, y: 22 }, // Highlighted peak!
    { day: 'Mon', value: '$95.8', x: 270, y: 72 },
    { day: 'Tue', value: '$91.0', x: 320, y: 75 },
  ];

  const activePoint = chartPoints.find((p) => p.day === selectedDay) || chartPoints[4];

  return (
    <div className="d2-viewport">
      <div className="d2-container">
        {/* =========================================================
            LEFT SIDEBAR (WHITE CAPSULE)
            ========================================================= */}
        <aside className="d2-sidebar">
          {/* Top 4-Square Grid Logo */}
          <div
            className={`d2-sidebar-top-logo ${activeNav === 'menu' ? 'active' : ''}`}
            title="Portfolio Overview"
            onClick={() => {
              setActiveNav('menu');
              showToast('Portfolio Overview');
            }}
          >
            <LayoutGrid size={18} strokeWidth={2.4} />
          </div>

          {/* Navigation Icons Column */}
          <nav className="d2-sidebar-nav">
            <button
              className={`d2-sidebar-btn ${activeNav === 'calendar' ? 'active' : ''}`}
              onClick={() => {
                setActiveNav('calendar');
                showToast('Financial Calendar');
              }}
              title="Financial Calendar"
            >
              <Calendar size={17} strokeWidth={2} />
            </button>
            <button
              className={`d2-sidebar-btn ${activeNav === 'mail' ? 'active' : ''}`}
              onClick={() => {
                setActiveNav('mail');
                showToast('Messages & Alerts');
              }}
              title="Messages & Notifications"
            >
              <Mail size={17} strokeWidth={2} />
            </button>
            <button
              className={`d2-sidebar-btn ${activeNav === 'stats' ? 'active' : ''}`}
              onClick={() => {
                setActiveNav('stats');
                showToast('Portfolio Analytics');
              }}
              title="In-depth Analytics"
            >
              <BarChart2 size={17} strokeWidth={2} />
            </button>
            <button
              className={`d2-sidebar-btn ${activeNav === 'users' ? 'active' : ''}`}
              onClick={() => {
                setActiveNav('users');
                showToast('Investor Team & Accounts');
              }}
              title="Team & Joint Accounts"
            >
              <Users size={17} strokeWidth={2} />
            </button>
            <button
              className={`d2-sidebar-btn ${activeNav === 'layers' ? 'active' : ''}`}
              onClick={() => {
                setActiveNav('layers');
                showToast('Multi-Portfolios');
              }}
              title="Portfolios & Assets"
            >
              <Layers size={17} strokeWidth={2} />
            </button>
            <button
              className={`d2-sidebar-btn ${activeNav === 'settings' ? 'active' : ''}`}
              onClick={() => {
                setActiveNav('settings');
                showToast('Account Settings');
              }}
              title="Settings & Preferences"
            >
              <Settings size={17} strokeWidth={2} />
            </button>

            <div className="d2-sidebar-divider"></div>

            <button
              className={`d2-sidebar-btn ${activeNav === 'scan' ? 'active' : ''}`}
              onClick={() => {
                setActiveNav('scan');
                showToast('QR Terminal & Wallet');
              }}
              title="Scan QR & Connect"
            >
              <ScanLine size={17} strokeWidth={2} />
            </button>
            <button
              className={`d2-sidebar-btn ${activeNav === 'help' ? 'active' : ''}`}
              onClick={() => {
                setActiveNav('help');
                showToast('24/7 VIP Support');
              }}
              title="Help & Support"
            >
              <HelpCircle size={17} strokeWidth={2} />
            </button>
          </nav>

          {/* User Avatar at Bottom */}
          <div className="d2-sidebar-bottom">
            <div
              className={`d2-avatar-circle ${activeNav === 'profile' ? 'active' : ''}`}
              title="User Profile - Thomas Anderson"
              onClick={() => {
                setActiveNav('profile');
                showToast('Investor Profile');
              }}
            >
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                alt="Avatar"
              />
            </div>
          </div>
        </aside>

        {/* =========================================================
            MAIN DASHBOARD AREA
            ========================================================= */}
        <main className="d2-main">
          {/* TOP HEADER */}
          <header className="d2-header">
            <div className="d2-header-left">
              {/* Maple Leaf Badge */}
              <div className="d2-leaf-badge" title="Canada Portfolio">
                <svg width="20" height="20" viewBox="0 0 32 32" fill="none">
                  <circle cx="16" cy="16" r="14.5" fill="#ffffff" stroke="#ef4444" strokeWidth="1.5" />
                  <path
                    d="M16 6 L17.5 10.5 L20.5 9.5 L19.5 12.5 L23.5 13 L21 16 L24 18 L21.5 19.5 L22 22 L17.5 20.5 L17 25 L15 25 L14.5 20.5 L10 22 L10.5 19.5 L8 18 L11 16 L8.5 13 L12.5 12.5 L11.5 9.5 L14.5 10.5 Z"
                    fill="#ef4444"
                  />
                </svg>
              </div>

              {/* Navigation Pill Bar */}
              <div className="d2-header-nav-pills">
                {['Portfolio Overview', 'Activity', 'Key Metrics', 'Reports'].map(
                  (tab, idx) => (
                    <button
                      key={idx}
                      className={`d2-nav-item ${
                        activeHeaderTab === tab ? 'active' : ''
                      }`}
                      onClick={() => setActiveHeaderTab(tab)}
                    >
                      {tab}
                    </button>
                  )
                )}
              </div>
            </div>

            {/* Right Action Icons & Theme Toggle */}
            <div className="d2-header-right">
              <button
                className="d2-icon-circle-btn"
                title="Search"
                onClick={() => showToast('Search triggered')}
              >
                <Search size={15} />
              </button>

              <button
                className="d2-icon-circle-btn"
                title="Notifications"
                onClick={() => showToast('1 New Notification')}
              >
                <Bell size={15} />
                <span className="d2-badge-count">1</span>
              </button>

              <button
                className="d2-icon-circle-btn"
                title="Information"
                onClick={() => showToast('Market Info & Help')}
              >
                <Info size={15} />
              </button>

              {/* Day / Night Theme Toggle */}
              <div
                className="d2-theme-toggle-pill"
                onClick={() => setIsDarkMode(!isDarkMode)}
                title="Toggle Theme"
              >
                <span className={`d2-theme-icon ${!isDarkMode ? 'active' : ''}`}>
                  <Sun size={13} />
                </span>
                <span className={`d2-theme-icon ${isDarkMode ? 'active' : ''}`}>
                  <Moon size={13} />
                </span>
              </div>
            </div>
          </header>

          {/* =========================================================
              MAIN CONTENT OR DYNAMIC SUBVIEWS
              ========================================================= */}
          {activeNav === 'menu' ? (
            <>
              {/* =========================================================
                  ROW 1: TOP 4 BENTO FEATURE CARDS
                  ========================================================= */}
              <section className="d2-row-top">
                {/* Card 1: Invest for your future */}
                <div className="d2-card-feature">
                  <div className="d2-feature-header">
                    <h3 className="d2-feature-title">
                      Invest <span>for your future</span>
                    </h3>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#717680" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                      <path d="M3 3v5h5" />
                      <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
                      <path d="M16 21h5v-5" />
                    </svg>
                  </div>
                  <div
                    className="d2-pill-badge"
                    onClick={() => showToast('Balance: $254.32')}
                  >
                    $254.32
                  </div>
                </div>

                {/* Card 2: Early for kids */}
                <div className="d2-card-feature">
                  <div className="d2-feature-header">
                    <h3 className="d2-feature-title">
                      Early <span>for kids</span>
                    </h3>
                    <Smile size={17} className="d2-feature-icon" />
                  </div>
                  <div
                    className="d2-pill-badge"
                    onClick={() => showToast('Exploring Junior Plans')}
                  >
                    Explore
                  </div>
                </div>

                {/* Card 3: Balance your budget */}
                <div className="d2-card-feature">
                  <div className="d2-feature-header">
                    <h3 className="d2-feature-title">
                      Balance <span>your budget</span>
                    </h3>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#717680" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect width="20" height="14" x="2" y="5" rx="2" />
                      <line x1="2" x2="22" y1="10" y2="10" />
                      <circle cx="18" cy="14" r="1" fill="#717680" />
                    </svg>
                  </div>
                  <div
                    className="d2-pill-badge"
                    onClick={() => showToast('April Budget Selected')}
                  >
                    April
                  </div>
                </div>

                {/* Card 4 (Banner): Retire on your terms */}
                <div className="d2-card-banner">
                  <div className="d2-banner-header">
                    <h3 className="d2-banner-title">
                      Retire <span>on your terms</span>
                    </h3>
                    <div className="d2-banner-clock">
                      <Clock size={14} strokeWidth={2.5} />
                    </div>
                  </div>

                  <div className="d2-banner-bottom">
                    <button
                      className="d2-banner-btn"
                      onClick={() => showToast('Exploring Retirement Plans')}
                    >
                      Explore
                    </button>

                    <div className="d2-soundwave-bars">
                      {[4, 7, 10, 5, 12, 8, 16, 11, 20, 14, 25, 18, 22, 27, 16, 21, 24, 28, 19, 23, 27].map(
                        (h, i) => (
                          <div
                            key={i}
                            className="d2-wave-bar"
                            style={{ height: `${h}px` }}
                          ></div>
                        )
                      )}
                    </div>
                  </div>
                </div>
              </section>

              {/* =========================================================
                  ROW 2: MIDDLE SECTION (3 COLUMNS)
                  ========================================================= */}
              <section className="d2-row-middle">
                {/* Column 1: Current Price & Stock Ticker */}
                <div className="d2-card-stock">
                  <div className="d2-stock-header">
                    <div>
                      <p className="d2-stock-label">Current Price</p>
                      <h2 className="d2-stock-price">114.72 USD</h2>
                    </div>
                    <div
                      className="d2-stock-flag-pill"
                      onClick={() => showToast('Currency: USD')}
                    >
                      <span className="d2-flag-icon">🇺🇸</span>
                      <span>USD</span>
                      <ChevronDown size={11} />
                    </div>
                  </div>

                  {/* 2x3 Metric Grid with vertical divider */}
                  <div className="d2-stock-stats-grid">
                    <div className="d2-stat-col">
                      <div className="d2-stat-item">
                        <span className="d2-stat-key">Open</span>
                        <span className="d2-stat-val">124.9</span>
                      </div>
                      <div className="d2-stat-item">
                        <span className="d2-stat-key">High</span>
                        <span className="d2-stat-val">115.1</span>
                      </div>
                      <div className="d2-stat-item">
                        <span className="d2-stat-key">Low</span>
                        <span className="d2-stat-val">36.7</span>
                      </div>
                    </div>

                    <div className="d2-stat-divider-v"></div>

                    <div className="d2-stat-col">
                      <div className="d2-stat-item">
                        <span className="d2-stat-key">Vol</span>
                        <span className="d2-stat-val">32.6M</span>
                      </div>
                      <div className="d2-stat-item">
                        <span className="d2-stat-key">P/E</span>
                        <span className="d2-stat-val">12.4</span>
                      </div>
                      <div className="d2-stat-item">
                        <span className="d2-stat-key">Mkt Cap</span>
                        <span className="d2-stat-val">6.004T</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons: Sell & Buy */}
                  <div className="d2-stock-actions">
                    <button
                      className="d2-btn-sell"
                      onClick={() => showToast('Order Placed: Sell')}
                    >
                      Sell
                    </button>
                    <button
                      className="d2-btn-buy"
                      onClick={() => showToast('Order Placed: Buy')}
                    >
                      Buy
                    </button>
                  </div>
                </div>

                {/* Column 2: Active Users Stepped Area Graph */}
                <div className="d2-card-chart">
                  <div className="d2-chart-header">
                    <h3 className="d2-chart-title">Active Users</h3>
                    <p className="d2-chart-subtitle">
                      View your income in a certain period of time
                    </p>
                  </div>

                  <div className="d2-chart-body">
                    <div className="d2-chart-y-axis">
                      <span>30k</span>
                      <span>20k</span>
                      <span>10k</span>
                      <span>0k</span>
                    </div>

                    <div className="d2-chart-svg-area">
                      <svg
                        width="100%"
                        height="100%"
                        viewBox="0 0 340 120"
                        preserveAspectRatio="none"
                      >
                        <defs>
                          <linearGradient
                            id="sundayGlow"
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                          >
                            <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.45" />
                            <stop offset="100%" stopColor="#fb923c" stopOpacity="0.05" />
                          </linearGradient>
                          <pattern
                            id="dotGrid"
                            x="0"
                            y="0"
                            width="16"
                            height="16"
                            patternUnits="userSpaceOnUse"
                          >
                            <circle cx="2" cy="2" r="0.8" fill="#e5e7eb" />
                          </pattern>
                        </defs>

                        <rect
                          x="0"
                          y="10"
                          width="340"
                          height="95"
                          fill="url(#dotGrid)"
                        />

                        {/* Sunday Highlight Vertical Bar */}
                        <rect
                          x="202"
                          y="22"
                          width="28"
                          height="88"
                          fill="url(#sundayGlow)"
                          rx="3"
                        />

                        {/* Dotted Center Guide Line on Sunday */}
                        <line
                          x1="216"
                          y1="22"
                          x2="216"
                          y2="110"
                          stroke="#fb7185"
                          strokeWidth="1.2"
                          strokeDasharray="2,2"
                        />

                        {/* Stepped Line Path */}
                        <path
                          d="M 0,92 L 20,88 L 45,88 L 55,78 L 90,78 L 100,55 L 140,55 L 150,62 L 195,62 L 202,22 L 230,22 L 238,72 L 290,72 L 300,75 L 340,75"
                          fill="none"
                          stroke="#f43f5e"
                          strokeWidth="2.4"
                          strokeLinejoin="round"
                        />

                        {/* Peak Circle */}
                        <circle
                          cx={activePoint.x}
                          cy={activePoint.y}
                          r="4"
                          fill="#121316"
                          stroke="#ffffff"
                          strokeWidth="2"
                        />
                      </svg>

                      <div
                        style={{
                          position: 'absolute',
                          left: '64%',
                          top: '12%',
                          background: '#ffffff',
                          boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
                          border: '1px solid #f0f2f5',
                          borderRadius: '8px',
                          padding: '2px 8px',
                          fontSize: '10px',
                          fontWeight: 800,
                          color: '#121316',
                          pointerEvents: 'none',
                        }}
                      >
                        $126.3
                      </div>
                    </div>
                  </div>

                  <div className="d2-chart-days-row">
                    {chartPoints.map((p) => (
                      <span
                        key={p.day}
                        className={`d2-day-label ${
                          selectedDay === p.day ? 'active' : ''
                        }`}
                        onClick={() => setSelectedDay(p.day)}
                        style={{ cursor: 'pointer' }}
                      >
                        {p.day}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Column 3: 2x2 Metrics Grid */}
                <div className="d2-metrics-2x2">
                  <div className="d2-metric-tile">
                    <div className="d2-metric-top">
                      <p className="d2-metric-label">Portfolio Type</p>
                    </div>
                    <h4 className="d2-metric-value">General</h4>
                  </div>

                  <div className="d2-metric-tile">
                    <div className="d2-metric-top">
                      <p className="d2-metric-label">Total Investment</p>
                      <div className="d2-badge-row">
                        <span className="d2-metric-badge d2-badge-orange-red">
                          -1.321%
                        </span>
                        <span className="d2-badge-subtext">Last 7 days</span>
                      </div>
                    </div>
                    <h4 className="d2-metric-value">$4,389.80</h4>
                  </div>

                  <div className="d2-metric-tile">
                    <div className="d2-metric-top">
                      <p className="d2-metric-label">Net Growth Score</p>
                      <div className="d2-badge-row">
                        <span className="d2-metric-badge d2-badge-magenta">
                          -1.45%
                        </span>
                        <span className="d2-badge-subtext">Last 7 days</span>
                      </div>
                    </div>
                    <h4 className="d2-metric-value">$7,320</h4>
                  </div>

                  <div className="d2-metric-tile">
                    <div className="d2-metric-top">
                      <p className="d2-metric-label">Strategy Type</p>
                    </div>
                    <h4 className="d2-metric-value">Steady Growth</h4>
                  </div>
                </div>
              </section>

              {/* =========================================================
                  ROW 3: BOTTOM SECTION (TRANSACTIONS & WALLET)
                  ========================================================= */}
              <section className="d2-row-bottom">
                <div className="d2-card-transactions">
                  <div className="d2-tx-header">
                    <h3 className="d2-tx-title">Recent Transaction</h3>
                    <div className="d2-tx-controls">
                      <button
                        className="d2-filter-pill"
                        onClick={() => showToast('Period Filter: This Week')}
                      >
                        <span>This Week</span>
                        <ChevronDown size={12} />
                      </button>
                      <button
                        className="d2-filter-pill"
                        onClick={() => showToast('Transactions Filter opened')}
                      >
                        <span>Filter</span>
                        <Filter size={11} />
                      </button>
                    </div>
                  </div>

                  <table className="d2-tx-table">
                    <thead>
                      <tr>
                        <th style={{ width: '28px' }}></th>
                        <th>Activity</th>
                        <th>Price</th>
                        <th>Date</th>
                        <th>Note</th>
                        <th style={{ textAlign: 'right' }}>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {transactions.map((tx) => (
                        <tr key={tx.id}>
                          <td>
                            <div
                              className={`d2-checkbox ${tx.checked ? 'checked' : ''}`}
                              onClick={() => toggleCheck(tx.id)}
                            >
                              {tx.checked && <Check size={11} strokeWidth={3} />}
                            </div>
                          </td>
                          <td>
                            <div className="d2-activity-cell">
                              {tx.type === 'apple' && (
                                <span className="d2-activity-icon apple">
                                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                                    <rect width="24" height="24" rx="5" fill="#0071e3" />
                                    <path d="M12 4.5 L7.5 17.5 M12 4.5 L16.5 17.5 M6 13.5 L18 13.5" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
                                  </svg>
                                </span>
                              )}
                              {tx.type === 'concert' && (
                                <span className="d2-activity-icon concert">
                                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                                    <rect width="24" height="24" rx="5" fill="#f43f5e" />
                                    <path d="M9 16V6l9-2v10" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                    <circle cx="7" cy="16" r="2.5" fill="#ffffff" />
                                    <circle cx="16" cy="14" r="2.5" fill="#ffffff" />
                                  </svg>
                                </span>
                              )}
                              {tx.type === 'grocery' && (
                                <span className="d2-activity-icon grocery">
                                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                                    <rect width="24" height="24" rx="5" fill="#22c55e" />
                                    <path d="M12 19V11 M12 11c0-4 4-5 6-5-1 4-3 5-6 5zm0 0c0-4-4-5-6-5 1 4 3 5 6 5z" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                  </svg>
                                </span>
                              )}
                              {tx.type === 'software' && (
                                <span className="d2-activity-icon software">
                                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                                    <rect x="1" y="1" width="7" height="7" rx="1.5" fill="#f25022" />
                                    <rect x="10" y="1" width="7" height="7" rx="1.5" fill="#7fba00" />
                                    <rect x="1" y="10" width="7" height="7" rx="1.5" fill="#00a4ef" />
                                    <rect x="10" y="10" width="7" height="7" rx="1.5" fill="#ffb900" />
                                  </svg>
                                </span>
                              )}
                              <span>{tx.name}</span>
                            </div>
                          </td>
                          <td style={{ fontWeight: 700 }}>{tx.price}</td>
                          <td>
                            <span style={{ fontWeight: 700 }}>{tx.date}</span>
                            <span className="d2-date-subtext">{tx.time}</span>
                          </td>
                          <td style={{ color: '#8c919d' }}>{tx.note}</td>
                          <td style={{ textAlign: 'right' }}>
                            <span
                              className={`d2-status-tag ${
                                tx.status === 'Failed'
                                  ? 'failed'
                                  : tx.status === 'Successful'
                                  ? 'success'
                                  : 'pending'
                              }`}
                            >
                              {tx.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Right Stacked Column */}
                <div className="d2-col-wallet">
                  <div className="d2-card-balance">
                    <svg
                      className="d2-balance-watermark"
                      viewBox="0 0 100 100"
                      fill="none"
                    >
                      <path
                        d="M50 0 C50 25, 75 50, 100 50 C75 50, 50 75, 50 100 C50 75, 25 50, 0 50 C25 50, 50 25, 50 0 Z"
                        stroke="#ffffff"
                        strokeWidth="4"
                        fill="none"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="15"
                        stroke="#ffffff"
                        strokeWidth="3"
                      />
                    </svg>

                    <p className="d2-balance-label">Your Balance</p>
                    <h2 className="d2-balance-amount">70,147.41 USD</h2>

                    <div className="d2-balance-actions">
                      <div
                        className="d2-balance-action-btn"
                        onClick={() => showToast('Deposit Initiated')}
                      >
                        <div className="d2-action-circle">
                          <Download size={16} />
                        </div>
                        <span className="d2-action-label">Deposit</span>
                      </div>

                      <div
                        className="d2-balance-action-btn"
                        onClick={() => showToast('Withdraw Initiated')}
                      >
                        <div className="d2-action-circle">
                          <Upload size={16} />
                        </div>
                        <span className="d2-action-label">Withdraw</span>
                      </div>

                      <div
                        className="d2-balance-action-btn"
                        onClick={() => showToast('Transfer Initiated')}
                      >
                        <div className="d2-action-circle highlight">
                          <CreditCard size={16} />
                        </div>
                        <span className="d2-action-label">Transfer</span>
                      </div>
                    </div>
                  </div>

                  <div className="d2-card-invest-summary">
                    <p className="d2-invest-summary-text">
                      You Invest <strong>$1226.3</strong> in
                    </p>
                    <p className="d2-invest-summary-sub">Last 30 Days</p>
                  </div>
                </div>
              </section>
            </>
          ) : (
            /* =========================================================
               DYNAMIC SUBVIEWS (SETTINGS, CALENDAR, MAIL, STATS, ETC.)
               ========================================================= */
            <div className="d2-subview-wrapper">
              {/* Top Subview Navigation / Header */}
              <div className="d2-subview-header">
                <div className="d2-subview-title-wrap">
                  <h2 className="d2-subview-title">
                    {activeNav === 'settings' && 'Account Settings & Preferences'}
                    {activeNav === 'calendar' && 'Financial Calendar & Schedules'}
                    {activeNav === 'mail' && 'Inbox & Market Notifications'}
                    {activeNav === 'stats' && 'In-depth Portfolio Analytics'}
                    {activeNav === 'users' && 'Investor Network & Joint Accounts'}
                    {activeNav === 'layers' && 'Multi-Portfolio Asset Vaults'}
                    {activeNav === 'scan' && 'QR Terminal & Hardware Connect'}
                    {activeNav === 'help' && '24/7 VIP Financial Concierge'}
                    {activeNav === 'profile' && 'Investor Profile & KYC Status'}
                  </h2>
                  <p className="d2-subview-subtitle">
                    {activeNav === 'settings' && 'Manage your personal investor profile, trading permissions, and security'}
                    {activeNav === 'calendar' && 'Upcoming dividend distributions, earnings releases, and auto-buy dates'}
                    {activeNav === 'mail' && 'Direct broker confirmations, price triggers, and private advisor communication'}
                    {activeNav === 'stats' && 'Risk-adjusted Sharpe ratios, sector diversification, and asset breakdown'}
                    {activeNav === 'users' && 'Authorized co-signers, private wealth managers, and estate trustees'}
                    {activeNav === 'layers' && 'Active asset holdings across growth, retirement, and innovation accounts'}
                    {activeNav === 'scan' && 'Instant point-of-sale transfer terminal and Web3 cold-storage pairing'}
                    {activeNav === 'help' && 'Dedicated private wealth desk with sub-minute response SLA'}
                    {activeNav === 'profile' && 'Accredited investor certification and global tax reporting'}
                  </p>
                </div>
                <button
                  className="d2-subview-back-btn"
                  onClick={() => setActiveNav('menu')}
                >
                  <ArrowLeft size={13} />
                  <span>Back to Overview</span>
                </button>
              </div>

              {/* VIEW 1: SETTINGS */}
              {activeNav === 'settings' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div className="d2-subview-grid-2col">
                    {/* Left: Investor Profile & Tax Details */}
                    <div className="d2-subview-card">
                      <h3 className="d2-card-section-title">
                        <span>Personal &amp; Tax Information</span>
                        <User size={15} color="#7c828d" />
                      </h3>

                      <div className="d2-form-group">
                        <div className="d2-form-row">
                          <span className="d2-form-label">Full Legal Name</span>
                          <input
                            className="d2-form-input"
                            value={settingsForm.name}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, name: e.target.value })
                            }
                          />
                        </div>

                        <div className="d2-form-row">
                          <span className="d2-form-label">Investor Email</span>
                          <input
                            className="d2-form-input"
                            value={settingsForm.email}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, email: e.target.value })
                            }
                          />
                        </div>

                        <div className="d2-form-row">
                          <span className="d2-form-label">Tax ID (TIN / SSN)</span>
                          <input
                            className="d2-form-input"
                            value={settingsForm.taxId}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, taxId: e.target.value })
                            }
                          />
                        </div>

                        <div className="d2-form-row">
                          <span className="d2-form-label">Base Currency</span>
                          <select
                            className="d2-form-input"
                            value={settingsForm.currency}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, currency: e.target.value })
                            }
                          >
                            <option>USD ($)</option>
                            <option>CAD ($)</option>
                            <option>EUR (€)</option>
                            <option>GBP (£)</option>
                          </select>
                        </div>
                      </div>

                      <button
                        className="d2-action-btn-dark"
                        onClick={() => showToast('✓ Personal profile saved successfully!')}
                      >
                        Save Personal Info
                      </button>
                    </div>

                    {/* Right: Security & Trading Toggles */}
                    <div className="d2-subview-card">
                      <h3 className="d2-card-section-title">
                        <span>Security &amp; Trading Protection</span>
                        <Shield size={15} color="#7c828d" />
                      </h3>

                      <div className="d2-form-group">
                        <div className="d2-form-row">
                          <div>
                            <p className="d2-form-label" style={{ margin: 0 }}>Two-Factor Authentication (2FA)</p>
                            <span style={{ fontSize: '10px', color: '#8c919d' }}>Authenticator app required on withdrawal</span>
                          </div>
                          <div
                            className={`d2-switch ${settingsForm.twoFactor ? 'active' : ''}`}
                            onClick={() =>
                              setSettingsForm({
                                ...settingsForm,
                                twoFactor: !settingsForm.twoFactor,
                              })
                            }
                          >
                            <div className="d2-switch-thumb"></div>
                          </div>
                        </div>

                        <div className="d2-form-row">
                          <div>
                            <p className="d2-form-label" style={{ margin: 0 }}>Biometric FaceID / TouchID</p>
                            <span style={{ fontSize: '10px', color: '#8c919d' }}>Instant login on trusted devices</span>
                          </div>
                          <div
                            className={`d2-switch ${settingsForm.biometrics ? 'active' : ''}`}
                            onClick={() =>
                              setSettingsForm({
                                ...settingsForm,
                                biometrics: !settingsForm.biometrics,
                              })
                            }
                          >
                            <div className="d2-switch-thumb"></div>
                          </div>
                        </div>

                        <div className="d2-form-row">
                          <div>
                            <p className="d2-form-label" style={{ margin: 0 }}>Auto-Rebalance Portfolio</p>
                            <span style={{ fontSize: '10px', color: '#8c919d' }}>Quarterly target allocation tuning</span>
                          </div>
                          <div
                            className={`d2-switch ${settingsForm.autoRebalance ? 'active' : ''}`}
                            onClick={() =>
                              setSettingsForm({
                                ...settingsForm,
                                autoRebalance: !settingsForm.autoRebalance,
                              })
                            }
                          >
                            <div className="d2-switch-thumb"></div>
                          </div>
                        </div>

                        <div className="d2-form-row">
                          <div>
                            <p className="d2-form-label" style={{ margin: 0 }}>Dividend Reinvestment (DRIP)</p>
                            <span style={{ fontSize: '10px', color: '#8c919d' }}>Auto-reinvest cash dividends into stock</span>
                          </div>
                          <div
                            className={`d2-switch ${settingsForm.dividendReinvest ? 'active' : ''}`}
                            onClick={() =>
                              setSettingsForm({
                                ...settingsForm,
                                dividendReinvest: !settingsForm.dividendReinvest,
                              })
                            }
                          >
                            <div className="d2-switch-thumb"></div>
                          </div>
                        </div>
                      </div>

                      <button
                        className="d2-action-btn-dark"
                        onClick={() => showToast('✓ Security preferences updated!')}
                      >
                        Update Security
                      </button>
                    </div>
                  </div>

                  {/* Linked Bank Accounts */}
                  <div className="d2-subview-card">
                    <h3 className="d2-card-section-title">
                      <span>Linked Financial Institutions</span>
                      <Building size={15} color="#7c828d" />
                    </h3>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
                      <div className="d2-bank-item">
                        <div className="d2-bank-info">
                          <div className="d2-bank-icon-box">🏛️</div>
                          <div>
                            <p className="d2-bank-name">Chase Private Client</p>
                            <p className="d2-bank-acc">Checking •••• 3921</p>
                          </div>
                        </div>
                        <span className="d2-status-tag success">Primary</span>
                      </div>

                      <div className="d2-bank-item">
                        <div className="d2-bank-info">
                          <div className="d2-bank-icon-box">🏦</div>
                          <div>
                            <p className="d2-bank-name">Silicon Valley Wealth</p>
                            <p className="d2-bank-acc">Wire Account •••• 8820</p>
                          </div>
                        </div>
                        <span className="d2-status-tag success">Verified</span>
                      </div>

                      <div className="d2-bank-item">
                        <div className="d2-bank-info">
                          <div className="d2-bank-icon-box">💳</div>
                          <div>
                            <p className="d2-bank-name">Apple Card Goldman</p>
                            <p className="d2-bank-acc">Mastercard •••• 4012</p>
                          </div>
                        </div>
                        <span className="d2-status-tag pending">Linked</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 2: CALENDAR */}
              {activeNav === 'calendar' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div className="d2-subview-grid-3col">
                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Next Dividend Distribution</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '18px', fontWeight: 800 }}>Apr 24, 2026</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '12px', color: '#16a34a', fontWeight: 700 }}>+$184.50 USD (Apple Inc)</p>
                    </div>
                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Monthly Expected Yield</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '18px', fontWeight: 800 }}>$612.80 USD</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '12px', color: '#8c919d' }}>Across 8 dividend assets</p>
                    </div>
                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Scheduled Auto-Invest</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '18px', fontWeight: 800 }}>$1,500.00 / mo</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '12px', color: '#f43f5e', fontWeight: 700 }}>Next debit: Apr 28</p>
                    </div>
                  </div>

                  <div className="d2-subview-card">
                    <h3 className="d2-card-section-title">
                      <span>Scheduled Financial Events</span>
                      <Calendar size={15} color="#7c828d" />
                    </h3>

                    <div className="d2-event-item">
                      <div className="d2-event-date-box">
                        <span>APR</span>
                        <div style={{ fontSize: '14px', fontWeight: 800 }}>24</div>
                      </div>
                      <div className="d2-event-content">
                        <h4 className="d2-event-title">Apple Inc (AAPL) — Q2 Cash Dividend</h4>
                        <p className="d2-event-desc">$184.50 USD credited to Core Cash Wallet automatically</p>
                      </div>
                      <span className="d2-status-tag success">Confirmed</span>
                    </div>

                    <div className="d2-event-item">
                      <div className="d2-event-date-box">
                        <span>APR</span>
                        <div style={{ fontSize: '14px', fontWeight: 800 }}>28</div>
                      </div>
                      <div className="d2-event-content">
                        <h4 className="d2-event-title">Vanguard S&amp;P 500 ETF (VOO) — Recurring Buy</h4>
                        <p className="d2-event-desc">$500.00 USD auto-debit from Chase Private Client</p>
                      </div>
                      <span className="d2-status-tag pending">Scheduled</span>
                    </div>

                    <div className="d2-event-item">
                      <div className="d2-event-date-box">
                        <span>MAY</span>
                        <div style={{ fontSize: '14px', fontWeight: 800 }}>02</div>
                      </div>
                      <div className="d2-event-content">
                        <h4 className="d2-event-title">Federal Reserve FOMC Rate Decision</h4>
                        <p className="d2-event-desc">Macroeconomic monetary policy announcement &amp; press conference</p>
                      </div>
                      <span className="d2-status-tag" style={{ background: '#eff6ff', color: '#3b82f6' }}>Macro Event</span>
                    </div>

                    <div className="d2-event-item">
                      <div className="d2-event-date-box">
                        <span>MAY</span>
                        <div style={{ fontSize: '14px', fontWeight: 800 }}>10</div>
                      </div>
                      <div className="d2-event-content">
                        <h4 className="d2-event-title">Microsoft Corp (MSFT) — Q3 2026 Earnings Call</h4>
                        <p className="d2-event-desc">Live audio webcast &amp; quarterly cloud revenue release</p>
                      </div>
                      <span className="d2-status-tag" style={{ background: '#f5f3ff', color: '#8b5cf6' }}>Earnings</span>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 3: MAIL & NOTIFICATIONS */}
              {activeNav === 'mail' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div className="d2-subview-card">
                    <h3 className="d2-card-section-title">
                      <span>Broker Alerts &amp; Advisor Inbox</span>
                      <span style={{ fontSize: '11px', color: '#f43f5e', fontWeight: 700 }}>2 New Messages</span>
                    </h3>

                    <div className="d2-inbox-item unread" onClick={() => showToast('Viewing trade confirmation')}>
                      <div className="d2-inbox-avatar" style={{ background: '#e0f2fe', color: '#0284c7' }}>📈</div>
                      <div className="d2-inbox-text-box">
                        <div className="d2-inbox-subject">
                          <span>Trade Executed: BUY 15 AAPL @ $114.72 USD</span>
                          <span className="d2-inbox-time">12 mins ago</span>
                        </div>
                        <p className="d2-inbox-snippet">
                          Your limit order of 15 shares of Apple Inc filled at $114.72 USD. Order ID: #ORD-99214. Cash settlement cleared.
                        </p>
                      </div>
                    </div>

                    <div className="d2-inbox-item unread" onClick={() => showToast('Opening advisor message')}>
                      <div className="d2-inbox-avatar" style={{ background: '#fef3c7', color: '#d97706' }}>💬</div>
                      <div className="d2-inbox-text-box">
                        <div className="d2-inbox-subject">
                          <span>Sarah Jenkins (Senior Wealth Advisor)</span>
                          <span className="d2-inbox-time">1 hour ago</span>
                        </div>
                        <p className="d2-inbox-snippet">
                          "Hi Thomas, I completed the quarterly tax-loss harvesting review for your Growth Portfolio. Let me know when you'd like to schedule our 15-minute call."
                        </p>
                      </div>
                    </div>

                    <div className="d2-inbox-item" onClick={() => showToast('Opening statement')}>
                      <div className="d2-inbox-avatar" style={{ background: '#f0fdf4', color: '#16a34a' }}>📄</div>
                      <div className="d2-inbox-text-box">
                        <div className="d2-inbox-subject">
                          <span>March 2026 Consolidated Statement Ready</span>
                          <span className="d2-inbox-time">Yesterday</span>
                        </div>
                        <p className="d2-inbox-snippet">
                          Your audited monthly asset valuation statement is available for PDF download in the tax center.
                        </p>
                      </div>
                    </div>

                    <div className="d2-inbox-item" onClick={() => showToast('Viewing deposit receipt')}>
                      <div className="d2-inbox-avatar" style={{ background: '#f5f3ff', color: '#7c3aed' }}>🏦</div>
                      <div className="d2-inbox-text-box">
                        <div className="d2-inbox-subject">
                          <span>Deposit Received: $10,000.00 USD</span>
                          <span className="d2-inbox-time">3 days ago</span>
                        </div>
                        <p className="d2-inbox-snippet">
                          Wire transfer from Chase Private Client •••• 3921 settled successfully into your High-Yield Cash reserve.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 4: STATS & ANALYTICS */}
              {activeNav === 'stats' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div className="d2-subview-grid-3col">
                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Cumulative All-Time ROI</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: 800, color: '#16a34a' }}>+34.20%</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '11px', color: '#8c919d' }}>+$17,820.00 net capital gain</p>
                    </div>
                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Sharpe Ratio (Risk-Adjusted)</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: 800 }}>2.45</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '11px', color: '#16a34a', fontWeight: 700 }}>Excellent risk/reward</p>
                    </div>
                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Portfolio Beta vs S&amp;P 500</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: 800 }}>0.85</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '11px', color: '#8c919d' }}>Defensive volatility rating</p>
                    </div>
                  </div>

                  <div className="d2-subview-grid-2col">
                    <div className="d2-subview-card">
                      <h3 className="d2-card-section-title">
                        <span>Sector Diversification</span>
                        <PieChart size={15} color="#7c828d" />
                      </h3>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        <div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', fontWeight: 700 }}>
                            <span>Information Technology</span>
                            <span>48%</span>
                          </div>
                          <div style={{ height: '6px', background: '#f0f2f5', borderRadius: '4px', overflow: 'hidden', marginTop: '3px' }}>
                            <div style={{ width: '48%', height: '100%', background: '#f43f5e', borderRadius: '4px' }}></div>
                          </div>
                        </div>

                        <div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', fontWeight: 700 }}>
                            <span>Financial Services</span>
                            <span>22%</span>
                          </div>
                          <div style={{ height: '6px', background: '#f0f2f5', borderRadius: '4px', overflow: 'hidden', marginTop: '3px' }}>
                            <div style={{ width: '22%', height: '100%', background: '#38bdf8', borderRadius: '4px' }}></div>
                          </div>
                        </div>

                        <div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', fontWeight: 700 }}>
                            <span>Healthcare &amp; Bio</span>
                            <span>16%</span>
                          </div>
                          <div style={{ height: '6px', background: '#f0f2f5', borderRadius: '4px', overflow: 'hidden', marginTop: '3px' }}>
                            <div style={{ width: '16%', height: '100%', background: '#4ade80', borderRadius: '4px' }}></div>
                          </div>
                        </div>

                        <div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', fontWeight: 700 }}>
                            <span>Clean Energy</span>
                            <span>14%</span>
                          </div>
                          <div style={{ height: '6px', background: '#f0f2f5', borderRadius: '4px', overflow: 'hidden', marginTop: '3px' }}>
                            <div style={{ width: '14%', height: '100%', background: '#fb923c', borderRadius: '4px' }}></div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="d2-subview-card">
                      <h3 className="d2-card-section-title">
                        <span>Top Performers vs Laggards</span>
                        <TrendingUp size={15} color="#7c828d" />
                      </h3>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px' }}>
                          <span style={{ fontWeight: 700 }}>Nvidia Corp (NVDA)</span>
                          <span style={{ color: '#16a34a', fontWeight: 800 }}>+84.2%</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px' }}>
                          <span style={{ fontWeight: 700 }}>Apple Inc (AAPL)</span>
                          <span style={{ color: '#16a34a', fontWeight: 800 }}>+28.4%</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px' }}>
                          <span style={{ fontWeight: 700 }}>Microsoft (MSFT)</span>
                          <span style={{ color: '#16a34a', fontWeight: 800 }}>+22.1%</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px' }}>
                          <span style={{ fontWeight: 700 }}>Tesla Inc (TSLA)</span>
                          <span style={{ color: '#ef4444', fontWeight: 800 }}>-6.4%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 5: USERS & TEAM */}
              {activeNav === 'users' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div className="d2-subview-card">
                    <h3 className="d2-card-section-title">
                      <span>Authorized Account Delegates &amp; Advisors</span>
                      <button
                        className="d2-filter-pill"
                        onClick={() => showToast('Invite link generated!')}
                      >
                        + Invite Advisor
                      </button>
                    </h3>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      <div className="d2-bank-item">
                        <div className="d2-bank-info">
                          <img
                            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&auto=format&fit=crop&q=80"
                            alt="Thomas"
                            style={{ width: '32px', height: '32px', borderRadius: '50%', objectFit: 'cover' }}
                          />
                          <div>
                            <p className="d2-bank-name">Thomas Anderson (You)</p>
                            <p className="d2-bank-acc">Primary Account Holder &amp; Trustee</p>
                          </div>
                        </div>
                        <span className="d2-status-tag success">Owner</span>
                      </div>

                      <div className="d2-bank-item">
                        <div className="d2-bank-info">
                          <div className="d2-bank-icon-box">👩‍💼</div>
                          <div>
                            <p className="d2-bank-name">Sarah Jenkins</p>
                            <p className="d2-bank-acc">Morgan Stanley Private Wealth Advisor</p>
                          </div>
                        </div>
                        <span className="d2-status-tag" style={{ background: '#eff6ff', color: '#3b82f6' }}>Advisory Access</span>
                      </div>

                      <div className="d2-bank-item">
                        <div className="d2-bank-info">
                          <div className="d2-bank-icon-box">👨‍⚖️</div>
                          <div>
                            <p className="d2-bank-name">Marcus Vance, CPA</p>
                            <p className="d2-bank-acc">Chartered Tax &amp; Estate Specialist</p>
                          </div>
                        </div>
                        <span className="d2-status-tag" style={{ background: '#f5f3ff', color: '#8b5cf6' }}>Tax Read-Only</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 6: LAYERS / PORTFOLIOS */}
              {activeNav === 'layers' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div className="d2-subview-grid-3col">
                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Core Growth Portfolio</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: 800 }}>$70,147.41 USD</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '11px', color: '#16a34a', fontWeight: 700 }}>+24.8% YTD · 14 Holdings</p>
                    </div>

                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Retirement Roth IRA</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: 800 }}>$28,450.00 USD</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '11px', color: '#16a34a', fontWeight: 700 }}>+14.2% YTD · 6 Index Funds</p>
                    </div>

                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Crypto &amp; Innovation Vault</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: 800 }}>$12,890.00 USD</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '11px', color: '#16a34a', fontWeight: 700 }}>+42.1% YTD · 5 Holdings</p>
                    </div>
                  </div>

                  <div className="d2-subview-card">
                    <h3 className="d2-card-section-title">
                      <span>Active Top Holdings Breakdown</span>
                      <Layers size={15} color="#7c828d" />
                    </h3>

                    <table className="d2-tx-table">
                      <thead>
                        <tr>
                          <th>Ticker</th>
                          <th>Asset Name</th>
                          <th>Shares</th>
                          <th>Avg Buy</th>
                          <th>Current Price</th>
                          <th style={{ textAlign: 'right' }}>Total Return</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td style={{ fontWeight: 800 }}>AAPL</td>
                          <td>Apple Inc</td>
                          <td>120</td>
                          <td>$94.50</td>
                          <td style={{ fontWeight: 700 }}>$114.72</td>
                          <td style={{ textAlign: 'right', color: '#16a34a', fontWeight: 800 }}>+21.4%</td>
                        </tr>
                        <tr>
                          <td style={{ fontWeight: 800 }}>NVDA</td>
                          <td>Nvidia Corp</td>
                          <td>45</td>
                          <td>$480.00</td>
                          <td style={{ fontWeight: 700 }}>$884.20</td>
                          <td style={{ textAlign: 'right', color: '#16a34a', fontWeight: 800 }}>+84.2%</td>
                        </tr>
                        <tr>
                          <td style={{ fontWeight: 800 }}>MSFT</td>
                          <td>Microsoft Corp</td>
                          <td>80</td>
                          <td>$340.00</td>
                          <td style={{ fontWeight: 700 }}>$415.10</td>
                          <td style={{ textAlign: 'right', color: '#16a34a', fontWeight: 800 }}>+22.1%</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* VIEW 7: SCAN QR & WALLET */}
              {activeNav === 'scan' && (
                <div className="d2-subview-card" style={{ alignItems: 'center', textAlign: 'center' }}>
                  <h3 className="d2-card-section-title" style={{ width: '100%', justifyContent: 'center' }}>
                    QR Pay Terminal &amp; Hardware Wallet Pair
                  </h3>
                  <p style={{ fontSize: '12px', color: '#7c828d', maxWidth: '420px', margin: '0 auto 10px' }}>
                    Scan this encrypted dynamic QR code using your mobile banking app or hardware key to transfer funds instantly.
                  </p>

                  <div className="d2-qr-container">
                    <div className="d2-qr-box">
                      <svg width="140" height="140" viewBox="0 0 100 100">
                        {/* Position marker top-left */}
                        <rect x="10" y="10" width="26" height="26" fill="#121316" rx="4" />
                        <rect x="14" y="14" width="18" height="18" fill="#ffffff" rx="2" />
                        <rect x="18" y="18" width="10" height="10" fill="#121316" rx="2" />

                        {/* Position marker top-right */}
                        <rect x="64" y="10" width="26" height="26" fill="#121316" rx="4" />
                        <rect x="68" y="14" width="18" height="18" fill="#ffffff" rx="2" />
                        <rect x="72" y="18" width="10" height="10" fill="#121316" rx="2" />

                        {/* Position marker bottom-left */}
                        <rect x="10" y="64" width="26" height="26" fill="#121316" rx="4" />
                        <rect x="14" y="68" width="18" height="18" fill="#ffffff" rx="2" />
                        <rect x="18" y="72" width="10" height="10" fill="#121316" rx="2" />

                        {/* QR Pattern dots */}
                        <rect x="42" y="12" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="52" y="12" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="42" y="24" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="42" y="38" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="52" y="44" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="22" y="44" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="64" y="48" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="76" y="56" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="44" y="64" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="58" y="72" width="6" height="6" fill="#121316" rx="1" />
                        <rect x="72" y="80" width="6" height="6" fill="#121316" rx="1" />
                      </svg>
                    </div>

                    <div
                      className="d2-qr-address-pill"
                      onClick={() => showToast('Wallet address copied!')}
                    >
                      <Copy size={12} />
                      <span>0x71C83921...8F2039CAD</span>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 8: HELP & SUPPORT */}
              {activeNav === 'help' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div className="d2-subview-grid-3col">
                    <div className="d2-subview-card">
                      <PhoneCall size={20} color="#f43f5e" />
                      <h4 style={{ margin: '8px 0 2px', fontSize: '13px', fontWeight: 800 }}>VIP Phone Concierge</h4>
                      <p style={{ margin: 0, fontSize: '11px', color: '#8c919d' }}>+1 (800) 849-0192</p>
                      <button
                        className="d2-action-btn-dark"
                        style={{ marginTop: '8px', fontSize: '10px', padding: '4px 12px' }}
                        onClick={() => showToast('Connecting to advisor...')}
                      >
                        Call Concierge
                      </button>
                    </div>

                    <div className="d2-subview-card">
                      <MessageSquare size={20} color="#38bdf8" />
                      <h4 style={{ margin: '8px 0 2px', fontSize: '13px', fontWeight: 800 }}>Live Desk Chat</h4>
                      <p style={{ margin: 0, fontSize: '11px', color: '#8c919d' }}>Average wait: &lt; 30 secs</p>
                      <button
                        className="d2-action-btn-dark"
                        style={{ marginTop: '8px', fontSize: '10px', padding: '4px 12px' }}
                        onClick={() => showToast('Live chat session started')}
                      >
                        Start Live Chat
                      </button>
                    </div>

                    <div className="d2-subview-card">
                      <FileText size={20} color="#22c55e" />
                      <h4 style={{ margin: '8px 0 2px', fontSize: '13px', fontWeight: 800 }}>Tax &amp; Legal Guides</h4>
                      <p style={{ margin: 0, fontSize: '11px', color: '#8c919d' }}>Form 1099, W-8BEN, KYC</p>
                      <button
                        className="d2-action-btn-dark"
                        style={{ marginTop: '8px', fontSize: '10px', padding: '4px 12px' }}
                        onClick={() => showToast('Opening tax library')}
                      >
                        View Guides
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 9: USER PROFILE */}
              {activeNav === 'profile' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div className="d2-subview-card">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                      <img
                        src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80"
                        alt="Thomas Anderson"
                        style={{ width: '64px', height: '64px', borderRadius: '50%', objectFit: 'cover', border: '3px solid #ffffff', boxShadow: '0 4px 14px rgba(0,0,0,0.1)' }}
                      />
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <h3 style={{ margin: 0, fontSize: '18px', fontWeight: 800 }}>Thomas Anderson</h3>
                          <span className="d2-status-tag success">KYC Verified</span>
                        </div>
                        <p style={{ margin: '2px 0 0', fontSize: '12px', color: '#7c828d' }}>
                          VIP Gold Private Wealth Investor · Account ID: CAD-INV-84920
                        </p>
                        <p style={{ margin: '2px 0 0', fontSize: '11px', color: '#8c919d' }}>
                          Accredited Investor (Regulation D / OSC) · Member since 2022
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="d2-subview-grid-3col">
                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Total Net Worth</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: 800 }}>$111,487.41 USD</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '11px', color: '#16a34a', fontWeight: 700 }}>Across 3 Vault Portfolios</p>
                    </div>

                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Annual Trading Volume</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: 800 }}>$480,000 USD</h3>
                      <p style={{ margin: '2px 0 0', fontSize: '11px', color: '#8c919d' }}>Zero commission tier active</p>
                    </div>

                    <div className="d2-subview-card">
                      <span style={{ fontSize: '11px', color: '#8c919d' }}>Tax Documents</span>
                      <h3 style={{ margin: '4px 0 0', fontSize: '15px', fontWeight: 800 }}>2025 Form 1099-B</h3>
                      <button
                        className="d2-action-btn-dark"
                        style={{ marginTop: '8px', fontSize: '10px', padding: '4px 12px' }}
                        onClick={() => showToast('Downloading 1099 tax PDF...')}
                      >
                        Download PDF
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Floating Dashboard Switcher Button */}
      {onSwitchToDash1 && (
        <div className="dashboard-switcher-pill">
          <span style={{ opacity: 0.7 }}>Dashboard:</span>
          <button className="switcher-btn" onClick={onSwitchToDash1}>
            Dashboard 1
          </button>
          <button className="switcher-btn active">Dashboard 2</button>
        </div>
      )}

      {/* Interactive Toast Notification */}
      {toastMsg && (
        <div
          style={{
            position: 'fixed',
            top: 20,
            right: 20,
            background: '#121316',
            color: '#ffffff',
            padding: '8px 18px',
            borderRadius: '20px',
            fontSize: '12px',
            fontWeight: 700,
            boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
            zIndex: 9999,
          }}
        >
          {toastMsg}
        </div>
      )}
    </div>
  );
}
