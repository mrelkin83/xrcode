import { useState } from 'react';
import './dashboard.css';

// Lightweight motion shim for smooth zero-dependency transitions
const motion = {
  div: ({ children, className = '', ...props }) => {
    const domProps = { ...props };
    delete domProps.initial;
    delete domProps.animate;
    delete domProps.exit;
    delete domProps.transition;
    return (
      <div className={className} {...domProps}>
        {children}
      </div>
    );
  },
};
const AnimatePresence = ({ children }) => <>{children}</>;

const chartDatasets = {
  revenue: {
    label: 'Revenue ($)',
    points: [45, 58, 52, 74, 68, 89, 82, 105, 98, 128],
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
    color: '#38bdf8',
    gradientId: 'revGrad',
    prefix: '$',
    suffix: 'k',
  },
  users: {
    label: 'Active Users',
    points: [18, 24, 29, 31, 35, 42, 40, 48, 55, 62],
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
    color: '#a78bfa',
    gradientId: 'usersGrad',
    prefix: '',
    suffix: 'k',
  },
  otp: {
    label: 'OTP Verifications',
    points: [120, 145, 138, 190, 210, 260, 245, 310, 295, 380],
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
    color: '#22c55e',
    gradientId: 'otpGrad',
    prefix: '',
    suffix: '/day',
  },
};

const initialTransactions = [
  {
    id: 'TX-9021',
    user: 'Alex Rivera',
    avatar: 'AR',
    color: '#38bdf8',
    method: 'SMS OTP (US)',
    ip: '192.168.1.42',
    status: 'success',
    amount: '$240.00',
    time: '2 mins ago',
  },
  {
    id: 'TX-9020',
    user: 'Sarah Chen',
    avatar: 'SC',
    color: '#a78bfa',
    method: 'Biometric 2FA',
    ip: '172.16.0.88',
    status: 'success',
    amount: '$1,420.50',
    time: '8 mins ago',
  },
  {
    id: 'TX-9019',
    user: 'Marcus Vance',
    avatar: 'MV',
    color: '#f59e0b',
    method: 'SMS OTP (UK)',
    ip: '10.0.4.11',
    status: 'pending',
    amount: '$89.00',
    time: '14 mins ago',
  },
  {
    id: 'TX-9018',
    user: 'Elena Rostova',
    avatar: 'ER',
    color: '#ef4444',
    method: 'Auth App (TOTP)',
    ip: '198.51.100.2',
    status: 'failed',
    amount: '$520.00',
    time: '22 mins ago',
  },
  {
    id: 'TX-9017',
    user: 'David Kim',
    avatar: 'DK',
    color: '#22c55e',
    method: 'Email Magic Link',
    ip: '203.0.113.19',
    status: 'success',
    amount: '$3,100.00',
    time: '35 mins ago',
  },
];

const usersDirectory = [
  { id: 1, name: 'CodeXr', email: 'admin@codexr.dev', role: 'Super Admin', authMethod: 'Hardware Token (FIDO2)', status: 'Active', verified: true, avatar: 'CX', color: '#ff7a59' },
  { id: 2, name: 'Alex Rivera', email: 'alex.r@enterprise.io', role: 'Security Lead', authMethod: 'SMS OTP (+1 555-019)', status: 'Active', verified: true, avatar: 'AR', color: '#38bdf8' },
  { id: 3, name: 'Sarah Chen', email: 'sarah.c@fintech.net', role: 'Developer', authMethod: 'Biometric Passkey', status: 'Active', verified: true, avatar: 'SC', color: '#a78bfa' },
  { id: 4, name: 'Marcus Vance', email: 'm.vance@techcorp.uk', role: 'Auditor', authMethod: 'Authenticator App', status: 'Pending 2FA', verified: false, avatar: 'MV', color: '#f59e0b' },
  { id: 5, name: 'Elena Rostova', email: 'elena@globalsec.org', role: 'Member', authMethod: 'SMS OTP (+44 791)', status: 'Suspended', verified: false, avatar: 'ER', color: '#ef4444' },
];

const liveFeedData = [
  { id: 1, title: 'OTP Auto-Verified for User @alex', time: 'Just now', type: 'success', color: '#22c55e' },
  { id: 2, title: 'High-Value Payment Authorization', time: '4 mins ago', type: 'payment', color: '#38bdf8' },
  { id: 3, title: 'New Session from Frankfurt (IP: 194.12.x.x)', time: '11 mins ago', type: 'security', color: '#a78bfa' },
  { id: 4, title: 'Failed 2FA Challenge flagged', time: '25 mins ago', type: 'alert', color: '#ef4444' },
];

const analyticsTrafficDatasets = {
  '24H': {
    labels: ['00:00', '03:00', '06:00', '09:00', '12:00', '15:00', '18:00', '21:00', '23:59'],
    success: [420, 310, 680, 1420, 1780, 1840, 1560, 1240, 890],
    threats: [14, 18, 52, 98, 124, 142, 86, 68, 34],
    avgLatency: '34ms',
    totalRequests: '48.6k',
    uptime: '99.99%',
  },
  '7D': {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    success: [14200, 16800, 19400, 18900, 22400, 15800, 13400],
    threats: [620, 780, 1140, 940, 1450, 680, 520],
    avgLatency: '38ms',
    totalRequests: '320.4k',
    uptime: '99.98%',
  },
  '30D': {
    labels: ['W1', 'W2', 'W3', 'W4'],
    success: [98400, 112000, 126400, 148900],
    threats: [4200, 5100, 6400, 5800],
    avgLatency: '36ms',
    totalRequests: '1.42M',
    uptime: '99.98%',
  },
};

const Dashboard = ({ onSwitchToOtp }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [activeMetric, setActiveMetric] = useState('revenue');
  const [timeRange, setTimeRange] = useState('30D');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [hoveredPoint, setHoveredPoint] = useState(null);
  const [analyticsRange, setAnalyticsRange] = useState('24H');
  const [analyticsHoverIdx, setAnalyticsHoverIdx] = useState(null);

  // Settings State
  const [enforce2FA, setEnforce2FA] = useState(true);
  const [geofencing, setGeofencing] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);

  // OTP Live Test simulator state
  const [simPhone, setSimPhone] = useState('+1 (555) 382-9012');
  const [simStatus, setSimStatus] = useState('ready');

  const dataset = chartDatasets[activeMetric];

  // SVG Chart path calculation
  const width = 640;
  const height = 180;
  const paddingX = 30;
  const paddingY = 20;

  const minVal = Math.min(...dataset.points) * 0.85;
  const maxVal = Math.max(...dataset.points) * 1.1;

  const coords = dataset.points.map((val, idx) => {
    const x = paddingX + (idx / (dataset.points.length - 1)) * (width - paddingX * 2);
    const y = height - paddingY - ((val - minVal) / (maxVal - minVal)) * (height - paddingY * 2);
    return { x, y, val, label: dataset.labels[idx] };
  });

  let pathD = `M ${coords[0].x} ${coords[0].y}`;
  for (let i = 0; i < coords.length - 1; i++) {
    const p0 = coords[i];
    const p1 = coords[i + 1];
    const cpX = (p0.x + p1.x) / 2;
    pathD += ` C ${cpX} ${p0.y}, ${cpX} ${p1.y}, ${p1.x} ${p1.y}`;
  }

  const areaD = `${pathD} L ${coords[coords.length - 1].x} ${height} L ${coords[0].x} ${height} Z`;

  // Analytics Traffic Chart calculation
  const aDataset = analyticsTrafficDatasets[analyticsRange];
  const aWidth = 640;
  const aHeight = 180;
  const aPadX = 30;
  const aPadY = 20;

  const aMaxSuccess = Math.max(...aDataset.success) * 1.15;
  const aCoordsSuccess = aDataset.success.map((val, idx) => ({
    x: aPadX + (idx / (aDataset.success.length - 1)) * (aWidth - aPadX * 2),
    y: aHeight - aPadY - (val / aMaxSuccess) * (aHeight - aPadY * 2),
    val,
    label: aDataset.labels[idx],
  }));

  let aPathSuccess = `M ${aCoordsSuccess[0].x} ${aCoordsSuccess[0].y}`;
  for (let i = 0; i < aCoordsSuccess.length - 1; i++) {
    const p0 = aCoordsSuccess[i];
    const p1 = aCoordsSuccess[i + 1];
    const cpX = (p0.x + p1.x) / 2;
    aPathSuccess += ` C ${cpX} ${p0.y}, ${cpX} ${p1.y}, ${p1.x} ${p1.y}`;
  }
  const aAreaSuccess = `${aPathSuccess} L ${aCoordsSuccess[aCoordsSuccess.length - 1].x} ${aHeight} L ${aCoordsSuccess[0].x} ${aHeight} Z`;

  const aMaxThreats = Math.max(...aDataset.threats) * 1.35;
  const aCoordsThreats = aDataset.threats.map((val, idx) => ({
    x: aPadX + (idx / (aDataset.threats.length - 1)) * (aWidth - aPadX * 2),
    y: aHeight - aPadY - (val / aMaxThreats) * (aHeight - aPadY * 2),
    val,
    label: aDataset.labels[idx],
  }));

  let aPathThreats = `M ${aCoordsThreats[0].x} ${aCoordsThreats[0].y}`;
  for (let i = 0; i < aCoordsThreats.length - 1; i++) {
    const p0 = aCoordsThreats[i];
    const p1 = aCoordsThreats[i + 1];
    const cpX = (p0.x + p1.x) / 2;
    aPathThreats += ` C ${cpX} ${p0.y}, ${cpX} ${p1.y}, ${p1.x} ${p1.y}`;
  }
  const aAreaThreats = `${aPathThreats} L ${aCoordsThreats[aCoordsThreats.length - 1].x} ${aHeight} L ${aCoordsThreats[0].x} ${aHeight} Z`;

  // Filter transactions
  const filteredTransactions = initialTransactions.filter((tx) => {
    const matchesSearch =
      tx.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.method.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || tx.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCopyKey = () => {
    navigator.clipboard?.writeText('sk_live_994b_82ef1092a4c017d84f');
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleSimulateOtp = () => {
    setSimStatus('sending');
    setTimeout(() => {
      setSimStatus('sent');
      setTimeout(() => setSimStatus('ready'), 3500);
    }, 1200);
  };

  return (
    <div className="dashboard-root">
      {/* ================= FIXED SIDEBAR ================= */}
      <aside className="dash-sidebar glass-panel">
        <div className="sidebar-logo">
          <div className="logo-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" width="22" height="22">
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div className="logo-text">
            <h2>Codexr Glass</h2>
            <span>Admin Center</span>
          </div>
        </div>

        <nav className="sidebar-nav">
          <div className="nav-section-title">Menu</div>
          <button
            type="button"
            className={`nav-item ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <rect x="3" y="3" width="7" height="9" rx="2" />
              <rect x="14" y="3" width="7" height="5" rx="2" />
              <rect x="14" y="12" width="7" height="9" rx="2" />
              <rect x="3" y="16" width="7" height="5" rx="2" />
            </svg>
            Overview
          </button>

          <button
            type="button"
            className={`nav-item ${activeTab === 'analytics' ? 'active' : ''}`}
            onClick={() => setActiveTab('analytics')}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 18l5-5 4 4 9-9" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M14 8h7v7" />
            </svg>
            Analytics
            <span className="nav-badge">Live</span>
          </button>

          <button
            type="button"
            className={`nav-item ${activeTab === 'otp' ? 'active' : ''}`}
            onClick={() => setActiveTab('otp')}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            OTP Station
          </button>

          <button
            type="button"
            className={`nav-item ${activeTab === 'users' ? 'active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M23 21v-2a4 4 0 00-3-3.87m-4-12a4 4 0 010 7.75" />
            </svg>
            Users & Auth
          </button>

          <button
            type="button"
            className={`nav-item ${activeTab === 'transactions' ? 'active' : ''}`}
            onClick={() => setActiveTab('transactions')}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <rect x="2" y="5" width="20" height="14" rx="2" />
              <line x1="2" y1="10" x2="22" y2="10" />
            </svg>
            Transactions
          </button>

          <div className="nav-section-title">System</div>
          <button
            type="button"
            className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveTab('settings')}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <circle cx="12" cy="12" r="3" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
            </svg>
            Security & Keys
          </button>
        </nav>

        <div className="sidebar-user">
          <div className="user-avatar" style={{ background: 'linear-gradient(135deg, #ff7a59 0%, #f05133 100%)' }}>CX</div>
          <div className="user-info">
            <div className="user-name">CodeXr</div>
            <div className="user-role">Super Administrator</div>
          </div>
        </div>
      </aside>

      {/* ================= MAIN DASHBOARD VIEWPORT ================= */}
      <main className="dash-main">
        {/* Top Header Bar */}
        <header className="dash-header glass-panel">
          <div className="header-search">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              placeholder="Search user, transaction ID, IP..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="header-actions">
            <div className="chart-filters">
              {['Today', '7D', '30D', '1Y'].map((range) => (
                <button
                  key={range}
                  type="button"
                  className={`filter-btn ${timeRange === range ? 'active' : ''}`}
                  onClick={() => setTimeRange(range)}
                >
                  {range}
                </button>
              ))}
            </div>

            {/* Quick Switch to Full OTP Card component */}
            {onSwitchToOtp && (
              <button type="button" className="header-btn" onClick={onSwitchToOtp}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="15" height="15">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                OTP View
              </button>
            )}

            <button type="button" className="icon-btn" aria-label="Notifications">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
                <path strokeLinecap="round" strokeLinejoin="round" d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.73 21a2 2 0 01-3.46 0" />
              </svg>
              <div className="pulse-dot" />
            </button>

            <button type="button" className="header-btn primary">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" width="15" height="15">
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
              New 2FA Rule
            </button>
          </div>
        </header>

        {/* ================= DYNAMIC ANIMATED TAB CONTENT ================= */}
        <AnimatePresence mode="wait">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 15, scale: 0.995 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -15, scale: 0.995 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="tab-content-wrapper"
            >
              {/* 4 KPI Metric Cards */}
              <section className="stats-grid">
                <div className="stat-card revenue glass-panel">
                  <div className="stat-card-header">
                    <span className="stat-title">Total Processed</span>
                    <div className="stat-icon">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
                        <line x1="12" y1="1" x2="12" y2="23" />
                        <path strokeLinecap="round" strokeLinejoin="round" d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="stat-value">$128,430.00</h3>
                  <div className="stat-footer">
                    <span className="trend-badge up">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" width="10" height="10">
                        <polyline points="18 15 12 9 6 15" />
                      </svg>
                      +14.6%
                    </span>
                    <span className="stat-subtitle">vs last month</span>
                  </div>
                </div>

                <div className="stat-card users glass-panel">
                  <div className="stat-card-header">
                    <span className="stat-title">Active Users</span>
                    <div className="stat-icon">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                        <circle cx="12" cy="7" r="4" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="stat-value">42,890</h3>
                  <div className="stat-footer">
                    <span className="trend-badge up">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" width="10" height="10">
                        <polyline points="18 15 12 9 6 15" />
                      </svg>
                      +8.2%
                    </span>
                    <span className="stat-subtitle">new accounts</span>
                  </div>
                </div>

                <div className="stat-card otp glass-panel">
                  <div className="stat-card-header">
                    <span className="stat-title">OTP Success Rate</span>
                    <div className="stat-icon">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="stat-value">99.4%</h3>
                  <div className="stat-footer">
                    <span className="trend-badge up">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" width="10" height="10">
                        <polyline points="18 15 12 9 6 15" />
                      </svg>
                      +0.6%
                    </span>
                    <span className="stat-subtitle">34,120 verified</span>
                  </div>
                </div>

                <div className="stat-card conversion glass-panel">
                  <div className="stat-card-header">
                    <span className="stat-title">Auth Velocity</span>
                    <div className="stat-icon">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
                        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                      </svg>
                    </div>
                  </div>
                  <h3 className="stat-value">1.42s</h3>
                  <div className="stat-footer">
                    <span className="trend-badge up">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" width="10" height="10">
                        <polyline points="18 15 12 9 6 15" />
                      </svg>
                      -0.3s
                    </span>
                    <span className="stat-subtitle">avg delivery & verify</span>
                  </div>
                </div>
              </section>

              {/* Charts Grid */}
              <section className="charts-grid">
                <div className="chart-card glass-panel">
                  <div className="chart-card-header">
                    <div>
                      <h3>Performance & Velocity Analytics</h3>
                    </div>
                    <div className="chart-filters">
                      <button
                        type="button"
                        className={`filter-btn ${activeMetric === 'revenue' ? 'active' : ''}`}
                        onClick={() => setActiveMetric('revenue')}
                      >
                        Revenue
                      </button>
                      <button
                        type="button"
                        className={`filter-btn ${activeMetric === 'users' ? 'active' : ''}`}
                        onClick={() => setActiveMetric('users')}
                      >
                        Users
                      </button>
                      <button
                        type="button"
                        className={`filter-btn ${activeMetric === 'otp' ? 'active' : ''}`}
                        onClick={() => setActiveMetric('otp')}
                      >
                        Verifications
                      </button>
                    </div>
                  </div>

                  <div className="svg-chart-container">
                    <svg viewBox={`0 0 ${width} ${height}`} className="svg-chart">
                      <defs>
                        <linearGradient id={dataset.gradientId} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={dataset.color} stopOpacity="0.4" />
                          <stop offset="100%" stopColor={dataset.color} stopOpacity="0.0" />
                        </linearGradient>
                      </defs>

                      {[0.25, 0.5, 0.75].map((ratio) => (
                        <line
                          key={ratio}
                          x1={paddingX}
                          y1={height * ratio}
                          x2={width - paddingX}
                          y2={height * ratio}
                          stroke="rgba(255, 255, 255, 0.08)"
                          strokeDasharray="4 4"
                        />
                      ))}

                      <path d={areaD} fill={`url(#${dataset.gradientId})`} />
                      <path
                        d={pathD}
                        fill="none"
                        stroke={dataset.color}
                        strokeWidth="2.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />

                      {coords.map((pt, i) => (
                        <g key={i}>
                          <circle
                            cx={pt.x}
                            cy={pt.y}
                            r={hoveredPoint === i ? 6 : 4}
                            fill="#fff"
                            stroke={dataset.color}
                            strokeWidth="2"
                            style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                            onMouseEnter={() => setHoveredPoint(i)}
                            onMouseLeave={() => setHoveredPoint(null)}
                          />
                          <text
                            x={pt.x}
                            y={height - 2}
                            textAnchor="middle"
                            fill="rgba(255, 255, 255, 0.45)"
                            fontSize="10"
                            fontFamily="Inter"
                          >
                            {pt.label}
                          </text>
                        </g>
                      ))}
                    </svg>

                    {hoveredPoint !== null && (
                      <div
                        className="chart-tooltip"
                        style={{
                          left: `${(coords[hoveredPoint].x / width) * 100}%`,
                          top: `${(coords[hoveredPoint].y / height) * 100}%`,
                        }}
                      >
                        <div className="chart-tooltip-date">{coords[hoveredPoint].label} 2026</div>
                        <div className="chart-tooltip-value">
                          {dataset.prefix}
                          {coords[hoveredPoint].val}
                          {dataset.suffix}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="chart-card glass-panel">
                  <div className="chart-card-header">
                    <h3>Verification Distribution</h3>
                  </div>
                  <div className="radial-breakdown">
                    <div className="donut-wrapper">
                      <svg viewBox="0 0 100 100" width="140" height="140">
                        <circle cx="50" cy="50" r="38" fill="none" stroke="rgba(255, 255, 255, 0.08)" strokeWidth="10" />
                        <circle
                          cx="50"
                          cy="50"
                          r="38"
                          fill="none"
                          stroke="#22c55e"
                          strokeWidth="10"
                          strokeDasharray="129 238"
                          strokeDashoffset="0"
                          strokeLinecap="round"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="38"
                          fill="none"
                          stroke="#38bdf8"
                          strokeWidth="10"
                          strokeDasharray="67 238"
                          strokeDashoffset="-135"
                          strokeLinecap="round"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="38"
                          fill="none"
                          stroke="#f59e0b"
                          strokeWidth="10"
                          strokeDasharray="42 238"
                          strokeDashoffset="-206"
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="donut-center-info">
                        <div className="value">54%</div>
                        <div className="label">SMS OTP</div>
                      </div>
                    </div>

                    <div className="radial-legend">
                      <div className="legend-item">
                        <div className="legend-left">
                          <div className="legend-dot" style={{ background: '#22c55e' }} />
                          <span>SMS OTP</span>
                        </div>
                        <span className="legend-val">54% (18.4k)</span>
                      </div>
                      <div className="legend-item">
                        <div className="legend-left">
                          <div className="legend-dot" style={{ background: '#38bdf8' }} />
                          <span>Biometric 2FA</span>
                        </div>
                        <span className="legend-val">28% (9.5k)</span>
                      </div>
                      <div className="legend-item">
                        <div className="legend-left">
                          <div className="legend-dot" style={{ background: '#f59e0b' }} />
                          <span>Authenticator App</span>
                        </div>
                        <span className="legend-val">18% (6.2k)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* Bottom Tables Grid */}
              <section className="bottom-grid">
                <div className="table-card glass-panel">
                  <div className="table-header">
                    <div>
                      <h3>Recent Verification Challenges</h3>
                    </div>
                    <div className="status-pills">
                      {['all', 'success', 'pending', 'failed'].map((st) => (
                        <button
                          key={st}
                          type="button"
                          className={`status-pill-btn ${statusFilter === st ? 'active' : ''}`}
                          onClick={() => setStatusFilter(st)}
                        >
                          {st.charAt(0).toUpperCase() + st.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div style={{ overflowX: 'auto' }}>
                    <table className="glass-table">
                      <thead>
                        <tr>
                          <th>User</th>
                          <th>Method</th>
                          <th>IP / Location</th>
                          <th>Status</th>
                          <th>Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredTransactions.map((tx) => (
                          <tr key={tx.id}>
                            <td>
                              <div className="user-cell">
                                <div className="mini-avatar" style={{ backgroundColor: tx.color }}>
                                  {tx.avatar}
                                </div>
                                <div>
                                  <div style={{ fontWeight: 600 }}>{tx.user}</div>
                                  <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.45)' }}>{tx.id}</div>
                                </div>
                              </div>
                            </td>
                            <td>{tx.method}</td>
                            <td style={{ fontFamily: 'monospace', fontSize: '12px', color: 'rgba(255,255,255,0.7)' }}>
                              {tx.ip}
                            </td>
                            <td>
                              <span className={`status-tag ${tx.status}`}>
                                {tx.status === 'success' && 'Verified'}
                                {tx.status === 'pending' && 'Challenged'}
                                {tx.status === 'failed' && 'Failed'}
                              </span>
                            </td>
                            <td style={{ color: 'rgba(255,255,255,0.5)', fontSize: '12px' }}>{tx.time}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="feed-card glass-panel">
                  <div className="feed-header">
                    <h3>Live Security Log</h3>
                    <div className="live-badge">
                      <div className="live-dot" />
                      Live Feed
                    </div>
                  </div>

                  <div className="feed-list">
                    {liveFeedData.map((item) => (
                      <div className="feed-item" key={item.id}>
                        <div className="feed-icon" style={{ color: item.color }}>
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" width="14" height="14">
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                        </div>
                        <div className="feed-content">
                          <div className="feed-title">{item.title}</div>
                          <div className="feed-time">{item.time}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {/* TAB 2: ANALYTICS */}
          {activeTab === 'analytics' && (
            <motion.div
              key="analytics"
              initial={{ opacity: 0, y: 15, scale: 0.995 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -15, scale: 0.995 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="tab-content-wrapper"
            >
              {/* 4 KPI Metric Cards */}
              <div className="stats-grid">
                <div className="stat-card glass-panel">
                  <span className="stat-title">Peak Auth TPS</span>
                  <h3 className="stat-value">1,840 TPS</h3>
                  <div className="stat-footer">
                    <span className="trend-badge up">+22.4%</span>
                    <span className="stat-subtitle">Max burst volume</span>
                  </div>
                </div>
                <div className="stat-card glass-panel">
                  <span className="stat-title">Global Edge Latency</span>
                  <h3 className="stat-value">28.4 ms</h3>
                  <div className="stat-footer">
                    <span className="trend-badge up">-4.2ms</span>
                    <span className="stat-subtitle">99.98% SLA target</span>
                  </div>
                </div>
                <div className="stat-card glass-panel">
                  <span className="stat-title">Protocol Velocity</span>
                  <h3 className="stat-value">99.92%</h3>
                  <div className="stat-footer">
                    <span className="trend-badge up">Optimal</span>
                    <span className="stat-subtitle">Under risk benchmark</span>
                  </div>
                </div>
                <div className="stat-card glass-panel">
                  <span className="stat-title">Threat Interceptions</span>
                  <h3 className="stat-value">14,820</h3>
                  <div className="stat-footer">
                    <span className="trend-badge down">Shield Active</span>
                    <span className="stat-subtitle">0 breaches detected</span>
                  </div>
                </div>
              </div>

              {/* Main Full-Width Multi-Line Area Graph */}
              <div className="chart-card glass-panel">
                <div className="chart-card-header">
                  <div>
                    <h3>Global Ingestion Velocity & Anomaly Waveform</h3>
                    <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                      Real-time cryptographic token authorizations vs mitigated attack vectors
                    </p>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#22c55e', background: 'rgba(34, 197, 94, 0.1)', border: '1px solid rgba(34, 197, 94, 0.25)', padding: '4px 10px', borderRadius: '20px' }}>
                      <span className="pulse-dot" style={{ position: 'static', display: 'inline-block', width: '6px', height: '6px' }} />
                      <span>Live Feed • 18.4k req/sec</span>
                    </div>
                    <div className="chart-filters">
                      {['24H', '7D', '30D'].map((range) => (
                        <button
                          key={range}
                          type="button"
                          className={`filter-btn ${analyticsRange === range ? 'active' : ''}`}
                          onClick={() => setAnalyticsRange(range)}
                        >
                          {range}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="svg-chart-container" style={{ height: '220px' }}>
                  <svg viewBox={`0 0 ${aWidth} ${aHeight}`} className="svg-chart">
                    <defs>
                      <linearGradient id="analyticsSuccessGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.38" />
                        <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
                      </linearGradient>
                      <linearGradient id="analyticsThreatGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.3" />
                        <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>

                    {/* Grid Lines */}
                    {[0.25, 0.5, 0.75].map((ratio) => (
                      <line
                        key={ratio}
                        x1={aPadX}
                        y1={aHeight * ratio}
                        x2={aWidth - aPadX}
                        y2={aHeight * ratio}
                        stroke="rgba(255, 255, 255, 0.08)"
                        strokeDasharray="4 4"
                      />
                    ))}

                    {/* Success Area & Line */}
                    <path d={aAreaSuccess} fill="url(#analyticsSuccessGrad)" />
                    <path
                      d={aPathSuccess}
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />

                    {/* Threat Area & Line */}
                    <path d={aAreaThreats} fill="url(#analyticsThreatGrad)" />
                    <path
                      d={aPathThreats}
                      fill="none"
                      stroke="#f43f5e"
                      strokeWidth="2"
                      strokeDasharray="5 3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />

                    {/* Interactive Points on Success Curve */}
                    {aCoordsSuccess.map((pt, idx) => (
                      <g key={idx}>
                        <circle
                          cx={pt.x}
                          cy={pt.y}
                          r={analyticsHoverIdx === idx ? 6 : 3.5}
                          fill="#38bdf8"
                          stroke="#08090b"
                          strokeWidth="2"
                          style={{ cursor: 'pointer', transition: 'r 0.15s ease' }}
                          onMouseEnter={() => setAnalyticsHoverIdx(idx)}
                          onMouseLeave={() => setAnalyticsHoverIdx(null)}
                        />
                        {/* Threat Point */}
                        <circle
                          cx={aCoordsThreats[idx].x}
                          cy={aCoordsThreats[idx].y}
                          r={analyticsHoverIdx === idx ? 5 : 2.5}
                          fill="#f43f5e"
                          stroke="#08090b"
                          strokeWidth="1.5"
                          style={{ cursor: 'pointer', transition: 'r 0.15s ease' }}
                          onMouseEnter={() => setAnalyticsHoverIdx(idx)}
                          onMouseLeave={() => setAnalyticsHoverIdx(null)}
                        />
                        {/* X-axis labels */}
                        <text
                          x={pt.x}
                          y={aHeight - 4}
                          textAnchor="middle"
                          fill="rgba(255, 255, 255, 0.45)"
                          fontSize="10"
                        >
                          {pt.label}
                        </text>
                      </g>
                    ))}
                  </svg>

                  {/* Interactive Tooltip */}
                  {analyticsHoverIdx !== null && (
                    <div
                      className="chart-tooltip"
                      style={{
                        left: `${(aCoordsSuccess[analyticsHoverIdx].x / aWidth) * 100}%`,
                        top: `${(aCoordsSuccess[analyticsHoverIdx].y / aHeight) * 100}%`,
                      }}
                    >
                      <div className="chart-tooltip-date">{aDataset.labels[analyticsHoverIdx]}</div>
                      <div style={{ color: '#38bdf8', fontWeight: 600 }}>
                        Auth Requests: {aDataset.success[analyticsHoverIdx].toLocaleString()}
                      </div>
                      <div style={{ color: '#f43f5e', fontSize: '11px', marginTop: '2px' }}>
                        Blocked Injections: {aDataset.threats[analyticsHoverIdx]}
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Graph Legend */}
                <div className="analytics-legend">
                  <div className="legend-item">
                    <span className="legend-dot" style={{ background: '#38bdf8', boxShadow: '0 0 8px #38bdf8' }} />
                    <span>Successful Token Authorizations (Total: <strong style={{ color: '#fff' }}>{aDataset.totalRequests}</strong>)</span>
                  </div>
                  <div className="legend-item">
                    <span className="legend-dot" style={{ background: '#f43f5e', boxShadow: '0 0 8px #f43f5e' }} />
                    <span>Mitigated Attack Vectors (Avg Latency: <strong style={{ color: '#fff' }}>{aDataset.avgLatency}</strong>)</span>
                  </div>
                  <div className="legend-item" style={{ marginLeft: 'auto' }}>
                    <span style={{ color: 'rgba(255,255,255,0.5)' }}>Global SLA Reliability:</span>
                    <strong style={{ color: '#22c55e' }}>{aDataset.uptime}</strong>
                  </div>
                </div>
              </div>

              {/* Dual Graphs Grid: Latency Meters & Protocol Donut */}
              <div className="charts-grid">
                {/* Graph 1: Edge Datacenter Latency */}
                <div className="chart-card glass-panel">
                  <div className="chart-card-header">
                    <div>
                      <h3>Global Edge Datacenter Latency</h3>
                      <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                        Roundtrip network handshake per geographic PoP
                      </p>
                    </div>
                    <span style={{ fontSize: '11px', color: '#38bdf8', fontWeight: 600 }}>Target &lt; 50ms</span>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '14px' }}>
                    {[
                      { region: 'US-East (N. Virginia)', ms: '22 ms', pct: 90, color: '#22c55e', sla: '99.99%' },
                      { region: 'EU-Central (Frankfurt)', ms: '34 ms', pct: 76, color: '#38bdf8', sla: '99.98%' },
                      { region: 'AP-South (Mumbai)', ms: '46 ms', pct: 64, color: '#a78bfa', sla: '100.0%' },
                      { region: 'AP-Northeast (Tokyo)', ms: '58 ms', pct: 52, color: '#f59e0b', sla: '99.95%' },
                      { region: 'SA-East (São Paulo)', ms: '84 ms', pct: 36, color: '#ff7a59', sla: '99.92%' },
                    ].map((node) => (
                      <div key={node.region} className="latency-meter-item">
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '13px' }}>
                          <span style={{ fontWeight: 500 }}>{node.region}</span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.45)' }}>SLA {node.sla}</span>
                            <span style={{ fontWeight: 700, color: node.color }}>{node.ms}</span>
                          </div>
                        </div>
                        <div className="progress-bar-track" style={{ height: '6px' }}>
                          <div
                            className="progress-bar-fill"
                            style={{
                              width: `${node.pct}%`,
                              background: node.color,
                              boxShadow: `0 0 10px ${node.color}55`,
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Graph 2: Protocol Donut Chart */}
                <div className="chart-card glass-panel">
                  <div className="chart-card-header">
                    <div>
                      <h3>Auth Protocol Distribution</h3>
                      <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                        Volume breakdown across multi-factor channels
                      </p>
                    </div>
                  </div>

                  <div className="donut-layout">
                    {/* SVG Donut Circle */}
                    <div style={{ position: 'relative', width: '150px', height: '150px', flexShrink: 0 }}>
                      <svg viewBox="0 0 160 160" width="150" height="150">
                        {/* Background track */}
                        <circle cx="80" cy="80" r="60" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="18" />
                        {/* SMS OTP (44%) */}
                        <circle
                          cx="80"
                          cy="80"
                          r="60"
                          fill="none"
                          stroke="#38bdf8"
                          strokeWidth="18"
                          strokeDasharray="165.8 377"
                          strokeDashoffset="0"
                          strokeLinecap="round"
                        />
                        {/* Passkeys (28%) */}
                        <circle
                          cx="80"
                          cy="80"
                          r="60"
                          fill="none"
                          stroke="#22c55e"
                          strokeWidth="18"
                          strokeDasharray="105.5 377"
                          strokeDashoffset="-170"
                          strokeLinecap="round"
                        />
                        {/* TOTP (18%) */}
                        <circle
                          cx="80"
                          cy="80"
                          r="60"
                          fill="none"
                          stroke="#a78bfa"
                          strokeWidth="18"
                          strokeDasharray="67.8 377"
                          strokeDashoffset="-280"
                          strokeLinecap="round"
                        />
                        {/* Magic Link (10%) */}
                        <circle
                          cx="80"
                          cy="80"
                          r="60"
                          fill="none"
                          stroke="#f59e0b"
                          strokeWidth="18"
                          strokeDasharray="37.7 377"
                          strokeDashoffset="-352"
                          strokeLinecap="round"
                        />
                        <text x="80" y="76" className="donut-center-text">99.9%</text>
                        <text x="80" y="94" className="donut-sub-text">SUCCESS SLA</text>
                      </svg>
                    </div>

                    {/* Donut Legend */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', flex: 1 }}>
                      {[
                        { label: 'SMS Carrier OTP', val: '44%', speed: '1.2s avg', color: '#38bdf8' },
                        { label: 'Biometric Passkeys', val: '28%', speed: '320ms avg', color: '#22c55e' },
                        { label: 'Authenticator (TOTP)', val: '18%', speed: '480ms avg', color: '#a78bfa' },
                        { label: 'Email Magic Link', val: '10%', speed: '2.4s avg', color: '#f59e0b' },
                      ].map((item) => (
                        <div key={item.label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '12px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: item.color }} />
                            <span>{item.label}</span>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <span style={{ color: 'rgba(255,255,255,0.45)', fontSize: '11px' }}>{item.speed}</span>
                            <span style={{ fontWeight: 700, color: item.color }}>{item.val}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Third Grid: Devices, Geo & Security Feed */}
              <div className="charts-grid">
                {/* Device Breakdown */}
                <div className="chart-card glass-panel">
                  <h3>Client Platform & Device Breakdown</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginTop: '14px' }}>
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px' }}>
                        <span>iOS Safari & Native App</span>
                        <span style={{ fontWeight: 600 }}>48% (20.5k)</span>
                      </div>
                      <div className="progress-bar-track">
                        <div className="progress-bar-fill" style={{ width: '48%', background: '#38bdf8' }} />
                      </div>
                    </div>
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px' }}>
                        <span>Android Chrome & Biometrics</span>
                        <span style={{ fontWeight: 600 }}>34% (14.5k)</span>
                      </div>
                      <div className="progress-bar-track">
                        <div className="progress-bar-fill" style={{ width: '34%', background: '#22c55e' }} />
                      </div>
                    </div>
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px' }}>
                        <span>Desktop macOS & Windows</span>
                        <span style={{ fontWeight: 600 }}>18% (7.7k)</span>
                      </div>
                      <div className="progress-bar-track">
                        <div className="progress-bar-fill" style={{ width: '18%', background: '#a78bfa' }} />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Geo Regions */}
                <div className="chart-card glass-panel">
                  <h3>Top Geographic Hubs</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '12px' }}>
                    {[
                      { country: 'United States', code: 'US', rate: '99.7%', count: '18.2k', color: '#38bdf8' },
                      { country: 'Germany & EU', code: 'DE', rate: '99.5%', count: '9.4k', color: '#22c55e' },
                      { country: 'United Kingdom', code: 'UK', rate: '99.2%', count: '6.1k', color: '#a78bfa' },
                      { country: 'India & APAC', code: 'IN', rate: '98.9%', count: '4.8k', color: '#f59e0b' },
                    ].map((geo) => (
                      <div key={geo.code} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '13px', padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <span style={{ width: '24px', height: '18px', background: 'rgba(255,255,255,0.1)', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', fontWeight: 700 }}>{geo.code}</span>
                          <span>{geo.country}</span>
                        </div>
                        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                          <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '12px' }}>{geo.count}</span>
                          <span style={{ color: geo.color, fontWeight: 600, fontSize: '12px' }}>{geo.rate}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom Telemetry & Cluster System Health */}
              <div className="chart-card glass-panel">
                <div className="chart-card-header">
                  <div>
                    <h3>Infrastructure Cluster Telemetry</h3>
                    <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                      Distributed node compute allocation, cache hits & live socket workers
                    </p>
                  </div>
                  <span style={{ fontSize: '12px', color: '#22c55e', fontWeight: 600 }}>All Systems Operational</span>
                </div>

                <div className="system-health-bar">
                  <div className="system-health-chip">
                    <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)' }}>Node CPU Allocation</span>
                    <strong style={{ fontSize: '16px', color: '#fff' }}>32.4%</strong>
                    <span style={{ fontSize: '10px', color: '#22c55e' }}>Healthy • 64 Cores</span>
                  </div>
                  <div className="system-health-chip">
                    <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)' }}>KV In-Memory Cache</span>
                    <strong style={{ fontSize: '16px', color: '#38bdf8' }}>58.1%</strong>
                    <span style={{ fontSize: '10px', color: 'rgba(255,255,255,0.45)' }}>Redis 99.4% Hit Rate</span>
                  </div>
                  <div className="system-health-chip">
                    <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)' }}>Active WS Streamers</span>
                    <strong style={{ fontSize: '16px', color: '#a78bfa' }}>14,290</strong>
                    <span style={{ fontSize: '10px', color: '#22c55e' }}>Zero dropped frames</span>
                  </div>
                  <div className="system-health-chip">
                    <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)' }}>Threat Engine DB</span>
                    <strong style={{ fontSize: '16px', color: '#22c55e' }}>v4.28.1</strong>
                    <span style={{ fontSize: '10px', color: 'rgba(255,255,255,0.45)' }}>Synced 4 mins ago</span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 3: OTP STATION */}
          {activeTab === 'otp' && (
            <motion.div
              key="otp"
              initial={{ opacity: 0, y: 15, scale: 0.995 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -15, scale: 0.995 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="tab-content-wrapper"
            >
              <div className="charts-grid">
                {/* OTP Test Simulator Card */}
                <div className="chart-card glass-panel">
                  <div className="chart-card-header">
                    <div>
                      <h3>Live OTP Challenge Simulator</h3>
                      <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                        Trigger instant mock OTP challenge token directly to verification gateway
                      </p>
                    </div>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginTop: '12px' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '12px', color: 'rgba(255,255,255,0.6)', marginBottom: '6px' }}>Target Mobile Number</label>
                      <input
                        type="text"
                        className="glass-input-box"
                        value={simPhone}
                        onChange={(e) => setSimPhone(e.target.value)}
                      />
                    </div>

                    <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                      <button
                        type="button"
                        className="header-btn primary"
                        disabled={simStatus === 'sending'}
                        onClick={handleSimulateOtp}
                      >
                        {simStatus === 'sending' ? 'Dispatching Token...' : simStatus === 'sent' ? '✓ Token Sent: 4920' : 'Send Test OTP Token'}
                      </button>

                      {onSwitchToOtp && (
                        <button type="button" className="header-btn" onClick={onSwitchToOtp}>
                          Open Full Glassy Card View →
                        </button>
                      )}
                    </div>

                    {simStatus === 'sent' && (
                      <div style={{ padding: '12px', background: 'rgba(34,197,94,0.15)', border: '1px solid rgba(34,197,94,0.4)', borderRadius: '10px', fontSize: '13px', color: '#4ade80' }}>
                        OTP Token <strong>4920</strong> has been broadcasted via carrier gateway. You can enter it in the OTP View to test the rotating coral beam & merge animations!
                      </div>
                    )}
                  </div>
                </div>

                {/* Gateway Telemetry */}
                <div className="chart-card glass-panel">
                  <h3>Telecom Provider Health</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginTop: '12px' }}>
                    {[
                      { name: 'Twilio SMS Gateway', uptime: '99.98%', ping: '42ms', status: 'Optimal' },
                      { name: 'AWS SNS Multi-Region', uptime: '99.99%', ping: '31ms', status: 'Optimal' },
                      { name: 'Infobip Global Direct', uptime: '99.95%', ping: '58ms', status: 'Optimal' },
                      { name: 'Apple WebAuthn Engine', uptime: '100%', ping: '18ms', status: 'Optimal' },
                    ].map((gw) => (
                      <div key={gw.name} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: '10px', border: '1px solid rgba(255,255,255,0.06)' }}>
                        <div>
                          <div style={{ fontSize: '13px', fontWeight: 600 }}>{gw.name}</div>
                          <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)' }}>Latency: {gw.ping}</div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <span className="status-tag success">{gw.status}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 4: USERS & AUTH DIRECTORY */}
          {activeTab === 'users' && (
            <motion.div
              key="users"
              initial={{ opacity: 0, y: 15, scale: 0.995 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -15, scale: 0.995 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="tab-content-wrapper"
            >
              <div className="table-card glass-panel">
                <div className="table-header">
                  <div>
                    <h3>Users & Credential Directory</h3>
                    <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                      Total {usersDirectory.length} active registered administrative and member accounts
                    </p>
                  </div>
                  <button type="button" className="header-btn primary">
                    + Invite New User
                  </button>
                </div>

                <div style={{ overflowX: 'auto' }}>
                  <table className="glass-table">
                    <thead>
                      <tr>
                        <th>User Profile</th>
                        <th>Role</th>
                        <th>Primary 2FA Method</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {usersDirectory.map((usr) => (
                        <tr key={usr.id}>
                          <td>
                            <div className="user-cell">
                              <div className="mini-avatar" style={{ backgroundColor: usr.color }}>
                                {usr.avatar}
                              </div>
                              <div>
                                <div style={{ fontWeight: 600 }}>{usr.name}</div>
                                <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.45)' }}>{usr.email}</div>
                              </div>
                            </div>
                          </td>
                          <td>
                            <span style={{ fontSize: '12px', color: 'rgba(255,255,255,0.85)' }}>{usr.role}</span>
                          </td>
                          <td>
                            <span style={{ fontSize: '12px', color: '#38bdf8' }}>{usr.authMethod}</span>
                          </td>
                          <td>
                            <span className={`status-tag ${usr.status === 'Active' ? 'success' : usr.status === 'Pending 2FA' ? 'pending' : 'failed'}`}>
                              {usr.status}
                            </span>
                          </td>
                          <td>
                            <div style={{ display: 'flex', gap: '8px' }}>
                              <button type="button" className="action-btn-sm">Reset 2FA</button>
                              <button type="button" className="action-btn-sm">Logs</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 5: TRANSACTIONS */}
          {activeTab === 'transactions' && (
            <motion.div
              key="transactions"
              initial={{ opacity: 0, y: 15, scale: 0.995 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -15, scale: 0.995 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="tab-content-wrapper"
            >
              <div className="table-card glass-panel">
                <div className="table-header">
                  <div>
                    <h3>Transactions & Verification Audit Log</h3>
                    <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                      Complete real-time ledger of authorized payments and verified checkpoints
                    </p>
                  </div>
                  <button type="button" className="header-btn">
                    Download CSV Audit
                  </button>
                </div>

                <div style={{ overflowX: 'auto' }}>
                  <table className="glass-table">
                    <thead>
                      <tr>
                        <th>Transaction ID</th>
                        <th>User</th>
                        <th>Amount</th>
                        <th>Verification Protocol</th>
                        <th>Origin IP</th>
                        <th>Status</th>
                        <th>Timestamp</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredTransactions.map((tx) => (
                        <tr key={tx.id}>
                          <td style={{ fontFamily: 'monospace', fontWeight: 600, color: '#38bdf8' }}>{tx.id}</td>
                          <td>
                            <div className="user-cell">
                              <div className="mini-avatar" style={{ backgroundColor: tx.color }}>
                                {tx.avatar}
                              </div>
                              <span style={{ fontWeight: 600 }}>{tx.user}</span>
                            </div>
                          </td>
                          <td style={{ fontWeight: 700, color: '#fff' }}>{tx.amount}</td>
                          <td>{tx.method}</td>
                          <td style={{ fontFamily: 'monospace', fontSize: '12px', color: 'rgba(255,255,255,0.7)' }}>{tx.ip}</td>
                          <td>
                            <span className={`status-tag ${tx.status}`}>
                              {tx.status === 'success' && 'Authorized'}
                              {tx.status === 'pending' && 'Challenged'}
                              {tx.status === 'failed' && 'Declined'}
                            </span>
                          </td>
                          <td style={{ color: 'rgba(255,255,255,0.5)', fontSize: '12px' }}>{tx.time}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 6: SETTINGS & SECURITY */}
          {activeTab === 'settings' && (
            <motion.div
              key="settings"
              initial={{ opacity: 0, y: 15, scale: 0.995 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -15, scale: 0.995 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="tab-content-wrapper"
            >
              <div className="chart-card glass-panel">
                <div className="chart-card-header">
                  <div>
                    <h3>Security Keys & Enforcement Policies</h3>
                    <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                      Manage cryptographic access tokens, 2FA guardrails, and enterprise whitelists
                    </p>
                  </div>
                </div>

                <div className="settings-section">
                  {/* API Key Row */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <label style={{ fontSize: '13px', fontWeight: 600, color: '#fff' }}>Production Secret Key</label>
                    <div className="api-key-container">
                      <span style={{ flex: 1 }}>
                        {showApiKey ? 'sk_live_994b_82ef1092a4c017d84f' : 'sk_live_••••••••••••••••••••••••'}
                      </span>
                      <button type="button" className="action-btn-sm" onClick={() => setShowApiKey(!showApiKey)}>
                        {showApiKey ? 'Hide' : 'Reveal'}
                      </button>
                      <button type="button" className="action-btn-sm" onClick={handleCopyKey}>
                        {copiedKey ? '✓ Copied' : 'Copy'}
                      </button>
                    </div>
                  </div>

                  {/* Toggle 1 */}
                  <div className="settings-row">
                    <div className="settings-row-text">
                      <h4>Mandatory 2FA Enforcement</h4>
                      <p>Require hardware or SMS OTP authentication on every new administrative login</p>
                    </div>
                    <div
                      className={`glass-switch ${enforce2FA ? 'active' : ''}`}
                      onClick={() => setEnforce2FA(!enforce2FA)}
                    >
                      <div className="glass-switch-handle" />
                    </div>
                  </div>

                  {/* Toggle 2 */}
                  <div className="settings-row">
                    <div className="settings-row-text">
                      <h4>Geofencing & IP Reputation Shield</h4>
                      <p>Block authentication requests originating from anonymous proxies or Tor exit nodes</p>
                    </div>
                    <div
                      className={`glass-switch ${geofencing ? 'active' : ''}`}
                      onClick={() => setGeofencing(!geofencing)}
                    >
                      <div className="glass-switch-handle" />
                    </div>
                  </div>

                  {/* Toggle 3 */}
                  <div className="settings-row">
                    <div className="settings-row-text">
                      <h4>Strict 15-Minute Session Inactivity Timeout</h4>
                      <p>Automatically invalidate admin tokens after fifteen minutes of idle activity</p>
                    </div>
                    <div
                      className={`glass-switch ${sessionTimeout ? 'active' : ''}`}
                      onClick={() => setSessionTimeout(!sessionTimeout)}
                    >
                      <div className="glass-switch-handle" />
                    </div>
                  </div>

                  {/* Webhook Endpoint */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <label style={{ fontSize: '13px', fontWeight: 600, color: '#fff' }}>Webhook Alert Delivery Endpoint</label>
                    <input
                      type="text"
                      className="glass-input-box"
                      defaultValue="https://api.codexr.dev/v1/auth/events/webhook"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default Dashboard;
