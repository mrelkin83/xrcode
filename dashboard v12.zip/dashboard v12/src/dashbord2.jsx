import { useState } from 'react';
import './dashbord2.css';

// ==========================================================================
// Embedded High-Precision SVG Icons (Exact Quixotic Visual Fidelity)
// ==========================================================================

const QuixoticLogo = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
    <path
      d="M12 2C6.477 2 2 6.477 2 12C2 17.523 6.477 22 12 22C14.28 22 16.38 21.236 18.06 19.94L15.65 17.53C14.58 18.15 13.33 18.5 12 18.5C8.41 18.5 5.5 15.59 5.5 12C5.5 8.41 8.41 5.5 12 5.5C15.59 5.5 18.5 8.41 18.5 12C18.5 13.06 18.25 14.06 17.8 14.95L20.35 17.5C21.39 15.9 22 14.02 22 12C22 6.477 17.523 2 12 2Z"
      fill="#FFFFFF"
    />
    <rect x="13.5" y="13.5" width="4.5" height="4.5" rx="1.5" fill="#FFFFFF" />
  </svg>
);

const SearchIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8" />
    <line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
);

const BellIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </svg>
);

const ArrowUpRightIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <line x1="7" y1="17" x2="17" y2="7" />
    <polyline points="7 7 17 7 17 17" />
  </svg>
);

const CalendarIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
    <line x1="16" y1="2" x2="16" y2="6" />
    <line x1="8" y1="2" x2="8" y2="6" />
    <line x1="3" y1="10" x2="21" y2="10" />
  </svg>
);

const ChevronDownIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="6 9 12 15 18 9" />
  </svg>
);

const PlusIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="5" x2="12" y2="19" />
    <line x1="5" y1="12" x2="19" y2="12" />
  </svg>
);

// Sidebar Navigation Icons
const AppGridIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <rect x="3" y="3" width="7.5" height="7.5" rx="2" fill="currentColor" />
    <rect x="13.5" y="3" width="7.5" height="7.5" rx="2" fill="currentColor" />
    <rect x="3" y="13.5" width="7.5" height="7.5" rx="2" fill="currentColor" />
    <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2" fill="currentColor" />
  </svg>
);

const AnalyticsIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="20" x2="18" y2="10" />
    <line x1="12" y1="20" x2="12" y2="4" />
    <line x1="6" y1="20" x2="6" y2="14" />
    <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.6" />
  </svg>
);

const WalletIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" />
    <path d="M16 3H8a2 2 0 0 0-2 2v2h12V5a2 2 0 0 0-2-2z" />
    <circle cx="17" cy="14" r="1.5" fill="currentColor" />
  </svg>
);

const ChatBubbleIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="16" rx="4" />
    <line x1="7" y1="9" x2="17" y2="9" />
    <line x1="7" y1="13" x2="13" y2="13" />
  </svg>
);

const FolderIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
  </svg>
);

const MailIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
    <polyline points="22,6 12,13 2,6" />
  </svg>
);

const PercentCircleIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" />
    <line x1="9" y1="15" x2="15" y2="9" />
    <circle cx="9.5" cy="9.5" r="1.2" fill="currentColor" />
    <circle cx="14.5" cy="14.5" r="1.2" fill="currentColor" />
  </svg>
);

const SettingsIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </svg>
);

const LogoutIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
    <polyline points="16 17 21 12 16 7" />
    <line x1="21" y1="12" x2="9" y2="12" />
  </svg>
);

// Card Specific Icons
const ContactlessIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" strokeWidth="2.2" strokeLinecap="round">
    <path d="M8.5 16.5C10.5 14.5 10.5 9.5 8.5 7.5" />
    <path d="M12 19C15 16 15 8 12 5" />
    <path d="M15.5 21.5C19.5 17.5 19.5 6.5 15.5 2.5" />
  </svg>
);

const RateSquareIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="4" width="20" height="16" rx="4" />
    <line x1="6" y1="10" x2="10" y2="10" />
    <line x1="6" y1="14" x2="14" y2="14" />
    <circle cx="16" cy="10" r="1.5" fill="currentColor" />
  </svg>
);

const RefundIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="4" width="20" height="16" rx="3" />
    <path d="M2 10h20" />
    <line x1="6" y1="15" x2="10" y2="15" />
  </svg>
);

// Table Brand Logos
const DribbbleLogo = () => (
  <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: '#EA4C89', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <path d="M19.13 5.09C15.22 9.14 10 10.44 2.25 10.94" />
      <path d="M21.75 12.84c-6.62-1.41-12.14 1-16.38 6.32" />
      <path d="M8.56 2.75c4.37 6 6 9.42 8 17.72" />
    </svg>
  </div>
);

const GooglePayLogo = () => (
  <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: '#F8FAFC', border: '1px solid #E2E8F0', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <svg width="20" height="20" viewBox="0 0 24 24">
      <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"/>
      <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.25 21.36 7.31 24 12 24z"/>
      <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.17 0 9.96 0 12s.45 3.83 1.25 5.42l4.03-3.15z"/>
      <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.25 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
    </svg>
  </div>
);

const AmazonLogo = () => (
  <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: '#F8FAFC', border: '1px solid #E2E8F0', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path d="M11.5 6C8.5 6 6 7.5 6 10.5C6 12.8 7.8 14 9.8 14C11.5 14 12.5 13.1 13 12.1V13.8H15.5V6.3H13V7.8C12.5 6.8 11.5 6 11.5 6ZM11 12C9.5 12 8.5 11.3 8.5 10C8.5 8.7 9.5 8 11 8C12.2 8 13 8.7 13 10C13 11.3 12.2 12 11 12Z" fill="#111827"/>
      <path d="M4 17.5C8 20 15 20.5 19 16.5" stroke="#FF9900" strokeWidth="2.2" strokeLinecap="round"/>
      <path d="M17.5 15.5L19.5 16.5L18.5 18.5" stroke="#FF9900" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  </div>
);

// High-fidelity Realistic Stylized Avatars
const UserProfileAvatar = () => (
  <svg width="40" height="40" viewBox="0 0 40 40" fill="none" className="qx-avatar">
    <circle cx="20" cy="20" r="20" fill="#3B82F6"/>
    <circle cx="20" cy="15" r="7" fill="#F87171"/>
    <path d="M8 34C8 27.37 13.37 22 20 22C26.63 22 32 27.37 32 34" fill="#1E293B"/>
    <path d="M14 11C14 8 18 6 22 7C25 8 26 12 25 15C21 15 17 13 14 11Z" fill="#991B1B"/>
  </svg>
);

const AvatarOne = () => (
  <svg width="44" height="44" viewBox="0 0 44 44" fill="none" className="qx-stacked-avatar">
    <circle cx="22" cy="22" r="21" fill="#FDE047" stroke="#FFFFFF" strokeWidth="2"/>
    <circle cx="22" cy="16" r="8" fill="#F59E0B"/>
    <circle cx="19" cy="15" r="1.5" fill="#1F2937"/>
    <circle cx="25" cy="15" r="1.5" fill="#1F2937"/>
    <rect x="17" y="13" width="10" height="3" rx="1.5" stroke="#1F2937" strokeWidth="1.2" fill="none"/>
    <path d="M10 38C10 30 15 26 22 26C29 26 34 30 34 38" fill="#D97706"/>
  </svg>
);

const AvatarTwo = () => (
  <svg width="44" height="44" viewBox="0 0 44 44" fill="none" className="qx-stacked-avatar">
    <circle cx="22" cy="22" r="21" fill="#E2E8F0" stroke="#FFFFFF" strokeWidth="2"/>
    <circle cx="22" cy="16" r="8" fill="#F97316"/>
    <path d="M16 17C16 22 28 22 28 17" fill="#C2410C"/>
    <circle cx="19" cy="14" r="1.5" fill="#1F2937"/>
    <circle cx="25" cy="14" r="1.5" fill="#1F2937"/>
    <path d="M10 38C10 30 15 26 22 26C29 26 34 30 34 38" fill="#475569"/>
  </svg>
);

const AvatarThree = () => (
  <svg width="44" height="44" viewBox="0 0 44 44" fill="none" className="qx-stacked-avatar">
    <circle cx="22" cy="22" r="21" fill="#FED7AA" stroke="#FFFFFF" strokeWidth="2"/>
    <circle cx="22" cy="16" r="8" fill="#FBBF24"/>
    <circle cx="19" cy="15" r="1.5" fill="#1F2937"/>
    <circle cx="25" cy="15" r="1.5" fill="#1F2937"/>
    <path d="M19 19C21 21 23 21 25 19" stroke="#1F2937" strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M10 38C10 30 15 26 22 26C29 26 34 30 34 38" fill="#EA580C"/>
  </svg>
);

const AvatarFour = () => (
  <svg width="44" height="44" viewBox="0 0 44 44" fill="none" className="qx-stacked-avatar">
    <circle cx="22" cy="22" r="21" fill="#93C5FD" stroke="#FFFFFF" strokeWidth="2"/>
    <circle cx="22" cy="16" r="8" fill="#3B82F6"/>
    <path d="M16 16C16 23 28 23 28 16" fill="#1E3A8A"/>
    <circle cx="19" cy="14" r="1.5" fill="#FFFFFF"/>
    <circle cx="25" cy="14" r="1.5" fill="#FFFFFF"/>
    <path d="M10 38C10 30 15 26 22 26C29 26 34 30 34 38" fill="#1D4ED8"/>
  </svg>
);

// ==========================================================================
// Main Dashboard Component
// ==========================================================================

export default function QuixoticDashboard() {
  // Navigation states
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [sidebarActive, setSidebarActive] = useState('grid');
  const [rateTimeframe, setRateTimeframe] = useState('Annually');
  const [toastMessage, setToastMessage] = useState('');

  const triggerToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage('');
    }, 2800);
  };

  return (
    <div className="qx-viewport">
      {/* ==================================================================
          1. Top Navigation Bar (Quixotic Header)
          ================================================================== */}
      <header className="qx-navbar">
        {/* Brand Logo & Name */}
        <div className="qx-brand" onClick={() => triggerToast('Quixotic Home')}>
          <div className="qx-brand-logo">
            <QuixoticLogo />
          </div>
          <span className="qx-brand-name">Quixotic</span>
        </div>

        {/* Center Nav Pills */}
        <nav className="qx-nav-links">
          {['Dashboard', 'Reports', 'Documents', 'History', 'Contacts'].map((tab) => (
            <button
              key={tab}
              className={`qx-nav-item ${activeTab === tab ? 'active' : ''}`}
              onClick={() => {
                setActiveTab(tab);
                triggerToast(`Switched to ${tab}`);
              }}
            >
              {tab}
            </button>
          ))}
        </nav>

        {/* Right Nav Actions & Profile */}
        <div className="qx-nav-actions">
          <button className="qx-circle-btn" onClick={() => triggerToast('Search opened')} aria-label="Search">
            <SearchIcon />
          </button>
          <button className="qx-circle-btn" onClick={() => triggerToast('No new notifications')} aria-label="Notifications">
            <BellIcon />
          </button>
          <button className="qx-profile-btn" onClick={() => triggerToast('Profile menu')} aria-label="User Profile">
            <UserProfileAvatar />
            <span style={{ color: '#6B7280' }}>
              <ChevronDownIcon />
            </span>
          </button>
        </div>
      </header>

      {/* ==================================================================
          2. Greeting Row & Action Buttons
          ================================================================== */}
      <section className="qx-greeting-row">
        <h1 className="qx-greeting-title">
          <strong>Welcome Back,</strong>
          <span>Sujon</span>
        </h1>

        <div className="qx-greeting-controls">
          <button className="qx-date-pill" onClick={() => triggerToast('Date range filter clicked')}>
            <CalendarIcon />
            <span>29 Jun, 2025 - 29 August, 2025</span>
            <ChevronDownIcon />
          </button>

          <button className="qx-add-wallet-btn" onClick={() => triggerToast('Add New Wallet modal opened')}>
            <PlusIcon />
            <span>Add New Wallet</span>
          </button>
        </div>
      </section>

      {/* ==================================================================
          3. Main Workspace (Sidebar + Grid Content)
          ================================================================== */}
      <main className="qx-workspace">
        {/* Left Floating Pill Sidebar */}
        <aside className="qx-sidebar">
          {/* Top Group */}
          <div className="qx-sidebar-group">
            <button
              className={`qx-sidebar-btn ${sidebarActive === 'grid' ? 'active' : ''}`}
              onClick={() => setSidebarActive('grid')}
              aria-label="Dashboard Grid"
            >
              <AppGridIcon />
            </button>
            <button
              className={`qx-sidebar-btn ${sidebarActive === 'analytics' ? 'active' : ''}`}
              onClick={() => setSidebarActive('analytics')}
              aria-label="Analytics"
            >
              <AnalyticsIcon />
            </button>
            <button
              className={`qx-sidebar-btn ${sidebarActive === 'wallet' ? 'active' : ''}`}
              onClick={() => setSidebarActive('wallet')}
              aria-label="Wallet"
            >
              <WalletIcon />
            </button>
            <button
              className={`qx-sidebar-btn ${sidebarActive === 'chat' ? 'active' : ''}`}
              onClick={() => setSidebarActive('chat')}
              aria-label="Messages"
            >
              <ChatBubbleIcon />
            </button>

            <div className="qx-sidebar-divider" />

            {/* Middle Group */}
            <button
              className={`qx-sidebar-btn ${sidebarActive === 'folder' ? 'active' : ''}`}
              onClick={() => setSidebarActive('folder')}
              aria-label="Documents"
            >
              <FolderIcon />
            </button>
            <button
              className={`qx-sidebar-btn ${sidebarActive === 'mail' ? 'active' : ''}`}
              onClick={() => setSidebarActive('mail')}
              aria-label="Mail"
            >
              <MailIcon />
            </button>
            <button
              className={`qx-sidebar-btn ${sidebarActive === 'percent' ? 'active' : ''}`}
              onClick={() => setSidebarActive('percent')}
              aria-label="Discounts"
            >
              <PercentCircleIcon />
            </button>
          </div>

          {/* Bottom Group */}
          <div className="qx-sidebar-group">
            <button
              className={`qx-sidebar-btn ${sidebarActive === 'settings' ? 'active' : ''}`}
              onClick={() => {
                setSidebarActive('settings');
                triggerToast('Settings panel');
              }}
              aria-label="Settings"
            >
              <SettingsIcon />
            </button>
            <button
              className="qx-sidebar-btn"
              onClick={() => triggerToast('Logged out')}
              aria-label="Logout"
            >
              <LogoutIcon />
            </button>
          </div>
        </aside>

        {/* Dashboard Cards Grid */}
        <div className="qx-grid">
          {/* ==============================================================
              Card 1: Payment Goal (Emerald VISA Card + Weekly Revenue)
              ============================================================== */}
          <div className="qx-card">
            <div className="qx-card-header">
              <div>
                <h3 className="qx-card-title">Payment Goal</h3>
                <p className="qx-card-subtitle">Total amount goal</p>
              </div>
              <button className="qx-arrow-btn" onClick={() => triggerToast('Goal details')} aria-label="Details">
                <ArrowUpRightIcon />
              </button>
            </div>

            {/* The Vibrant Emerald VISA Card */}
            <div className="qx-credit-card">
              <div className="qx-credit-card-top">
                <span className="qx-visa-logo">VISA</span>
                <ContactlessIcon />
              </div>

              <div className="qx-card-balance-section">
                <p className="qx-card-type-label">Credit Card</p>
                <h2 className="qx-card-balance-amount">$ 78,989.09</h2>
              </div>

              <div className="qx-credit-card-bottom">
                <span>•••• 909090</span>
                <span>EXP 09/26</span>
              </div>
            </div>

            {/* Weekly Revenue Footer */}
            <div className="qx-revenue-section">
              <div>
                <p className="qx-rev-label">Weekly Revenue</p>
                <h4 className="qx-rev-amount">+3,945 USD</h4>
              </div>
              <span className="qx-pill-badge">+12.8%</span>
            </div>
          </div>

          {/* ==============================================================
              Card 2: Engagement Rate (Striped Diagonal Capsule Bar Chart)
              ============================================================== */}
          <div className="qx-card">
            <div className="qx-card-header">
              <div className="qx-card-title-group">
                <RateSquareIcon />
                <h3 className="qx-card-title">Engagement Rate</h3>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div className="qx-toggle-pill">
                  <button
                    className={`qx-toggle-btn ${rateTimeframe === 'Monthly' ? 'active' : ''}`}
                    onClick={() => setRateTimeframe('Monthly')}
                  >
                    Monthly
                  </button>
                  <button
                    className={`qx-toggle-btn ${rateTimeframe === 'Annually' ? 'active' : ''}`}
                    onClick={() => setRateTimeframe('Annually')}
                  >
                    Annually
                  </button>
                </div>
                <button className="qx-arrow-btn" onClick={() => triggerToast('Rate analytics')} aria-label="Details">
                  <ArrowUpRightIcon />
                </button>
              </div>
            </div>

            {/* Precision SVG Chart with Diagonal Hatched Patterns & Active APR */}
            <div className="qx-chart-wrapper">
              <svg width="100%" height="100%" viewBox="0 0 520 220" preserveAspectRatio="none">
                <defs>
                  {/* Diagonal Green Hatch Pattern for the non-active bars */}
                  <pattern
                    id="diagonalGreenHatch"
                    width="10"
                    height="10"
                    patternTransform="rotate(45 0 0)"
                    patternUnits="userSpaceOnUse"
                  >
                    <rect width="10" height="10" fill="#9ECBBB" />
                    <line x1="0" y1="0" x2="0" y2="10" stroke="#529B81" strokeWidth="3" />
                  </pattern>
                </defs>

                {/* Y-Axis Gridlines & Values */}
                {[
                  { val: '5k', y: 30 },
                  { val: '4k', y: 64 },
                  { val: '3k', y: 98 },
                  { val: '2k', y: 132 },
                  { val: '1k', y: 166 },
                  { val: '0', y: 200 },
                ].map((item) => (
                  <g key={item.val}>
                    <text x="14" y={item.y + 4} fill="#9CA3AF" fontSize="11" fontWeight="500" textAnchor="end">
                      {item.val}
                    </text>
                    <line
                      x1="26"
                      y1={item.y}
                      x2="510"
                      y2={item.y}
                      stroke="#F0F2F6"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                    />
                  </g>
                ))}

                {/* Bars & X Labels */}
                {/* 1. JAN */}
                <rect x="52" y="142" width="36" height="58" rx="18" fill="url(#diagonalGreenHatch)" />
                <text x="70" y="214" fill="#8C95A6" fontSize="11" fontWeight="600" textAnchor="middle">JAN</text>

                {/* 2. FEB */}
                <rect x="130" y="60" width="36" height="140" rx="18" fill="url(#diagonalGreenHatch)" />
                <text x="148" y="214" fill="#8C95A6" fontSize="11" fontWeight="600" textAnchor="middle">FEB</text>

                {/* 3. MAR */}
                <rect x="208" y="104" width="36" height="96" rx="18" fill="url(#diagonalGreenHatch)" />
                <text x="226" y="214" fill="#8C95A6" fontSize="11" fontWeight="600" textAnchor="middle">MAR</text>

                {/* 4. APR (Active Highlighted Column in Solid Emerald Green) */}
                <g>
                  <rect x="286" y="38" width="36" height="162" rx="18" fill="#0D8253" />
                  {/* Top indicator dot & circle */}
                  <circle cx="304" cy="38" r="4.5" fill="#0D8253" />
                  <circle cx="304" cy="38" r="2.5" fill="#FFFFFF" />

                  {/* Floating +17.8% badge pill */}
                  <rect x="283" y="10" width="42" height="18" rx="9" fill="#0D8253" />
                  <text x="304" y="23" fill="#FFFFFF" fontSize="9.5" fontWeight="700" textAnchor="middle">
                    +17.8%
                  </text>
                </g>
                <text x="304" y="214" fill="#8C95A6" fontSize="11" fontWeight="600" textAnchor="middle">APR</text>

                {/* 5. MAY */}
                <rect x="364" y="86" width="36" height="114" rx="18" fill="url(#diagonalGreenHatch)" />
                <text x="382" y="214" fill="#8C95A6" fontSize="11" fontWeight="600" textAnchor="middle">MAY</text>

                {/* 6. JUN */}
                <rect x="442" y="62" width="36" height="138" rx="18" fill="url(#diagonalGreenHatch)" />
                <text x="460" y="214" fill="#8C95A6" fontSize="11" fontWeight="600" textAnchor="middle">JUN</text>
              </svg>
            </div>
          </div>

          {/* ==============================================================
              Card 3: Payment Goal (Wavy Area Chart + Send / Receive)
              ============================================================== */}
          <div className="qx-card">
            <div className="qx-card-header" style={{ marginBottom: '8px' }}>
              <div>
                <h3 className="qx-card-title">Payment Goal</h3>
                <p className="qx-card-subtitle">Total amount goal</p>
              </div>
              <button className="qx-arrow-btn" onClick={() => triggerToast('Total balance history')} aria-label="Details">
                <ArrowUpRightIcon />
              </button>
            </div>

            {/* Total Balance Amount */}
            <div className="qx-wave-balance-header">
              <p className="qx-wave-balance-label">Total Balance</p>
              <h2 className="qx-wave-balance-num">
                $32,678<span>.90</span>
              </h2>
            </div>

            {/* Spline Area Chart */}
            <div className="qx-wave-chart-container">
              <svg width="100%" height="100%" viewBox="0 0 320 100" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="waveGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#0D8253" stopOpacity="0.28" />
                    <stop offset="85%" stopColor="#0D8253" stopOpacity="0.04" />
                    <stop offset="100%" stopColor="#0D8253" stopOpacity="0" />
                  </linearGradient>
                </defs>

                {/* Subtle Horizontal Reference Line */}
                <line x1="0" y1="58" x2="320" y2="58" stroke="#E5E7EB" strokeWidth="0.8" strokeDasharray="3 3" />

                {/* Gradient Fill Under Curve */}
                <path
                  d="M0,58 C25,58 35,74 55,74 C75,74 85,32 105,32 C125,32 140,68 160,68 C180,68 190,34 210,34 C230,34 245,68 265,68 C285,68 295,35 320,35 L320,100 L0,100 Z"
                  fill="url(#waveGradient)"
                />

                {/* Smooth Emerald Green Curve Stroke */}
                <path
                  d="M0,58 C25,58 35,74 55,74 C75,74 85,32 105,32 C125,32 140,68 160,68 C180,68 190,34 210,34 C230,34 245,68 265,68 C285,68 295,35 320,35"
                  fill="none"
                  stroke="#0D8253"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                />
              </svg>
            </div>

            {/* Action Buttons: Send & Receive */}
            <div className="qx-actions-row">
              <button className="qx-btn-send" onClick={() => triggerToast('Send Funds initiated')}>
                Send <span>↑</span>
              </button>
              <button className="qx-btn-receive" onClick={() => triggerToast('Receive QR Code shown')}>
                Receive <span>↓</span>
              </button>
            </div>
          </div>

          {/* ==============================================================
              Card 4: Payment History Table (Spans Columns 1 & 2)
              ============================================================== */}
          <div className="qx-card qx-card-history">
            <div className="qx-card-header">
              <div>
                <h3 className="qx-card-title">Payment History</h3>
                <p className="qx-card-subtitle">Recent payments history</p>
              </div>
              <button className="qx-arrow-btn" onClick={() => triggerToast('Full transaction history')} aria-label="Details">
                <ArrowUpRightIcon />
              </button>
            </div>

            <table className="qx-history-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Status</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                {/* Row 1: Dribbble Design */}
                <tr className="qx-table-row">
                  <td>
                    <div className="qx-name-cell">
                      <DribbbleLogo />
                      <div className="qx-name-info">
                        <span className="qx-item-title">Dribbble Design</span>
                        <span className="qx-item-gain">+18.67%</span>
                      </div>
                    </div>
                  </td>
                  <td>16 Jun 2025</td>
                  <td>10: 30 PM</td>
                  <td>
                    <div className="qx-status-cell">
                      <span className="qx-status-dot" />
                      <span>Successful</span>
                    </div>
                  </td>
                  <td>89, 345. 23 USD</td>
                </tr>

                {/* Row 2: Google Pay */}
                <tr className="qx-table-row">
                  <td>
                    <div className="qx-name-cell">
                      <GooglePayLogo />
                      <div className="qx-name-info">
                        <span className="qx-item-title">Google Pay</span>
                        <span className="qx-item-gain">+9.34%</span>
                      </div>
                    </div>
                  </td>
                  <td>15 Jun 2025</td>
                  <td>11: 45 PM</td>
                  <td>
                    <div className="qx-status-cell">
                      <span className="qx-status-dot" />
                      <span>Successful</span>
                    </div>
                  </td>
                  <td>12, 345. 89 USD</td>
                </tr>

                {/* Row 3: Amazon Shopping */}
                <tr className="qx-table-row">
                  <td>
                    <div className="qx-name-cell">
                      <AmazonLogo />
                      <div className="qx-name-info">
                        <span className="qx-item-title">Amazon Shopping</span>
                        <span className="qx-item-gain">+12.23%</span>
                      </div>
                    </div>
                  </td>
                  <td>14 Jun 2025</td>
                  <td>10: 15 PM</td>
                  <td>
                    <div className="qx-status-cell">
                      <span className="qx-status-dot" />
                      <span>Successful</span>
                    </div>
                  </td>
                  <td>32, 123. 67 USD</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ==============================================================
              Card 5: Right Column Bottom (Amount of Credit + Mandatory Payments)
              ============================================================== */}
          <div className="qx-col3-bottom">
            {/* Sub-Card A: Amount of credit */}
            <div className="qx-card qx-card-credit-stat">
              <div className="qx-credit-stat-header">
                <div className="qx-card-icon-bubble">
                  <RefundIcon />
                </div>
                <div>
                  <h3 className="qx-card-title">Amount of credit</h3>
                  <p className="qx-card-subtitle">Total refund amount with fee</p>
                </div>
              </div>

              <div className="qx-credit-stat-val-row">
                <h2 className="qx-credit-stat-amount">
                  $8,945<span>.89</span>
                </h2>
                <span className="qx-pill-badge">+12.8%</span>
              </div>
            </div>

            {/* Sub-Card B: Mandatory Payments (Overlapping Avatars) */}
            <div className="qx-card qx-card-mandatory">
              <div className="qx-card-header" style={{ marginBottom: '4px' }}>
                <div>
                  <h3 className="qx-card-title">Mandatory Payments</h3>
                  <p className="qx-card-subtitle">Recent payments</p>
                </div>
                <button className="qx-arrow-btn" onClick={() => triggerToast('Mandatory recipients')} aria-label="Details">
                  <ArrowUpRightIcon />
                </button>
              </div>

              {/* Overlapping User Avatars Stack with +2 Badge */}
              <div className="qx-avatar-stack">
                <AvatarOne />
                <AvatarTwo />
                <AvatarThree />
                <AvatarFour />
                <div
                  className="qx-avatar-more-badge"
                  onClick={() => triggerToast('+2 more contacts: Sarah & Liam')}
                  title="2 more contacts"
                >
                  +2
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Floating Interactive Toast Feedback */}
      {toastMessage && (
        <div className="qx-toast">
          <span style={{ color: '#10B981', fontWeight: 'bold' }}>✓</span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
