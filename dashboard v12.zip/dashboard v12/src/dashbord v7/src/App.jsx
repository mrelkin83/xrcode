import { useState } from 'react';
import AdminDashboard from './daashbrod1.jsx';
import GlassFitnessDashboard from './dashbrod2.jsx';

function App() {
  // Default to Dashboard 2 as requested by user
  const [currentDashboard, setCurrentDashboard] = useState(2);

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh', overflow: 'hidden' }}>

      {/* Floating Modern Switcher at Bottom Center */}
      <div
        style={{
          position: 'fixed',
          bottom: '14px',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 9999,
          display: 'flex',
          gap: '6px',
          background: 'rgba(15, 23, 42, 0.85)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          border: '1px solid rgba(255, 255, 255, 0.22)',
          borderRadius: '9999px',
          padding: '4px',
          boxShadow: '0 10px 35px rgba(0, 0, 0, 0.45)',
        }}
      >
        <button
          onClick={() => setCurrentDashboard(1)}
          style={{
            border: 'none',
            outline: 'none',
            padding: '6px 14px',
            borderRadius: '9999px',
            fontSize: '11.5px',
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            background: currentDashboard === 1 ? '#1967d2' : 'transparent',
            color: '#ffffff',
            boxShadow: currentDashboard === 1 ? '0 2px 8px rgba(25, 103, 210, 0.4)' : 'none',
          }}
        >
          Dashboard 1 (Admin)
        </button>

        <button
          onClick={() => setCurrentDashboard(2)}
          style={{
            border: 'none',
            outline: 'none',
            padding: '6px 14px',
            borderRadius: '9999px',
            fontSize: '11.5px',
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            background: currentDashboard === 2 ? '#ff701e' : 'transparent',
            color: '#ffffff',
            boxShadow: currentDashboard === 2 ? '0 2px 8px rgba(255, 112, 30, 0.4)' : 'none',
          }}
        >
          Dashboard 2 (Glassy Fitness ✨)
        </button>
      </div>

      {/* Render Current Dashboard */}
      {currentDashboard === 1 ? <AdminDashboard /> : <GlassFitnessDashboard />}
    </div>
  );
}

export default App;
