import { useState, useMemo } from 'react';
import './dashbord1.css';

// ==========================================================================
// Modern Enterprise Admin SVG Icons (Clean, Fast, Zero External Dependencies)
// ==========================================================================

const AdminLogoIcon = () => (
  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="24" height="24" rx="6" fill="#1967D2"/>
    <path d="M7 12L10.5 15.5L17 8.5" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="12" cy="12" r="9" stroke="#FFFFFF" strokeOpacity="0.3" strokeWidth="1.5"/>
  </svg>
);

const SearchIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8"></circle>
    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
  </svg>
);

const BellIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
    <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
  </svg>
);

const HelpIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle>
    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
    <line x1="12" y1="17" x2="12.01" y2="17"></line>
  </svg>
);

const SettingsIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3"></circle>
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
  </svg>
);

const SlidersIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="4" y1="21" x2="4" y2="14"></line>
    <line x1="4" y1="10" x2="4" y2="3"></line>
    <line x1="12" y1="21" x2="12" y2="12"></line>
    <line x1="12" y1="8" x2="12" y2="3"></line>
    <line x1="20" y1="21" x2="20" y2="16"></line>
    <line x1="20" y1="12" x2="20" y2="3"></line>
    <line x1="1" y1="14" x2="7" y2="14"></line>
    <line x1="9" y1="8" x2="15" y2="8"></line>
    <line x1="17" y1="16" x2="23" y2="16"></line>
  </svg>
);

const PlusIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
);

// Sidebar Nav Icons for Pure Admin Dashboard
const DashboardNavIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="9"></rect>
    <rect x="14" y="3" width="7" height="5"></rect>
    <rect x="14" y="12" width="7" height="9"></rect>
    <rect x="3" y="16" width="7" height="5"></rect>
  </svg>
);

const AnalyticsNavIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="20" x2="18" y2="10"></line>
    <line x1="12" y1="20" x2="12" y2="4"></line>
    <line x1="6" y1="20" x2="6" y2="14"></line>
  </svg>
);

const UsersNavIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
    <circle cx="9" cy="7" r="4"></circle>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
  </svg>
);

const OrdersNavIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
    <line x1="1" y1="10" x2="23" y2="10"></line>
  </svg>
);

const ProductsNavIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="16.5" y1="9.4" x2="7.5" y2="4.21"></line>
    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
    <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
    <line x1="12" y1="22.08" x2="12" y2="12"></line>
  </svg>
);

const SecurityNavIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
  </svg>
);

const ConfigNavIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3"></circle>
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
  </svg>
);

// Telemetry Icons
const CpuIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect>
    <rect x="9" y="9" width="6" height="6"></rect>
    <line x1="9" y1="1" x2="9" y2="4"></line>
    <line x1="15" y1="1" x2="15" y2="4"></line>
    <line x1="9" y1="20" x2="9" y2="23"></line>
    <line x1="15" y1="20" x2="15" y2="23"></line>
    <line x1="20" y1="9" x2="23" y2="9"></line>
    <line x1="20" y1="14" x2="23" y2="14"></line>
    <line x1="1" y1="9" x2="4" y2="9"></line>
    <line x1="1" y1="14" x2="4" y2="14"></line>
  </svg>
);

const RamIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2 12h20M6 8v8M10 8v8M14 8v8M18 8v8"></path>
    <rect x="2" y="6" width="20" height="12" rx="2"></rect>
  </svg>
);

// Content Action Icons
const ActionBadgeIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
  </svg>
);

const GridViewIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7"></rect>
    <rect x="14" y="3" width="7" height="7"></rect>
    <rect x="14" y="14" width="7" height="7"></rect>
    <rect x="3" y="14" width="7" height="7"></rect>
  </svg>
);

const InfoCircleIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle>
    <line x1="12" y1="16" x2="12" y2="12"></line>
    <line x1="12" y1="8" x2="12.01" y2="8"></line>
  </svg>
);

const LinkIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
  </svg>
);

const MoreDotsIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="1"></circle>
    <circle cx="19" cy="12" r="1"></circle>
    <circle cx="5" cy="12" r="1"></circle>
  </svg>
);

// Transaction & Enterprise Brand Row Icons
const EnterpriseDocIcon = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" fill="#1967d2">
    <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
  </svg>
);

const StripePaymentIcon = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" fill="#0f9d58">
    <rect x="2" y="4" width="20" height="16" rx="3" fill="#0f9d58"/>
    <path d="M6 10h12M6 14h6" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);

const CloudTierIcon = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" fill="#ea4335">
    <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z"/>
  </svg>
);

const BankWireIcon = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" fill="#185abd">
    <path d="M4 10v7h3v-7H4zm6 0v7h3v-7h-3zM2 22h19v-3H2v3zm14-12v7h3v-7h-3zm-4.5-9L2 6v2h19V6l-9.5-5z"/>
  </svg>
);

const ServerInstanceIcon = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" fill="#f29900">
    <rect x="2" y="3" width="20" height="8" rx="2" fill="#f29900"/>
    <rect x="2" y="13" width="20" height="8" rx="2" fill="#f29900"/>
    <circle cx="6" cy="7" r="1.5" fill="#FFFFFF"/>
    <circle cx="6" cy="17" r="1.5" fill="#FFFFFF"/>
  </svg>
);

// Sample Avatars for Team & Customers
const AVATARS = {
  alex: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=60&auto=format&fit=crop&q=80",
  david: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&auto=format&fit=crop&q=80",
  sarah: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&auto=format&fit=crop&q=80",
  jessica: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=60&auto=format&fit=crop&q=80",
  marcus: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=60&auto=format&fit=crop&q=80",
};

// ==========================================================================
// Pure Enterprise Admin Dashboard Datasets for All 7 Tabs
// ==========================================================================

const ADMIN_TAB_DATA = {
  'overview': {
    title: 'Admin Overview',
    quickAccessTitle: 'KEY PERFORMANCE METRICS',
    sectionTitle: 'RECENT TRANSACTIONS & CLIENTS',
    cards: [
      {
        id: 'qc-1',
        type: 'blue',
        tag: 'MONTHLY ARR',
        avatars: [AVATARS.alex, AVATARS.david, AVATARS.sarah, AVATARS.jessica],
        sublabel: 'REVENUE GROWTH',
        name: '$128,450.00 (+16.4%)'
      },
      {
        id: 'qc-2',
        type: 'light',
        tag: 'TOTAL MEMBERS',
        avatars: [AVATARS.sarah, AVATARS.marcus, AVATARS.david],
        sublabel: 'ACTIVE USERS',
        name: '24,890 Accounts'
      },
      {
        id: 'qc-3',
        type: 'light',
        tag: 'FULFILLMENT 99.4%',
        avatars: [AVATARS.alex, AVATARS.david, AVATARS.marcus],
        sublabel: 'COMPLETED ORDERS',
        name: '1,420 Transactions'
      },
      {
        id: 'qc-4',
        type: 'doc',
        tag: 'EXECUTIVE BRIEF',
        docTitle: 'Q3 Enterprise Revenue Milestone Achieved',
        avatar: AVATARS.jessica,
        sublabel: 'SYSTEM DISPATCH',
        name: 'Sep 28, 2026 - 11:30 AM'
      }
    ],
    columns: ['CLIENT / TRANSACTION', 'ASSIGNED ADMIN', 'TIMESTAMP', 'AMOUNT / STATUS'],
    rows: [
      {
        id: 'r1',
        name: 'Acme Corp - Enterprise Cloud License',
        icon: <EnterpriseDocIcon />,
        owners: [AVATARS.alex, AVATARS.david],
        modified: 'Today - 04:30 PM',
        size: '$14,500.00 (Paid)',
        selected: false
      },
      {
        id: 'r2',
        name: 'Stripe Settlement - US Merchant Gateway',
        icon: <StripePaymentIcon />,
        owners: [AVATARS.sarah],
        modified: 'Today - 03:15 PM',
        size: '$28,900.00 (Settled)',
        selected: false
      },
      {
        id: 'r3',
        name: 'Vercel Inc - Global CDN Edge Compute',
        icon: <CloudTierIcon />,
        owners: [AVATARS.jessica],
        modified: 'Today - 01:45 PM',
        size: '$4,200.00 (Paid)',
        selected: false
      },
      {
        id: 'r4',
        name: 'Shopify Storefront - API Sync License',
        icon: <BankWireIcon />,
        owners: [AVATARS.alex],
        modified: 'Today - 11:10 AM',
        size: '$1,850.00 (Paid)',
        selected: false
      },
      {
        id: 'r5',
        name: 'Tesla Motors - Dedicated GPU Cluster Tier',
        icon: <ServerInstanceIcon />,
        owners: [AVATARS.david],
        modified: 'Today - 09:20 AM',
        size: '$52,000.00 (Processing)',
        selected: true // Highlighted soft blue row matching screenshot design
      },
      {
        id: 'r6',
        name: 'Spotify Soundworks - Bandwidth Allocation',
        icon: <ServerInstanceIcon />,
        owners: [AVATARS.marcus],
        modified: 'Today - 08:00 AM',
        size: '$9,400.00 (Paid)',
        selected: false
      }
    ]
  },

  'analytics': {
    title: 'Analytics & Traffic',
    quickAccessTitle: 'TRAFFIC & CONVERSION METRICS',
    sectionTitle: 'TOP REVENUE & CONVERTING CHANNELS',
    cards: [
      {
        id: 'an-1',
        type: 'blue',
        tag: 'MONTHLY VOLUME',
        avatars: [AVATARS.alex, AVATARS.jessica],
        sublabel: 'PAGEVIEWS',
        name: '1.84M Unique Hits'
      },
      {
        id: 'an-2',
        type: 'light',
        tag: 'ENGAGEMENT',
        avatars: [AVATARS.sarah],
        sublabel: 'AVG SESSION',
        name: '4m 38s (+18s)'
      },
      {
        id: 'an-3',
        type: 'light',
        tag: 'BENCHMARK',
        avatars: [AVATARS.david],
        sublabel: 'BOUNCE RATE',
        name: '24.2% Optimal'
      },
      {
        id: 'an-4',
        type: 'doc',
        tag: 'CAMPAIGN REPORT',
        docTitle: 'Google Ads Q3 ROI Exceeds 420%',
        avatar: AVATARS.marcus,
        sublabel: 'AUDITED AT',
        name: 'Sep 27, 2026 - 06:10 PM'
      }
    ],
    columns: ['CHANNEL SOURCE', 'LEAD STEWARD', 'CONVERSION RATE', 'TOTAL REVENUE'],
    rows: [
      {
        id: 'a1',
        name: 'Organic Search (Google & Bing)',
        icon: <EnterpriseDocIcon />,
        owners: [AVATARS.alex],
        modified: '4.8% CR',
        size: '$64,200.00',
        selected: false
      },
      {
        id: 'a2',
        name: 'Direct Traffic & Bookmarks',
        icon: <BankWireIcon />,
        owners: [AVATARS.david],
        modified: '6.2% CR',
        size: '$38,400.00',
        selected: true
      },
      {
        id: 'a3',
        name: 'LinkedIn Enterprise B2B Sponsored',
        icon: <CloudTierIcon />,
        owners: [AVATARS.sarah],
        modified: '3.9% CR',
        size: '$22,800.00',
        selected: false
      },
      {
        id: 'a4',
        name: 'Partner Affiliate Referrals',
        icon: <StripePaymentIcon />,
        owners: [AVATARS.marcus],
        modified: '5.1% CR',
        size: '$18,100.00',
        selected: false
      },
      {
        id: 'a5',
        name: 'Email Newsletter Automation',
        icon: <ServerInstanceIcon />,
        owners: [AVATARS.jessica],
        modified: '7.4% CR',
        size: '$12,950.00',
        selected: false
      }
    ]
  },

  'users': {
    title: 'Users & Customers',
    quickAccessTitle: 'USER ROLES & ACCOUNTS',
    sectionTitle: 'REGISTERED CLIENT ACCOUNTS',
    cards: [
      {
        id: 'us-1',
        type: 'blue',
        tag: 'ADMIN ROLES',
        avatars: [AVATARS.jessica, AVATARS.alex, AVATARS.david],
        sublabel: 'SUPER ADMINS',
        name: '6 Verified Leads'
      },
      {
        id: 'us-2',
        type: 'light',
        tag: 'CLIENT TIER',
        avatars: [AVATARS.sarah, AVATARS.marcus],
        sublabel: 'ENTERPRISE ACCOUNTS',
        name: '148 Organizations'
      },
      {
        id: 'us-3',
        type: 'light',
        tag: 'RETENTION',
        avatars: [AVATARS.alex, AVATARS.david],
        sublabel: 'CHURN RATE',
        name: '0.84% Lowest Ever'
      },
      {
        id: 'us-4',
        type: 'doc',
        tag: 'NEW ONBOARDING',
        docTitle: 'OpenAI Enterprise Team Added to Cluster',
        avatar: AVATARS.sarah,
        sublabel: 'JOINED AT',
        name: 'Today - 09:12 AM'
      }
    ],
    columns: ['USER / ORGANIZATION', 'ACCOUNT LEAD', 'LAST ACTIVE', 'LIFETIME VALUE'],
    rows: [
      {
        id: 'u1',
        name: 'Dr. Arthur Pendelton (Nexus Health)',
        icon: <EnterpriseDocIcon />,
        owners: [AVATARS.alex],
        modified: 'Active 2 mins ago',
        size: '$84,000.00 LTV',
        selected: false
      },
      {
        id: 'u2',
        name: 'Elena Rostova (Fintech Global)',
        icon: <BankWireIcon />,
        owners: [AVATARS.sarah],
        modified: 'Active 14 mins ago',
        size: '$112,500.00 LTV',
        selected: true
      },
      {
        id: 'u3',
        name: 'Michael Chang (AeroSpace Dynamics)',
        icon: <CloudTierIcon />,
        owners: [AVATARS.david],
        modified: 'Active 1 hour ago',
        size: '$64,200.00 LTV',
        selected: false
      },
      {
        id: 'u4',
        name: 'Sarah Jenkins (Modern Retailers)',
        icon: <StripePaymentIcon />,
        owners: [AVATARS.marcus],
        modified: 'Active yesterday',
        size: '$28,400.00 LTV',
        selected: false
      },
      {
        id: 'u5',
        name: 'Kavita Rao (Cloud Native Labs)',
        icon: <ServerInstanceIcon />,
        owners: [AVATARS.jessica],
        modified: 'Active 3 days ago',
        size: '$42,000.00 LTV',
        selected: false
      }
    ]
  },

  'orders': {
    title: 'Orders & Billing',
    quickAccessTitle: 'BILLING & INVOICE PIPELINE',
    sectionTitle: 'CLIENT INVOICE LEDGER',
    cards: [
      {
        id: 'or-1',
        type: 'blue',
        tag: 'SETTLED YTD',
        avatars: [AVATARS.david, AVATARS.alex],
        sublabel: 'GROSS VOLUME',
        name: '$1,480,200.00'
      },
      {
        id: 'or-2',
        type: 'light',
        tag: 'DUE 48 HRS',
        avatars: [AVATARS.sarah],
        sublabel: 'PENDING INVOICES',
        name: '$34,800.00'
      },
      {
        id: 'or-3',
        type: 'light',
        tag: 'ACCURACY',
        avatars: [AVATARS.jessica],
        sublabel: 'DISPUTE RATE',
        name: '0.02% Standard'
      },
      {
        id: 'or-4',
        type: 'doc',
        tag: 'AUTOMATED AUDIT',
        docTitle: 'Monthly Tax & VAT Ledger Generated',
        avatar: AVATARS.alex,
        sublabel: 'CONFIRMED ON',
        name: 'Sep 26, 2026'
      }
    ],
    columns: ['INVOICE ID & CLIENT', 'BILLING LEAD', 'DUE DATE', 'TOTAL AMOUNT'],
    rows: [
      {
        id: 'o1',
        name: 'INV-2026-0891 - Acme Corp Annual License',
        icon: <BankWireIcon />,
        owners: [AVATARS.alex],
        modified: 'Paid Sep 28',
        size: '$14,500.00',
        selected: false
      },
      {
        id: 'o2',
        name: 'INV-2026-0892 - Stripe Integration Tier',
        icon: <StripePaymentIcon />,
        owners: [AVATARS.sarah],
        modified: 'Paid Sep 28',
        size: '$28,900.00',
        selected: false
      },
      {
        id: 'o3',
        name: 'INV-2026-0893 - Tesla AI Fleet Compute',
        icon: <ServerInstanceIcon />,
        owners: [AVATARS.david],
        modified: 'Pending Approval',
        size: '$52,000.00',
        selected: true
      },
      {
        id: 'o4',
        name: 'INV-2026-0894 - Spotify Media Bandwidth',
        icon: <CloudTierIcon />,
        owners: [AVATARS.marcus],
        modified: 'Paid Sep 27',
        size: '$9,400.00',
        selected: false
      }
    ]
  },

  'products': {
    title: 'Products & SaaS Plans',
    quickAccessTitle: 'SUBSCRIPTION CATALOG',
    sectionTitle: 'ACTIVE SOFTWARE TIERS & SERVICES',
    cards: [
      {
        id: 'pr-1',
        type: 'blue',
        tag: 'PRIMARY DRIVER',
        avatars: [AVATARS.alex, AVATARS.sarah],
        sublabel: 'ENTERPRISE PLAN',
        name: '64% Total MRR'
      },
      {
        id: 'pr-2',
        type: 'light',
        tag: 'GROWTH ENGINE',
        avatars: [AVATARS.david],
        sublabel: 'PRO CLOUD TIER',
        name: '1,240 Active Subs'
      },
      {
        id: 'pr-3',
        type: 'light',
        tag: 'DEV ECOSYSTEM',
        avatars: [AVATARS.marcus],
        sublabel: 'API GATEWAY TIER',
        name: '42.8M Requests/day'
      },
      {
        id: 'pr-4',
        type: 'doc',
        tag: 'PRODUCT UPDATE',
        docTitle: 'Dedicated GPU AI Inference Tier Released',
        avatar: AVATARS.jessica,
        sublabel: 'DEPLOYED ON',
        name: 'Sep 25, 2026'
      }
    ],
    columns: ['PLAN NAME / SKU', 'PRODUCT MANAGER', 'REVISION DATE', 'PRICE / MRR'],
    rows: [
      {
        id: 'p1',
        name: 'Enterprise Dedicated Cloud Architecture',
        icon: <EnterpriseDocIcon />,
        owners: [AVATARS.alex],
        modified: 'v3.2 Stable',
        size: '$1,999.00 / mo',
        selected: false
      },
      {
        id: 'p2',
        name: 'Professional Team Collaboration Tier',
        icon: <CloudTierIcon />,
        owners: [AVATARS.david],
        modified: 'v2.8 Live',
        size: '$249.00 / mo',
        selected: true
      },
      {
        id: 'p3',
        name: 'Developer API Microservices License',
        icon: <ServerInstanceIcon />,
        owners: [AVATARS.marcus],
        modified: 'v4.1 FastTrack',
        size: '$99.00 / mo',
        selected: false
      },
      {
        id: 'p4',
        name: 'Starter Business Essentials Suite',
        icon: <StripePaymentIcon />,
        owners: [AVATARS.sarah],
        modified: 'v1.9 Active',
        size: '$29.00 / mo',
        selected: false
      }
    ]
  },

  'security': {
    title: 'Security & Audit Logs',
    quickAccessTitle: 'SYSTEM INTEGRITY MONITOR',
    sectionTitle: 'REAL-TIME SECURITY AUDIT TRAIL',
    cards: [
      {
        id: 'sc-1',
        type: 'blue',
        tag: 'GLOBAL STATUS',
        avatars: [AVATARS.alex, AVATARS.jessica],
        sublabel: 'THREAT LEVEL',
        name: 'Defcon 5 (Normal)'
      },
      {
        id: 'sc-2',
        type: 'light',
        tag: 'DDOS SHIELD',
        avatars: [AVATARS.david],
        sublabel: 'BLOCKED ATTACKS',
        name: '124 Automated Blocks'
      },
      {
        id: 'sc-3',
        type: 'light',
        tag: 'ENFORCEMENT',
        avatars: [AVATARS.sarah],
        sublabel: '2FA COMPLIANCE',
        name: '99.4% Team Coverage'
      },
      {
        id: 'sc-4',
        type: 'doc',
        tag: 'CERTIFICATE',
        docTitle: 'Wildcard SSL TLS 1.3 Verified Active',
        avatar: AVATARS.alex,
        sublabel: 'EXPIRES IN',
        name: '240 Days'
      }
    ],
    columns: ['AUDIT EVENT', 'OPERATOR / ACTOR', 'TIMESTAMP', 'IP & SEVERITY'],
    rows: [
      {
        id: 's1',
        name: 'SuperAdmin Jessica updated API Key permissions',
        icon: <EnterpriseDocIcon />,
        owners: [AVATARS.jessica],
        modified: '8 mins ago',
        size: '192.168.1.4 (Low)',
        selected: false
      },
      {
        id: 's2',
        name: 'Automated Database Snapshot encrypted & verified',
        icon: <BankWireIcon />,
        owners: [AVATARS.david],
        modified: '1 hour ago',
        size: 'Internal Service (Info)',
        selected: true
      },
      {
        id: 's3',
        name: 'Failed SSH Login Attempt blocked by firewall',
        icon: <ServerInstanceIcon />,
        owners: [AVATARS.alex],
        modified: '2 hours ago',
        size: '142.250.190.46 (Blocked)',
        selected: false
      },
      {
        id: 's4',
        name: 'Marcus rotated production AWS IAM Access Tokens',
        icon: <CloudTierIcon />,
        owners: [AVATARS.marcus],
        modified: '4 hours ago',
        size: '10.0.4.12 (Audited)',
        selected: false
      }
    ]
  },

  'settings': {
    title: 'System Configurations',
    quickAccessTitle: 'GLOBAL ENVIRONMENT & CLOUD',
    sectionTitle: 'ACTIVE SERVICES & ENDPOINTS',
    cards: [
      {
        id: 'st-1',
        type: 'blue',
        tag: 'CLOUD FLEET',
        avatars: [AVATARS.alex, AVATARS.david],
        sublabel: 'PRIMARY REGION',
        name: 'US-East (N. Virginia)'
      },
      {
        id: 'st-2',
        type: 'light',
        tag: 'RATE LIMIT',
        avatars: [AVATARS.marcus],
        sublabel: 'THROTTLING',
        name: '10,000 req/min'
      },
      {
        id: 'st-3',
        type: 'light',
        tag: 'WEBHOOKS',
        avatars: [AVATARS.sarah],
        sublabel: 'ACTIVE ENDPOINTS',
        name: '14 Endpoints Healthy'
      },
      {
        id: 'st-4',
        type: 'doc',
        tag: 'SYSTEM STATUS',
        docTitle: 'Continuous Deployment Pipeline v4.8 Active',
        avatar: AVATARS.jessica,
        sublabel: 'UPTIME',
        name: '99.98% Past 90 Days'
      }
    ],
    columns: ['SERVICE / COMPONENT', 'TEAM STEWARD', 'RUNTIME ENV', 'HEALTH STATUS'],
    rows: [
      {
        id: 'st1',
        name: 'GraphQL API Gateway Core Service',
        icon: <CloudTierIcon />,
        owners: [AVATARS.alex],
        modified: 'Node.js 22 LTS',
        size: 'Healthy (12ms ping)',
        selected: false
      },
      {
        id: 'st2',
        name: 'Primary PostgreSQL Database Cluster',
        icon: <BankWireIcon />,
        owners: [AVATARS.david],
        modified: 'Postgres 16 Multi-AZ',
        size: 'Optimal (42% Load)',
        selected: true
      },
      {
        id: 'st3',
        name: 'Redis In-Memory Distributed Cache',
        icon: <ServerInstanceIcon />,
        owners: [AVATARS.marcus],
        modified: 'Redis 7.2 Cluster',
        size: 'Healthy (99.8% hit)',
        selected: false
      },
      {
        id: 'st4',
        name: 'Stripe Webhook Event Listener Daemon',
        icon: <StripePaymentIcon />,
        owners: [AVATARS.sarah],
        modified: 'Serverless Worker',
        size: 'Active (0 Retries)',
        selected: false
      }
    ]
  }
};

// ==========================================================================
// Main Component: AdminDashboard
// ==========================================================================

export default function AdminDashboard() {
  // Navigation State
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('list');
  const [selectedRowId, setSelectedRowId] = useState('r5');

  // Menus & Modals State
  const [showQuickActionModal, setShowQuickActionModal] = useState(false);
  const [showTelemetryModal, setShowTelemetryModal] = useState(false);
  const [showNotificationMenu, setShowNotificationMenu] = useState(false);
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showInfoDrawer, setShowInfoDrawer] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  // Form State for Quick Action Modal
  const [newRecordName, setNewRecordName] = useState('');
  const [newRecordCategory, setNewRecordCategory] = useState('Enterprise License');
  const [newRecordAmount, setNewRecordAmount] = useState('$12,500.00');

  // Custom data records per tab
  const [customRows, setCustomRows] = useState({});
  const currentTabData = ADMIN_TAB_DATA[activeTab] || ADMIN_TAB_DATA['overview'];

  // Toast feedback trigger
  const triggerToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage('');
    }, 2800);
  };

  // Tab switch
  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
    setSearchQuery('');
    const tabRows = customRows[tabId] || ADMIN_TAB_DATA[tabId]?.rows || [];
    const defaultSel = tabRows.find(r => r.selected) || tabRows[0];
    if (defaultSel) {
      setSelectedRowId(defaultSel.id);
    }
  };

  // Add new record form submit
  const handleCreateRecord = (e) => {
    e.preventDefault();
    if (!newRecordName.trim()) return;

    let iconComp = <EnterpriseDocIcon />;
    if (newRecordCategory.includes('Payment') || newRecordCategory.includes('Stripe')) {
      iconComp = <StripePaymentIcon />;
    } else if (newRecordCategory.includes('Cloud')) {
      iconComp = <CloudTierIcon />;
    } else if (newRecordCategory.includes('Server')) {
      iconComp = <ServerInstanceIcon />;
    }

    const newRecord = {
      id: 'custom-' + Date.now(),
      name: newRecordName,
      icon: iconComp,
      owners: [AVATARS.jessica],
      modified: 'Just now by Jessica',
      size: `${newRecordAmount} (Active)`,
      selected: true
    };

    const currentList = customRows[activeTab] || currentTabData.rows;
    setCustomRows({
      ...customRows,
      [activeTab]: [newRecord, ...currentList]
    });

    setSelectedRowId(newRecord.id);
    setNewRecordName('');
    setShowQuickActionModal(false);
    triggerToast(`Created record: "${newRecordName}"`);
  };

  // Live filtered records based on search bar
  const effectiveRows = useMemo(() => {
    const list = customRows[activeTab] || currentTabData.rows;
    if (!searchQuery.trim()) return list;
    return list.filter(item =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [activeTab, currentTabData, customRows, searchQuery]);

  // Copy URL / Record Link
  const handleCopyLink = (name, e) => {
    e.stopPropagation();
    navigator.clipboard?.writeText?.(`https://admin.enterprise.cloud/records/${encodeURIComponent(name)}`);
    triggerToast(`Copied audit link for: ${name}`);
  };

  return (
    <div className="db-outer-viewport">
      <div className="db-window">

        {/* ==================================================================
            Header Topbar (Title: Admin Dashboard)
            ================================================================== */}
        <header className="db-header">
          <div className="db-header-left">
            {/* Brand Logo & Title */}
            <div className="db-brand" onClick={() => handleTabChange('overview')}>
              <div className="db-brand-icon">
                <AdminLogoIcon />
              </div>
              <h1 className="db-brand-title">Admin Dashboard</h1>
            </div>

            {/* Pill Search Box */}
            <div className="db-search-box">
              <span className="db-search-icon">
                <SearchIcon />
              </span>
              <input
                type="text"
                className="db-search-input"
                placeholder="Search customers, orders, metrics, logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Header Action Tools */}
          <div className="db-header-right">
            {/* Notification Bell */}
            <button
              className={`db-icon-btn ${showNotificationMenu ? 'active' : ''}`}
              title="Admin Alerts"
              onClick={() => {
                setShowNotificationMenu(!showNotificationMenu);
                setShowSettingsMenu(false);
                setShowProfileMenu(false);
              }}
            >
              <BellIcon />
              <span className="db-badge-dot"></span>
            </button>

            {/* Help / Docs */}
            <button
              className="db-icon-btn"
              title="API & Admin Documentation"
              onClick={() => triggerToast('Admin System API Docs v4.2')}
            >
              <HelpIcon />
            </button>

            {/* Settings */}
            <button
              className={`db-icon-btn ${showSettingsMenu ? 'active' : ''}`}
              title="System Preferences"
              onClick={() => {
                setShowSettingsMenu(!showSettingsMenu);
                setShowNotificationMenu(false);
                setShowProfileMenu(false);
              }}
            >
              <SettingsIcon />
            </button>

            {/* User Profile Pill */}
            <div
              className="db-user-pill"
              onClick={() => {
                setShowProfileMenu(!showProfileMenu);
                setShowNotificationMenu(false);
                setShowSettingsMenu(false);
              }}
            >
              <span className="db-user-name">Jessica</span>
              <div className="db-user-avatar">J</div>
            </div>

            {/* Equalizer / Filter Sliders */}
            <button
              className="db-icon-btn"
              title="Filter records"
              onClick={() => triggerToast('Filters: All Enterprise records active')}
            >
              <SlidersIcon />
            </button>
          </div>
        </header>

        {/* ==================================================================
            Body (Sidebar + Main Content Area)
            ================================================================== */}
        <div className="db-body">

          {/* Left Sidebar (Solid Royal Blue Curved Shape) */}
          <aside className="db-sidebar">
            <div className="db-sidebar-top">
              {/* White Pill Button: Quick Action / New Record */}
              <button className="db-upload-btn" onClick={() => setShowQuickActionModal(true)}>
                <PlusIcon />
                <span>+ New Record</span>
              </button>

              {/* Navigation Menu (7 Pure Admin Tabs) */}
              <ul className="db-nav-list">
                <li
                  className={`db-nav-item ${activeTab === 'overview' ? 'active' : ''}`}
                  onClick={() => handleTabChange('overview')}
                >
                  <span className="db-nav-icon"><DashboardNavIcon /></span>
                  <span>Overview</span>
                </li>

                <li
                  className={`db-nav-item ${activeTab === 'analytics' ? 'active' : ''}`}
                  onClick={() => handleTabChange('analytics')}
                >
                  <span className="db-nav-icon"><AnalyticsNavIcon /></span>
                  <span>Analytics</span>
                </li>

                <li
                  className={`db-nav-item ${activeTab === 'users' ? 'active' : ''}`}
                  onClick={() => handleTabChange('users')}
                >
                  <span className="db-nav-icon"><UsersNavIcon /></span>
                  <span>Users & Clients</span>
                </li>

                <li
                  className={`db-nav-item ${activeTab === 'orders' ? 'active' : ''}`}
                  onClick={() => handleTabChange('orders')}
                >
                  <span className="db-nav-icon"><OrdersNavIcon /></span>
                  <span>Orders & Billing</span>
                </li>

                <li
                  className={`db-nav-item ${activeTab === 'products' ? 'active' : ''}`}
                  onClick={() => handleTabChange('products')}
                >
                  <span className="db-nav-icon"><ProductsNavIcon /></span>
                  <span>Products & Plans</span>
                </li>

                <li
                  className={`db-nav-item ${activeTab === 'security' ? 'active' : ''}`}
                  onClick={() => handleTabChange('security')}
                >
                  <span className="db-nav-icon"><SecurityNavIcon /></span>
                  <span>Security & Logs</span>
                </li>

                <li
                  className={`db-nav-item ${activeTab === 'settings' ? 'active' : ''}`}
                  onClick={() => handleTabChange('settings')}
                >
                  <span className="db-nav-icon"><ConfigNavIcon /></span>
                  <span>Configurations</span>
                </li>
              </ul>
            </div>

            {/* System Telemetry & Server Resources at Sidebar Bottom */}
            <div className="db-sidebar-bottom">
              <h3 className="db-storage-heading">SYSTEM CAPACITY</h3>

              {/* CPU Load Progress */}
              <div className="db-storage-item">
                <div className="db-storage-item-header">
                  <CpuIcon />
                  <span>CPU Usage (16 Cores)</span>
                </div>
                <div className="db-storage-bar-bg">
                  <div className="db-storage-bar-fill" style={{ width: '64%' }}></div>
                </div>
                <div className="db-storage-text">64.2% Load Balance</div>
              </div>

              {/* RAM Allocation Progress */}
              <div className="db-storage-item">
                <div className="db-storage-item-header">
                  <RamIcon />
                  <span>RAM Allocation</span>
                </div>
                <div className="db-storage-bar-bg">
                  <div className="db-storage-bar-fill" style={{ width: '33%' }}></div>
                </div>
                <div className="db-storage-text">10.7 GB of 32 GB used</div>
              </div>

              {/* Telemetry Action Link */}
              <div className="db-upgrade-link" onClick={() => setShowTelemetryModal(true)}>
                Server Telemetry ↗
              </div>
            </div>
          </aside>

          {/* Main Content Area */}
          <main className="db-content">

            {/* Header Line inside content */}
            <div className="db-content-header">
              <div className="db-title-group">
                <h2 className="db-page-title">{currentTabData.title}</h2>
                <button
                  className="db-folder-btn-badge"
                  title="Create new record"
                  onClick={() => setShowQuickActionModal(true)}
                >
                  <ActionBadgeIcon />
                </button>
              </div>

              <div className="db-content-actions">
                {/* Grid / List View Toggle */}
                <button
                  className={`db-action-square-btn ${viewMode === 'grid' ? 'active' : ''}`}
                  title="Toggle Grid / List View"
                  onClick={() => setViewMode(viewMode === 'list' ? 'grid' : 'list')}
                >
                  <GridViewIcon />
                </button>

                {/* Info Drawer Toggle */}
                <button
                  className={`db-action-square-btn ${showInfoDrawer ? 'active' : ''}`}
                  title="View System Inspector"
                  onClick={() => setShowInfoDrawer(!showInfoDrawer)}
                >
                  <InfoCircleIcon />
                </button>
              </div>
            </div>

            {/* Quick KPI / Metric Cards Section */}
            <div className="db-section-label">{currentTabData.quickAccessTitle}</div>
            <div className="db-quick-cards-grid">
              {currentTabData.cards.map((card) => {
                if (card.type === 'doc') {
                  return (
                    <div
                      key={card.id}
                      className="db-quick-card card-doc"
                      onClick={() => triggerToast(`Audit Log: ${card.docTitle}`)}
                    >
                      <div className="db-card-top-row">
                        <div className="db-card-doc-header">
                          <span className="db-doc-icon-badge"><EnterpriseDocIcon /></span>
                          <span className="db-doc-title">{card.docTitle}</span>
                        </div>
                        <img src={card.avatar} alt="Author" className="db-avatar-img" />
                      </div>
                      <div className="db-card-bottom">
                        <span className="db-card-sublabel">{card.sublabel}</span>
                        <span className="db-card-modified-date">{card.name}</span>
                      </div>
                    </div>
                  );
                }

                const isBlue = card.type === 'blue';
                return (
                  <div
                    key={card.id}
                    className={`db-quick-card ${isBlue ? 'card-blue' : 'card-light'}`}
                    onClick={() => triggerToast(`Metric Selected: ${card.name}`)}
                  >
                    <div className="db-card-top-row">
                      <div>
                        <span className="db-card-tag">{card.tag}</span>
                        <div className="db-avatar-stack">
                          {card.avatars.map((av, idx) => (
                            <img key={idx} src={av} alt="Member" className="db-avatar-img" />
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="db-card-bottom">
                      <span className="db-card-sublabel">{card.sublabel}</span>
                      <span className="db-card-name">{card.name}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Admin Data Table Section */}
            <div className="db-table-section">
              <div className="db-section-label">{currentTabData.sectionTitle}</div>

              <div className="db-table-container">
                {viewMode === 'list' ? (
                  <table className="db-table">
                    <thead>
                      <tr>
                        <th style={{ width: '42%' }}>{currentTabData.columns[0]}</th>
                        <th style={{ width: '18%' }}>{currentTabData.columns[1]}</th>
                        <th style={{ width: '22%' }}>{currentTabData.columns[2]}</th>
                        <th style={{ width: '12%' }}>{currentTabData.columns[3]}</th>
                        <th style={{ width: '6%', textAlign: 'right' }}></th>
                      </tr>
                    </thead>
                    <tbody>
                      {effectiveRows.length === 0 ? (
                        <tr>
                          <td colSpan="5" style={{ textAlign: 'center', padding: '30px', color: '#94a3b8' }}>
                            No admin records found matching "{searchQuery}"
                          </td>
                        </tr>
                      ) : (
                        effectiveRows.map((row) => {
                          const isSelected = selectedRowId === row.id;
                          return (
                            <tr
                              key={row.id}
                              className={isSelected ? 'row-selected' : ''}
                              onClick={() => setSelectedRowId(row.id)}
                            >
                              <td>
                                <div className="db-file-name-cell">
                                  <span className="db-file-type-icon">{row.icon}</span>
                                  <span>{row.name}</span>
                                </div>
                              </td>

                              <td>
                                <div className="db-owner-cell">
                                  {row.owners.map((av, idx) => (
                                    <img
                                      key={idx}
                                      src={av}
                                      alt="Owner"
                                      className="db-avatar-img"
                                      style={{ marginLeft: idx > 0 ? '-6px' : '0' }}
                                    />
                                  ))}
                                </div>
                              </td>

                              <td>
                                <span className="db-date-cell">{row.modified}</span>
                              </td>

                              <td>
                                <span className="db-size-cell">{row.size}</span>
                              </td>

                              <td>
                                <div className="db-action-cell">
                                  <button
                                    className="db-row-icon-btn"
                                    title="Copy record link"
                                    onClick={(e) => handleCopyLink(row.name, e)}
                                  >
                                    <LinkIcon />
                                  </button>
                                  <button
                                    className="db-row-icon-btn"
                                    title="Record settings"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      triggerToast(`Admin options for ${row.name}`);
                                    }}
                                  >
                                    <MoreDotsIcon />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                ) : (
                  /* Grid View Alternative */
                  <div className="db-grid-view">
                    {effectiveRows.map((row) => (
                      <div
                        key={row.id}
                        className="db-grid-item"
                        onClick={() => setSelectedRowId(row.id)}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                          <span className="db-file-type-icon">{row.icon}</span>
                          <span style={{ fontSize: '11px', color: '#1967d2', fontWeight: 600 }}>{row.size}</span>
                        </div>
                        <div style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>{row.name}</div>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '6px' }}>
                          <span style={{ fontSize: '10.5px', color: '#94a3b8' }}>{row.modified}</span>
                          <button
                            className="db-row-icon-btn"
                            onClick={(e) => handleCopyLink(row.name, e)}
                          >
                            <LinkIcon />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

          </main>
        </div>

        {/* ==================================================================
            Notification Dropdown Menu
            ================================================================== */}
        {showNotificationMenu && (
          <div className="db-dropdown" style={{ top: '60px', right: '110px' }}>
            <div className="db-dropdown-header">System Notifications (3)</div>
            <div className="db-dropdown-item" onClick={() => triggerToast('Reviewed payment event')}>
              <span style={{ color: '#10b981' }}>●</span> New $14,500 Enterprise wire received
            </div>
            <div className="db-dropdown-item" onClick={() => triggerToast('Reviewed user access')}>
              <span style={{ color: '#3b82f6' }}>●</span> Elena added to Fintech Global Team
            </div>
            <div className="db-dropdown-item" onClick={() => triggerToast('Reviewed server alert')}>
              <span style={{ color: '#f59e0b' }}>●</span> US-East Server pool autoscaled to 4 nodes
            </div>
          </div>
        )}

        {/* ==================================================================
            Settings Dropdown Menu
            ================================================================== */}
        {showSettingsMenu && (
          <div className="db-dropdown" style={{ top: '60px', right: '70px' }}>
            <div className="db-dropdown-header">Admin Preferences</div>
            <div className="db-dropdown-item" onClick={() => triggerToast('Real-time streaming enabled')}>
              ⚡ Live Event Streaming: On
            </div>
            <div className="db-dropdown-item" onClick={() => triggerToast('Compact density toggled')}>
              📏 Layout Density: Compact
            </div>
            <div className="db-dropdown-item" onClick={() => triggerToast('Audit trail verified')}>
              🛡️ TLS 1.3 Security: Enforced
            </div>
          </div>
        )}

        {/* ==================================================================
            User Profile Dropdown Menu
            ================================================================== */}
        {showProfileMenu && (
          <div className="db-dropdown" style={{ top: '60px', right: '20px' }}>
            <div className="db-dropdown-header">Jessica Parker</div>
            <div style={{ padding: '6px 10px', fontSize: '11px', color: '#64748b' }}>
              Role: Super Administrator
            </div>
            <div className="db-dropdown-item" onClick={() => triggerToast('Opening admin credentials')}>
              👤 Profile & Security Tokens
            </div>
            <div className="db-dropdown-item" onClick={() => triggerToast('Opening enterprise billing')}>
              💳 Organization Billing Portal
            </div>
            <div className="db-dropdown-item" style={{ color: '#ef4444' }} onClick={() => triggerToast('Signed out of demo session')}>
              🚪 Sign Out
            </div>
          </div>
        )}

        {/* ==================================================================
            Quick Action Modal (+ New Record)
            ================================================================== */}
        {showQuickActionModal && (
          <div className="db-modal-overlay" onClick={() => setShowQuickActionModal(false)}>
            <div className="db-modal-card" onClick={(e) => e.stopPropagation()}>
              <div className="db-modal-header">
                <h3 className="db-modal-title">Create Record in {currentTabData.title}</h3>
                <button className="db-modal-close" onClick={() => setShowQuickActionModal(false)}>✕</button>
              </div>

              <form onSubmit={handleCreateRecord}>
                <div className="db-form-group">
                  <label className="db-form-label">Client or Record Title</label>
                  <input
                    type="text"
                    className="db-form-input"
                    placeholder="e.g. OpenAI - Dedicated Compute Cluster"
                    value={newRecordName}
                    onChange={(e) => setNewRecordName(e.target.value)}
                    required
                  />
                </div>

                <div className="db-form-group" style={{ marginTop: '12px' }}>
                  <label className="db-form-label">Category / Contract Type</label>
                  <select
                    className="db-form-select"
                    value={newRecordCategory}
                    onChange={(e) => setNewRecordCategory(e.target.value)}
                  >
                    <option value="Enterprise License">Enterprise Annual Contract</option>
                    <option value="Stripe Payment">Stripe Payment Gateway</option>
                    <option value="Cloud Compute">Cloud Server Infrastructure</option>
                    <option value="API Service">API Gateway Service Tier</option>
                  </select>
                </div>

                <div className="db-form-group" style={{ marginTop: '12px' }}>
                  <label className="db-form-label">Contract Amount / Valuation</label>
                  <input
                    type="text"
                    className="db-form-input"
                    placeholder="$25,000.00"
                    value={newRecordAmount}
                    onChange={(e) => setNewRecordAmount(e.target.value)}
                  />
                </div>

                <div className="db-modal-actions">
                  <button type="button" className="db-btn-secondary" onClick={() => setShowQuickActionModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="db-btn-primary">
                    Create Record
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ==================================================================
            Server Telemetry Modal
            ================================================================== */}
        {showTelemetryModal && (
          <div className="db-modal-overlay" onClick={() => setShowTelemetryModal(false)}>
            <div className="db-modal-card" onClick={(e) => e.stopPropagation()}>
              <div className="db-modal-header">
                <h3 className="db-modal-title">Infrastructure Telemetry</h3>
                <button className="db-modal-close" onClick={() => setShowTelemetryModal(false)}>✕</button>
              </div>

              <div>
                <div style={{ fontSize: '13px', color: '#475569', marginBottom: '14px' }}>
                  Current cluster load is optimal. <strong>16 vCPUs</strong> active across US-East with <strong>99.98%</strong> uptime.
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', marginBottom: '4px' }}>
                      <span>Core Compute Load</span>
                      <span>64.2%</span>
                    </div>
                    <div style={{ height: '8px', background: '#e2e8f0', borderRadius: '999px', overflow: 'hidden' }}>
                      <div style={{ width: '64%', height: '100%', background: '#1967d2' }}></div>
                    </div>
                  </div>

                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', marginBottom: '4px' }}>
                      <span>Memory Allocation</span>
                      <span>10.7 GB / 32 GB</span>
                    </div>
                    <div style={{ height: '8px', background: '#e2e8f0', borderRadius: '999px', overflow: 'hidden' }}>
                      <div style={{ width: '33%', height: '100%', background: '#10b981' }}></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="db-modal-actions">
                <button className="db-btn-secondary" onClick={() => setShowTelemetryModal(false)}>Close</button>
                <button
                  className="db-btn-primary"
                  onClick={() => {
                    setShowTelemetryModal(false);
                    triggerToast('Telemetry snapshot exported!');
                  }}
                >
                  Export Metrics CSV
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================================
            System Inspector Drawer
            ================================================================== */}
        {showInfoDrawer && (
          <div className="db-dropdown" style={{ top: '60px', right: '28px', width: '290px' }}>
            <div className="db-dropdown-header">System Inspector</div>
            <div style={{ fontSize: '12px', padding: '6px 10px', color: '#475569', lineHeight: '1.6' }}>
              <strong>Module:</strong> {currentTabData.title}<br />
              <strong>Total Records:</strong> {effectiveRows.length}<br />
              <strong>Selected ID:</strong> {selectedRowId}<br />
              <strong>Role:</strong> Super Administrator<br />
              <strong>TLS Protocol:</strong> TLS 1.3 / AES-256
            </div>
            <div className="db-dropdown-item" onClick={() => triggerToast('Admin Audit CSV exported')}>
              📥 Download Audit CSV
            </div>
          </div>
        )}

        {/* ==================================================================
            Floating Success Toast
            ================================================================== */}
        {toastMessage && (
          <div className="db-toast">
            <span>✓</span> {toastMessage}
          </div>
        )}

      </div>
    </div>
  );
}
