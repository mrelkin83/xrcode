import { useState, useEffect } from 'react';
import './dashbrod2.css';

// ==========================================================================
// SVGs / Icons (Ultra crisp, tailored for Glassy Fitness UI)
// ==========================================================================

const DumbbellLogo = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
    <rect x="2" y="9" width="3" height="6" rx="1.5" fill="#ff701e" />
    <rect x="6" y="7" width="2" height="10" rx="1" fill="#ff701e" />
    <rect x="8" y="11" width="8" height="2" fill="#22c55e" />
    <rect x="16" y="7" width="2" height="10" rx="1" fill="#ff701e" />
    <rect x="19" y="9" width="3" height="6" rx="1.5" fill="#ff701e" />
  </svg>
);

const GridNavIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
    <rect x="3" y="3" width="7" height="7" rx="2" fill="currentColor"></rect>
    <rect x="14" y="3" width="7" height="7" rx="2" fill="currentColor"></rect>
    <rect x="14" y="14" width="7" height="7" rx="2" fill="currentColor"></rect>
    <rect x="3" y="14" width="7" height="7" rx="2" fill="currentColor"></rect>
  </svg>
);

const ChartNavIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 3v18h18" />
    <path d="M18 9l-5 5-4-4-3 3" />
  </svg>
);

const CalendarNavIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
    <line x1="16" y1="2" x2="16" y2="6"></line>
    <line x1="8" y1="2" x2="8" y2="6"></line>
    <line x1="3" y1="10" x2="21" y2="10"></line>
  </svg>
);

const TimerNavIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="13" r="8"></circle>
    <path d="M12 9v4l2 2"></path>
    <path d="M5 3L2 6"></path>
    <path d="M22 6l-3-3"></path>
    <path d="M12 2v3"></path>
  </svg>
);

const CommunityNavIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
    <circle cx="9" cy="7" r="4"></circle>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
  </svg>
);

const SettingsNavIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3"></circle>
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
  </svg>
);

const SunIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
    <circle cx="12" cy="12" r="5"></circle>
    <line x1="12" y1="1" x2="12" y2="3" stroke="currentColor" strokeWidth="2"></line>
    <line x1="12" y1="21" x2="12" y2="23" stroke="currentColor" strokeWidth="2"></line>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" stroke="currentColor" strokeWidth="2"></line>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" stroke="currentColor" strokeWidth="2"></line>
    <line x1="1" y1="12" x2="3" y2="12" stroke="currentColor" strokeWidth="2"></line>
    <line x1="21" y1="12" x2="23" y2="12" stroke="currentColor" strokeWidth="2"></line>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" stroke="currentColor" strokeWidth="2"></line>
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" stroke="currentColor" strokeWidth="2"></line>
  </svg>
);

const MoonIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
  </svg>
);

const FlameIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
    <path d="M8.5 14.5c0 1.93 1.57 3.5 3.5 3.5s3.5-1.57 3.5-3.5c0-1.78-1.32-3.26-3.04-3.47.24-.76.71-1.42 1.34-1.89-1.92.51-3.3 2.27-3.3 4.36zm3.5-12.5C6.48 2 2 6.48 2 12c0 5.52 4.48 10 10 10s10-4.48 10-10c0-5.52-4.48-10-10-10zm0 18c-4.41 0-8-3.59-8-8 0-3.35 2.07-6.22 5-7.41v1.91c0 2.21 1.79 4 4 4 1.1 0 2.09-.45 2.81-1.17.65 1.14 1.19 2.5 1.19 4.17 0 4.41-3.59 8-8 8z" />
  </svg>
);

const HeartPulseIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
  </svg>
);

const WalkingManIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="5" r="2"></circle>
    <path d="M10 22v-5l-2-2V9l4-2 3 3v4"></path>
    <path d="M14 17l3 5"></path>
  </svg>
);

const MoonSmallIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/>
  </svg>
);

const MoreDotsIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="1.5" fill="currentColor"></circle>
    <circle cx="19" cy="12" r="1.5" fill="currentColor"></circle>
    <circle cx="5" cy="12" r="1.5" fill="currentColor"></circle>
  </svg>
);

// High Quality Image References matching the screenshot
const IMAGES = {
  messi: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80",
  runner: "https://images.unsplash.com/photo-1483721310020-03333e577078?w=500&auto=format&fit=crop&q=80",
  fruitSalad: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=160&auto=format&fit=crop&q=80",
  vegSalad: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=160&auto=format&fit=crop&q=80",
  mixedSalad: "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=160&auto=format&fit=crop&q=80",
  cardioWorkshop: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=140&auto=format&fit=crop&q=80",
  strengthWorkshop: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=140&auto=format&fit=crop&q=80",
};

// ==========================================================================
// Main Component: GlassFitnessDashboard (dashbrod2)
// ==========================================================================

export default function GlassFitnessDashboard() {
  // Navigation: 6 distinct sidebar tabs
  const [activeNav, setActiveNav] = useState('grid');
  const [selectedDay, setSelectedDay] = useState(23); // Day 23 active in calendar
  const [activeDietTab, setActiveDietTab] = useState(2); // Day 2 orange card
  const [timeFilter, setTimeFilter] = useState('Weekly');
  const [themeMode, setThemeMode] = useState('day');
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMsg, setToastMsg] = useState('');

  // Right Panel Interactive Modals & Menus
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showWorkoutModal, setShowWorkoutModal] = useState(null);
  const [showStatsModal, setShowStatsModal] = useState(null);
  const [showFullScheduleModal, setShowFullScheduleModal] = useState(false);

  // Live Timer / Stopwatch State
  const [timerSeconds, setTimerSeconds] = useState(2720); // 45:20
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  useEffect(() => {
    let interval = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimerSeconds(s => s + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const formatTimerTime = (totalSec) => {
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${hrs > 0 ? String(hrs).padStart(2, '0') + ':' : ''}${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // macOS Dock Magnification State
  const [hoveredNavIndex, setHoveredNavIndex] = useState(null);

  const navItems = [
    { id: 'grid', label: 'Overview', icon: <GridNavIcon /> },
    { id: 'chart', label: 'Analytics', icon: <ChartNavIcon /> },
    { id: 'calendar', label: 'Schedule', icon: <CalendarNavIcon /> },
    { id: 'timer', label: 'Stopwatch', icon: <TimerNavIcon /> },
    { id: 'community', label: 'Leaderboard', icon: <CommunityNavIcon /> },
    { id: 'settings', label: 'Biometrics', icon: <SettingsNavIcon /> }
  ];

  const getDockScale = (index) => {
    if (hoveredNavIndex === null) return 1;
    const distance = Math.abs(hoveredNavIndex - index);
    if (distance === 0) return 1.44; // Target icon magnifies to 1.44x
    if (distance === 1) return 1.22; // Adjacent icons magnify to 1.22x like macOS dock
    if (distance === 2) return 1.08; // Secondary neighbors magnify to 1.08x
    return 1;
  };

  // User Editable Body Stats
  const [bodyStats, setBodyStats] = useState({
    weight: '75',
    height: '180',
    age: '26'
  });

  // Calendar Month Navigation
  const [currentMonthIndex, setCurrentMonthIndex] = useState(11); // Dec 2022
  const monthNames = [
    'January 2022', 'February 2022', 'March 2022', 'April 2022',
    'May 2022', 'June 2022', 'July 2022', 'August 2022',
    'September 2022', 'October 2022', 'November 2022', 'December 2022'
  ];

  const triggerToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 2500);
  };

  // Workout schedule list
  const [workoutList, setWorkoutList] = useState([
    {
      id: 'w1',
      tag: 'Fitness',
      title: 'Cardio Workshop',
      desc: 'Strengthens your muscles',
      date: '17-21 Dec',
      thumb: IMAGES.cardioWorkshop
    },
    {
      id: 'w2',
      tag: 'Fitness',
      title: 'Cardio Workshop',
      desc: 'Strengthens your muscles',
      date: '17-21 Dec',
      thumb: IMAGES.strengthWorkshop
    },
    {
      id: 'w3',
      tag: 'Fitness',
      title: 'Cardio Workshop',
      desc: 'Strengthens your muscles',
      date: '17-21 Dec',
      thumb: IMAGES.cardioWorkshop
    }
  ]);

  return (
    <div className="gdb-viewport">

      {/* ==================================================================
          Main Glass Dashboard Container (3 Columns: Slim Sidebar, Main Card, Dark Right)
          (Top fitness.com dock removed cleanly as requested!)
          ================================================================== */}
      <div className="gdb-main-container">

        {/* ----------------------------------------------------------------
            1. Left Slim Capsule Dark Glass Sidebar
            ---------------------------------------------------------------- */}
        <aside className="gdb-sidebar">
          <div className="gdb-logo-icon-wrap" title="Fitness Pro">
            <DumbbellLogo />
          </div>

          <div
            className="gdb-nav-group"
            onMouseLeave={() => setHoveredNavIndex(null)}
          >
            {navItems.map((item, idx) => {
              const scale = getDockScale(idx);
              const isHovered = hoveredNavIndex === idx;
              return (
                <button
                  key={item.id}
                  className={`gdb-nav-icon-btn ${activeNav === item.id ? 'active' : ''}`}
                  style={{
                    transform: `scale(${scale})`,
                    zIndex: isHovered ? 40 : 30 - Math.abs((hoveredNavIndex ?? 0) - idx),
                  }}
                  onMouseEnter={() => setHoveredNavIndex(idx)}
                  onClick={() => {
                    setActiveNav(item.id);
                    triggerToast(`View: ${item.label}`);
                  }}
                  title={item.label}
                >
                  {item.icon}
                  <span className="gdb-dock-tooltip">{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Day / Night Switcher */}
          <div className="gdb-theme-toggle">
            <button
              className={`gdb-theme-btn ${themeMode === 'day' ? 'active-sun' : ''}`}
              onClick={() => { setThemeMode('day'); triggerToast('Day Mode Active'); }}
              title="Day Mode"
            >
              <SunIcon />
            </button>
            <button
              className={`gdb-theme-btn ${themeMode === 'night' ? 'active-sun' : ''}`}
              onClick={() => { setThemeMode('night'); triggerToast('Night Mode Active'); }}
              title="Night Mode"
            >
              <MoonIcon />
            </button>
          </div>
        </aside>

        {/* ----------------------------------------------------------------
            2. Middle Main Glass Card (Exact Dark Glass matching Right Panel!)
            ---------------------------------------------------------------- */}
        <main className="gdb-center-card">

          {/* Top Greeting Row */}
          <div className="gdb-center-header">
            <div>
              <h2 className="gdb-greeting-title">
                Good Morning, <strong>Lionel</strong> 👋
              </h2>
              <p className="gdb-greeting-sub">Let's do some workout today</p>
            </div>

            <div className="gdb-header-actions">
              {/* Capsule Search Bar */}
              <div className="gdb-glass-search">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="rgba(255, 255, 255, 0.75)" strokeWidth="2.2">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <input
                  type="text"
                  className="gdb-glass-search-input"
                  placeholder="Search something here..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* Notification Bell */}
              <button
                className="gdb-glass-bell-btn"
                title="Notifications"
                onClick={() => triggerToast('Notification: You hit 9,886 steps today!')}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                  <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                </svg>
                <span style={{ position: 'absolute', top: '7px', right: '7px', width: '6px', height: '6px', backgroundColor: '#ff701e', borderRadius: '50%' }}></span>
              </button>
            </div>
          </div>

          {/* ==============================================================
              DYNAMIC CENTER CONTENT BASED ON LEFT SIDEBAR ICONS
              ============================================================== */}

          {/* TAB 1: OVERVIEW (Flagship Screenshot View) */}
          {activeNav === 'grid' && (
            <>
              {/* Row 1: 4 White Metric Cards */}
              <div className="gdb-metrics-row">
                <div className="gdb-metric-card" onClick={() => triggerToast('Calories goal: 2000 Kcal daily')}>
                  <div className="gdb-metric-top">
                    <span className="gdb-metric-label">Calories</span>
                    <span className="gdb-metric-icon-badge orange"><FlameIcon /></span>
                  </div>
                  <div className="gdb-metric-graph">
                    <svg width="100%" height="28" viewBox="0 0 100 28" fill="none">
                      <rect x="5" y="16" width="3" height="12" rx="1.5" fill="#ffd1b3" />
                      <rect x="18" y="8" width="3" height="20" rx="1.5" fill="#ffa870" />
                      <rect x="31" y="14" width="3" height="14" rx="1.5" fill="#ffd1b3" />
                      <rect x="44" y="6" width="3" height="22" rx="1.5" fill="#ff701e" />
                      <rect x="57" y="10" width="3" height="18" rx="1.5" fill="#ffa870" />
                      <rect x="70" y="12" width="3" height="16" rx="1.5" fill="#ff701e" />
                      <rect x="83" y="8" width="3" height="20" rx="1.5" fill="#ffa870" />
                    </svg>
                  </div>
                  <div className="gdb-metric-bottom">
                    <span className="gdb-metric-value orange">1428</span>
                    <span className="gdb-metric-unit">Kcal</span>
                  </div>
                </div>

                <div className="gdb-metric-card" onClick={() => triggerToast('Resting Heart Rate: 62 bpm')}>
                  <div className="gdb-metric-top">
                    <span className="gdb-metric-label">Heart Rate</span>
                    <span className="gdb-metric-icon-badge pink"><HeartPulseIcon /></span>
                  </div>
                  <div className="gdb-metric-graph">
                    <svg width="100%" height="28" viewBox="0 0 100 28" fill="none">
                      <path d="M2 14h18l4-10 6 22 5-16 4 9 4-5h12l3-7 5 15 4-11 3 7h24" stroke="#ff3b71" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <div className="gdb-metric-bottom">
                    <span className="gdb-metric-value pink">104</span>
                    <span className="gdb-metric-unit">bpm/day</span>
                  </div>
                </div>

                <div className="gdb-metric-card" onClick={() => triggerToast('Target: 10,000 Steps (98.8% done)')}>
                  <div className="gdb-metric-top">
                    <span className="gdb-metric-label">Steps</span>
                    <span className="gdb-metric-icon-badge green"><WalkingManIcon /></span>
                  </div>
                  <div className="gdb-metric-graph">
                    <svg width="56" height="34" viewBox="0 0 56 34">
                      <path d="M 6 30 A 22 22 0 0 1 50 30" fill="none" stroke="#e2e8f0" strokeWidth="5.5" strokeLinecap="round" />
                      <path d="M 6 30 A 22 22 0 0 1 45 16" fill="none" stroke="#22c55e" strokeWidth="5.5" strokeLinecap="round" />
                    </svg>
                  </div>
                  <div className="gdb-metric-bottom">
                    <span className="gdb-metric-value green" style={{ fontSize: '15px' }}>9,886</span>
                    <span className="gdb-metric-unit">Steps</span>
                  </div>
                </div>

                <div className="gdb-metric-card" onClick={() => triggerToast('Deep Sleep: 3 hrs 24 mins')}>
                  <div className="gdb-metric-top">
                    <span className="gdb-metric-label">Sleep</span>
                    <span className="gdb-metric-icon-badge blue"><MoonSmallIcon /></span>
                  </div>
                  <div className="gdb-metric-graph">
                    <svg width="100%" height="28" viewBox="0 0 100 28" fill="none">
                      <rect x="8" y="12" width="3" height="16" rx="1.5" fill="#93c5fd" />
                      <rect x="20" y="6" width="3" height="22" rx="1.5" fill="#3b82f6" />
                      <rect x="32" y="10" width="3" height="18" rx="1.5" fill="#93c5fd" />
                      <rect x="44" y="4" width="3" height="24" rx="1.5" fill="#2563eb" />
                      <rect x="56" y="8" width="3" height="20" rx="1.5" fill="#3b82f6" />
                      <rect x="68" y="14" width="3" height="14" rx="1.5" fill="#93c5fd" />
                      <rect x="80" y="6" width="3" height="22" rx="1.5" fill="#3b82f6" />
                    </svg>
                  </div>
                  <div className="gdb-metric-bottom">
                    <span className="gdb-metric-value blue">8.5</span>
                    <span className="gdb-metric-unit">hrs/day</span>
                  </div>
                </div>
              </div>

              {/* Row 2: Activity Tracking & Running Workout Hero */}
              <div className="gdb-activity-row">
                <div className="gdb-chart-card">
                  <div className="gdb-chart-header">
                    <h3 className="gdb-card-heading">Activity Tracking</h3>
                    <button
                      className="gdb-dropdown-filter-btn"
                      onClick={() => {
                        const next = timeFilter === 'Weekly' ? 'Monthly' : timeFilter === 'Monthly' ? 'Daily' : 'Weekly';
                        setTimeFilter(next);
                        triggerToast(`Filter: ${next}`);
                      }}
                    >
                      <span>{timeFilter}</span>
                      <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                  </div>

                  <div className="gdb-chart-content">
                    <svg width="100%" height="135" viewBox="0 0 460 135" fill="none">
                      <text x="5" y="16" fill="#94a3b8" fontSize="9" fontWeight="500">100%</text>
                      <text x="5" y="42" fill="#94a3b8" fontSize="9" fontWeight="500">80%</text>
                      <text x="5" y="68" fill="#94a3b8" fontSize="9" fontWeight="500">60%</text>
                      <text x="5" y="94" fill="#94a3b8" fontSize="9" fontWeight="500">40%</text>
                      <text x="5" y="118" fill="#94a3b8" fontSize="9" fontWeight="500">20%</text>

                      <line x1="32" y1="13" x2="455" y2="13" stroke="#f1f5f9" strokeWidth="1" />
                      <line x1="32" y1="39" x2="455" y2="39" stroke="#f1f5f9" strokeWidth="1" />
                      <line x1="32" y1="65" x2="455" y2="65" stroke="#f1f5f9" strokeWidth="1" />
                      <line x1="32" y1="91" x2="455" y2="91" stroke="#f1f5f9" strokeWidth="1" />
                      <line x1="32" y1="115" x2="455" y2="115" stroke="#f1f5f9" strokeWidth="1" />

                      <defs>
                        <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#ff701e" stopOpacity="0.25"/>
                          <stop offset="100%" stopColor="#ff701e" stopOpacity="0.0"/>
                        </linearGradient>
                      </defs>

                      <path
                        d="M 38 115 C 60 112, 70 85, 95 85 C 120 85, 130 102, 150 96 C 175 88, 185 75, 205 84 C 230 96, 245 88, 260 52 C 275 18, 290 85, 315 70 C 340 55, 355 90, 385 80 C 405 72, 420 50, 445 68 L 445 115 Z"
                        fill="url(#chartGradient)"
                      />

                      <path
                        d="M 38 115 C 60 112, 70 85, 95 85 C 120 85, 130 102, 150 96 C 175 88, 185 75, 205 84 C 230 96, 245 88, 260 52 C 275 18, 290 85, 315 70 C 340 55, 355 90, 385 80 C 405 72, 420 50, 445 68"
                        stroke="#ff701e"
                        strokeWidth="3.2"
                        strokeLinecap="round"
                        fill="none"
                      />

                      <g transform="translate(254, 18)">
                        <rect x="-24" y="-18" width="56" height="20" rx="10" fill="#ffffff" stroke="#ff701e" strokeWidth="1.5" filter="drop-shadow(0 2px 6px rgba(0,0,0,0.08))" />
                        <text x="4" y="-4" textAnchor="middle" fill="#ff701e" fontSize="9.5" fontWeight="700">24 kmph</text>
                        <circle cx="4" cy="18" r="5" fill="#ffffff" stroke="#ff701e" strokeWidth="3" />
                      </g>

                      <g transform="translate(0, 130)" fill="#94a3b8" fontSize="8.5" fontWeight="500">
                        <text x="38" textAnchor="middle">Jan</text>
                        <text x="80" textAnchor="middle">Feb</text>
                        <text x="125" textAnchor="middle">Mar</text>
                        <text x="170" textAnchor="middle">Apr</text>
                        <text x="215" textAnchor="middle">May</text>
                        <text x="260" textAnchor="middle">Jun</text>
                        <text x="305" textAnchor="middle">Jul</text>
                        <text x="350" textAnchor="middle">Aug</text>
                        <text x="395" textAnchor="middle">Sep</text>
                        <text x="440" textAnchor="middle">Oct</text>
                      </g>
                    </svg>
                  </div>
                </div>

                <div className="gdb-hero-workout-card">
                  <div className="gdb-hero-text-wrap">
                    <h3 className="gdb-hero-title">Running with resistance band</h3>
                    <div className="gdb-hero-stats">
                      <div className="gdb-hero-stat-block">
                        <div className="gdb-hero-stat-num">12 <span>km</span></div>
                        <div className="gdb-hero-stat-desc">Today's distance</div>
                      </div>
                      <div className="gdb-hero-stat-block">
                        <div className="gdb-hero-stat-num">428 <span>km</span></div>
                        <div className="gdb-hero-stat-desc">Total distance covered</div>
                      </div>
                    </div>
                  </div>

                  <div className="gdb-hero-graphic-wrap">
                    <img src={IMAGES.runner} alt="Runner" className="gdb-runner-img" />
                  </div>
                </div>
              </div>

              {/* Row 3: Diet Plan Section */}
              <div className="gdb-diet-section">
                <div className="gdb-section-header-row">
                  <div className="gdb-section-title-wrap">
                    <span className="gdb-orange-indicator"></span>
                    <h3 className="gdb-section-heading">Diet Plan</h3>
                  </div>
                  <span className="gdb-view-all-link" onClick={() => triggerToast('Opening Full Nutrition Meal Plan')}>
                    view all
                  </span>
                </div>

                <div className="gdb-diet-cards-grid">
                  <div
                    className={`gdb-diet-card ${activeDietTab === 1 ? 'orange' : 'white'}`}
                    onClick={() => { setActiveDietTab(1); triggerToast('Day 1 Fruit Nutrition Selected'); }}
                  >
                    <div className="gdb-diet-info">
                      <h4 className="gdb-diet-title">Fruits only</h4>
                      <p className="gdb-diet-desc">It contains most water contain in it.</p>
                      <span className="gdb-day-pill">Day 1</span>
                    </div>
                    <img src={IMAGES.fruitSalad} alt="Fruits" className="gdb-diet-plate-img" />
                  </div>

                  <div
                    className={`gdb-diet-card ${activeDietTab === 2 ? 'orange' : 'white'}`}
                    onClick={() => { setActiveDietTab(2); triggerToast('Day 2 Vegetable Detox Selected'); }}
                  >
                    <div className="gdb-diet-info">
                      <h4 className="gdb-diet-title">Vegetables only</h4>
                      <p className="gdb-diet-desc">It contains most water contain in it.</p>
                      <span className="gdb-day-pill">Day 2</span>
                    </div>
                    <img src={IMAGES.vegSalad} alt="Vegetables" className="gdb-diet-plate-img" />
                  </div>

                  <div
                    className={`gdb-diet-card ${activeDietTab === 3 ? 'orange' : 'white'}`}
                    onClick={() => { setActiveDietTab(3); triggerToast('Day 3 Balanced Nutrition Selected'); }}
                  >
                    <div className="gdb-diet-info">
                      <h4 className="gdb-diet-title">Fruits and Vegetables</h4>
                      <p className="gdb-diet-desc">It contains most water contain in it.</p>
                      <span className="gdb-day-pill">Day 3</span>
                    </div>
                    <img src={IMAGES.mixedSalad} alt="Fruits and Vegetables" className="gdb-diet-plate-img" />
                  </div>
                </div>
              </div>
            </>
          )}

          {/* TAB 2: TRAINING ANALYTICS */}
          {activeNav === 'chart' && (
            <div className="gdb-subview-wrap">
              <div className="gdb-metrics-row">
                <div className="gdb-metric-card">
                  <div className="gdb-metric-top"><span className="gdb-metric-label">Weekly Burn</span><span className="gdb-metric-icon-badge orange"><FlameIcon /></span></div>
                  <div className="gdb-metric-value orange" style={{ fontSize: '20px' }}>14,280 <span style={{ fontSize: '11px', color: '#64748b' }}>Kcal</span></div>
                  <div style={{ fontSize: '10.5px', color: '#10b981', fontWeight: 600 }}>+12% vs last week</div>
                </div>
                <div className="gdb-metric-card">
                  <div className="gdb-metric-top"><span className="gdb-metric-label">Peak Pulse</span><span className="gdb-metric-icon-badge pink"><HeartPulseIcon /></span></div>
                  <div className="gdb-metric-value pink" style={{ fontSize: '20px' }}>178 <span style={{ fontSize: '11px', color: '#64748b' }}>bpm</span></div>
                  <div style={{ fontSize: '10.5px', color: '#64748b' }}>During interval sprint</div>
                </div>
                <div className="gdb-metric-card">
                  <div className="gdb-metric-top"><span className="gdb-metric-label">Recovery</span><span className="gdb-metric-icon-badge green"><WalkingManIcon /></span></div>
                  <div className="gdb-metric-value green" style={{ fontSize: '20px' }}>94% <span style={{ fontSize: '11px', color: '#64748b' }}>Score</span></div>
                  <div style={{ fontSize: '10.5px', color: '#10b981', fontWeight: 600 }}>Prime physical state</div>
                </div>
                <div className="gdb-metric-card">
                  <div className="gdb-metric-top"><span className="gdb-metric-label">Strain Index</span><span className="gdb-metric-icon-badge blue"><MoonSmallIcon /></span></div>
                  <div className="gdb-metric-value blue" style={{ fontSize: '20px' }}>8.2 <span style={{ fontSize: '11px', color: '#64748b' }}>/ 10</span></div>
                  <div style={{ fontSize: '10.5px', color: '#64748b' }}>High endurance load</div>
                </div>
              </div>

              <div className="gdb-subview-card">
                <h3 style={{ fontSize: '15px', fontWeight: 700, marginBottom: '12px' }}>Muscle Group Load & Training Zones</h3>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px' }}>
                  <div style={{ padding: '12px', background: '#f8fafc', borderRadius: '12px' }}>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Legs & Glutes</div>
                    <div style={{ fontSize: '18px', fontWeight: 700, color: '#ff701e', marginTop: '2px' }}>42%</div>
                    <div style={{ height: '4px', background: '#ff701e', borderRadius: '99px', marginTop: '6px' }}></div>
                  </div>
                  <div style={{ padding: '12px', background: '#f8fafc', borderRadius: '12px' }}>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Core & Obliques</div>
                    <div style={{ fontSize: '18px', fontWeight: 700, color: '#22c55e', marginTop: '2px' }}>28%</div>
                    <div style={{ height: '4px', background: '#22c55e', borderRadius: '99px', marginTop: '6px' }}></div>
                  </div>
                  <div style={{ padding: '12px', background: '#f8fafc', borderRadius: '12px' }}>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Upper Body</div>
                    <div style={{ fontSize: '18px', fontWeight: 700, color: '#3b82f6', marginTop: '2px' }}>18%</div>
                    <div style={{ height: '4px', background: '#3b82f6', borderRadius: '99px', marginTop: '6px' }}></div>
                  </div>
                  <div style={{ padding: '12px', background: '#f8fafc', borderRadius: '12px' }}>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Back & Shoulders</div>
                    <div style={{ fontSize: '18px', fontWeight: 700, color: '#ff3b71', marginTop: '2px' }}>12%</div>
                    <div style={{ height: '4px', background: '#ff3b71', borderRadius: '99px', marginTop: '6px' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: WORKOUT SCHEDULE */}
          {activeNav === 'calendar' && (
            <div className="gdb-subview-wrap">
              <div className="gdb-subview-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Weekly Elite Training Drills</h3>
                  <p style={{ fontSize: '12px', color: '#64748b' }}>Periodized plan tailored for match day fitness</p>
                </div>
                <button
                  className="gdb-btn-orange"
                  onClick={() => triggerToast('Added new custom drill to calendar')}
                >
                  + Add Drill
                </button>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {[
                  { day: 'Monday', title: 'High-Intensity Interval Sprint (45 mins)', status: 'Completed ✓', color: '#22c55e' },
                  { day: 'Tuesday', title: 'Resistance Band Plyometrics (60 mins)', status: 'Completed ✓', color: '#22c55e' },
                  { day: 'Wednesday', title: 'Running with Resistance Band (Today - Active)', status: 'In Progress ⚡', color: '#ff701e' },
                  { day: 'Thursday', title: 'Upper Body Power & Core Stabilization', status: 'Scheduled (Tomorrow)', color: '#3b82f6' },
                  { day: 'Friday', title: 'Agility Ball Mastery & Speed Drills', status: 'Scheduled', color: '#64748b' },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    className="gdb-subview-card"
                    style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 18px', cursor: 'pointer' }}
                    onClick={() => triggerToast(`${item.day}: ${item.title}`)}
                  >
                    <div>
                      <span style={{ fontSize: '11px', fontWeight: 700, color: item.color, textTransform: 'uppercase' }}>{item.day}</span>
                      <h4 style={{ fontSize: '13.5px', fontWeight: 600, marginTop: '2px' }}>{item.title}</h4>
                    </div>
                    <span style={{ fontSize: '11px', fontWeight: 700, color: item.color }}>{item.status}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: LIVE STOPWATCH & HIIT TIMER */}
          {activeNav === 'timer' && (
            <div className="gdb-subview-wrap">
              <div className="gdb-subview-card" style={{ textAlign: 'center', padding: '24px' }}>
                <span style={{ fontSize: '12px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '1px' }}>
                  HIIT Interval Sprint Session
                </span>
                <div className="gdb-timer-display">{formatTimerTime(timerSeconds)}</div>
                <div style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
                  Round <strong>4 of 8</strong> (Work: 45s / Rest: 15s)
                </div>

                <div className="gdb-timer-controls">
                  <button
                    className="gdb-btn-orange"
                    onClick={() => setIsTimerRunning(!isTimerRunning)}
                  >
                    {isTimerRunning ? '⏸ Pause Timer' : '▶ Start Timer'}
                  </button>
                  <button
                    className="gdb-btn-ghost"
                    onClick={() => { setTimerSeconds(0); setIsTimerRunning(false); triggerToast('Timer Reset'); }}
                  >
                    ↺ Reset
                  </button>
                  <button
                    className="gdb-btn-ghost"
                    onClick={() => triggerToast(`Lap recorded at ${formatTimerTime(timerSeconds)}`)}
                  >
                    ⏱ Lap Split
                  </button>
                </div>
              </div>

              <div className="gdb-subview-card">
                <h4 style={{ fontSize: '13px', fontWeight: 700, marginBottom: '8px' }}>Recent Interval Laps</h4>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', padding: '6px 0', borderBottom: '1px solid #f1f5f9' }}>
                  <span>Lap 3: 400m Resistance Sprint</span>
                  <strong style={{ color: '#22c55e' }}>01:14.2</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', padding: '6px 0', borderBottom: '1px solid #f1f5f9' }}>
                  <span>Lap 2: Plyometric High Knees</span>
                  <strong style={{ color: '#ff701e' }}>01:18.9</strong>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: COMMUNITY & ATHLETE LEADERBOARD */}
          {activeNav === 'community' && (
            <div className="gdb-subview-wrap">
              <div className="gdb-subview-card">
                <h3 style={{ fontSize: '15px', fontWeight: 700, marginBottom: '4px' }}>Global Athlete League Leaderboard</h3>
                <p style={{ fontSize: '11.5px', color: '#64748b', marginBottom: '12px' }}>Ranked by overall workout volume, consistency & heart rate zones</p>

                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  {[
                    { rank: '1 🥇', name: 'Lionel Messi (You)', points: '48,200 pts', badge: 'Active Leader' },
                    { rank: '2 🥈', name: 'Cristiano Ronaldo', points: '47,850 pts', badge: 'Challenger' },
                    { rank: '3 🥉', name: 'Kylian Mbappé', points: '44,100 pts', badge: 'Elite' },
                    { rank: '4', name: 'Erling Haaland', points: '42,900 pts', badge: 'Power Striker' },
                    { rank: '5', name: 'Neymar Jr', points: '39,400 pts', badge: 'Pro' }
                  ].map((row, idx) => (
                    <div key={idx} className="gdb-leaderboard-row">
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <span style={{ fontWeight: 700, width: '28px' }}>{row.rank}</span>
                        <span style={{ fontWeight: 600 }}>{row.name}</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <span style={{ fontSize: '12px', color: '#ff701e', fontWeight: 700 }}>{row.points}</span>
                        <button
                          style={{ background: '#f1f5f9', border: 'none', padding: '4px 10px', borderRadius: '99px', fontSize: '10.5px', fontWeight: 600, cursor: 'pointer' }}
                          onClick={() => triggerToast(`Sent Cheer to ${row.name}!`)}
                        >
                          👏 Cheer
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: SETTINGS & BIOMETRICS */}
          {activeNav === 'settings' && (
            <div className="gdb-subview-wrap">
              <div className="gdb-subview-card">
                <h3 style={{ fontSize: '15px', fontWeight: 700, marginBottom: '10px' }}>Connected Biometric Devices</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid #f1f5f9' }}>
                    <div>
                      <div style={{ fontWeight: 600 }}>Apple Watch Ultra 2</div>
                      <div style={{ fontSize: '11px', color: '#22c55e' }}>● Connected (94% Battery) - Continuous HR On</div>
                    </div>
                    <button style={{ padding: '4px 12px', background: '#f1f5f9', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '11px' }} onClick={() => triggerToast('Synced Apple Watch data')}>Sync Now</button>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0' }}>
                    <div>
                      <div style={{ fontWeight: 600 }}>Whoop 4.0 Recovery Strap</div>
                      <div style={{ fontSize: '11px', color: '#22c55e' }}>● Connected (88% Battery) - Sleep Staging Active</div>
                    </div>
                    <button style={{ padding: '4px 12px', background: '#f1f5f9', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '11px' }} onClick={() => triggerToast('Synced Whoop strap data')}>Sync Now</button>
                  </div>
                </div>
              </div>

              <div className="gdb-subview-card">
                <h4 style={{ fontSize: '13px', fontWeight: 700, marginBottom: '8px' }}>Daily Health Targets</h4>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px' }}>
                  <div style={{ padding: '8px', background: '#f8fafc', borderRadius: '8px' }}><div style={{ fontSize: '10px', color: '#64748b' }}>CALORIES</div><strong style={{ color: '#ff701e' }}>2,200 Kcal</strong></div>
                  <div style={{ padding: '8px', background: '#f8fafc', borderRadius: '8px' }}><div style={{ fontSize: '10px', color: '#64748b' }}>STEPS</div><strong style={{ color: '#22c55e' }}>10,000</strong></div>
                  <div style={{ padding: '8px', background: '#f8fafc', borderRadius: '8px' }}><div style={{ fontSize: '10px', color: '#64748b' }}>SLEEP</div><strong style={{ color: '#3b82f6' }}>8.0 Hours</strong></div>
                  <div style={{ padding: '8px', background: '#f8fafc', borderRadius: '8px' }}><div style={{ fontSize: '10px', color: '#64748b' }}>WATER</div><strong style={{ color: '#06b6d4' }}>3.5 Liters</strong></div>
                </div>
              </div>
            </div>
          )}

        </main>

        {/* ----------------------------------------------------------------
            3. Right Dark Glass Profile & Schedule Panel
            (All icons and components interactive as requested!)
            ---------------------------------------------------------------- */}
        <aside className="gdb-right-panel">

          {/* Profile Header */}
          <div className="gdb-profile-header">
            <div
              className="gdb-profile-info-group"
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              title="Click to view Lionel Messi Profile"
            >
              <img src={IMAGES.messi} alt="Lionel Messi" className="gdb-messi-avatar" />
              <div className="gdb-profile-meta">
                <span className="gdb-profile-name">
                  Lionel Messi
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="6 9 12 15 18 9"/></svg>
                </span>
                <span className="gdb-profile-handle">@itsworks</span>
              </div>
            </div>

            <button
              className="gdb-dark-icon-btn"
              title="Profile Options"
              onClick={() => setShowProfileMenu(!showProfileMenu)}
            >
              <MoreDotsIcon />
            </button>
          </div>

          {/* Body Stats Row (75 kg, 180 cm, 26 yrs - Interactive!) */}
          <div className="gdb-body-stats-row">
            <div className="gdb-body-stat-col" onClick={() => setShowStatsModal('weight')} style={{ cursor: 'pointer' }} title="Click to edit weight">
              <span className="gdb-stat-num">{bodyStats.weight} kg</span>
              <span className="gdb-stat-lbl">Weight</span>
            </div>
            <div className="gdb-body-stat-col" onClick={() => setShowStatsModal('height')} style={{ cursor: 'pointer' }} title="Click to edit height">
              <span className="gdb-stat-num">{bodyStats.height} cm</span>
              <span className="gdb-stat-lbl">Height</span>
            </div>
            <div className="gdb-body-stat-col" onClick={() => setShowStatsModal('age')} style={{ cursor: 'pointer' }} title="Click to edit age">
              <span className="gdb-stat-num">{bodyStats.age} yrs</span>
              <span className="gdb-stat-lbl">Age</span>
            </div>
          </div>

          {/* Interactive Calendar Section */}
          <div className="gdb-calendar-wrap">
            <div className="gdb-cal-header">
              <span className="gdb-cal-title">{monthNames[currentMonthIndex]}</span>
              <div className="gdb-cal-arrows">
                <button
                  className="gdb-cal-arrow-btn"
                  title="Previous Month"
                  onClick={() => {
                    const prev = currentMonthIndex > 0 ? currentMonthIndex - 1 : 11;
                    setCurrentMonthIndex(prev);
                    triggerToast(`Showing ${monthNames[prev]}`);
                  }}
                >
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <button
                  className="gdb-cal-arrow-btn"
                  title="Next Month"
                  onClick={() => {
                    const next = currentMonthIndex < 11 ? currentMonthIndex + 1 : 0;
                    setCurrentMonthIndex(next);
                    triggerToast(`Showing ${monthNames[next]}`);
                  }}
                >
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
              </div>
            </div>

            {/* Days of week */}
            <div className="gdb-cal-days-head">
              <span>Su</span>
              <span>Mo</span>
              <span>Tu</span>
              <span>We</span>
              <span>Th</span>
              <span>Fr</span>
              <span>Sa</span>
            </div>

            {/* Calendar Days Grid */}
            <div className="gdb-cal-grid">
              <span style={{ opacity: 0 }}></span>
              <span style={{ opacity: 0 }}></span>
              <span style={{ opacity: 0 }}></span>
              <span style={{ opacity: 0 }}></span>

              {Array.from({ length: 31 }, (_, i) => {
                const day = i + 1;
                let dayClass = 'gdb-cal-day';
                if (day === 17 || day === 21) {
                  dayClass += ' completed-green';
                } else if (day === selectedDay) {
                  dayClass += ' active-orange';
                } else if (day === 25) {
                  dayClass += ' rest-pink';
                }

                return (
                  <span
                    key={day}
                    className={dayClass}
                    onClick={() => {
                      setSelectedDay(day);
                      if (day === 17 || day === 21) {
                        triggerToast(`Dec ${day}: Workout Complete! (Cardio Session)`);
                      } else if (day === 25) {
                        triggerToast(`Dec 25: Christmas Recovery & Rest Day`);
                      } else {
                        triggerToast(`Selected: Dec ${day}, 2022`);
                      }
                    }}
                  >
                    {day}
                  </span>
                );
              })}
            </div>
          </div>

          {/* Scheduled Workouts Section */}
          <div className="gdb-scheduled-wrap">
            <div className="gdb-scheduled-header">
              <div className="gdb-section-title-wrap">
                <span className="gdb-orange-indicator"></span>
                <span style={{ fontSize: '13px', fontWeight: 700 }}>Scheduled</span>
              </div>
              <span
                className="gdb-view-all-link"
                style={{ color: 'rgba(255,255,255,0.7)' }}
                onClick={() => setShowFullScheduleModal(true)}
              >
                view all
              </span>
            </div>

            {/* Workout Cards List */}
            <div className="gdb-workout-list">
              {workoutList.map((item, idx) => (
                <div
                  key={idx}
                  className="gdb-workout-card"
                  onClick={() => setShowWorkoutModal(item)}
                >
                  <div className="gdb-workout-left">
                    <img src={item.thumb} alt={item.title} className="gdb-workout-thumb" />
                    <div className="gdb-workout-meta">
                      <span className="gdb-tag-pill">{item.tag}</span>
                      <span className="gdb-workout-title">{item.title}</span>
                      <span className="gdb-workout-desc">{item.desc}</span>
                    </div>
                  </div>

                  <div className="gdb-workout-right">
                    <button
                      className="gdb-dark-icon-btn"
                      style={{ width: '22px', height: '22px' }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowWorkoutModal(item);
                      }}
                      title="Workout Actions"
                    >
                      <MoreDotsIcon />
                    </button>
                    <span className="gdb-workout-date">{item.date}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </aside>

      </div>

      {/* Profile Modal */}
      {showProfileMenu && (
        <div className="gdb-modal-overlay" onClick={() => setShowProfileMenu(false)}>
          <div className="gdb-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="gdb-modal-header">
              <h3 className="gdb-modal-title">Athlete Profile</h3>
              <button className="gdb-modal-close" onClick={() => setShowProfileMenu(false)}>✕</button>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <img src={IMAGES.messi} alt="Lionel Messi" style={{ width: '56px', height: '56px', borderRadius: '50%' }} />
              <div>
                <h4 style={{ fontSize: '16px', fontWeight: 700 }}>Lionel Messi</h4>
                <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.7)' }}>Professional Footballer & Elite Athlete</p>
                <span style={{ fontSize: '11px', color: '#ff701e', fontWeight: 600 }}>Active Training Program</span>
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '10px' }}>
              <button
                style={{ padding: '10px', borderRadius: '10px', background: 'rgba(255,255,255,0.1)', border: 'none', color: '#fff', cursor: 'pointer', textAlign: 'left', fontSize: '12.5px' }}
                onClick={() => { setShowProfileMenu(false); triggerToast('Training Plan synced to Apple Health'); }}
              >
                ⌚ Connect Apple Health / Whoop Strap
              </button>
              <button
                style={{ padding: '10px', borderRadius: '10px', background: 'rgba(255,255,255,0.1)', border: 'none', color: '#fff', cursor: 'pointer', textAlign: 'left', fontSize: '12.5px' }}
                onClick={() => { setShowProfileMenu(false); triggerToast('Heart Rate Zones updated'); }}
              >
                ❤️ Set Max Heart Rate (192 bpm)
              </button>
              <button
                style={{ padding: '10px', borderRadius: '10px', background: '#ff701e', border: 'none', color: '#fff', cursor: 'pointer', fontWeight: 600, fontSize: '12.5px' }}
                onClick={() => { setShowProfileMenu(false); triggerToast('Profile Saved'); }}
              >
                Save Preferences
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Workout Action Modal */}
      {showWorkoutModal && (
        <div className="gdb-modal-overlay" onClick={() => setShowWorkoutModal(null)}>
          <div className="gdb-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="gdb-modal-header">
              <h3 className="gdb-modal-title">{showWorkoutModal.title}</h3>
              <button className="gdb-modal-close" onClick={() => setShowWorkoutModal(null)}>✕</button>
            </div>
            <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.8)' }}>
              Scheduled for <strong>{showWorkoutModal.date}</strong>. {showWorkoutModal.desc}.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <button
                style={{ padding: '10px', borderRadius: '10px', background: '#22c55e', border: 'none', color: '#fff', fontWeight: 600, cursor: 'pointer', fontSize: '13px' }}
                onClick={() => {
                  setShowWorkoutModal(null);
                  triggerToast('✓ Marked Cardio Workshop as Completed!');
                }}
              >
                ✓ Mark Workout Completed
              </button>
              <button
                style={{ padding: '10px', borderRadius: '10px', background: 'rgba(255,255,255,0.12)', border: 'none', color: '#fff', cursor: 'pointer', fontSize: '13px' }}
                onClick={() => {
                  setShowWorkoutModal(null);
                  triggerToast('Rescheduled for Dec 26');
                }}
              >
                📅 Reschedule Session
              </button>
              <button
                style={{ padding: '10px', borderRadius: '10px', background: 'rgba(239,68,68,0.2)', border: '1px solid rgba(239,68,68,0.4)', color: '#fca5a5', cursor: 'pointer', fontSize: '13px' }}
                onClick={() => {
                  setWorkoutList(workoutList.filter(w => w.id !== showWorkoutModal.id));
                  setShowWorkoutModal(null);
                  triggerToast('Workout removed from schedule');
                }}
              >
                🗑 Remove from Schedule
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Body Stats Edit Modal */}
      {showStatsModal && (
        <div className="gdb-modal-overlay" onClick={() => setShowStatsModal(null)}>
          <div className="gdb-modal-card" style={{ maxWidth: '360px' }} onClick={(e) => e.stopPropagation()}>
            <div className="gdb-modal-header">
              <h3 className="gdb-modal-title">Update {showStatsModal.toUpperCase()}</h3>
              <button className="gdb-modal-close" onClick={() => setShowStatsModal(null)}>✕</button>
            </div>
            <div>
              <label style={{ fontSize: '12px', color: 'rgba(255,255,255,0.7)' }}>Enter new value:</label>
              <input
                type="number"
                defaultValue={bodyStats[showStatsModal]}
                id="statInput"
                style={{ width: '100%', marginTop: '6px', padding: '10px', borderRadius: '10px', background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: '#fff', fontSize: '16px' }}
              />
            </div>
            <button
              style={{ padding: '10px', borderRadius: '10px', background: '#ff701e', border: 'none', color: '#fff', fontWeight: 600, cursor: 'pointer' }}
              onClick={() => {
                const val = document.getElementById('statInput').value;
                setBodyStats({ ...bodyStats, [showStatsModal]: val });
                setShowStatsModal(null);
                triggerToast(`Updated ${showStatsModal} to ${val}`);
              }}
            >
              Save Changes
            </button>
          </div>
        </div>
      )}

      {/* Full Schedule Modal */}
      {showFullScheduleModal && (
        <div className="gdb-modal-overlay" onClick={() => setShowFullScheduleModal(false)}>
          <div className="gdb-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="gdb-modal-header">
              <h3 className="gdb-modal-title">Full December Schedule</h3>
              <button className="gdb-modal-close" onClick={() => setShowFullScheduleModal(false)}>✕</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', maxHeight: '280px', overflowY: 'auto' }}>
              <div style={{ padding: '10px', background: 'rgba(255,255,255,0.08)', borderRadius: '10px' }}>
                <strong>Dec 17:</strong> HIIT Cardio Sprint (45 mins) - Completed ✓
              </div>
              <div style={{ padding: '10px', background: 'rgba(255,255,255,0.08)', borderRadius: '10px' }}>
                <strong>Dec 21:</strong> Resistance Band Drills - Completed ✓
              </div>
              <div style={{ padding: '10px', background: 'rgba(255,112,30,0.25)', borderRadius: '10px', border: '1px solid #ff701e' }}>
                <strong>Dec 23 (Today):</strong> Running with Resistance Band - Active ⚡
              </div>
              <div style={{ padding: '10px', background: 'rgba(255,255,255,0.08)', borderRadius: '10px' }}>
                <strong>Dec 25:</strong> Holiday Recovery Stretch (20 mins)
              </div>
              <div style={{ padding: '10px', background: 'rgba(255,255,255,0.08)', borderRadius: '10px' }}>
                <strong>Dec 28:</strong> Core & Abdominals Workshop (30 mins)
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Toast Feedback */}
      {toastMsg && (
        <div className="gdb-toast">
          {toastMsg}
        </div>
      )}

    </div>
  );
}
