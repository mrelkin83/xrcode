import { useState } from 'react';
import GlassFitnessDashboard from './dashbord1.jsx';
import QuixoticDashboard from './dashbord2.jsx';
import AdminDashboard from './dashbord v7/src/daashbrod1.jsx';

function App() {
  // Default to Dashboard 2 (Quixotic) as requested
  const [currentDashboard, setCurrentDashboard] = useState(2);

  return (
    <div style={{ position: 'relative', width: '100%', minHeight: '100vh' }}>
      {/* ==================================================================
          Active Dashboard View
          ================================================================== */}
      {currentDashboard === 1 && <GlassFitnessDashboard />}
      {currentDashboard === 2 && <QuixoticDashboard />}
      {currentDashboard === 3 && <AdminDashboard />}

      {/* ==================================================================
          Floating Modern Switcher at Bottom Center
          ================================================================== */}
      <nav
        aria-label="Dashboard Switcher"
        style={{
          position: 'fixed',
          bottom: '18px',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 99999,
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          background: 'rgba(15, 23, 42, 0.88)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          border: '1px solid rgba(255, 255, 255, 0.18)',
          borderRadius: '9999px',
          padding: '5px 8px',
          boxShadow: '0 14px 40px rgba(0, 0, 0, 0.38)',
        }}
      >
        <span
          style={{
            fontSize: '11px',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '0.6px',
            color: 'rgba(255, 255, 255, 0.45)',
            padding: '0 6px 0 8px',
            userSelect: 'none',
          }}
        >
          Switch
        </span>

        {/* Dashboard 1 Button (Fitness) */}
        <button
          type="button"
          onClick={() => setCurrentDashboard(1)}
          style={{
            border: 'none',
            outline: 'none',
            padding: '7px 16px',
            borderRadius: '9999px',
            fontSize: '12.5px',
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            background:
              currentDashboard === 1
                ? 'linear-gradient(135deg, #ff701e 0%, #fa630f 100%)'
                : 'transparent',
            color: currentDashboard === 1 ? '#ffffff' : 'rgba(255, 255, 255, 0.75)',
            boxShadow:
              currentDashboard === 1
                ? '0 4px 14px rgba(255, 112, 30, 0.45)'
                : 'none',
          }}
        >
          <span>⚡</span>
          <span>Dashboard 1</span>
        </button>

        {/* Dashboard 2 Button (Quixotic) */}
        <button
          type="button"
          onClick={() => setCurrentDashboard(2)}
          style={{
            border: 'none',
            outline: 'none',
            padding: '7px 16px',
            borderRadius: '9999px',
            fontSize: '12.5px',
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            background:
              currentDashboard === 2
                ? 'linear-gradient(135deg, #0d8253 0%, #096841 100%)'
                : 'transparent',
            color: currentDashboard === 2 ? '#ffffff' : 'rgba(255, 255, 255, 0.75)',
            boxShadow:
              currentDashboard === 2
                ? '0 4px 14px rgba(13, 130, 83, 0.45)'
                : 'none',
          }}
        >
          <span>🌿</span>
          <span>Dashboard 2</span>
        </button>

        {/* Admin Dashboard Button */}
        <button
          type="button"
          onClick={() => setCurrentDashboard(3)}
          style={{
            border: 'none',
            outline: 'none',
            padding: '7px 16px',
            borderRadius: '9999px',
            fontSize: '12.5px',
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            background:
              currentDashboard === 3
                ? 'linear-gradient(135deg, #1967d2 0%, #1557b0 100%)'
                : 'transparent',
            color: currentDashboard === 3 ? '#ffffff' : 'rgba(255, 255, 255, 0.75)',
            boxShadow:
              currentDashboard === 3
                ? '0 4px 14px rgba(25, 103, 210, 0.45)'
                : 'none',
          }}
        >
          <span>📊</span>
          <span>Admin</span>
        </button>
      </nav>
    </div>
  );
}

export default App;
