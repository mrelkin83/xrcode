import React, { useState, useEffect, useRef } from 'react';
import { Mail, Lock, Eye, EyeOff, User } from 'lucide-react';
import { motion, AnimatePresence, useMotionValue, useSpring, useMotionTemplate, useTransform } from 'framer-motion';
import './index.css';

// Interactive Constellation (Spider Web) Component
const FloatingParticles = ({ mouseX, mouseY }) => {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animationFrameId;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);
    resize();

    const particles = [];
    const numParticles = 35; // Reduced from 70 for massive performance boost

    for (let i = 0; i < numParticles; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        radius: Math.random() * 2 + 1,
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const mx = mouseX.get();
      const my = mouseY.get();

      particles.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.fill();

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(255, 255, 255, ${(1 - dist / 120) * 0.4})`;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }

        const mdx = p.x - mx;
        const mdy = p.y - my;
        const mdist = Math.sqrt(mdx * mdx + mdy * mdy);

        if (mdist < 180) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(mx, my);
          // Highlight mouse connections to make them pop!
          ctx.strokeStyle = `rgba(255, 255, 255, ${(1 - mdist / 180) * 0.8})`;
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [mouseX, mouseY]);

  return (
    <canvas 
      ref={canvasRef} 
      style={{ 
        position: 'absolute', 
        top: 0, 
        left: 0, 
        width: '100%', 
        height: '100%', 
        pointerEvents: 'none', 
        zIndex: 1 
      }} 
    />
  );
};

// Type-to-Pulse Ripples Component
const Ripples = ({ ripples }) => {
  return (
    <div className="particles-container">
      <AnimatePresence>
        {ripples.map(r => (
          <motion.div
            key={r.id}
            initial={{ scale: 0, opacity: 0.6 }}
            animate={{ scale: 3, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            style={{
              position: 'absolute',
              width: 100,
              height: 100,
              borderRadius: '50%',
              border: '2px solid rgba(255,255,255,0.5)',
              left: `calc(${r.x}% - 50px)`,
              top: `calc(${r.y}% - 50px)`,
              pointerEvents: 'none'
            }}
          />
        ))}
      </AnimatePresence>
    </div>
  );
};

// Smooth Typewriter Component
const Typewriter = ({ textLines, delay = 0 }) => {
  const container = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.02, delayChildren: delay },
    },
  };

  const child = {
    hidden: { opacity: 0, y: 8, filter: "blur(2px)" },
    visible: {
      opacity: 1,
      y: 0,
      filter: "blur(0px)",
      transition: { type: "spring", stiffness: 150, damping: 10 }
    },
  };

  return (
    <motion.div variants={container} initial="hidden" animate="visible" style={{ display: 'inline-block' }}>
      {textLines.map((line, lineIndex) => (
        <React.Fragment key={lineIndex}>
          {Array.from(line).map((char, index) => (
            <motion.span 
              key={`${lineIndex}-${index}`} 
              variants={child} 
              whileHover={{ 
                scale: 1.2, 
                y: -4,
                color: "#d8b4fe",
                transition: { type: "spring", stiffness: 400, damping: 10 }
              }}
              style={{ display: "inline-block", cursor: 'default' }}
            >
              {char === " " ? "\u00A0" : char}
            </motion.span>
          ))}
          {lineIndex < textLines.length - 1 && <br />}
        </React.Fragment>
      ))}
    </motion.div>
  );
};

// Interactive Panda Mascot Component
const PandaMascot = ({ mouseX, mouseY, isCoveringEyes }) => {
  const [isHappy, setIsHappy] = useState(false);
  
  // Map a tighter area of the screen to the pupil movement. This makes the eyes dart faster (higher sensitivity)
  const pupilX = useTransform(mouseX, [(window.innerWidth || 1500) / 2 - 300, (window.innerWidth || 1500) / 2 + 300], [-4, 4]);
  const pupilY = useTransform(mouseY, [(window.innerHeight || 1000) / 2 - 200, (window.innerHeight || 1000) / 2 + 200], [-4, 4]);
  
  return (
    <div 
      style={{ width: 120, height: 120, margin: '0 auto -10px auto', zIndex: 4, position: 'relative', WebkitTapHighlightColor: 'transparent', transform: 'translateY(-15px)' }}
      onMouseDown={() => setIsHappy(true)}
      onMouseUp={() => setIsHappy(false)}
      onMouseLeave={() => setIsHappy(false)}
      onTouchStart={() => setIsHappy(true)}
      onTouchEnd={() => setIsHappy(false)}
    >
      <svg viewBox="0 0 100 100" width="100%" height="100%" style={{ filter: 'drop-shadow(0px 6px 6px rgba(0,0,0,0.12))', willChange: 'transform' }}>
        <defs>
          <radialGradient id="face-grad" cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#f0f0f0" />
          </radialGradient>
        </defs>

        {/* Happy Sparkles (Only visible when happy) */}
        <motion.g 
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: isHappy ? 1 : 0, opacity: isHappy ? 1 : 0 }} 
          style={{ transformOrigin: "15px 20px" }}
        >
          <path d="M 15 5 L 17 12 L 24 14 L 17 16 L 15 23 L 13 16 L 6 14 L 13 12 Z" fill="#FFD700" />
        </motion.g>
        <motion.g 
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: isHappy ? 1 : 0, opacity: isHappy ? 1 : 0 }} 
          style={{ transformOrigin: "85px 25px" }}
        >
          <path d="M 85 10 L 86.5 15 L 91.5 16.5 L 86.5 18 L 85 23 L 83.5 18 L 78.5 16.5 L 83.5 15 Z" fill="#FFD700" />
        </motion.g>

        {/* Left Ear */}
        <circle cx="20" cy="30" r="14" fill="#2d2d2d" />
        <circle cx="21" cy="31" r="6" fill="#1a1a1a" /> {/* Inner Ear */}

        {/* Right Ear */}
        <circle cx="80" cy="30" r="14" fill="#2d2d2d" />
        <circle cx="79" cy="31" r="6" fill="#1a1a1a" /> {/* Inner Ear */}
        
        {/* Face Base with gradient */}
        <circle cx="50" cy="55" r="42" fill="url(#face-grad)" stroke="#e0e0e0" strokeWidth="2" />
        
        {/* Left Eye Patch */}
        <path d="M 25 40 Q 35 30 43 45 Q 40 55 25 50 Z" fill="#2d2d2d" />
        {/* Right Eye Patch */}
        <path d="M 75 40 Q 65 30 57 45 Q 60 55 75 50 Z" fill="#2d2d2d" />
        
        {/* Left Eye Base (White) */}
        <circle cx="34" cy="44" r="8" fill="#ffffff" />
        {/* Right Eye Base (White) */}
        <circle cx="66" cy="44" r="8" fill="#ffffff" />

        {/* Left Pupil + Anime Highlight (Animated) */}
        <motion.g style={{ x: pupilX, y: pupilY }}>
          <circle cx="34" cy="44" r="4.5" fill="#2d2d2d" />
          <circle cx="32" cy="42" r="1.5" fill="#ffffff" />
        </motion.g>
        
        {/* Right Pupil + Anime Highlight (Animated) */}
        <motion.g style={{ x: pupilX, y: pupilY }}>
          <circle cx="66" cy="44" r="4.5" fill="#2d2d2d" />
          <circle cx="64" cy="42" r="1.5" fill="#ffffff" />
        </motion.g>
        
        {/* Nose with Specular Highlight */}
        <motion.ellipse cx="50" cy="62" rx="7" ry="4.5" fill="#2d2d2d" animate={{ y: isHappy ? -1 : 0 }} />
        <motion.ellipse cx="48" cy="60.5" rx="2.5" ry="1.5" fill="#ffffff" opacity="0.7" animate={{ y: isHappy ? -1 : 0 }} />
        
        {/* Eyebrows (Reacts to covering eyes) */}
        <motion.path 
          d="M 27 34 Q 32 30 38 34" 
          fill="transparent" stroke="#2d2d2d" strokeWidth="2.5" strokeLinecap="round"
          animate={{ 
            y: isCoveringEyes ? 2 : (isHappy ? -3 : 0),
            rotate: isCoveringEyes ? 10 : (isHappy ? -5 : 0)
          }} 
          style={{ transformOrigin: "32px 32px" }}
        />
        <motion.path 
          d="M 62 34 Q 68 30 73 34" 
          fill="transparent" stroke="#2d2d2d" strokeWidth="2.5" strokeLinecap="round"
          animate={{ 
            y: isCoveringEyes ? 2 : (isHappy ? -3 : 0),
            rotate: isCoveringEyes ? -10 : (isHappy ? 5 : 0)
          }}
          style={{ transformOrigin: "68px 32px" }}
        />

        {/* Mouth Group */}
        <motion.g>
          {/* Mouth Outline */}
          <motion.path 
            animate={{ 
              d: isHappy 
                ? "M 42 67 Q 50 82 58 67" // Big Happy Smile
                : "M 45 70 Q 50 74 55 70" // Normal subtle curve
            }}
            stroke="#2d2d2d" strokeWidth="2.5" fill={isHappy ? "#2d2d2d" : "transparent"} strokeLinecap="round" 
          />
          {/* Happy Tongue */}
          <motion.ellipse 
            cx="50" cy="74" rx="5" ry="3.5" fill="#ff7b89"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: isHappy ? 1 : 0, scale: isHappy ? 1 : 0 }}
          />
        </motion.g>

        {/* Left Paw (Covers Eyes) */}
        <motion.g
          initial={false}
          animate={{
            y: isCoveringEyes ? -45 : (isHappy ? -5 : 0),
            x: isCoveringEyes ? 12 : 0,
            rotate: isCoveringEyes ? 45 : (isHappy ? -15 : 0)
          }}
          transition={{ type: "spring", stiffness: 220, damping: 18 }}
          style={{ transformOrigin: "22px 85px" }}
        >
          <ellipse cx="22" cy="85" rx="14" ry="18" fill="#2d2d2d" />
          <ellipse cx="22" cy="82" rx="7" ry="5" fill="#444444" /> {/* Main Pad */}
          <ellipse cx="14" cy="74" rx="2.5" ry="3.5" fill="#444444" /> {/* Left Toe */}
          <ellipse cx="22" cy="71" rx="2.5" ry="3.5" fill="#444444" /> {/* Mid Toe */}
          <ellipse cx="30" cy="74" rx="2.5" ry="3.5" fill="#444444" /> {/* Right Toe */}
        </motion.g>

        {/* Right Paw (Covers Eyes) */}
        <motion.g
          initial={false}
          animate={{
            y: isCoveringEyes ? -45 : (isHappy ? -5 : 0),
            x: isCoveringEyes ? -12 : 0,
            rotate: isCoveringEyes ? -45 : (isHappy ? 15 : 0)
          }}
          transition={{ type: "spring", stiffness: 220, damping: 18 }}
          style={{ transformOrigin: "78px 85px" }}
        >
          <ellipse cx="78" cy="85" rx="14" ry="18" fill="#2d2d2d" />
          <ellipse cx="78" cy="82" rx="7" ry="5" fill="#444444" /> {/* Main Pad */}
          <ellipse cx="70" cy="74" rx="2.5" ry="3.5" fill="#444444" /> {/* Left Toe */}
          <ellipse cx="78" cy="71" rx="2.5" ry="3.5" fill="#444444" /> {/* Mid Toe */}
          <ellipse cx="86" cy="74" rx="2.5" ry="3.5" fill="#444444" /> {/* Right Toe */}
        </motion.g>
      </svg>
    </div>
  );
};

const App = () => {
  const [showPassword, setShowPassword] = useState(true);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLogin, setIsLogin] = useState(true);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [focusedInput, setFocusedInput] = useState(null);
  const [pandaFocus, setPandaFocus] = useState('none'); // Remembers last focused field for Panda
  const passwordRef = useRef(null);

  // Type-to-Pulse ripples state
  const [ripples, setRipples] = useState([]);

  // Mouse tracking for Spotlight Gradient
  const mouseX = useMotionValue(500); // Default center
  const mouseY = useMotionValue(300);

  // Smooth springs so spotlight follows mouse elegantly
  const smoothX = useSpring(mouseX, { damping: 40, stiffness: 150 });
  const smoothY = useSpring(mouseY, { damping: 40, stiffness: 150 });

  // Generate dynamic gradient based on mouse position
  const background = useMotionTemplate`radial-gradient(1200px circle at ${smoothX}px ${smoothY}px, #9a2bf6 0%, #4a00e0 80%)`;

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set(e.clientX - rect.left);
    mouseY.set(e.clientY - rect.top);
  };

  const handleType = (e) => {
    // Only trigger ripples on actual typing keys
    if (e.key.length === 1 || e.key === 'Backspace') {
      // Create ripple mostly in the purple background areas (corners)
      const isTopRight = Math.random() > 0.5;
      const x = isTopRight ? 60 + Math.random() * 40 : Math.random() * 40;
      const y = isTopRight ? Math.random() * 40 : 60 + Math.random() * 40;

      const newRipple = { id: Date.now() + Math.random(), x, y };
      // Keep only last 4 to prevent performance issues
      setRipples(prev => [...prev.slice(-3), newRipple]);
    }
  };

  const togglePage = (e) => {
    e.preventDefault();
    if (isTransitioning) return;

    setIsTransitioning(true);

    setTimeout(() => {
      setIsLogin(!isLogin);
      setTimeout(() => {
        setIsTransitioning(false);
      }, 150);
    }, 600);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.4 // Wait slightly for clouds to open
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: "spring", stiffness: 120, damping: 12 }
    }
  };

  return (
    <div className="card-container" onMouseMove={handleMouseMove}>
      <motion.div 
        className="bg-gradient" 
        style={{ background, willChange: 'background' }} 
      />

      {/* Floating Constellation Web & Typing Ripples */}
      <FloatingParticles mouseX={smoothX} mouseY={smoothY} />
      <Ripples ripples={ripples} />

      {/* Wrapper for the Infinite "Breathing" Cloud Animation */}
      <motion.div
        className="cloud-wrapper"
        animate={{ scale: [1, 1.02, 1] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 2, pointerEvents: 'none', willChange: 'transform' }}
      >
        <motion.svg
          className="cloud-svg"
          viewBox="0 0 1000 600"
          preserveAspectRatio="xMidYMid slice"
          xmlns="http://www.w3.org/2000/svg"
          // Epic Page Load Sequence: Start fully closed (scaleY: 0)
          initial={{ scaleY: 0 }}
          animate={{ scaleY: isTransitioning ? 0 : 1 }}
          transition={{ type: "spring", damping: 15, stiffness: 80, delay: 0.1 }}
          style={{ transformOrigin: 'center center', width: '100%', height: '100%' }}
        >
          {/* Organic Liquid Morphing Path */}
          <motion.path
            fill="#ffffff"
            animate={{
              d: [
                // Original Shape
                "M 0 0 L 350 0 Q 420 -10 460 30 Q 520 20 570 60 Q 640 50 710 100 Q 800 90 870 150 Q 960 140 1000 220 L 1000 380 Q 980 440 920 450 Q 900 520 830 500 Q 810 560 730 530 Q 700 590 620 560 Q 580 610 500 570 Q 450 610 380 570 Q 330 610 260 550 Q 210 580 140 510 Q 70 540 0 460 Z",
                // Morphed Liquid Shape (Control points shifted)
                "M 0 0 L 350 0 Q 435 -25 460 30 Q 505 35 570 60 Q 655 35 710 100 Q 785 105 870 150 Q 975 125 1000 220 L 1000 380 Q 995 425 920 450 Q 885 535 830 500 Q 825 545 730 530 Q 685 605 620 560 Q 595 595 500 570 Q 435 625 380 570 Q 345 595 260 550 Q 195 595 140 510 Q 85 525 0 460 Z",
                // Back to Original
                "M 0 0 L 350 0 Q 420 -10 460 30 Q 520 20 570 60 Q 640 50 710 100 Q 800 90 870 150 Q 960 140 1000 220 L 1000 380 Q 980 440 920 450 Q 900 520 830 500 Q 810 560 730 530 Q 700 590 620 560 Q 580 610 500 570 Q 450 610 380 570 Q 330 610 260 550 Q 210 580 140 510 Q 70 540 0 460 Z"
              ]
            }}
            transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
          />
        </motion.svg>
      </motion.div>

      {/* Content Layer */}
      <motion.div
        className="content-container"
        animate={{
          opacity: isTransitioning ? 0 : 1,
          scale: isTransitioning ? 0.95 : 1
        }}
        transition={{ duration: 0.3 }}
        style={{ zIndex: 3, willChange: 'opacity, transform' }}
      >
        {/* Left Form Section */}
        <motion.div 
          className="login-section"
          key={isLogin ? 'login' : 'register'}
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.h1 className="title" variants={itemVariants}>
            {isLogin ? 'Hello!' : 'Create Account'}
          </motion.h1>
          <motion.p className="subtitle" variants={itemVariants}>
            {isLogin ? 'Sign in to your account' : 'Register to get started'}
          </motion.p>

          <form
            onSubmit={(e) => e.preventDefault()}
            className="form"
          >
            
            {/* Mascot Component */}
            <motion.div variants={itemVariants}>
              <PandaMascot 
                mouseX={mouseX} 
                mouseY={mouseY} 
                isCoveringEyes={pandaFocus === 'password' && !showPassword} 
              />
            </motion.div>

            {!isLogin && (
              <motion.div className="input-card" variants={itemVariants}>
                <motion.div
                  className="icon-badge"
                  animate={{ scale: focusedInput === 'name' ? 1.15 : 1, rotate: focusedInput === 'name' ? -10 : 0 }}
                  transition={{ type: "spring", stiffness: 300, damping: 10 }}
                >
                  <User size={18} color="#a020f0" strokeWidth={2.2} />
                </motion.div>
                <input
                  type="text"
                  placeholder="Full Name"
                  className="input-field"
                  autoComplete="off"
                  onFocus={() => { setFocusedInput('name'); setPandaFocus('name'); }}
                  onBlur={() => setFocusedInput(null)}
                  onKeyDown={handleType}
                />
              </motion.div>
            )}

            <motion.div className="input-card" variants={itemVariants}>
              <motion.div
                className="icon-badge"
                animate={{ scale: focusedInput === 'email' ? 1.15 : 1, rotate: focusedInput === 'email' ? -10 : 0 }}
                transition={{ type: "spring", stiffness: 300, damping: 10 }}
              >
                <Mail size={18} color="#a020f0" strokeWidth={2.2} />
              </motion.div>
              <input
                type="email"
                placeholder="Email Address"
                className="input-field"
                autoComplete="off"
                onFocus={() => { setFocusedInput('email'); setPandaFocus('email'); }}
                onBlur={() => setFocusedInput(null)}
                onKeyDown={handleType}
              />
            </motion.div>

            <motion.div className="input-card" variants={itemVariants}>
              <motion.div
                className="icon-badge"
                animate={{ scale: focusedInput === 'password' ? 1.15 : 1, rotate: focusedInput === 'password' ? -10 : 0 }}
                transition={{ type: "spring", stiffness: 300, damping: 10 }}
              >
                <Lock size={18} color="#a020f0" strokeWidth={2.2} />
              </motion.div>
              <input
                ref={passwordRef}
                type={showPassword ? 'text' : 'password'}
                placeholder="Password"
                className="input-field"
                autoComplete="new-password"
                onFocus={() => { setFocusedInput('password'); setPandaFocus('password'); }}
                onBlur={() => setFocusedInput(null)}
                onKeyDown={handleType}
              />
              <button
                type="button"
                className="toggle-eye"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  setShowPassword(!showPassword);
                  passwordRef.current?.focus();
                }}
                aria-label="Toggle password visibility"
              >
                <motion.div
                  initial={false}
                  animate={{ rotate: showPassword ? 180 : 0, scale: showPassword ? 1.2 : 1 }}
                  transition={{ type: "spring", stiffness: 200, damping: 12 }}
                >
                  {showPassword ? (
                    <Eye size={18} color="#a020f0" />
                  ) : (
                    <EyeOff size={18} color="#a020f0" />
                  )}
                </motion.div>
              </button>
            </motion.div>

            {isLogin ? (
              <motion.div className="options-row" variants={itemVariants}>
                <label className="checkbox-container">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                  />
                  <span className="custom-checkbox">
                    <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="white" strokeWidth="3">
                      <motion.polyline
                        points="20 6 9 17 4 12"
                        initial={{ pathLength: 0, opacity: 0 }}
                        animate={{ pathLength: rememberMe ? 1 : 0, opacity: rememberMe ? 1 : 0 }}
                        transition={{ duration: 0.3, ease: "easeOut" }}
                      />
                    </svg>
                  </span>
                  <span className="label-text">Remember me</span>
                </label>

                <a href="#forgot" className="forgot-link">
                  Forgot password?
                </a>
              </motion.div>
            ) : (
              <div style={{ height: '24px' }}></div>
            )}

            <motion.div className="button-wrapper" variants={itemVariants}>
              <motion.button
                type="submit"
                className="sign-in-button"
                whileHover={{ scale: 1.04, boxShadow: "0 12px 24px rgba(0,0,0,0.18)" }}
                whileTap={{ scale: 0.95, boxShadow: "0 4px 10px rgba(0,0,0,0.1)" }}
              >
                {isLogin ? 'SIGN IN' : 'SIGN UP'}
              </motion.button>
            </motion.div>
          </form>

          <p className="footer-text">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <a href="#swap" className="create-link" onClick={togglePage}>
              {isLogin ? 'Create' : 'Sign in'}
            </a>
          </p>
        </motion.div>

        {/* Right Welcome Section with Typewriter Effect */}
        <div className="welcome-section" key={isLogin ? 'login-text' : 'register-text'}>
          <h2 className="welcome-title">
            <Typewriter
              textLines={[isLogin ? 'Welcome Back!' : 'Hello Friend!']}
              delay={0.6}
            />
          </h2>
          <p className="welcome-desc">
            {isLogin ? (
              <Typewriter
                textLines={[
                  "Lorem ipsum dolor sit amet, consectetur",
                  "adipiscing elit. Sed pharetra magna nisl, at",
                  "posuere sem dapibus sed."
                ]}
                delay={0.9}
              />
            ) : (
              <Typewriter
                textLines={[
                  "Enter your personal details",
                  "and start your journey",
                  "with us today."
                ]}
                delay={0.9}
              />
            )}
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default App;