import { useState } from 'react'
import { motion } from 'framer-motion'
import './App.css'

function TeamLogoIcon() {
  return (
    <svg
      width="38"
      height="28"
      viewBox="0 0 42 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="card-logo"
      aria-label="Team Plan Logo"
    >
      <defs>
        <linearGradient id="logo-left-grad" x1="6" y1="5" x2="22" y2="25" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#688aff" />
          <stop offset="50%" stopColor="#4368f5" />
          <stop offset="100%" stopColor="#2c51e0" />
        </linearGradient>

        <linearGradient id="logo-right-grad" x1="18" y1="5" x2="34" y2="25" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#4a6ef5" />
          <stop offset="60%" stopColor="#2f51de" />
          <stop offset="100%" stopColor="#1e3cb8" />
        </linearGradient>

        <linearGradient id="fold-shadow" x1="17" y1="8" x2="23" y2="20" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#10257e" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#10257e" stopOpacity="0" />
        </linearGradient>
      </defs>

      <rect
        x="7.5"
        y="8.5"
        width="15"
        height="15"
        rx="4"
        transform="rotate(45 15 16)"
        fill="url(#logo-left-grad)"
      />

      <rect
        x="19.5"
        y="8.5"
        width="15"
        height="15"
        rx="4"
        transform="rotate(45 27 16)"
        fill="url(#logo-right-grad)"
      />

      <path
        d="M21 10L27 16L21 22"
        stroke="url(#fold-shadow)"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </svg>
  )
}

function GreenCheckIcon({ size = 18 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path
        d="M4.5 10.5L8.2 14.2L15.5 6.5"
        stroke="#00b894"
        strokeWidth="2.3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function MiniCheckIcon({ className = '' }) {
  return (
    <svg
      width="13"
      height="13"
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path
        d="M3 8.5L6.5 12L13 4"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function WalletPocketCard({
  theme = 'blue-theme',
  docTitle,
  badge = 'PRO',
  price = '$500',
  pricePeriod = '/license',
  subDesc = 'Complete Pitch & Strategy Kit',
  features = [],
  btnText = 'Get Template · $500',
  titlePart1,
  titlePart2,
  date = '11th May 2024',
  isLeft = true,
}) {
  const [hovered, setHovered] = useState(false)
  const [tapped, setTapped] = useState(false)
  const isBlue = theme === 'blue-theme'
  const active = hovered || tapped

  return (
    <div
      className="wallet-card-container"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={() => setTapped((prev) => !prev)}
    >
      {/* 1. Wallet Back Panel (inside cavity) */}
      <motion.div
        className={`wallet-back-panel ${theme}`}
        initial={false}
        animate={{
          scale: active ? 1.01 : 1,
        }}
        transition={{
          type: 'spring',
          stiffness: 300,
          damping: 26,
        }}
      />

      {/* 2. Document Card (Slides out FROM INSIDE the wallet on hover/tap) */}
      <motion.div
        className="wallet-doc-wrapper"
        initial={false}
        animate={{
          y: active ? -138 : 0,
          scale: active ? 1.02 : 1,
          rotate: active ? (isLeft ? -1.5 : 1.5) : 0,
        }}
        transition={{
          type: 'spring',
          stiffness: 280,
          damping: 24,
        }}
      >
        <div className={`doc-frame ${theme}`}>
          {/* Header */}
          <div className="doc-header-tag">
            <span>{docTitle}</span>
            <span className={`doc-badge ${isBlue ? 'blue-badge' : 'pink-badge'}`}>
              {badge}
            </span>
          </div>

          {/* Skeleton pills preview (visible at rest) */}
          <div className="doc-skeleton-row">
            <span className="doc-pill w-short" />
            <span className="doc-pill w-med" />
            <span className="doc-pill w-short" />
          </div>

          {/* Subscription / Pricing Details revealed on hover/tap */}
          <div className="doc-price-area">
            <span className="doc-price-val">{price}</span>
            <span className="doc-price-period">{pricePeriod}</span>
          </div>
          <div className="doc-sub-desc">{subDesc}</div>

          {/* Custom Feature Bullets */}
          <ul className="doc-feature-list">
            {features.map((feat, idx) => (
              <li key={idx} className="doc-feature-item">
                <MiniCheckIcon
                  className={`doc-check-icon ${isBlue ? 'blue-check' : 'pink-check'}`}
                />
                <span>{feat}</span>
              </li>
            ))}
          </ul>

          {/* Action CTA Button */}
          <button
            type="button"
            className={`doc-action-btn ${isBlue ? 'blue-btn' : 'pink-btn'}`}
            onClick={(e) => {
              e.stopPropagation()
            }}
          >
            {btnText}
          </button>
        </div>
      </motion.div>

      {/* 3. Front Flap of Wallet */}
      <motion.div
        className="wallet-front-flap"
        initial={false}
        animate={{
          y: active ? 8 : 0,
          scale: active ? 0.995 : 1,
        }}
        transition={{
          type: 'spring',
          stiffness: 280,
          damping: 24,
        }}
      >
        <svg
          className="wallet-flap-svg"
          viewBox="0 0 340 310"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient
              id={`blueFlapGrad-${theme}`}
              x1="170"
              y1="0"
              x2="170"
              y2="310"
              gradientUnits="userSpaceOnUse"
            >
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="35%" stopColor="#f8faff" />
              <stop offset="70%" stopColor="#edf2ff" />
              <stop offset="100%" stopColor="#dce8fe" />
            </linearGradient>

            <linearGradient
              id={`pinkFlapGrad-${theme}`}
              x1="170"
              y1="0"
              x2="170"
              y2="310"
              gradientUnits="userSpaceOnUse"
            >
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="35%" stopColor="#fdf4f9" />
              <stop offset="70%" stopColor="#fae8ff" />
              <stop offset="100%" stopColor="#f5d0fe" />
            </linearGradient>
          </defs>

          {/* Front pocket flap with seamless scoop curve */}
          <path
            d="M 20,0 L 26,0 C 32,0 36,6 40,14 C 44,22 50,26 60,26 L 280,26 C 290,26 296,22 300,14 C 304,6 308,0 314,0 L 320,0 C 331,0 340,9 340,20 L 340,290 C 340,301 331,310 320,310 L 20,310 C 9,310 0,301 0,290 L 0,20 C 0,9 9,0 20,0 Z"
            fill={isBlue ? `url(#blueFlapGrad-${theme})` : `url(#pinkFlapGrad-${theme})`}
            stroke={isBlue ? 'rgba(219, 234, 254, 0.7)' : 'rgba(250, 232, 255, 0.7)'}
            strokeWidth="1"
          />

          {/* Subtle rim border around the scoop opening */}
          <path
            d="M 26,0 C 32,0 36,6 40,14 C 44,22 50,26 60,26 L 280,26 C 290,26 296,22 300,14 C 304,6 308,0 314,0"
            stroke="rgba(0, 0, 0, 0.05)"
            strokeWidth="1.5"
            fill="none"
          />
        </svg>

        {/* Content on the front flap */}
        <div className="wallet-front-content">
          <h3 className="wallet-card-title">
            {titlePart1}
            <br />
            {titlePart2}
          </h3>
          <span className="wallet-card-date">{date}</span>
        </div>
      </motion.div>
    </div>
  )
}

function App() {
  const [hovered1, setHovered1] = useState(false)
  const [hovered2, setHovered2] = useState(false)

  return (
    <>
      {/* ================= SECTION 1: PRICING CARDS ================= */}
      <section className="pricing-wrapper">
        {/* CARD 1: TEAM PLAN */}
        <div className="card-slot card-left">
          <motion.div
            className="pricing-card-wrapper"
            onMouseEnter={() => setHovered1(true)}
            onMouseLeave={() => setHovered1(false)}
            initial={false}
            animate={{
              y: hovered1 ? -36 : 0,
              paddingTop: hovered1 ? 40 : 2.5,
              paddingLeft: hovered1 ? 4.5 : 2.5,
              paddingRight: hovered1 ? 4.5 : 2.5,
              paddingBottom: hovered1 ? 4.5 : 2.5,
              boxShadow: hovered1
                ? '0 30px 60px -14px rgba(15, 23, 42, 0.14), 0 0 32px 2px rgba(244, 63, 94, 0.25)'
                : '0 20px 40px -12px rgba(15, 23, 42, 0.08), 0 0 18px -3px rgba(6, 182, 212, 0.12)',
            }}
            transition={{
              type: 'spring',
              stiffness: 380,
              damping: 28,
            }}
          >
            <div className="card-top-banner">
              <motion.span
                className="top-banner-text"
                initial={false}
                animate={{
                  opacity: hovered1 ? 1 : 0,
                  y: hovered1 ? 0 : -8,
                  scale: hovered1 ? 1 : 0.9,
                }}
                transition={{
                  duration: 0.2,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                BEST VALUE TO PRICE
              </motion.span>
            </div>

            <div
              className="pricing-card"
              style={{ borderRadius: hovered1 ? '23.5px' : '25.5px' }}
            >
              <div className="card-header">
                <TeamLogoIcon />
                <span className="popular-badge">Most popular</span>
              </div>

              <div className="card-title-group">
                <h1 className="card-plan-name">Team</h1>
                <p className="card-plan-desc">Best for startups and small business.</p>
              </div>

              <div className="card-pricing-group">
                <span className="card-price">$299</span>
                <span className="card-billing-period">per user per month</span>
              </div>

              <button type="button" className="card-cta-button">
                Upgrade plan
              </button>

              <ul className="card-features-list">
                <li className="feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={18} />
                  </span>
                  <span className="feature-text">Unlimited users</span>
                </li>
                <li className="feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={18} />
                  </span>
                  <span className="feature-text">Update every hour</span>
                </li>
                <li className="feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={18} />
                  </span>
                  <span className="feature-text">Priority support</span>
                </li>
              </ul>
            </div>
          </motion.div>
        </div>

        {/* CARD 2: MICRODOSE RETAINER */}
        <div className="card-slot">
          <motion.div
            className="pricing-card-wrapper"
            onMouseEnter={() => setHovered2(true)}
            onMouseLeave={() => setHovered2(false)}
            initial={false}
            animate={{
              y: hovered2 ? -36 : 0,
              paddingTop: hovered2 ? 40 : 2.5,
              paddingLeft: hovered2 ? 4.5 : 2.5,
              paddingRight: hovered2 ? 4.5 : 2.5,
              paddingBottom: hovered2 ? 4.5 : 2.5,
              boxShadow: hovered2
                ? '0 30px 60px -14px rgba(15, 23, 42, 0.14), 0 0 32px 2px rgba(139, 92, 246, 0.25)'
                : '0 20px 40px -12px rgba(15, 23, 42, 0.08), 0 0 18px -3px rgba(6, 182, 212, 0.12)',
            }}
            transition={{
              type: 'spring',
              stiffness: 380,
              damping: 28,
            }}
          >
            <div className="card-top-banner">
              <motion.span
                className="top-banner-text"
                initial={false}
                animate={{
                  opacity: hovered2 ? 1 : 0,
                  y: hovered2 ? 0 : -8,
                  scale: hovered2 ? 1 : 0.9,
                }}
                transition={{
                  duration: 0.2,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                BEST VALUE TO PRICE
              </motion.span>
            </div>

            <div
              className="pricing-card"
              style={{ borderRadius: hovered2 ? '23.5px' : '25.5px' }}
            >
              <div className="retainer-header">
                <div className="retainer-tag">
                  <span className="retainer-num">02</span>
                  <span className="retainer-name">Retainer</span>
                </div>
                <button
                  type="button"
                  className="card-more-btn"
                  aria-label="More options"
                >
                  <span className="more-dot"></span>
                  <span className="more-dot"></span>
                  <span className="more-dot"></span>
                </button>
              </div>

              <div className="retainer-title-group">
                <h2 className="retainer-plan-name">
                  Micro<span className="serif-dose">dose</span>
                </h2>
                <p className="retainer-plan-desc">Double your delivery 2x</p>
              </div>

              <div className="card-action-row">
                <button type="button" className="card-pill-button">
                  Get me dose
                </button>
                <div className="card-pricing-col">
                  <div className="card-price-inline">
                    <span className="card-price-cur">$</span>
                    <span className="card-price-num">8 900</span>
                    <span className="card-price-unit">/mo</span>
                  </div>
                  <span className="card-price-sub">Pause or cancel anytime.</span>
                </div>
              </div>

              <ul className="card-features-list-dense">
                <li className="dense-feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={15} />
                  </span>
                  <span className="dense-feature-text">All from Nanodose membership</span>
                </li>
                <li className="dense-feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={15} />
                  </span>
                  <span className="dense-feature-text">Direct comms in Slack + weekly sync</span>
                </li>
                <li className="dense-feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={15} />
                  </span>
                  <span className="dense-feature-text">No-code development for free</span>
                </li>
                <li className="dense-feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={15} />
                  </span>
                  <span className="dense-feature-text">Available for 5 days each week</span>
                </li>
                <li className="dense-feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={15} />
                  </span>
                  <span className="dense-feature-text">Delivery in avg. 48 hours</span>
                </li>
                <li className="dense-feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={15} />
                  </span>
                  <span className="dense-feature-text">Easy-to-manage ticketing system in Notion</span>
                </li>
                <li className="dense-feature-item">
                  <span className="feature-icon-wrapper">
                    <GreenCheckIcon size={15} />
                  </span>
                  <span className="dense-feature-text">Immediate start</span>
                </li>
              </ul>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ================= SECTION 2: WALLET POCKET TEMPLATE CARDS ================= */}
      <section className="wallet-section">
        {/* Left Card: Project Proposal Template */}
        <WalletPocketCard
          theme="blue-theme"
          docTitle="Project Proposal"
          badge="PRO"
          price="$499"
          pricePeriod="/license"
          subDesc="Complete Pitch & Client Kit"
          features={[
            '24+ Custom slide decks',
            'Figma & Notion editable',
            'Commercial client rights',
          ]}
          btnText="Get Template · $499"
          titlePart1="Project Proposal"
          titlePart2="Template"
          date="11th May 2024"
          isLeft={true}
        />

        {/* Right Card: Website Design Quotation Template */}
        <WalletPocketCard
          theme="pink-theme"
          docTitle="Website Design Quotation"
          badge="KIT"
          price="$500"
          pricePeriod="/subscription"
          subDesc="Interactive Quotation Calculator"
          features={[
            'Dynamic price calculator',
            'Scope of work generator',
            'Instant client invoicing',
          ]}
          btnText="Get Template · $500"
          titlePart1="Website Design"
          titlePart2="Quotation Template"
          date="11th May 2024"
          isLeft={false}
        />
      </section>
    </>
  )
}

export default App
