import Navbar from './Navbar'
import './App.css'

function App() {
  return (
    <main className="app-container">
      <Navbar />
    </main>
  )
}

export default App
