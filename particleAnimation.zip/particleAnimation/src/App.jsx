import ParticleSphere from './ParticleSphere'
import './ParticleSphere.css'

function App() {
  return (
    <div style={{ width: '100vw', height: '100vh', position: 'fixed', inset: 0, overflow: 'hidden', background: '#000' }}>
      <ParticleSphere />
    </div>
  )
}

export default App
