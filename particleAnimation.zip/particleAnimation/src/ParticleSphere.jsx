import { useEffect, useRef, useState } from 'react'
import './ParticleSphere.css'

const COUNT = 9000
const SPEED = 0.28 // radians per second
const BASE_TILT = 0.18
const REPEL_RADIUS = 0.6 // fraction of sphere radius
const REPEL_FORCE = 4
const SPRING = 0.04 // pull back to home
const DAMPING = 0.84

// morph timing (seconds): burst outward, then gather into the new shape
const SCATTER = 0.7
const FORM = 1.6
const MAX_DELAY = 0.4

const SHAPES = [
  { id: 'sphere', label: 'Sphere' },
  { id: 'ring', label: 'Ring' },
  { id: 'cube', label: 'Cube' },
  { id: 'heart', label: 'Heart' },
  { id: 'text:A', label: 'A' },
  { id: 'text:CODEXR', label: 'CODEXR' },
]

// flat shapes stop spinning and face the viewer so they stay readable
const isFlat = (id) => id === 'heart' || id.startsWith('text:')

const rotX = (out, i, a) => {
  const y = out[i + 1]
  const z = out[i + 2]
  out[i + 1] = y * Math.cos(a) - z * Math.sin(a)
  out[i + 2] = y * Math.sin(a) + z * Math.cos(a)
}

const rotZ = (out, i, a) => {
  const x = out[i]
  const y = out[i + 1]
  out[i] = x * Math.cos(a) - y * Math.sin(a)
  out[i + 1] = x * Math.sin(a) + y * Math.cos(a)
}

// sphere shell, with extra clusters at the poles like the reference
function sphereShape() {
  const out = new Float32Array(COUNT * 3)
  for (let i = 0; i < COUNT; i++) {
    let y
    if (Math.random() < 0.28) {
      const side = Math.random() < 0.5 ? -1 : 1
      y = side * (1 - Math.pow(Math.random(), 2.2) * 0.35)
    } else {
      y = Math.random() * 2 - 1
    }
    const a = Math.random() * Math.PI * 2
    const ring = Math.sqrt(1 - y * y)
    const r = 1 + (Math.random() - 0.5) * 0.06
    out[i * 3] = Math.cos(a) * ring * r
    out[i * 3 + 1] = y * r
    out[i * 3 + 2] = Math.sin(a) * ring * r
  }
  return out
}

// tilted torus, like a planet ring
function ringShape() {
  const out = new Float32Array(COUNT * 3)
  for (let i = 0; i < COUNT; i++) {
    const u = Math.random() * Math.PI * 2
    const v = Math.random() * Math.PI * 2
    const tube = 0.16 * Math.sqrt(Math.random())
    const k = i * 3
    out[k] = (1 + tube * Math.cos(v)) * Math.cos(u)
    out[k + 1] = tube * Math.sin(v)
    out[k + 2] = (1 + tube * Math.cos(v)) * Math.sin(u)
    rotX(out, k, 1.15)
  }
  return out
}

// cube surface with brighter edges
function cubeShape() {
  const out = new Float32Array(COUNT * 3)
  const s = 0.72
  for (let i = 0; i < COUNT; i++) {
    const k = i * 3
    const p = [Math.random() * 2 - 1, Math.random() * 2 - 1, Math.random() * 2 - 1]
    const axis = Math.floor(Math.random() * 3)
    p[axis] = Math.random() < 0.5 ? -1 : 1
    if (Math.random() < 0.35) {
      const other = (axis + 1 + Math.floor(Math.random() * 2)) % 3
      p[other] = Math.random() < 0.5 ? -1 : 1
    }
    out[k] = p[0] * s
    out[k + 1] = p[1] * s
    out[k + 2] = p[2] * s
    rotX(out, k, 0.5)
    rotZ(out, k, 0.6)
  }
  return out
}

// puffy heart: dense outline, softer fill, a little depth
function heartShape() {
  const out = new Float32Array(COUNT * 3)
  for (let i = 0; i < COUNT; i++) {
    const t = Math.random() * Math.PI * 2
    const k = Math.random() < 0.6 ? 0.88 + Math.random() * 0.12 : Math.sqrt(Math.random())
    const hx = 16 * Math.sin(t) ** 3
    const hy = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)
    out[i * 3] = (hx / 17) * k * 1.1
    out[i * 3 + 1] = (-hy / 17) * k * 1.1 - 0.15
    out[i * 3 + 2] = (Math.random() * 2 - 1) * 0.28 * Math.sqrt(1 - k * 0.9)
  }
  return out
}

// rasterise text offscreen, then drop particles on the filled pixels
function textShape(text) {
  const font = '900 200px "Arial Black", "Helvetica Neue", system-ui, sans-serif'
  const c = document.createElement('canvas')
  const g = c.getContext('2d', { willReadFrequently: true })
  g.font = font
  const tw = Math.ceil(g.measureText(text).width) + 40
  c.width = tw
  c.height = 280
  g.font = font
  g.fillStyle = '#fff'
  g.textAlign = 'center'
  g.textBaseline = 'middle'
  g.fillText(text, tw / 2, 140)

  const data = g.getImageData(0, 0, c.width, c.height).data
  const filled = []
  let minX = Infinity
  let maxX = -Infinity
  let minY = Infinity
  let maxY = -Infinity
  for (let y = 0; y < c.height; y++) {
    for (let x = 0; x < c.width; x++) {
      if (data[(y * c.width + x) * 4 + 3] > 128) {
        filled.push(x, y)
        if (x < minX) minX = x
        if (x > maxX) maxX = x
        if (y < minY) minY = y
        if (y > maxY) maxY = y
      }
    }
  }
  if (!filled.length) return sphereShape()

  const out = new Float32Array(COUNT * 3)
  const midX = (minX + maxX) / 2
  const midY = (minY + maxY) / 2
  const maxH = text.length <= 2 ? 2 : 1.4
  const unit = Math.max((maxX - minX) / 3, (maxY - minY) / maxH)
  const n = filled.length / 2
  for (let i = 0; i < COUNT; i++) {
    const j = Math.floor(Math.random() * n) * 2
    out[i * 3] = (filled[j] + Math.random() - midX) / unit
    out[i * 3 + 1] = (filled[j + 1] + Math.random() - midY) / unit
    out[i * 3 + 2] = (Math.random() * 2 - 1) * 0.06
  }
  return out
}

function buildShape(id) {
  if (id === 'ring') return ringShape()
  if (id === 'cube') return cubeShape()
  if (id === 'heart') return heartShape()
  if (id.startsWith('text:')) return textShape(id.slice(5))
  return sphereShape()
}

const easeOutCubic = (t) => 1 - (1 - t) ** 3
const easeInOutCubic = (t) => (t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2)

const ParticleSphere = () => {
  const canvasRef = useRef(null)
  const morphRef = useRef(null)
  const [active, setActive] = useState('sphere')
  const [custom, setCustom] = useState('')

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches

    const pos = sphereShape()
    const start = new Float32Array(COUNT * 3)
    const mid = new Float32Array(COUNT * 3)
    let end = pos
    const bright = new Float32Array(COUNT)
    const delay = new Float32Array(COUNT)
    for (let i = 0; i < COUNT; i++) bright[i] = 0.35 + Math.random() * 0.65
    let morphT = -1
    let flatTarget = 0
    let flat = 0

    morphRef.current = (id) => {
      start.set(pos)
      end = buildShape(id)
      for (let i = 0; i < COUNT; i++) {
        const k = i * 3
        // burst outward from where each particle is now, plus a random kick
        const push = 1.5 + Math.random() * 0.6
        const theta = Math.random() * Math.PI * 2
        const phi = Math.acos(Math.random() * 2 - 1)
        const kick = 0.35 + Math.random() * 0.35
        mid[k] = start[k] * push + Math.sin(phi) * Math.cos(theta) * kick
        mid[k + 1] = start[k + 1] * push + Math.sin(phi) * Math.sin(theta) * kick
        mid[k + 2] = start[k + 2] * push + Math.cos(phi) * kick
        delay[i] = Math.random() * MAX_DELAY
      }
      morphT = 0
      flatTarget = isFlat(id) ? 1 : 0
    }

    let w = 0
    let h = 0
    let dpr = 1
    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      w = canvas.clientWidth * dpr
      h = canvas.clientHeight * dpr
      canvas.width = w
      canvas.height = h
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(canvas)

    // pointer gently tilts the shape
    const target = { x: 0, y: 0 }
    const tilt = { x: 0, y: 0 }

    // hover scatters nearby particles; each one springs back to its spot
    const offset = new Float32Array(COUNT * 2)
    const vel = new Float32Array(COUNT * 2)
    const mouse = { x: -1e6, y: -1e6 }
    const onMove = (e) => {
      target.x = (e.clientY / window.innerHeight - 0.5) * 0.5
      target.y = (e.clientX / window.innerWidth - 0.5) * 0.7
      const rect = canvas.getBoundingClientRect()
      mouse.x = (e.clientX - rect.left) * dpr
      mouse.y = (e.clientY - rect.top) * dpr
    }
    const onLeave = () => {
      mouse.x = -1e6
      mouse.y = -1e6
    }
    window.addEventListener('pointermove', onMove)
    document.addEventListener('pointerleave', onLeave)
    window.addEventListener('blur', onLeave)

    let angle = 0
    let last = performance.now()
    let raf = 0

    const draw = (now) => {
      const dt = Math.min((now - last) / 1000, 0.05)
      last = now
      tilt.x += (target.x - tilt.x) * 0.05
      tilt.y += (target.y - tilt.y) * 0.05
      flat += (flatTarget - flat) * 0.04

      // spin freely, or settle face-on with a gentle sway for flat shapes
      if (flatTarget) {
        const home = Math.round(angle / (Math.PI * 2)) * Math.PI * 2
        angle += (home - angle) * 0.05
      } else if (!reduceMotion) {
        angle += dt * SPEED
      }
      const sway = Math.sin(now * 0.0008) * 0.28 * flat

      // advance the morph
      if (morphT >= 0) {
        morphT += reduceMotion ? dt * 4 : dt
        if (morphT < SCATTER) {
          const e = easeOutCubic(morphT / SCATTER)
          for (let k = 0; k < COUNT * 3; k++) pos[k] = start[k] + (mid[k] - start[k]) * e
        } else if (morphT < SCATTER + FORM + MAX_DELAY) {
          for (let i = 0; i < COUNT; i++) {
            const t = Math.min(Math.max((morphT - SCATTER - delay[i]) / FORM, 0), 1)
            const e = easeInOutCubic(t)
            const k = i * 3
            pos[k] = mid[k] + (end[k] - mid[k]) * e
            pos[k + 1] = mid[k + 1] + (end[k + 1] - mid[k + 1]) * e
            pos[k + 2] = mid[k + 2] + (end[k + 2] - mid[k + 2]) * e
          }
        } else {
          pos.set(end)
          morphT = -1
        }
      }

      ctx.fillStyle = '#000'
      ctx.fillRect(0, 0, w, h)
      ctx.fillStyle = '#fff'
      // additive blend so dense areas (poles, rim, letters) glow
      ctx.globalCompositeOperation = 'lighter'

      const R = Math.min(w, h) * 0.24
      const cx = w / 2
      const cy = h / 2
      const yaw = angle + tilt.y + sway
      const pitch = BASE_TILT * (1 - flat) + tilt.x
      const cosA = Math.cos(yaw)
      const sinA = Math.sin(yaw)
      const cosT = Math.cos(pitch)
      const sinT = Math.sin(pitch)
      const fov = 3.2
      const step = dt * 60 // keep the spring feel the same at 60Hz and 120Hz
      const repelR = R * REPEL_RADIUS
      const repelR2 = repelR * repelR

      for (let i = 0; i < COUNT; i++) {
        const x = pos[i * 3]
        const y = pos[i * 3 + 1]
        const z = pos[i * 3 + 2]
        const x1 = x * cosA + z * sinA
        const z1 = -x * sinA + z * cosA
        const y2 = y * cosT - z1 * sinT
        const z2 = y * sinT + z1 * cosT
        const p = fov / Math.max(fov - z2, 0.5)
        const depth = Math.min(Math.max((z2 + 1) / 2, 0), 1) // 0 = back, 1 = front
        const homeX = cx + x1 * R * p
        const homeY = cy + y2 * R * p
        const o = i * 2
        let vx = vel[o]
        let vy = vel[o + 1]

        const dx = homeX + offset[o] - mouse.x
        const dy = homeY + offset[o + 1] - mouse.y
        const d2 = dx * dx + dy * dy
        if (d2 < repelR2 && d2 > 0.01) {
          const d = Math.sqrt(d2)
          const f = (1 - d / repelR) ** 2 * REPEL_FORCE * dpr * (0.4 + 0.6 * depth)
          vx += (dx / d) * f * step
          vy += (dy / d) * f * step
        }
        vx = (vx - offset[o] * SPRING * step) * DAMPING ** step
        vy = (vy - offset[o + 1] * SPRING * step) * DAMPING ** step
        offset[o] += vx * step
        offset[o + 1] += vy * step
        vel[o] = vx
        vel[o + 1] = vy

        const size = (1 + depth * 1.3) * dpr
        ctx.globalAlpha = bright[i] * (0.22 + 0.78 * depth)
        ctx.fillRect(homeX + offset[o] - size / 2, homeY + offset[o + 1] - size / 2, size, size)
      }
      ctx.globalAlpha = 1
      ctx.globalCompositeOperation = 'source-over'

      raf = requestAnimationFrame(draw)
    }
    raf = requestAnimationFrame(draw)

    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
      morphRef.current = null
      window.removeEventListener('pointermove', onMove)
      document.removeEventListener('pointerleave', onLeave)
      window.removeEventListener('blur', onLeave)
    }
  }, [])

  const morph = (id) => {
    setActive(id)
    morphRef.current?.(id)
  }

  const submitCustom = (e) => {
    e.preventDefault()
    const text = custom.trim().toUpperCase()
    if (text) morph(`text:${text}`)
  }

  return (
    <>
      <canvas ref={canvasRef} className="particle-sphere" aria-label="Morphing particle shape" role="img" />

      <div className="morph-dock">
        <div className="morph-shapes" role="group" aria-label="Morph into">
          {SHAPES.map((s) => (
            <button
              key={s.id}
              type="button"
              className="morph-btn"
              aria-pressed={active === s.id}
              onClick={() => morph(s.id)}
            >
              {s.label}
            </button>
          ))}
        </div>
        <form className="morph-custom" onSubmit={submitCustom}>
          <input
            className="morph-input"
            value={custom}
            onChange={(e) => setCustom(e.target.value)}
            placeholder="Type anything…"
            maxLength={10}
            aria-label="Custom text to morph into"
          />
          <button type="submit" className="morph-go" disabled={!custom.trim()}>
            Morph
          </button>
        </form>
      </div>
    </>
  )
}

export default ParticleSphere
