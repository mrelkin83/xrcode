import { useState, useEffect, useCallback } from 'react';
import Carousel from './components/Carousel';
import PlayerBar from './components/PlayerBar';
import { MOVIES } from './data/movies';
import { audioEngine } from './utils/audioEngine';
import './App.css';

function App() {
  // Default to index 2 ("Dune: Part Two"), centered with surrounding blockbusters
  const [activeIndex, setActiveIndex] = useState(2);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isVideoMode, setIsVideoMode] = useState(false);

  const currentMovie = MOVIES[activeIndex];

  // Subscribe to audio engine changes
  useEffect(() => {
    const unsubscribe = audioEngine.subscribe((state) => {
      setIsPlaying(state.isPlaying);
    });
    return unsubscribe;
  }, []);

  const handleSelectTrack = useCallback((index) => {
    setActiveIndex(index);
    if (audioEngine.isPlaying) {
      audioEngine.play(MOVIES[index]);
    }
  }, []);

  const handleTogglePlay = useCallback(() => {
    if (isPlaying) {
      audioEngine.pause();
      setIsPlaying(false);
    } else {
      audioEngine.play(currentMovie);
      setIsPlaying(true);
    }
  }, [isPlaying, currentMovie]);

  const handleToggleVideoMode = useCallback((open) => {
    setIsVideoMode(open);
    if (open) {
      // Pause ambient audio when video mode starts so trailer audio is clean
      audioEngine.pause();
      setIsPlaying(false);
    }
  }, []);

  const handlePrev = useCallback(() => {
    const nextIdx = (activeIndex - 1 + MOVIES.length) % MOVIES.length;
    handleSelectTrack(nextIdx);
  }, [activeIndex, handleSelectTrack]);

  const handleNext = useCallback(() => {
    const nextIdx = (activeIndex + 1) % MOVIES.length;
    handleSelectTrack(nextIdx);
  }, [activeIndex, handleSelectTrack]);

  return (
    <div
      className="app-viewport"
      style={{
        background: currentMovie.bgGradient,
      }}
    >
      {/* Background ambient lighting mesh */}
      <div
        className="ambient-bg-mesh"
        style={{
          background: `radial-gradient(circle at 50% 30%, ${currentMovie.glowColor} 0%, transparent 65%)`,
        }}
      />

      {/* Center 3D Coverflow Movie Carousel */}
      <main className="app-main-content">
        <Carousel
          items={MOVIES}
          activeIndex={activeIndex}
          onSelectTrack={handleSelectTrack}
          isPlaying={isPlaying}
          onTogglePlay={handleTogglePlay}
          isVideoMode={isVideoMode}
          onToggleVideoMode={handleToggleVideoMode}
        />
      </main>

      {/* Bottom Floating Frosted Glass Player Bar (Smoothly slides down when video plays) */}
      <footer className={`app-footer ${isVideoMode ? 'slide-down-hidden' : ''}`}>
        <PlayerBar
          track={currentMovie}
          isPlaying={isPlaying}
          onTogglePlay={handleTogglePlay}
          onPrev={handlePrev}
          onNext={handleNext}
        />
      </footer>
    </div>
  );
}

export default App;
