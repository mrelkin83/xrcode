import { useState, useEffect, useRef } from 'react';
import { audioEngine } from '../utils/audioEngine';
import './PlayerBar.css';

export default function PlayerBar({
  track,
  isPlaying,
  onTogglePlay,
  onPrev,
  onNext,
}) {
  const [progress, setProgress] = useState(0); // 0 to 100
  const [currentTime, setCurrentTime] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);
  const [showAirplayModal, setShowAirplayModal] = useState(false);
  const [barHeights, setBarHeights] = useState([8, 14, 18, 12, 16, 9]);

  const animFrameRef = useRef(null);
  const trackDuration = track?.durationSec || (typeof track?.duration === 'number' ? track?.duration : 180);

  // Track progress timer
  useEffect(() => {
    let interval = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= trackDuration) {
            onNext();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, trackDuration, onNext]);

  // Reset progress when track changes
  useEffect(() => {
    setCurrentTime(0);
  }, [track?.id]);

  useEffect(() => {
    setProgress((currentTime / trackDuration) * 100);
  }, [currentTime, trackDuration]);

  // Audio visualizer live waveform loop
  useEffect(() => {
    const updateVisualizer = () => {
      if (isPlaying) {
        const freq = audioEngine.getFrequencyData();
        // Sample 6 bins from frequency data
        const heights = [
          Math.max(4, (freq[1] || 40) / 255 * 22),
          Math.max(6, (freq[3] || 110) / 255 * 24),
          Math.max(8, (freq[5] || 180) / 255 * 26),
          Math.max(5, (freq[7] || 95) / 255 * 22),
          Math.max(7, (freq[9] || 140) / 255 * 25),
          Math.max(4, (freq[11] || 60) / 255 * 20),
        ];
        setBarHeights(heights);
      } else {
        setBarHeights([4, 6, 8, 5, 6, 4]);
      }
      animFrameRef.current = requestAnimationFrame(updateVisualizer);
    };

    animFrameRef.current = requestAnimationFrame(updateVisualizer);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isPlaying]);

  const handleVolumeChange = (e) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    audioEngine.setVolume(val);
    if (val > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  const handleToggleMute = () => {
    const muted = audioEngine.toggleMute();
    setIsMuted(muted);
  };

  const formatTime = (secs) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="player-bar-container">
      <div className="player-pill">
        {/* Left: Previous / Play-Pause / Next */}
        <div className="player-controls-left">
          <button
            className="player-btn prev-btn"
            onClick={onPrev}
            title="Previous track"
            aria-label="Previous track"
          >
            <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
              <path d="M6 6h2v12H6zm3.5 6l8.5 6V6z" />
            </svg>
          </button>

          <button
            className={`player-btn play-pause-btn ${isPlaying ? 'playing' : ''}`}
            onClick={onTogglePlay}
            title={isPlaying ? 'Pause' : 'Play'}
            aria-label={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
                <path d="M6 5h4v14H6zm8 0h4v14h-4z" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
                <path d="M8 5v14l11-7z" />
              </svg>
            )}
          </button>

          <button
            className="player-btn next-btn"
            onClick={onNext}
            title="Next track"
            aria-label="Next track"
          >
            <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
              <path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z" />
            </svg>
          </button>
        </div>

        {/* Center: Mini Track Info + Waveform + Progress Bar */}
        <div className="player-center-capsule">
          <div className="mini-album-thumb">
            <img src={track.cover} alt={track.title} draggable="false" />
          </div>

          <div className="mini-track-info">
            <div className="mini-title-row">
              <span className="mini-title">{track.title}</span>
              <span className="mini-artist">{track.genre || track.duration || track.album}</span>
            </div>

            <div className="mini-progress-track">
              <div
                className="mini-progress-fill"
                style={{
                  width: `${progress}%`,
                  background: track.accentColor || '#a855f7',
                }}
              />
            </div>
          </div>

          {/* Sound wave visualizer bars */}
          <div className="mini-visualizer" title={isPlaying ? 'Live Audio Frequency' : 'Idle'}>
            {barHeights.map((h, i) => (
              <span
                key={i}
                className={`wave-bar ${isPlaying ? 'active' : ''}`}
                style={{
                  height: `${h}px`,
                  backgroundColor: track.accentColor || '#c084fc',
                }}
              />
            ))}
          </div>
        </div>

        {/* Right: Airplay / Shuffle-Repeat / Volume */}
        <div className="player-controls-right">
          {/* Airplay / Output button */}
          <div className="popover-wrapper">
            <button
              className={`player-btn utility-btn ${showAirplayModal ? 'active' : ''}`}
              onClick={() => setShowAirplayModal(!showAirplayModal)}
              title="Audio Output Device"
              aria-label="Audio Output"
            >
              <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
                <path d="M12 3C6.5 3 2 6.5 2 12c0 2.5 1 4.8 2.8 6.5l1.4-1.4C4.8 15.6 4 13.9 4 12c0-4.4 3.6-8 8-8s8 3.6 8 8c0 1.9-.8 3.6-2.2 5.1l1.4 1.4C21 16.8 22 14.5 22 12c0-5.5-4.5-9-10-9zm0 4c-2.8 0-5 2.2-5 5 0 1.4.6 2.6 1.5 3.5l1.4-1.4c-.6-.5-.9-1.3-.9-2.1 0-1.7 1.3-3 3-3s3 1.3 3 3c0 .8-.3 1.6-.9 2.1l1.4 1.4c.9-.9 1.5-2.1 1.5-3.5 0-2.8-2.2-5-5-5zm0 8l-4 5h8l-4-5z" />
              </svg>
            </button>

            {showAirplayModal && (
              <div className="glass-popover airplay-popover">
                <div className="popover-header">Connected Devices</div>
                <div className="popover-item active">
                  <span className="dot" />
                  <span>MacBook Pro Speakers</span>
                  <span className="badge">Active</span>
                </div>
                <div className="popover-item">
                  <span className="dot inactive" />
                  <span>Studio Monitors (AirPlay)</span>
                </div>
                <div className="popover-item">
                  <span className="dot inactive" />
                  <span>AirPods Max</span>
                </div>
              </div>
            )}
          </div>

          {/* Shuffle / Repeat toggle */}
          <button
            className={`player-btn utility-btn ${isShuffle ? 'active' : ''}`}
            onClick={() => setIsShuffle(!isShuffle)}
            title={isShuffle ? 'Shuffle: On' : 'Shuffle: Off'}
            aria-label="Shuffle"
          >
            <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
              <path d="M10.59 9.17L5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41l-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z" />
            </svg>
          </button>

          {/* Volume Button & Slider */}
          <div
            className="popover-wrapper"
            onMouseEnter={() => setShowVolumeSlider(true)}
            onMouseLeave={() => setShowVolumeSlider(false)}
          >
            <button
              className={`player-btn utility-btn ${isMuted ? 'muted' : ''}`}
              onClick={handleToggleMute}
              title={isMuted ? 'Unmute' : 'Mute'}
              aria-label="Volume"
            >
              {isMuted || volume === 0 ? (
                <svg viewBox="0 0 24 24" width="21" height="21" fill="currentColor">
                  <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" width="21" height="21" fill="currentColor">
                  <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" />
                </svg>
              )}
            </button>

            {showVolumeSlider && (
              <div className="glass-popover volume-popover">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="volume-slider"
                  aria-label="Volume Slider"
                />
                <span className="volume-label">
                  {isMuted ? 'Muted' : `${Math.round(volume * 100)}%`}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
