import { useState, useRef, useEffect, useCallback } from 'react';
import './Carousel.css';

export default function Carousel({
  items,
  movies,
  tracks,
  activeIndex,
  onSelectTrack,
  isPlaying,
  onTogglePlay,
  isVideoMode,
  onToggleVideoMode,
}) {
  const dataList = items || movies || tracks || [];
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [tilt, setTilt] = useState({ x: 3, y: -4 });

  // Animation Phase for choreographed sequencing:
  // 'idle' -> 'retracting' (side cards tuck behind) -> 'active' (center card advances forward with 3D tilt & video)
  // 'active' -> 'returning' (center card steps back) -> 'idle' (side cards fan back out)
  const [animPhase, setAnimPhase] = useState('idle');

  const [isTiltTracking, setIsTiltTracking] = useState(false);
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50 });

  const startXRef = useRef(0);
  const currentDragRef = useRef(0);
  const containerRef = useRef(null);
  const phaseTimerRef = useRef(null);
  const tiltTimerRef = useRef(null);

  const totalTracks = dataList.length;
  const activeMovie = dataList[activeIndex];

  const goToTrack = useCallback(
    (newIndex) => {
      if (newIndex >= 0 && newIndex < totalTracks) {
        onSelectTrack(newIndex);
      }
    },
    [onSelectTrack, totalTracks]
  );

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (phaseTimerRef.current) clearTimeout(phaseTimerRef.current);
    };
  }, []);

  // Choreographed open sequence
  const startVideoMode = useCallback(() => {
    if (animPhase !== 'idle') return;
    if (phaseTimerRef.current) clearTimeout(phaseTimerRef.current);
    if (tiltTimerRef.current) clearTimeout(tiltTimerRef.current);

    // STEP 1: Notify parent (bottom bar slides down) & side cards retract behind center card
    setAnimPhase('retracting');
    setIsTiltTracking(false);
    onToggleVideoMode(true);

    // STEP 2: After side cards have tucked behind (~420ms), the center card advances forward & tilts!
    phaseTimerRef.current = setTimeout(() => {
      setAnimPhase('active');
      // After forward surge animation finishes (~460ms), engage instant cursor tracking
      tiltTimerRef.current = setTimeout(() => {
        setIsTiltTracking(true);
      }, 460);
    }, 420);
  }, [animPhase, onToggleVideoMode]);

  // Choreographed close sequence
  const closeVideoMode = useCallback(() => {
    if (animPhase === 'idle' || animPhase === 'returning') return;
    if (phaseTimerRef.current) clearTimeout(phaseTimerRef.current);
    if (tiltTimerRef.current) clearTimeout(tiltTimerRef.current);

    // STEP 1: Center card steps back to standard position
    setIsTiltTracking(false);
    setTilt({ x: 0, y: 0 });
    setGlarePos({ x: 50, y: 50 });
    setAnimPhase('returning');

    // STEP 2: After center card steps back (~380ms), side cards fan back out & bottom bar rises
    phaseTimerRef.current = setTimeout(() => {
      setAnimPhase('idle');
      onToggleVideoMode(false);
    }, 380);
  }, [animPhase, onToggleVideoMode]);

  // Sync with external isVideoMode prop if needed
  useEffect(() => {
    if (isVideoMode && animPhase === 'idle') {
      startVideoMode();
    } else if (!isVideoMode && animPhase === 'active') {
      closeVideoMode();
    }
  }, [isVideoMode, animPhase, startVideoMode, closeVideoMode]);

  // Keyboard navigation & Escape key handling
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        if (animPhase === 'active' || animPhase === 'retracting') {
          closeVideoMode();
        }
        return;
      }
      if (animPhase === 'idle') {
        if (e.key === 'ArrowLeft') {
          goToTrack(Math.max(0, activeIndex - 1));
        } else if (e.key === 'ArrowRight') {
          goToTrack(Math.min(totalTracks - 1, activeIndex + 1));
        } else if (e.key === 'Enter') {
          startVideoMode();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex, animPhase, closeVideoMode, goToTrack, startVideoMode, totalTracks]);

  // Window-wide pointer tracking for ultra-smooth, direct 3D cursor tilt when video mode is active
  useEffect(() => {
    if (animPhase !== 'active') {
      setIsTiltTracking(false);
      setTilt({ x: 0, y: 0 });
      return;
    }

    const handlePointerMove = (e) => {
      const { clientX, clientY } = e;
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;

      // Calculate normalized cursor offset from screen center (-1 to 1)
      const normX = (clientX - centerX) / (centerX || 1);
      const normY = (clientY - centerY) / (centerY || 1);

      const clampedX = Math.max(-1, Math.min(1, normX));
      const clampedY = Math.max(-1, Math.min(1, normY));

      // Natural 3D tilt: pointing directly towards the cursor
      const tiltX = -clampedY * 13; // -13deg to +13deg
      const tiltY = clampedX * 16;  // -16deg to +16deg

      setTilt({
        x: Math.round(tiltX * 10) / 10,
        y: Math.round(tiltY * 10) / 10,
      });

      // Specular light glare position
      const gx = Math.round(((clampedX + 1) / 2) * 100);
      const gy = Math.round(((clampedY + 1) / 2) * 100);
      setGlarePos({ x: gx, y: gy });
    };

    const handlePointerLeave = () => {
      setTilt({ x: 0, y: 0 });
      setGlarePos({ x: 50, y: 50 });
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    document.addEventListener('mouseleave', handlePointerLeave);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      document.removeEventListener('mouseleave', handlePointerLeave);
      if (tiltTimerRef.current) clearTimeout(tiltTimerRef.current);
    };
  }, [animPhase]);

  // Pointer drag/swipe events (only when idle in carousel mode)
  const handlePointerDown = (e) => {
    if (animPhase !== 'idle') return;
    if (e.button !== undefined && e.button !== 0) return;
    setIsDragging(true);
    startXRef.current = e.clientX || (e.touches && e.touches[0].clientX) || 0;
    currentDragRef.current = 0;
  };

  const handlePointerMove = (e) => {
    if (!isDragging || animPhase !== 'idle') return;
    const clientX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
    const delta = clientX - startXRef.current;
    currentDragRef.current = delta;
    setDragOffset(delta);
  };

  const handlePointerUp = () => {
    if (!isDragging || animPhase !== 'idle') return;
    setIsDragging(false);
    const delta = currentDragRef.current;
    const threshold = 50;

    if (delta < -threshold && activeIndex < totalTracks - 1) {
      goToTrack(activeIndex + 1);
    } else if (delta > threshold && activeIndex > 0) {
      goToTrack(activeIndex - 1);
    }
    setDragOffset(0);
    currentDragRef.current = 0;
  };

  const handleCardClick = (index) => {
    if (Math.abs(currentDragRef.current) > 6) return;

    if (index === activeIndex) {
      if (animPhase === 'idle') {
        startVideoMode();
      }
    } else if (animPhase === 'idle') {
      goToTrack(index);
    }
  };

  const isCardsRetracted = animPhase === 'retracting' || animPhase === 'active' || animPhase === 'returning';
  const isCardForward = animPhase === 'active';

  return (
    <div
      className={`coverflow-container ${animPhase !== 'idle' ? 'video-mode-active' : ''}`}
      ref={containerRef}
      onMouseDown={handlePointerDown}
      onMouseMove={(e) => {
        handlePointerMove(e);
        handleMouseMoveContainer(e);
      }}
      onMouseUp={handlePointerUp}
      onMouseLeave={() => {
        handlePointerUp();
        handleMouseLeaveContainer();
      }}
      onTouchStart={handlePointerDown}
      onTouchMove={handlePointerMove}
      onTouchEnd={handlePointerUp}
    >
      {/* Dynamic ambient backlight */}
      <div
        className="coverflow-ambient-glow"
        style={{
          background: activeMovie?.glowColor || 'rgba(168, 85, 247, 0.4)',
          transform: isCardForward
            ? 'translate(-50%, -50%) scale(1.65)'
            : 'translate(-50%, -50%) scale(1)',
          opacity: isCardForward ? 0.8 : 0.55,
        }}
      />

      <div className="coverflow-stage">
        {dataList.map((movie, index) => {
          const offset = index - activeIndex;
          const isCenter = offset === 0;

          let transform = '';
          let zIndex = 10 - Math.abs(offset) * 2;
          let opacity = 1;
          let filter = 'none';

          if (isCardsRetracted) {
            if (isCenter) {
              if (isCardForward) {
                // STEP 2: Active card surges forward towards camera and tilts in 3D!
                const rotX = tilt.x || 3;
                const rotY = tilt.y || -4;
                transform = `translateX(0px) translateZ(160px) rotateX(${rotX}deg) rotateY(${rotY}deg) scale(1.18)`;
                zIndex = 50;
                opacity = 1;
                filter = 'brightness(1.08) drop-shadow(0 40px 80px rgba(0,0,0,0.85))';
              } else {
                // STEP 1: Center card stays in place while side cards visibly slide behind it!
                transform = `translateX(0px) translateZ(0px) rotateX(0deg) rotateY(0deg) scale(1)`;
                zIndex = 30;
                opacity = 1;
                filter = 'brightness(1.05) drop-shadow(0 25px 45px rgba(0,0,0,0.55))';
              }
            } else {
              // ALL other cards visibly slide in BEHIND the center card in 3D!
              const sign = offset > 0 ? 1 : -1;
              const absOffset = Math.abs(offset);

              if (isCardForward) {
                // When center card is forward, background cards rest in a neat 3D stack behind it
                if (absOffset === 1) {
                  const xOffset = sign * 14;
                  const rotY = sign * -8;
                  transform = `translateX(${xOffset}px) translateZ(-160px) rotateY(${rotY}deg) scale(0.88)`;
                  zIndex = 15;
                  opacity = 0.55;
                  filter = 'brightness(0.35) blur(2px)';
                } else {
                  const xOffset = sign * 26;
                  const rotY = sign * -14;
                  transform = `translateX(${xOffset}px) translateZ(-250px) rotateY(${rotY}deg) scale(0.80)`;
                  zIndex = 10;
                  opacity = 0.35;
                  filter = 'brightness(0.25) blur(3.5px)';
                }
              } else {
                // In retracting phase, cards visibly fly behind the center card!
                if (absOffset === 1) {
                  const xOffset = sign * 18;
                  const rotY = sign * -12;
                  transform = `translateX(${xOffset}px) translateZ(-110px) rotateY(${rotY}deg) scale(0.92)`;
                  zIndex = 18;
                  opacity = 0.88;
                  filter = 'brightness(0.65) blur(0.8px)';
                } else {
                  const xOffset = sign * 32;
                  const rotY = sign * -18;
                  transform = `translateX(${xOffset}px) translateZ(-190px) rotateY(${rotY}deg) scale(0.85)`;
                  zIndex = 12;
                  opacity = 0.72;
                  filter = 'brightness(0.48) blur(1.8px)';
                }
              }
            }
          } else {
            // Standard 3D CoverFlow perspective
            const dragInfluence = isDragging ? dragOffset / 320 : 0;
            const virtualOffset = offset - dragInfluence;

            if (isCenter) {
              const rotY = -virtualOffset * 25;
              const transX = virtualOffset * 80;
              const scale = Math.max(0.88, 1 - Math.abs(virtualOffset) * 0.15);
              transform = `translateX(${transX}px) translateZ(0px) rotateY(${rotY}deg) scale(${scale})`;
              opacity = 1;
              filter = 'brightness(1.05) drop-shadow(0 25px 45px rgba(0,0,0,0.55))';
            } else {
              const sign = offset > 0 ? 1 : -1;
              const absOffset = Math.abs(offset);

              if (absOffset === 1) {
                const xPercent = sign * 68;
                const rotY = sign * -36;
                transform = `translateX(${xPercent}%) translateZ(-95px) rotateY(${rotY}deg) scale(0.86)`;
                opacity = 0.88;
                filter = 'brightness(0.85) drop-shadow(0 15px 30px rgba(0,0,0,0.45))';
              } else if (absOffset === 2) {
                const xPercent = sign * 118;
                const rotY = sign * -42;
                transform = `translateX(${xPercent}%) translateZ(-190px) rotateY(${rotY}deg) scale(0.72)`;
                opacity = 0.55;
                filter = 'brightness(0.68) drop-shadow(0 10px 20px rgba(0,0,0,0.4))';
              } else {
                const xPercent = sign * 155;
                const rotY = sign * -48;
                transform = `translateX(${xPercent}%) translateZ(-290px) rotateY(${rotY}deg) scale(0.58)`;
                opacity = 0;
              }
            }
          }

          return (
            <div
              key={movie.id}
              className={`coverflow-card ${isCenter ? 'is-active' : ''} ${isCenter && isCardForward ? 'is-video-playing' : ''
                } ${isCenter && isCardForward && isTiltTracking ? 'is-tilt-tracking' : ''} ${isDragging ? 'is-dragging' : ''
                }`}
              style={{
                transform,
                zIndex,
                opacity,
                filter,
                '--glare-x': `${glarePos.x}%`,
                '--glare-y': `${glarePos.y}%`,
              }}
              onClick={() => handleCardClick(index)}
            >
              <div className="card-glass-panel">
                {/* Specular 3D light glare sheen */}
                <div className="card-3d-glare" />
                {/* VIDEO PLAYER MODE (When active card is forward) */}
                {isCenter && isCardForward ? (
                  <div className="card-video-container">
                    <div className="video-header-bar">
                      <div className="video-badge-group">
                        <span className="live-rec-dot" />
                        <span className="video-badge">TRAILER • 4K HDR</span>
                      </div>
                      <button
                        className="video-close-btn"
                        onClick={(e) => {
                          e.stopPropagation();
                          closeVideoMode();
                        }}
                        title="Back to Carousel (Esc)"
                        aria-label="Close Trailer"
                      >
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
                          <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" />
                        </svg>
                        <span>Close</span>
                      </button>
                    </div>

                    {/* Active Trailer Video */}
                    <div className="video-player-frame">
                      {movie.trailerId ? (
                        <iframe
                          src={`https://www.youtube-nocookie.com/embed/${movie.trailerId}?autoplay=1&mute=0&controls=1&modestbranding=1&rel=0`}
                          title={`${movie.title} Trailer`}
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                          allowFullScreen
                          className="trailer-iframe"
                        />
                      ) : (
                        <video
                          src={movie.trailerVideo}
                          autoPlay
                          controls
                          playsInline
                          className="trailer-video"
                        />
                      )}
                    </div>

                    <div className="video-footer-meta">
                      <div className="video-title-row">
                        <h3 className="video-title">{movie.title}</h3>
                        <span className="video-rating-badge">{movie.subtitle}</span>
                      </div>
                      <p className="video-director">Directed by {movie.director}</p>
                    </div>
                  </div>
                ) : (
                  /* STANDARD POSTER COVER (Normal carousel card) */
                  <>
                    <div className="card-artwork-wrapper">
                      <img
                        src={movie.cover}
                        alt={`${movie.title}`}
                        className="card-artwork"
                        draggable="false"
                      />
                      {isCenter && (
                        <button
                          className="card-play-overlay"
                          onClick={(e) => {
                            e.stopPropagation();
                            startVideoMode();
                          }}
                          aria-label="Play Trailer"
                        >
                          <svg viewBox="0 0 24 24" width="28" height="28" fill="currentColor">
                            <path d="M8 5v14l11-7z" />
                          </svg>
                        </button>
                      )}

                      {/* Watch Trailer button pill */}
                      {isCenter && (
                        <div
                          className="card-hint-badge"
                          onClick={(e) => {
                            e.stopPropagation();
                            startVideoMode();
                          }}
                        >
                          <span>▶ Watch Trailer</span>
                        </div>
                      )}
                    </div>

                    <div className="card-meta">
                      <h3 className="card-title">{movie.title}</h3>
                      <p className="card-subtitle">{movie.subtitle || movie.genre}</p>
                    </div>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
