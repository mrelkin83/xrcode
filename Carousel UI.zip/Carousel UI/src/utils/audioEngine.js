// Web Audio API Synth Engine for realistic melodic ambient previews
class AudioEngine {
  constructor() {
    this.ctx = null;
    this.analyser = null;
    this.masterGain = null;
    this.isPlaying = false;
    this.timerId = null;
    this.currentTrack = null;
    this.volume = 0.75;
    this.isMuted = false;
    this.listeners = new Set();
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 64;
      this.analyser.smoothingTimeConstant = 0.8;

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);

      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  play(track) {
    this.init();
    if (!this.ctx) return;

    this.currentTrack = track;
    this.isPlaying = true;
    this.notifyState();

    this.stopSequence();
    this.startSequence(track);
  }

  pause() {
    this.isPlaying = false;
    this.stopSequence();
    this.notifyState();
  }

  togglePlay(track) {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play(track);
    }
  }

  setVolume(val) {
    this.volume = Math.max(0, Math.min(1, val));
    if (this.masterGain && this.ctx && !this.isMuted) {
      this.masterGain.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.05);
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      const target = this.isMuted ? 0 : this.volume;
      this.masterGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.05);
    }
    return this.isMuted;
  }

  startSequence(track) {
    if (!this.ctx || !track) return;

    const notes = track.notes || [261.63, 329.63, 392.00, 523.25];
    const beatInterval = (60 / (track.tempo || 90)) * 1000;
    let step = 0;

    const playNote = () => {
      if (!this.isPlaying || !this.ctx) return;

      const freq = notes[step % notes.length];
      const now = this.ctx.currentTime;

      // Soft dual oscillator for warm lush analog timbre
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const noteGain = this.ctx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(freq, now);

      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(freq * 1.002, now); // subtle chorus detune

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1200, now);
      filter.frequency.exponentialRampToValueAtTime(450, now + 1.2);

      noteGain.gain.setValueAtTime(0.001, now);
      noteGain.gain.exponentialRampToValueAtTime(0.28, now + 0.08); // attack
      noteGain.gain.exponentialRampToValueAtTime(0.001, now + 1.4); // decay

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(noteGain);
      noteGain.connect(this.masterGain);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 1.5);
      osc2.stop(now + 1.5);

      // Play soft bass sub note every 4 steps
      if (step % 4 === 0) {
        const bassOsc = this.ctx.createOscillator();
        const bassGain = this.ctx.createGain();
        bassOsc.type = 'sine';
        bassOsc.frequency.setValueAtTime(freq / 2, now);

        bassGain.gain.setValueAtTime(0.001, now);
        bassGain.gain.linearRampToValueAtTime(0.35, now + 0.05);
        bassGain.gain.exponentialRampToValueAtTime(0.001, now + 1.8);

        bassOsc.connect(bassGain);
        bassGain.connect(this.masterGain);

        bassOsc.start(now);
        bassOsc.stop(now + 1.9);
      }

      step++;
      this.timerId = setTimeout(playNote, beatInterval / 2);
    };

    playNote();
  }

  stopSequence() {
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
  }

  getFrequencyData() {
    if (!this.analyser) return new Uint8Array(8);
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(data);
    return data;
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notifyState() {
    this.listeners.forEach((fn) => fn({ isPlaying: this.isPlaying, currentTrack: this.currentTrack }));
  }
}

export const audioEngine = new AudioEngine();
