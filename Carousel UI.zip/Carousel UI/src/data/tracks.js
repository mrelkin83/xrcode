export const TRACKS = [
  {
    id: 1,
    artist: "Anggi Marito",
    title: "Tak Segampang Itu",
    album: "Tak Segampang Itu",
    cover: "/covers/anggi.jpg",
    accentColor: "#f59e0b",
    glowColor: "rgba(245, 158, 11, 0.35)",
    bgGradient: "radial-gradient(circle at 50% 25%, #422818 0%, #291823 45%, #150e20 85%, #0a0614 100%)",
    duration: 232, // 3:52
    notes: [329.63, 392.00, 440.00, 493.88], // E4, G4, A4, B4
    tempo: 78
  },
  {
    id: 2,
    artist: "Mahalini",
    title: "Bawa Dia Kembali",
    album: "Fabula",
    cover: "/covers/fabula.jpg",
    accentColor: "#f43f5e",
    glowColor: "rgba(244, 63, 94, 0.35)",
    bgGradient: "radial-gradient(circle at 50% 25%, #4c1d2d 0%, #301732 45%, #170f26 85%, #0c0817 100%)",
    duration: 218, // 3:38
    notes: [261.63, 311.13, 392.00, 466.16], // C4, Eb4, G4, Bb4
    tempo: 84
  },
  {
    id: 3,
    artist: "Gery & Gany",
    title: "Gery & Gany",
    album: "Rusuk",
    cover: "/covers/rusuk.jpg",
    accentColor: "#a855f7",
    glowColor: "rgba(168, 85, 247, 0.45)",
    bgGradient: "radial-gradient(circle at 50% 25%, #43296a 0%, #2e1e4f 45%, #18112e 85%, #0d081b 100%)",
    duration: 204, // 3:24
    notes: [293.66, 349.23, 440.00, 523.25], // D4, F4, A4, C5 (Groovy Dm9 vibe)
    tempo: 96
  },
  {
    id: 4,
    artist: "Tulus",
    title: "Tulus",
    album: "Monokrom",
    cover: "/covers/monokrom.jpg",
    accentColor: "#94a3b8",
    glowColor: "rgba(148, 163, 184, 0.35)",
    bgGradient: "radial-gradient(circle at 50% 25%, #33394a 0%, #222338 45%, #141324 85%, #0b0914 100%)",
    duration: 214, // 3:34
    notes: [261.63, 329.63, 392.00, 493.88], // Cmaj7 (C4, E4, G4, B4)
    tempo: 75
  },
  {
    id: 5,
    artist: "Yovie & Nuno",
    title: "Menjaga Hati",
    album: "The Miracle",
    cover: "/covers/menjaga_hati.jpg",
    accentColor: "#06b6d4",
    glowColor: "rgba(6, 182, 212, 0.35)",
    bgGradient: "radial-gradient(circle at 50% 25%, #163e4e 0%, #1e2544 45%, #121327 85%, #0a0917 100%)",
    duration: 198, // 3:18
    notes: [349.23, 440.00, 523.25, 659.25], // Fmaj7
    tempo: 102
  }
];
