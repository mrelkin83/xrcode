import React, { useState } from 'react';
import Form1 from './form1';
import Form2 from './form2';

const App = () => {
  const [activeForm, setActiveForm] = useState(2);

  return (
    <div className="app-container" style={{ position: 'relative' }}>
      {/* Floating Modern Component Switcher Bar */}
      <div 
        style={{
          position: 'fixed',
          top: '16px',
          right: '20px',
          zIndex: 9999,
          display: 'flex',
          gap: '8px',
          background: 'rgba(15, 10, 30, 0.65)',
          backdropFilter: 'blur(16px)',
          WebkitBackdropFilter: 'blur(16px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          borderRadius: '9999px',
          padding: '4px 6px',
          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.4)'
        }}
      >
        <button
          type="button"
          onClick={() => setActiveForm(1)}
          style={{
            background: activeForm === 1 ? 'linear-gradient(135deg, #ec4899, #06b6d4)' : 'transparent',
            color: '#ffffff',
            border: 'none',
            borderRadius: '9999px',
            padding: '6px 14px',
            fontSize: '12px',
            fontWeight: '700',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            opacity: activeForm === 1 ? 1 : 0.7
          }}
        >
          Form 1
        </button>
        <button
          type="button"
          onClick={() => setActiveForm(2)}
          style={{
            background: activeForm === 2 ? 'linear-gradient(135deg, #9333ea, #c084fc)' : 'transparent',
            color: '#ffffff',
            border: 'none',
            borderRadius: '9999px',
            padding: '6px 14px',
            fontSize: '12px',
            fontWeight: '700',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            opacity: activeForm === 2 ? 1 : 0.7
          }}
        >
          Form 2
        </button>
      </div>

      {activeForm === 1 ? <Form1 /> : <Form2 />}
    </div>
  );
};

export default App;