import React, { useState } from 'react';
import { motion, AnimatePresence, LayoutGroup } from 'framer-motion';
import './App.css';

function App() {
  const [isLogin, setIsLogin] = useState(true);
  const [isAnimating, setIsAnimating] = useState(false);

  const toggleMode = (mode) => {
    if (isAnimating) return;
    setIsAnimating(true);
    setIsLogin(mode === 'login');
    setTimeout(() => setIsAnimating(false), 1200);
  };

  // Login Exit: reduced translation distance to prevent clipping
  const loginFormVariants = {
    hidden: {},
    visible: { transition: { staggerChildren: 0.05 } },
    exit: { transition: { staggerChildren: 0.05, staggerDirection: 1 } }
  };

  const loginItemVariants = {
    hidden: { x: -40, opacity: 0, scale: 0.98 },
    visible: { x: 0, opacity: 1, scale: 1, transition: { duration: 0.45 } },
    exit: { x: -40, opacity: 0, scale: 0.98, transition: { duration: 0.45 } }
  };

  // Signup Entry: reduced translation distance to prevent right-side clipping
  const signupFormVariants = {
    hidden: {},
    visible: { transition: { staggerChildren: 0.05 } },
    exit: { transition: { staggerChildren: 0.05, staggerDirection: -1 } }
  };

  const signupItemVariants = {
    hidden: { x: 40, opacity: 0, filter: 'blur(8px)' },
    visible: { x: 0, opacity: 1, filter: 'blur(0px)', transition: { duration: 0.5 } },
    exit: { x: 40, opacity: 0, filter: 'blur(8px)', transition: { duration: 0.45 } }
  };

  // Welcome Text Variants
  const welcomeLoginVariants = {
    hidden: { opacity: 0, x: -30, y: -30 },
    visible: { opacity: 1, x: 0, y: 0, transition: { duration: 0.6, delay: 0.2 } },
    exit: { opacity: 0, x: 30, y: 30, transition: { duration: 0.4 } }
  };

  const welcomeSignupVariants = {
    hidden: { opacity: 0, x: 30, y: 30 },
    visible: { opacity: 1, x: 0, y: 0, transition: { duration: 0.6, delay: 0.2 } },
    exit: { opacity: 0, x: -30, y: -30, transition: { duration: 0.4 } }
  };

  // Diagonal Panel Sweeping Variant
  const panelVariants = {
    login: { x: "25%", skewX: 20 },
    signup: { x: "-85%", skewX: 20 }
  };

  return (
    <div className="login-container">

      {/* Background Sweeping Diagonal Panel */}
      <motion.div
        className="bg-shape-motion"
        variants={panelVariants}
        initial={false}
        animate={isLogin ? "login" : "signup"}
        transition={{ duration: 0.9, ease: "easeInOut" }}
      />

      <LayoutGroup>
        <div className="content-wrapper">

          <AnimatePresence mode="wait">
            {isLogin ? (
              <motion.div
                key="login-panel"
                className="form-container login-panel"
                variants={loginFormVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
              >
                <form onSubmit={(e) => e.preventDefault()} autoComplete="off">
                  <motion.h2 variants={loginItemVariants}>Login</motion.h2>

                  <motion.div className="input-group" variants={loginItemVariants}>
                    <input type="text" id="login-username" required placeholder=" " autoComplete="off" />
                    <label htmlFor="login-username">Username</label>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                      <path fillRule="evenodd" d="M7.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM3.751 20.105a8.25 8.25 0 0116.498 0 .75.75 0 01-.437.695A18.683 18.683 0 0112 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 01-.437-.695z" clipRule="evenodd" />
                    </svg>
                  </motion.div>

                  <motion.div className="input-group" variants={loginItemVariants}>
                    <input type="password" id="login-password" required placeholder=" " autoComplete="new-password" />
                    <label htmlFor="login-password">Password</label>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                      <path fillRule="evenodd" d="M12 1.5a5.25 5.25 0 00-5.25 5.25v3a3 3 0 00-3 3v6.75a3 3 0 003 3h10.5a3 3 0 003-3v-6.75a3 3 0 00-3-3v-3c0-2.9-2.35-5.25-5.25-5.25zm3.75 8.25v-3a3.75 3.75 0 10-7.5 0v3h7.5z" clipRule="evenodd" />
                    </svg>
                  </motion.div>

                  <motion.div variants={loginItemVariants} style={{ width: '100%' }}>
                    <button
                      type="submit"
                      className="btn-signup"
                      disabled={isAnimating}
                    >
                      Login
                    </button>
                  </motion.div>

                  <motion.p className="bottom-text" variants={loginItemVariants}>
                    Dont have an account? <button type="button" className="link-btn" onClick={() => toggleMode('signup')} disabled={isAnimating}>Sign Up</button>
                  </motion.p>

                </form>
              </motion.div>
            ) : (
              <motion.div
                key="signup-panel"
                className="form-container signup-panel"
                variants={signupFormVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
              >
                <form onSubmit={(e) => e.preventDefault()}>
                  <motion.h2 variants={signupItemVariants}>Sign Up</motion.h2>

                  <motion.div className="input-group" variants={signupItemVariants}>
                    <input type="text" id="signup-username" required placeholder=" " autoComplete="off" />
                    <label htmlFor="signup-username">Username</label>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                      <path fillRule="evenodd" d="M7.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM3.751 20.105a8.25 8.25 0 0116.498 0 .75.75 0 01-.437.695A18.683 18.683 0 0112 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 01-.437-.695z" clipRule="evenodd" />
                    </svg>
                  </motion.div>

                  <motion.div className="input-group" variants={signupItemVariants}>
                    <input type="email" id="signup-email" required placeholder=" " autoComplete="off" />
                    <label htmlFor="signup-email">Email</label>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M1.5 8.67v8.58a3 3 0 003 3h15a3 3 0 003-3V8.67l-8.928 5.493a3 3 0 01-3.144 0L1.5 8.67z" />
                      <path d="M22.5 6.908V6.75a3 3 0 00-3-3h-15a3 3 0 00-3 3v.158l9.714 5.978a1.5 1.5 0 001.572 0L22.5 6.908z" />
                    </svg>
                  </motion.div>

                  <motion.div className="input-group" variants={signupItemVariants}>
                    <input type="password" id="signup-password" required placeholder=" " autoComplete="new-password" />
                    <label htmlFor="signup-password">Password</label>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                      <path fillRule="evenodd" d="M12 1.5a5.25 5.25 0 00-5.25 5.25v3a3 3 0 00-3 3v6.75a3 3 0 003 3h10.5a3 3 0 003-3v-6.75a3 3 0 00-3-3v-3c0-2.9-2.35-5.25-5.25-5.25zm3.75 8.25v-3a3.75 3.75 0 10-7.5 0v3h7.5z" clipRule="evenodd" />
                    </svg>
                  </motion.div>

                  <motion.div variants={signupItemVariants} style={{ width: '100%' }}>
                    <button
                      type="submit"
                      className="btn-signup"
                      disabled={isAnimating}
                    >
                      Sign Up
                    </button>
                  </motion.div>

                  <motion.p className="bottom-text" variants={signupItemVariants}>
                    Alread have an account? <button type="button" className="link-btn" onClick={() => toggleMode('login')} disabled={isAnimating}>Login</button>
                  </motion.p>

                </form>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Welcome Text & Action Buttons */}
          <AnimatePresence mode="wait">
            {isLogin ? (
              <motion.div
                key="welcome-login"
                className="welcome-container welcome-login"
                variants={welcomeLoginVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
              >
                <h1>HELLO,<br />FRIEND!</h1>
                <p>Enter your personal details<br />and start your journey<br />with us.</p>
              </motion.div>
            ) : (
              <motion.div
                key="welcome-signup"
                className="welcome-container welcome-signup"
                variants={welcomeSignupVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
              >
                <h1>WELCOME<br />BACK!</h1>
                <p>Lorem ipsum, dolor sit<br />amet consectetur<br />adipisicing.</p>
              </motion.div>
            )}
          </AnimatePresence>

        </div>
      </LayoutGroup>
    </div>
  );
}

export default App;
