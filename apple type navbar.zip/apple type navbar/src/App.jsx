import { useState, useEffect } from 'react';
import Nav from './Nav';

function App() {
  const [theme, setTheme] = useState('dark');

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  return (
    <Nav theme={theme} toggleTheme={toggleTheme} heroComplete={true} />
  );
}

export default App;
